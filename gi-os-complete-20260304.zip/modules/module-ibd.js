/* META
 * @title      IBD OS — Clinical Tracker
 * @accent     #4fa8d5
 * @accent2    #7ecba1
 * @accentGlow rgba(79,168,213,.12)
 */

/**
 * IBD OS — Module
 * ═══════════════════════════════════════════════════════════
 * Only IBD-specific code lives here.
 * All storage, charts, library rendering, export/import
 * comes from Platform (platform-core.js).
 * ═══════════════════════════════════════════════════════════
 */

(() => {
"use strict";

const { Util, Stats, Charts, Calprotectin, LibRenderer, IO, KPI, Perf, Disclosure, initStorage, updateStorageModeUI } = Platform;
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

// ── MODULE CONFIG ────────────────────────────────────────────────
const MODULE_KEY = "ibd";

const FLAG_KEYS = [
  "fever","nightsweats","weightloss","nocturnal",
  "joints","eyes","skin",
  "antibiotics","nsaids","stress","travel","illness","dietdeviation","medchange"
];

const EIM_FLAGS = ["joints","eyes","skin"];
const RED_FLAGS = ["fever","nightsweats","weightloss","nocturnal"];

function defaultFlags() { const f={}; FLAG_KEYS.forEach(k=>f[k]=false); return f; }
function defaultDraft() { return { quality:null, frequency:null, blood:null, pain:0, wellbeing:0, urgency:0, flags:defaultFlags(), notes:"" }; }

// ── DISEASE ACTIVITY INDICES ─────────────────────────────────────
// Harvey-Bradshaw Index — Crohn's Disease (Harvey & Bradshaw, Lancet 1980)
// Validated in treat-to-target strategy: CALM trial, Lancet 2017
function calcHBI(d) {
  let s = 0;
  s += Util.clamp(d.wellbeing, 0, 4);
  s += Util.clamp(d.pain, 0, 3);
  const f = d.frequency || 0;
  if (f > 3) s += (f - 3);
  if (d.flags?.fever) s += 1;
  if (EIM_FLAGS.some(k => d.flags?.[k])) s += 1;
  return Math.max(0, s);
}
function interpHBI(s) {
  if (s < 5)  return { label:"Remission",          cls:"ok",     color:"var(--ok)" };
  if (s < 8)  return { label:"Mild Activity",       cls:"warn",   color:"var(--warn)" };
  if (s < 16) return { label:"Moderate Activity",   cls:"warn",   color:"var(--warn)" };
  return             { label:"Severe Activity",      cls:"danger", color:"var(--danger)" };
}

// Simple Clinical Colitis Activity Index — UC (Walmsley et al., Gut 1998)
function calcSCCAI(d) {
  let s = 0;
  const f = d.frequency || 0;
  s += f <= 3 ? 0 : f <= 6 ? 1 : f <= 9 ? 2 : 3;
  if (d.flags?.nocturnal) s += 1;
  s += Util.clamp(d.blood || 0, 0, 3);
  s += Util.clamp(d.urgency || 0, 0, 3);
  s += Util.clamp(d.wellbeing || 0, 0, 4);
  if (EIM_FLAGS.some(k => d.flags?.[k])) s += 1;
  return Math.max(0, s);
}
function interpSCCAI(s) {
  if (s < 3) return { label:"Remission",          cls:"ok",     color:"var(--ok)" };
  if (s < 6) return { label:"Mild Activity",       cls:"warn",   color:"var(--warn)" };
  if (s < 9) return { label:"Moderate Activity",   cls:"warn",   color:"var(--warn)" };
  return            { label:"Severe Activity",      cls:"danger", color:"var(--danger)" };
}

function calcScore(draft) {
  const d = State.disease;
  if (!d) return null;
  if (d === "cd") { const s = calcHBI(draft);  return { score:s, interp:interpHBI(s),  index:"Harvey-Bradshaw Index (CD)" }; }
  const s = calcSCCAI(draft); return { score:s, interp:interpSCCAI(s), index:"SCCAI (UC / IBD-U)" };
}

function diseaseLabel(d) {
  return { cd:"Crohn's Disease", uc:"Ulcerative Colitis", ibdu:"IBD-U" }[d] || "—";
}

// ── STATE ────────────────────────────────────────────────────────
const State = {
  store: null, storageMode: "unknown",
  premium: false, disease: null,
  draft: defaultDraft(), lastEntry: null,
  libCat: "all", libQuery: ""
};

// ── LIBRARY ──────────────────────────────────────────────────────
const LIBRARY = (() => {
  const cards = [];
  const add = o => cards.push({
    id: (o.cat+"::"+o.title).toLowerCase().replace(/[^a-z0-9]+/g,"-"),
    ...o
  });

  // CDED PROTOCOL
  add({ cat:"CDED Protocol", tag:"cded", title:"CDED: Overview and Mechanism",
    why:"The Crohn's Disease Exclusion Diet is the most evidence-supported whole-food dietary strategy for inducing and maintaining remission in Crohn's disease.",
    bullets:[
      "Developed by Sigall Boneh and Levine (Wolfson Medical Center, Israel). The landmark RCT (Levine et al., Gastroenterology 2019) showed 75.6% clinical remission at Week 6 — comparable to exclusive enteral nutrition at significantly lower patient burden.",
      "Mechanism: reduces dietary components that impair intestinal barrier function, dysregulate the microbiome, and drive mucosal immune activation. Primary targets: animal fat, emulsifiers, wheat/gluten, processed foods, microparticles.",
      "Three phases: Phase 1 (Weeks 0–6, induction), Phase 2 (Weeks 7–12, consolidation), Phase 3 (maintenance). Each phase has precisely defined food allowances and exclusions designed for patient execution without clinical supervision of individual meals."
    ],
    action:"Discuss CDED with your gastroenterologist before starting. Most effective in mild-to-moderate disease. A powerful adjunct to medical therapy, not a replacement. CDED is designed for patient self-execution — this library is your protocol.",
    more:"The CDED-AD pilot study (Yanai et al., Lancet Gastroenterol Hepatol 2022) demonstrated effectiveness in adults with mild-to-moderate CD. The diet works by limiting emulsifiers (which degrade the protective mucus layer), maltodextrin (which promotes AIEC colonization), animal fat (which drives pro-inflammatory microbiome shifts), and processed food microparticles (titanium dioxide, silica) that activate mucosal innate immune pathways.",
    evidence:"Levine et al., Gastroenterology 2019; Yanai et al., Lancet Gastroenterol Hepatol 2022; Sigall Boneh et al., Inflamm Bowel Dis 2024"
  });

  add({ cat:"CDED Protocol", tag:"cded", title:"CDED Phase 1 — Induction (Weeks 0–6)",
    why:"Phase 1 is the most restrictive phase. Goal: rapid reduction of dietary-driven inflammation and microbiome rebalancing through maximal exclusion of pro-inflammatory dietary components.",
    bullets:[
      "ALLOWED: chicken breast (boiled/baked, no skin, no marinade), canned tuna in water, eggs (any preparation without added fat), white rice (plain), potatoes (boiled/baked, not fried), selected fruits (apple, banana, melon, watermelon, grapes), selected vegetables (cucumber, lettuce, carrots, tomatoes), olive oil (small amounts), salt, water, plain herbal tea.",
      "EXCLUDED: all red meat, all processed meat, all dairy, all wheat/gluten, all processed/packaged foods (including emulsifiers, maltodextrin, artificial additives), all fried foods, all juices except fresh-squeezed, all sweetened beverages.",
      "Optional PEN (partial enteral nutrition): 50% of caloric needs from a polymeric formula (Modulen IBD, Ensure Plus). Significantly enhances efficacy in children. In adults, dietary component alone drives remission in the CDED-AD study — discuss PEN with your physician."
    ],
    action:"Follow Phase 1 strictly for 6 weeks. Do not substitute excluded foods. Log any deviations using the Diet deviation flag. Contact your gastroenterologist if symptoms significantly worsen in the first 2 weeks before modifying the protocol.",
    more:"Chicken breast is the preferred protein because it is low in saturated fat. Potatoes provide resistant starch that supports F. prausnitzii — the key butyrate-producing commensal depleted in CD. Olive oil provides monounsaturated fat without the pro-inflammatory saturated fat effects. The wheat exclusion addresses both gluten and wheat fructans, both of which affect barrier function in IBD independent of celiac disease.",
    evidence:"Levine et al., Gastroenterology 2019; Sigall Boneh et al., Clin Gastroenterol Hepatol 2014"
  });

  add({ cat:"CDED Protocol", tag:"cded", title:"CDED Phase 2 — Consolidation (Weeks 7–12)",
    why:"Phase 2 liberalizes the diet while maintaining the anti-inflammatory framework. Goal: consolidate remission with greater variety and improving long-term sustainability.",
    bullets:[
      "NEW in Phase 2: legumes (lentils, chickpeas — introduce slowly, small portions), additional vegetables (cooked zucchini, green beans, broccoli, cauliflower), most whole fruits, corn tortillas, quinoa, pumpkin seeds, tahini (plain, no additives).",
      "STILL EXCLUDED in Phase 2: all red meat, processed meat, dairy, wheat/gluten, all processed foods, all emulsifiers, all fried foods. Non-negotiable through Phase 2.",
      "Introduce new foods one at a time — one new food per week. If any food triggers symptoms, remove it for 2 weeks before retesting. Log all introductions in your daily notes."
    ],
    action:"One new food per week in Phase 2. Log any symptom changes so changes can be correlated with specific food introductions. Continue flagging any diet deviations.",
    more:"Legumes are introduced carefully because of FODMAP content — galacto-oligosaccharides in chickpeas and lentils require gradual introduction. Well-cooked, small portions are generally better tolerated. The continued wheat exclusion in Phase 2 is intentional — wheat fructans affect gut permeability in IBD even without celiac disease.",
    evidence:"Levine et al., Gastroenterology 2019; Yanai et al., Lancet Gastroenterol Hepatol 2022"
  });

  add({ cat:"CDED Protocol", tag:"cded", title:"CDED Phase 3 — Maintenance",
    why:"Phase 3 is the long-term maintenance framework. Goal: identify the minimal personalized exclusion set that maintains mucosal remission.",
    bullets:[
      "Core permanent exclusions (maintain indefinitely): ultra-processed foods, emulsifiers, red and processed meats, maltodextrin. These are permanent dietary modifications, not temporary restrictions.",
      "Gradual reintroduction: wheat and dairy can be tested in Phase 3 — introduce separately, at least 2-week gaps, with symptom monitoring. Not everyone needs to exclude these long-term.",
      "Calprotectin during reintroductions: a rise above 150 µg/g during any reintroduction is a clear objective signal to withdraw that food. Use data, not just symptoms."
    ],
    action:"Introduce one new food category in Phase 3 for 2 weeks. Monitor symptoms and, if available, calprotectin. Then decide to include or exclude permanently. This is your personal maintenance protocol — systematic reintroduction, not guesswork.",
    more:"Phase 3 is highly individualized. The goal is minimum effective exclusion — the smallest dietary change that maintains mucosal healing. Calprotectin monitoring during Phase 3 reintroductions provides objective mucosal data without requiring repeated endoscopy.",
    evidence:"Sigall Boneh et al., Inflamm Bowel Dis 2024; Yanai et al., Lancet Gastroenterol Hepatol 2022"
  });

  add({ cat:"CDED Protocol", tag:"cded", title:"Foods to Permanently Avoid — The Evidence",
    why:"Specific dietary components have mechanistic evidence for harming intestinal barrier integrity and driving IBD immune activation.",
    bullets:[
      "Emulsifiers (permanent exclusion): carrageenan (E407), polysorbate-80 (E433), carboxymethylcellulose/CMC (E466), soy lecithin (E322) in processed foods. Found in: commercial ice cream, chocolate, non-dairy milks, salad dressings, most bread, protein bars. Check every label.",
      "Maltodextrin: processed starch filler in hundreds of packaged foods. Promotes biofilm formation by adherent-invasive E. coli (AIEC) — bacterial strains directly implicated in CD pathogenesis (Darfeuille-Michaud et al., Gastroenterology 2004).",
      "Red and processed meats: nitrates, heme iron, animal fat combinations increase intestinal permeability and drive pro-inflammatory microbiome shifts. Consistent association with IBD onset and relapse across epidemiologic studies."
    ],
    action:"Read labels for these ingredients on every packaged food. Default to whole foods cooked from scratch. The Phase 1 food list is your permanent safe food reference.",
    more:"Emulsifier harm is most strongly supported for polysorbate-80 and CMC (Chassaing et al., Nature 2015). Human data (Chassaing et al., Gastroenterology 2022) shows microbiome and mucosal changes in healthy volunteers after 11 days of CMC consumption — directionally consistent with animal data and clinically meaningful for IBD patients with compromised barrier function.",
    evidence:"Chassaing et al., Nature 2015; Chassaing et al., Gastroenterology 2022; Darfeuille-Michaud et al., Gastroenterology 2004"
  });

  add({ cat:"CDED Protocol", tag:"cded", title:"Reading Labels for IBD",
    why:"Emulsifiers and pro-inflammatory additives are hidden in foods that appear healthy. Label literacy is essential for CDED adherence.",
    bullets:[
      "Search every label for: carrageenan (E407), polysorbate-80 (E433), CMC (E466), soy lecithin (E322), mono- and diglycerides (E471), maltodextrin, modified food starch, titanium dioxide (E171).",
      "Highest-risk categories: commercial ice cream, chocolate, non-dairy milks, commercial dressings, supermarket bread, protein bars, flavored yogurt, margarine, meal replacement shakes, soups.",
      "Safe by default: unprocessed whole foods — plain meat, fish, eggs, whole fruits, whole vegetables, plain legumes, plain grains, olive oil, vinegar, salt. If you cooked it from whole ingredients, it is safe."
    ],
    action:"Photograph ingredient lists before buying packaged foods. Search for E-numbers listed above. When in doubt during Phase 1 and 2, do not eat it. These are medical dietary restrictions, not lifestyle preferences.",
    evidence:"Chassaing et al., Nature 2015; Viennois et al., Front Nutr 2019; Sigall Boneh et al., Inflamm Bowel Dis 2024"
  });

  // CHIBA SVD
  add({ cat:"Chiba Plant-Based Diet", tag:"svd", title:"Chiba SVD: Evidence for Plant-Based Maintenance",
    why:"The semivegetarian diet (SVD) developed by Chiba et al. at Akita City Hospital is the most evidence-supported long-term dietary maintenance strategy for IBD remission.",
    bullets:[
      "Landmark prospective study (Chiba et al., World J Gastroenterol 2010): 22 IBD patients. SVD group 94% 2-year remission vs 33% omnivore (P<0.001). At 1 year: 100% SVD remission. 5-year follow-up confirmed durability.",
      "IPF therapy (Chiba et al., Perm J 2019): infliximab plus plant-based diet as first-line therapy showed 96% clinical remission induction in CD — outcomes superior to biologics alone in historical comparisons.",
      "The SVD is predominantly plant-based: fish once weekly, poultry (chicken) once every 2 weeks, no red meat. High vegetable variety, fermented foods daily, whole grains, legumes, seaweed."
    ],
    action:"Use Chiba SVD as your long-term maintenance framework after CDED Phase 3. The diets are complementary: CDED establishes induction and exclusions; SVD provides the positive dietary framework for long-term maintenance.",
    more:"Plant-based diets increase microbiome diversity (consistently reduced in IBD), maximize butyrate production, reduce arachidonic acid from animal fat, and provide polyphenols with anti-inflammatory activity. Japanese dietary patterns include miso and natto (fermented soy isoflavones, vitamin K2) and seaweed (fucoidan, laminarin — anti-inflammatory polysaccharides).",
    evidence:"Chiba et al., World J Gastroenterol 2010; Chiba et al., Perm J 2019; Chiba & Ishida, Nutrients 2021"
  });

  add({ cat:"Chiba Plant-Based Diet", tag:"svd", title:"SVD Food Framework — What to Eat",
    why:"The Chiba SVD has a specific positive food framework. Knowing what to eat — not just what to avoid — enables sustainable adherence.",
    bullets:[
      "Daily foundation: rice (brown preferred), miso soup (traditionally fermented, plain), abundant seasonal vegetables, seaweed (nori, wakame, kombu), fermented foods (miso, natto, kimchi without additives, plain sauerkraut), legumes (tofu, edamame, lentils, chickpeas), nuts and seeds (plain).",
      "Weekly inclusions: fatty fish 1–2× per week (salmon, mackerel, sardines — highest omega-3). Eggs 3–4× per week. Chicken breast (skinless, unprocessed) once every 1–2 weeks.",
      "Permanently minimal or excluded: red meat — none. Processed meats — none. Ultra-processed foods — none. Refined sugars — minimize."
    ],
    action:"Build meals around 60–70% vegetables, grains, legumes; 20–30% fish and eggs; minimal poultry. Fermented foods daily. The overlap with CDED Phase 3 exclusions ensures dietary compatibility.",
    more:"For Western patients: miso soup daily (refrigerated, traditionally fermented miso — ingredients should list only soybeans, salt, koji); kimchi or sauerkraut as fermented vegetable sources (traditionally fermented, not vinegar-acidified). Nori sheets as convenient seaweed. Tofu and edamame as regular protein sources.",
    evidence:"Chiba et al., World J Gastroenterol 2010; Chiba & Ishida, Nutrients 2021"
  });

  add({ cat:"Chiba Plant-Based Diet", tag:"svd", title:"Fermented Foods in IBD",
    why:"Fermented foods are a cornerstone of the Chiba SVD with mechanistic and clinical evidence for microbiome benefit.",
    bullets:[
      "Recommended fermented foods: miso (traditionally fermented, plain, not pasteurized), natto (fermented soybean), plain live-culture yogurt/kefir if dairy is tolerated in remission, kimchi and sauerkraut (traditionally fermented — look for 'live cultures', no vinegar), kombucha (plain, low sugar).",
      "A 2021 RCT (Wastyk et al., Cell 2021): high-fermented food diet significantly increased microbiome diversity and decreased 19 inflammatory proteins including IL-6 and IL-12 — directly relevant IBD biomarkers.",
      "Introduce during remission, not during active flare. Begin miso in CDED Phase 2. Broader fermented foods in Phase 3."
    ],
    action:"Add miso soup daily. Choose plain, traditionally fermented options — not pasteurized commercial versions which lack live cultures. Miso ingredients should list: soybeans, salt, koji. Nothing else.",
    evidence:"Wastyk et al., Cell 2021; Chiba et al., Perm J 2017"
  });

  add({ cat:"Chiba Plant-Based Diet", tag:"svd", title:"Butyrate and Short-Chain Fatty Acids",
    why:"Butyrate is the primary energy source for colonocytes with direct anti-inflammatory and barrier-protective effects. Plant-based diets maximize butyrate production.",
    bullets:[
      "Produced by Faecalibacterium prausnitzii, Roseburia intestinalis, Butyrivibrio fibrisolvens from dietary fiber. F. prausnitzii is consistently reduced in CD and inversely correlates with disease activity. Depletion at surgery predicts post-surgical recurrence (Sokol et al., PNAS 2008).",
      "High-butyrate foods: cooked-and-cooled potatoes and legumes (resistant starch), pectin-rich fruits (apples, carrots), oats (arabinoxylan). Cooling starches after cooking significantly increases resistant starch content.",
      "Red meat diets shift microbiome toward hydrogen sulfide-producing bacteria (Bilophila wadsworthia) — cytotoxic to colonocytes and directly implicated in UC pathogenesis."
    ],
    action:"Prioritize cooled potatoes (CDED Phase 1), legumes from Phase 2, oats in remission, apples and carrots daily. Cool starches after cooking where possible. Food-first microbiome support — not supplements.",
    evidence:"Sokol et al., PNAS 2008; Louis & Flint, FEMS Microbiol Lett 2009; Machiels et al., Gut 2014"
  });

  // BIOLOGICS
  add({ cat:"Biologics & Therapy", tag:"biologics", title:"IL-23 Inhibitors — Mechanism and Positioning",
    why:"IL-23 inhibitors represent the most clinically significant advance in IBD biologic therapy of the past decade.",
    bullets:[
      "IL-23 drives Th17 cell differentiation and sustains chronic intestinal inflammation in CD and UC. Genetically validated: IL23R variants are major IBD susceptibility loci in GWAS studies.",
      "Approved IBD agents: risankizumab (Skyrizi — CD and UC), mirikizumab (Omvoh — UC). Block the p19 subunit of IL-23 specifically. Advantages: no TB reactivation risk equivalent to anti-TNF, lower infection risk, no immunogenicity-driven loss of response.",
      "SEQUENCE trial (N Engl J Med 2023): risankizumab vs ustekinumab in CD patients who failed anti-TNF — superior endoscopic remission for risankizumab (32% vs 16% at 1 year)."
    ],
    action:"If prescribed an IL-23 inhibitor, this reflects current evidence-based preference for newer mechanisms with superior safety profiles. Continue dietary interventions alongside — combination approaches are more effective than either alone.",
    more:"The paradigm shift away from anti-TNF as universal first-line biologic is supported by both efficacy data (SEQUENCE, VARSITY) and the favorable benefit-risk profile of gut-selective and IL-23 pathway agents. INSPIRE/MOTIVATE established risankizumab for CD induction; LUCENT-1/2 established mirikizumab for UC.",
    evidence:"SEQUENCE trial, N Engl J Med 2023; INSPIRE/MOTIVATE, Lancet 2022; LUCENT-1/2, Lancet 2023"
  });

  add({ cat:"Biologics & Therapy", tag:"biologics", title:"Anti-TNF Agents — What to Monitor",
    why:"Anti-TNF agents were the first biologic class for IBD and remain widely used. Understanding their monitoring requirements enables informed care.",
    bullets:[
      "TNF-alpha neutralization (infliximab, adalimumab, certolizumab for CD; infliximab, adalimumab, golimumab for UC). Monitoring unique to anti-TNF: TB screening before initiation (anti-TNF reactivates latent TB — IGRA mandatory), hepatitis B screening, therapeutic drug monitoring (TDM).",
      "Loss of response from anti-drug antibody formation is a recognized limitation — TDM with drug levels and antibody testing guides optimization. Higher infection risk than newer agents, including opportunistic infections.",
      "Anti-TNF remains preferred when axial arthropathy (AS) coexists with IBD — IL-23 inhibitors do not have established efficacy for ankylosing spondylitis."
    ],
    action:"On anti-TNF: confirm TB screening completed, hepatitis B status known, drug level monitoring is part of your follow-up. Report infections, neurological symptoms, or loss of efficacy promptly.",
    more:"Anti-TNF agents have 25+ years of safety data. For fistulizing CD, infliximab has the strongest evidence for fistula closure. Biosimilars have significantly reduced cost. The SONIC trial established azathioprine + infliximab combination superiority over either alone in selected patients.",
    evidence:"SONIC trial, N Engl J Med 2010; VARSITY trial, N Engl J Med 2019; Colombel et al., Gut 2012"
  });

  add({ cat:"Biologics & Therapy", tag:"biologics", title:"Treat-to-Target in IBD",
    why:"Treat-to-target uses objective markers — calprotectin and endoscopy — to guide therapy rather than symptoms alone. Symptoms correlate poorly with mucosal healing.",
    bullets:[
      "CALM trial (Colombel et al., Lancet 2017): tight control using calprotectin-guided therapy resulted in 46% mucosal healing vs 30% in symptom-driven management. A significant, clinically meaningful difference.",
      "STRIDE-II (Turner et al., Gastroenterology 2021) targets: immediate (clinical response), intermediate (clinical remission + calprotectin <150–250 µg/g), long-term (endoscopic remission, transmural healing in CD, histologic remission in UC).",
      "A patient can feel well with active mucosal inflammation. A patient can feel unwell in mucosal remission. Objective data provides the signal symptoms cannot."
    ],
    action:"Log every calprotectin result in the Calprotectin tab. A rising trend toward 150 µg/g while feeling well is a signal to raise with your gastroenterologist before a full relapse.",
    evidence:"CALM trial, Lancet 2017; STRIDE-II, Gastroenterology 2021; Tibble meta-analysis, Am J Gastroenterol 2017"
  });

  add({ cat:"Biologics & Therapy", tag:"biologics", title:"Steroids in IBD — Bridge, Not Maintenance",
    why:"Steroids provide rapid symptom control but are not disease-modifying. They do not heal mucosa or alter disease course. Bridge therapy only.",
    bullets:[
      "Appropriate use: short-course induction in moderate-to-severe flare, as bridge while awaiting biologic effect (8–16 weeks typically). Taper as rapidly as clinical response allows.",
      "Steroid dependency (requiring steroids to maintain remission, or relapsing within 3 months of stopping) is a treatment failure requiring escalation — not continued steroid use.",
      "Cumulative exposure is harmful: adrenal suppression, osteoporosis (IBD patients at higher fracture risk), avascular necrosis, cataracts, metabolic and psychiatric effects. Every additional course adds risk."
    ],
    action:"More than one steroid course in 12 months, or steroids needed to maintain any remission = raise biologic escalation at your next appointment. This is the most important clinical action you can take.",
    evidence:"Munkholm et al., Gut 1994; Faubion et al., Gastroenterology 2001; ECCO Guidelines 2023"
  });

  // EIM
  add({ cat:"Extraintestinal Manifestations", tag:"eim", title:"EIM Overview — IBD Beyond the Gut",
    why:"Up to 40% of IBD patients develop extraintestinal manifestations (EIM). Many are missed because non-GI specialists do not connect them to underlying IBD.",
    bullets:[
      "EIMs occur in: joints (5–20%), skin (5–10%), eyes (2–5%), liver/biliary (5% for PSC), less commonly lungs, kidney, pancreas.",
      "Type 1 (activity-related): run parallel to gut disease, respond to IBD treatment. Type 2 (independent): run independent of gut activity, require separate specialist management.",
      "The patient must make the connection explicit: when seeing any rheumatologist, ophthalmologist, or dermatologist, always state 'I have IBD — could this be related?'"
    ],
    action:"Log joint, eye, and skin symptoms using the dedicated flags in every daily entry. Consistent logging builds a longitudinal EIM record. Show your gastroenterologist before specialist referral where possible.",
    more:"Mechanistic link: gut-derived activated immune cells home to extraintestinal sites via shared adhesion molecules; increased intestinal permeability allows microbial antigens into systemic circulation; shared genetic susceptibility (HLA-B27 linking UC to AS; NOD2 variants in CD associated with higher EIM risk). Effective biologic therapy — particularly anti-TNF — often improves EIMs in parallel.",
    evidence:"Vavricka et al., Gut 2015; Ott & Scholmerich, Nat Rev Gastroenterol Hepatol 2013; ECCO EIM Position Paper 2016"
  });

  add({ cat:"Extraintestinal Manifestations", tag:"eim", title:"Joint Manifestations — Arthropathy",
    why:"IBD arthropathy affects up to 20% of patients and is frequently attributed to other causes when the IBD connection is not recognized.",
    bullets:[
      "Type 1 peripheral (activity-related): fewer than 5 large joints, asymmetric (knees, ankles, wrists). Parallels gut disease — IBD treatment resolves joint symptoms. Non-erosive, no permanent joint damage.",
      "Type 2 peripheral (independent): 5+ small joints, symmetric. Runs independent of gut activity. Requires rheumatologic co-management.",
      "Axial arthropathy / AS: HLA-B27-associated, runs independent of gut activity. Critical: NSAIDs treat AS pain but can trigger IBD relapse — this drug conflict requires coordinated specialist management."
    ],
    action:"Log joint symptoms consistently. Specify large vs small joints, whether they parallel gut flares. This distinction guides whether IBD treatment will address them or separate rheumatology input is needed.",
    more:"For IBD patients with coexisting AS, anti-TNF (infliximab, adalimumab) has efficacy for both conditions — making it preferred over IL-23 inhibitors in this context. IL-23 inhibitors do not have established efficacy for ankylosing spondylitis.",
    evidence:"Vavricka et al., Gut 2015; Braun & Sieper, Lancet 2007; ASAS guidelines 2022"
  });

  add({ cat:"Extraintestinal Manifestations", tag:"eim", title:"Skin EIM: EN and Pyoderma Gangrenosum",
    why:"IBD skin manifestations are frequently overlooked or attributed to other causes. Pyoderma gangrenosum has a critical management pitfall that must be known.",
    bullets:[
      "Erythema nodosum (EN): tender red-purple nodules on shins. Activity-related — parallels gut disease. Responds to IBD treatment. Avoid biopsy unless diagnosis uncertain.",
      "Pyoderma gangrenosum (PG): ulcerating wound with violaceous undermined border. Runs INDEPENDENT of gut activity. CRITICAL: PG exhibits pathergy — surgical debridement or biopsy dramatically worsens it. Any ulcerating wound in an IBD patient must be assessed by gastroenterology before any surgical management.",
      "Sweet's syndrome: rare, activity-related. Tender erythematous plaques with fever. Responds to steroids."
    ],
    action:"Photograph any new skin lesion. Show gastroenterologist BEFORE seeing dermatology or surgery for any ulcerating wound. State your IBD diagnosis immediately to any physician assessing skin wounds.",
    evidence:"Brooklyn et al., Gut 2006; Jockenhöfer et al., J Eur Acad Dermatol Venereol 2017; ECCO EIM guidelines 2016"
  });

  add({ cat:"Extraintestinal Manifestations", tag:"eim", title:"Eye EIM: Uveitis and Episcleritis",
    why:"Ocular EIMs can cause permanent vision loss if unrecognized. Know the urgency difference between uveitis and episcleritis.",
    bullets:[
      "Episcleritis: superficial redness, mild discomfort, no vision change, no photophobia. Activity-related. Responds to IBD treatment. Non-urgent. Does not threaten vision.",
      "Uveitis: eye pain + photophobia + blurred vision + redness. May run INDEPENDENT of gut activity. Requires SAME-DAY ophthalmology — untreated uveitis causes permanent vision loss through synechiae, glaucoma, cataract.",
      "Clinical rule: red eye + pain + photophobia + visual change = uveitis = same-day emergency. Red eye without pain, normal vision = likely episcleritis = non-urgent."
    ],
    action:"Red, painful eye with photophobia in an IBD patient = same-day ophthalmology. Do not wait for a gastroenterology appointment. Tell the ophthalmologist you have IBD immediately.",
    evidence:"Larson et al., Am J Gastroenterol 1994; Mintz et al., Am J Ophthalmol 2004; ECCO EIM guidelines 2016"
  });

  add({ cat:"Extraintestinal Manifestations", tag:"eim", title:"PSC and IBD — A Critical Connection",
    why:"Primary sclerosing cholangitis dramatically changes colorectal cancer risk and surveillance requirements.",
    bullets:[
      "PSC in 5–8% of UC, 1–3% of CD. 70–80% of PSC patients have IBD — typically pancolitis with rectal sparing. PSC-IBD is a separate clinical entity.",
      "Colorectal cancer risk in PSC-IBD: cumulative 10-year CRC risk approaches 25%. Annual colonoscopy with chromoendoscopy from diagnosis — not the standard 8–10 year interval.",
      "PSC management (hepatology co-management required): annual MRI/MRCP + CA19-9 for cholangiocarcinoma surveillance. IBD therapy does not treat PSC — parallel management required."
    ],
    action:"If you have PSC or elevated LFTs alongside IBD: confirm hepatology co-management, confirm colonoscopy interval is annual with chromoendoscopy.",
    evidence:"Broome & Bergquist, Hepatology 2006; AASLD PSC Practice Guidance 2023"
  });

  // MONITORING
  add({ cat:"Monitoring & Surveillance", tag:"monitoring", title:"Calprotectin — How to Use Your Results",
    why:"Fecal calprotectin is the most practical non-invasive marker for mucosal inflammation. Using it correctly guides treatment and avoids unnecessary endoscopy.",
    bullets:[
      "Thresholds: <50 µg/g = deep remission. 50–149 µg/g = grey zone (repeat in 4–6 weeks, clinical correlation). ≥150 µg/g = active mucosal inflammation (treat-to-target threshold, clinical review indicated). ≥500 µg/g = highly active.",
      "150 µg/g has the strongest sensitivity/specificity balance for mucosal healing across meta-analyses and is the threshold used in the CALM trial.",
      "Confounders: NSAIDs elevate calprotectin significantly — avoid for 2 weeks before testing. PPIs cause mild elevation. Log NSAID use in your daily flags near the time of calprotectin testing."
    ],
    action:"Log every calprotectin result in the Calprotectin tab with the collection date. Track the trend — a single result is less informative than a trend. Rising trend over 3 readings, even below 150, warrants discussion with your gastroenterologist.",
    evidence:"Tibble et al., Am J Gastroenterol 2017; CALM trial, Lancet 2017; STRIDE-II, Gastroenterology 2021"
  });

  add({ cat:"Monitoring & Surveillance", tag:"monitoring", title:"IBD Surveillance and Cancer Risk",
    why:"IBD patients have elevated colorectal cancer risk requiring structured surveillance based on disease extent, duration, and inflammation control.",
    bullets:[
      "High risk (annual colonoscopy + chromoendoscopy): PSC-IBD, extensive colitis (≥50% colon), active histologic inflammation, prior dysplasia, first-degree relative with CRC under 50.",
      "Intermediate risk (every 2–3 years): left-sided colitis, mild ongoing activity, post-inflammatory polyps.",
      "Low risk (every 5 years after 8–10 year interval): well-controlled extensive/left-sided colitis, confirmed mucosal healing. Effective treat-to-target reduces long-term cancer risk."
    ],
    action:"Know your risk category. At your next appointment ask: 'What is my colonoscopy surveillance interval and why?' Mucosal healing is cancer prevention in IBD.",
    evidence:"Itzkowitz & Yio, Gastroenterology 2004; ECCO surveillance guidelines 2017; BSG IBD guidelines 2022"
  });

  // RED FLAGS
  add({ cat:"Red Flags", tag:"safety", title:"IBD Red Flags — When to Seek Urgent Care",
    why:"Certain features require same-day or emergency evaluation. They cannot be managed with dietary adjustment or watchful waiting.",
    bullets:[
      "Emergency: profuse rectal bleeding (Mayo 3 or large volume), severe abdominal pain with rigidity/rebound, fever >38.5°C with abdominal symptoms, dehydration with inability to maintain fluid intake, toxic megacolon (distension + fever + tachycardia).",
      "Prompt care within 24–48 hours: persistent fever, new/worsening nocturnal diarrhea, significant unintentional weight loss (>5% in 1 month), new perianal disease (fistula, abscess), new severe joint or eye symptoms.",
      "This app is a monitoring tool — not a substitute for clinical judgment in red flag situations."
    ],
    action:"Contact your gastroenterologist's on-call service, go to urgent care, or the emergency department depending on severity. Do not manage red flag features with dietary modification.",
    evidence:"ECCO acute severe colitis guidelines 2023; Travis et al., Gut 1996; Truelove & Witts, BMJ 1955"
  });

  return { cards };
})();

const LIB_CATS = ["all", ...new Set(LIBRARY.cards.map(c => c.cat))];

// ── HTML ─────────────────────────────────────────────────────────
function renderHTML() {
  document.getElementById("module-root").innerHTML = `
<div class="p-app">
  <header class="p-header">
    <div class="p-brand">
      <div class="p-logo-dot" aria-hidden="true"></div>
      <div>
        <h1 class="p-brand-name">IBD OS</h1>
        <div class="p-brand-sub">Symptom tracker</div>
      </div>
    </div>
    <div class="p-header-right">
      <div class="p-pill">🔥 <b id="kpiStreak">0</b>&nbsp;·&nbsp;7d <b id="kpi7d">0</b>&nbsp;·&nbsp;<b id="kpiTotal">0</b> total</div>
    </div>
  </header>

  <nav class="p-nav">
    <div class="p-tabs" role="tablist">
      <button class="p-tab" role="tab" id="tab-log"      aria-selected="true"  data-tab="log"      type="button">Log</button>
      <button class="p-tab" role="tab" id="tab-calp"     aria-selected="false" data-tab="calp"     type="button">Calprotectin</button>
      <button class="p-tab" role="tab" id="tab-history"  aria-selected="false" data-tab="history"  type="button">History</button>
      <button class="p-tab" role="tab" id="tab-library"  aria-selected="false" data-tab="library"  type="button">Library</button>
      <button class="p-tab" role="tab" id="tab-insights" aria-selected="false" data-tab="insights" type="button">Insights</button>
    </div>
  </nav>

  <!-- LOG -->
  <section id="view-log">
    <div class="p-grid two">
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>How are you today?</h2><p>Takes about a minute</p></div>
          <div class="p-kpis"><div class="p-kpi">Date <b id="todayLabel"></b></div></div>
        </div>
        <div class="p-card-b">
          <!-- Step 1 -->
          <div id="stepDisease">
            <div class="p-labelrow"><div class="p-lbl">First — what's your diagnosis?</div><div class="p-hint">saved permanently</div></div>
            <div class="p-seg" id="diseaseSegs">
              <button class="p-segBtn" type="button" data-disease="cd"   aria-pressed="false">Crohn's</button>
              <button class="p-segBtn" type="button" data-disease="uc"   aria-pressed="false">UC</button>
              <button class="p-segBtn" type="button" data-disease="ibdu" aria-pressed="false">IBD-U</button>
            </div>
            <div id="diseaseConfirm" class="hidden" style="margin-top:8px;">
              <div class="p-callout" style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
                <span>Disease: <b id="diseaseLabel">—</b></span>
                <button class="p-btn ghost sm" type="button" id="btnChangeDx">Change</button>
              </div>
            </div>
          </div>
          <!-- Step 2 -->
          <div id="stepQuality" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">How was today overall?</div><div class="p-hint">required</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-quality="great" aria-pressed="false">Great</button>
              <button class="p-segBtn" type="button" data-quality="okay"  aria-pressed="false">Okay</button>
              <button class="p-segBtn" type="button" data-quality="rough" aria-pressed="false">Rough</button>
            </div>
          </div>
          <!-- Step 3 -->
          <div id="stepFreq" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">How many bowel movements today?</div><div class="p-hint">required</div></div>
            <div class="p-freqGrid">
              ${[0,1,2,3,4,5,6,7].map(n => `
              <button class="p-freqBtn" type="button" data-freq="${n}" aria-pressed="false">
                <div class="fn">${n === 7 ? "7+" : n}</div>
                <div class="fl">${["none","once","twice","3×","4×","5×","6×","≥7×"][n]}</div>
              </button>`).join("")}
            </div>
          </div>
          <!-- Step 4 -->
          <div id="stepBlood" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Any blood today?</div><div class="p-hint">tap to select</div></div>
            <div class="p-bloodOpts" role="listbox">
              <div class="p-bldOpt" data-blood="0" aria-selected="false"><div class="p-bldBadge">0</div><div class="p-bldTxt"><div class="bt">None</div><div class="bd">No blood seen</div></div></div>
              <div class="p-bldOpt" data-blood="1" aria-selected="false"><div class="p-bldBadge">1</div><div class="p-bldTxt"><div class="bt">Streaks</div><div class="bd">Less than half of stools</div></div></div>
              <div class="p-bldOpt" data-blood="2" aria-selected="false"><div class="p-bldBadge">2</div><div class="p-bldTxt"><div class="bt">Obvious blood</div><div class="bd">Visible in most stools</div></div></div>
              <div class="p-bldOpt" data-blood="3" aria-selected="false"><div class="p-bldBadge">3</div><div class="p-bldTxt"><div class="bt">Mostly blood</div><div class="bd">Blood alone or predominant</div></div></div>
            </div>
          </div>
          <!-- Step 5 -->
          <div id="stepSymptoms" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Any other symptoms?</div><div class="p-hint">optional</div></div>
            <div class="p-labelrow" style="margin-top:4px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Abdominal pain</div><div class="p-hint" id="painLabel">none</div></div>
            <div class="p-chips" data-symptom="pain">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>
            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">General wellbeing</div><div class="p-hint" id="wellLabel">good</div></div>
            <div class="p-chips" data-symptom="wellbeing">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">Good</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Slightly below average</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Poor</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Terrible</button>
            </div>
            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Urgency / tenesmus</div><div class="p-hint" id="urgLabel">none</div></div>
            <div class="p-chips" data-symptom="urgency">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>
            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Flags</div><div class="p-hint">mark all that apply</div></div>
            <div class="p-chips">
              <button class="p-chip danger" type="button" data-flag="fever"         aria-pressed="false">Fever</button>
              <button class="p-chip danger" type="button" data-flag="nightsweats"   aria-pressed="false">Night sweats</button>
              <button class="p-chip danger" type="button" data-flag="weightloss"    aria-pressed="false">Weight loss</button>
              <button class="p-chip danger" type="button" data-flag="nocturnal"     aria-pressed="false">Nocturnal stools</button>
              <button class="p-chip warn"   type="button" data-flag="joints"        aria-pressed="false">Joint symptoms</button>
              <button class="p-chip warn"   type="button" data-flag="eyes"          aria-pressed="false">Eye symptoms</button>
              <button class="p-chip warn"   type="button" data-flag="skin"          aria-pressed="false">Skin lesion</button>
              <button class="p-chip"        type="button" data-flag="antibiotics"   aria-pressed="false">Antibiotics</button>
              <button class="p-chip"        type="button" data-flag="nsaids"        aria-pressed="false">NSAIDs</button>
              <button class="p-chip"        type="button" data-flag="stress"        aria-pressed="false">Stress↑</button>
              <button class="p-chip"        type="button" data-flag="travel"        aria-pressed="false">Travel</button>
              <button class="p-chip"        type="button" data-flag="illness"       aria-pressed="false">Intercurrent illness</button>
              <button class="p-chip"        type="button" data-flag="dietdeviation" aria-pressed="false">Diet deviation</button>
              <button class="p-chip"        type="button" data-flag="medchange"     aria-pressed="false">Med change</button>
            </div>
            <div id="eimAlert" class="p-callout warn hidden" style="margin-top:10px;">
              <b>EIM flag active.</b> Joint, eye, or skin symptoms may reflect IBD activity outside the gut. See Extraintestinal Manifestations in Library.
            </div>
            <div class="p-section">
              <div class="p-labelrow"><div class="p-lbl">Notes</div><div class="p-hint"><span id="noteCount">0</span>/800</div></div>
              <textarea id="notes" class="p-note" maxlength="800" placeholder="Foods, medications, events, observations (optional)"></textarea>
            </div>
          </div>
          <!-- Actions -->
          <div id="stepActions" class="p-section hidden">
            <div id="redFlagBox" class="p-callout danger hidden" style="margin-bottom:10px;">
              <b>Red flag active.</b> Fever, nocturnal stools, significant weight loss, or Mayo bleeding score 3 require urgent medical evaluation.
            </div>
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnSave" disabled>Done</button>
              <button class="p-btn" type="button" id="btnRepeat" disabled>Repeat last</button>
              <button class="p-btn ghost" type="button" id="btnReset">Reset</button>
            </div>
          </div>
        </div>
      </div>

      <!-- RIGHT -->
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>Clinical Guidance</h2><p>Interpretation · disease activity score</p></div>
          
        </div>
        <div class="p-card-b">
          <div id="guidance" class="p-callout">Complete the log steps. Guidance and your disease activity score will appear here.</div>
          <div id="inlineCard" class="p-section" style="display:none;"></div>
          <div id="scorePanel" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl" id="scoreIndexLabel">Disease Activity</div><div class="p-hint">calculated from today</div></div>
            <div class="p-scoreWrap">
              <div class="p-scoreBig" id="scoreBig">—</div>
              <div class="p-scoreSubLabel" id="scoreSubLabel">—</div>
            </div>
            <div id="scoreInterp" class="p-callout" style="margin-top:8px;"></div>
          </div>
          <div class="p-section">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnReport">Clinician report</button>
              <button class="p-btn" type="button" id="btnExportCsv">Export CSV</button>
              <button class="p-btn" type="button" id="btnExportJson">Export JSON</button>
              <button class="p-btn" type="button" id="btnImport">Import</button>
              <input id="importFile" type="file" accept="application/json" class="sr">
            </div>
          </div>
          <div class="p-section">
            <div class="p-premRow" id="premiumCta" style="cursor:pointer;">
              <div class="p-premLabel" id="premStatusLabel">Unlock Premium — trend analytics · trigger correlation · next steps</div>
              <div style="font-family:var(--font-mono);font-size:10px;letter-spacing:.08em;color:#f5c842;">UPGRADE ✦</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- CALPROTECTIN -->
  <section id="view-calp" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Calprotectin Monitoring</h2><p>Treat-to-target biomarker · threshold 150 µg/g</p></div>
        <div class="p-kpis"><div class="p-kpi">Readings <b id="kpiCalp">0</b></div></div>
      </div>
      <div class="p-card-b">
        <div class="p-callout" style="margin-bottom:14px;">
          <b>Clinical context:</b> Fecal calprotectin ≥150 µg/g indicates active mucosal inflammation. Below 50 µg/g = deep remission. 50–149 µg/g = grey zone. NSAIDs falsely elevate results — avoid 2 weeks before testing. Supported by CALM trial (Lancet 2017) and Tibble meta-analysis (Am J Gastroenterol 2017).
        </div>
        <div class="p-calpRow">
          <div class="p-calpField"><label>Value (µg/g)</label><input type="number" id="calpVal" placeholder="e.g. 120" min="0" max="10000"></div>
          <div class="p-calpField"><label>Collection date</label><input type="date" id="calpDate"></div>
          <div id="calpPreview" class="p-calpBadge" style="display:none;"></div>
        </div>
        <div class="p-rowBtns"><button class="p-btn primary" type="button" id="btnSaveCalp">Save reading</button></div>
        <div class="p-section">
          <div class="p-labelrow"><div class="p-lbl">Trend</div><div class="p-hint">dashed line = 150 µg/g threshold</div></div>
          <div class="p-chartWrap" style="margin-bottom:12px;"><canvas id="chartCalp" height="200"></canvas><div class="p-chartMeta">Calprotectin (µg/g)</div></div>
          <div class="p-list" id="calpList"></div>
        </div>
      </div>
    </div>
  </section>

  <!-- HISTORY -->
  <section id="view-history" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>History</h2><p>Most recent first</p></div>
        <div class="p-rowBtns" style="margin:0;">
          <button class="p-btn" type="button" id="btnExportCsv2">Export CSV</button>
          <button class="p-btn" type="button" id="btnExportJson2">Export JSON</button>
        </div>
      </div>
      <div class="p-card-b"><div class="p-list" id="histList"></div></div>
    </div>
  </section>

  <!-- LIBRARY -->
  <section id="view-library" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Clinical Library</h2><p>Evidence-based · academically sourced · protocolized</p></div>
        <div style="display:flex;gap:10px;align-items:center;">
          <div class="p-kpis"><div class="p-kpi">Cards <b id="kpiCards">0</b></div></div>
          <input id="libSearch" type="search" class="p-search" placeholder="Search CDED, biologic, EIM…">
        </div>
      </div>
      <div class="p-card-b">
        <div class="p-libCats" id="libCats"></div>
        <div class="p-libGrid" id="libGrid"></div>
      </div>
    </div>
  </section>

  <!-- INSIGHTS -->
  <section id="view-insights" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Insights</h2><p>Free: summary · Premium: trends + disease activity + next steps</p></div>
        <button class="p-btn" type="button" id="btnRefresh" style="margin:0;">Refresh</button>
      </div>
      <div class="p-card-b">
        <div id="insightsBody" class="p-callout">Log at least 5 entries to unlock insights.</div>
        <div class="p-section">
          <div class="p-chartWrap"><canvas id="chartFreq" height="200"></canvas><div class="p-chartMeta">Stool frequency distribution (last 28 days)</div></div>
        </div>
        <div id="premiumPanel" class="p-section hidden">
          <div class="p-grid two">
            <div class="p-chartWrap"><canvas id="chartFreqTrend" height="200"></canvas><div class="p-chartMeta">Frequency trend (last 30 entries)</div></div>
            <div class="p-chartWrap"><canvas id="chartScoreTrend" height="200"></canvas><div class="p-chartMeta">Disease activity score trend</div></div>
          </div>
          <div class="p-section p-grid two">
            <div class="p-callout" id="stabilityBox"></div>
            <div class="p-callout" id="calpInsightBox"></div>
          </div>
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Ranked next steps</div><div class="p-hint">data-driven</div></div>
            <div class="p-list" id="nextStepsList"></div>
          </div>
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">EIM monitoring (last 30 entries)</div></div>
            <div class="p-callout" id="eimSummaryBox"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>`;
}

// ── UI UPDATES ───────────────────────────────────────────────────
function updateProgress() {
  const d = State.draft;
  const hasDisease = !!State.disease;
  const hasQ = !!d.quality;
  const hasF = d.frequency !== null && d.frequency !== undefined;
  const hasB = d.blood !== null && d.blood !== undefined;

  $("#stepQuality")?.classList.toggle("hidden", !hasDisease);
  $("#stepFreq")?.classList.toggle("hidden", !(hasDisease && hasQ));
  $("#stepBlood")?.classList.toggle("hidden", !(hasDisease && hasQ && hasF));
  $("#stepSymptoms")?.classList.toggle("hidden", !(hasDisease && hasQ && hasF && hasB));
  $("#stepActions")?.classList.toggle("hidden", !(hasDisease && hasQ && hasF && hasB));

  const canSave = hasDisease && hasQ && hasF && hasB;
  const btnSave = $("#btnSave");
  if (btnSave) btnSave.disabled = !canSave;
  const btnRepeat = $("#btnRepeat");
  if (btnRepeat) btnRepeat.disabled = !State.lastEntry;

  $("#eimAlert")?.classList.toggle("hidden", !EIM_FLAGS.some(k => d.flags?.[k]));

  // INVARIANT: red flags always visible — never gated on premium. MDR compliance.
  const hasRedFlag = RED_FLAGS.some(k => d.flags?.[k]) || (d.blood >= 3);
  $("#redFlagBox")?.classList.toggle("hidden", !hasRedFlag);

  updateGuidance(d);
}


function renderInlineCard(cardTitle) {
  const container = document.getElementById("inlineCard");
  if (!container) return;

  const card = LIBRARY.cards.find(c => c.title === cardTitle);
  if (!card) { container.style.display = "none"; return; }

  container.style.display = "block";
  const safeTitle = card.title.split("—")[0].trim().replace(/'/g, "\'");

  const bulletsHTML = (card.bullets || []).map(b =>
    `<li style="font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:6px;">${b}</li>`
  ).join("");

  const moreHTML = card.more
    ? `<div style="font-size:12px;color:var(--muted2);line-height:1.5;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);">${card.more}</div>`
    : "";

  const evidenceHTML = card.evidence
    ? `<div style="font-size:11px;color:var(--muted2);font-family:var(--font-mono);margin-top:8px;line-height:1.5;">${card.evidence}</div>`
    : "";

  container.innerHTML = `
    <div style="border-left:3px solid var(--accent);padding-left:14px;margin-top:8px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px;">Your doctor says</div>
      <div style="font-size:15px;font-weight:600;color:var(--fg);margin-bottom:8px;">${card.title}</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;margin-bottom:10px;">${card.why}</div>
      ${bulletsHTML ? `<ul style="margin:0 0 10px 0;padding-left:16px;">${bulletsHTML}</ul>` : ""}
      ${card.action ? `
        <div style="padding:12px 14px;background:var(--surface2);border-radius:10px;margin-bottom:10px;">
          <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">What to do</div>
          <div style="font-size:13px;color:var(--fg);line-height:1.6;">${card.action}</div>
        </div>` : ""}
      ${moreHTML}
      ${evidenceHTML}
      <button type="button"
        style="font-size:12px;color:var(--accent);background:none;border:none;padding:4px 0 0 0;cursor:pointer;text-decoration:underline;display:block;margin-top:6px;"
        onclick="(function(){document.getElementById('tab-library')?.click();var s=document.getElementById('libSearch');if(s){s.value='${safeTitle}';s.dispatchEvent(new Event('input'));}})()">
        Browse all library cards →
      </button>
    </div>
  `;
}


function pickInlineCard(d) {
  const f = d.frequency || 0;
  if (d.blood >= 2) return null; // red flag, no card
  if (f >= 5) return "Treat-to-Target — Why Feeling Better Isn't Enough";
  if (d.flags?.steroids) return "Steroids in IBD — Bridge, Not Treatment";
  if (d.flags?.stress) return "Treat-to-Target — Why Feeling Better Isn't Enough";
  return "Biologics and Advanced Therapies — What They Actually Are";
}
function updateGuidance(d) {
  const g = $("#guidance");
  const sp = $("#scorePanel");
  if (!g) return;

  if (!State.disease || !d.quality || d.frequency === null || d.blood === null) {
    g.innerHTML = "Complete the log steps. Guidance and disease activity score will appear here.";
    sp?.classList.add("hidden");
    return;
  }

  const scoreRes = calcScore(d);

  const f = d.frequency || 0;
  let assessment = "";
  if (State.disease === "uc") {
    if (d.blood >= 2 && f >= 4) assessment = `Your log shows active UC markers today — significant rectal bleeding (Mayo ${d.blood}) with ${f} bowel movements. These findings together suggest active mucosal inflammation and warrant clinical review.`;
    else if (d.blood >= 1) assessment = `Your log records rectal bleeding today — Mayo score ${d.blood}. Even low-level bleeding in UC is worth tracking carefully — it is the most sensitive marker of mucosal activity.`;
    else if (f >= 6) assessment = `Your log shows ${f} bowel movements today. Without bleeding, this may reflect functional urgency, but a rising frequency trend in UC warrants a calprotectin check.`;
    else if (d.quality === "great") assessment = `Your log shows a good day — low frequency, no bleeding. This is what remission looks like. Consistent entries like this confirm your treatment is working.`;
    else assessment = `Your log shows a moderate symptom day — ${f} stool${f !== 1 ? "s" : ""}, no significant bleeding. The trend over 7–14 days matters more than any single entry.`;
  } else {
    if (f >= 5 && d.pain >= 2) assessment = `Your log shows active Crohn's markers today — ${f} bowel movements and significant abdominal pain. This combination warrants attention, particularly if it represents a change from your usual baseline.`;
    else if (d.flags?.fever) assessment = `Fever flagged alongside GI symptoms. In Crohn's, fever with GI symptoms may indicate a complication — stricture, abscess, or perforation. This requires same-day contact with your IBD team if fever is confirmed.`;
    else if (d.quality === "great") assessment = `Good day logged. Symptom-free days in Crohn's don't always reflect mucosal healing, but a consistent trend of low symptoms is meaningful data. Keep logging.`;
    else assessment = `Your log shows a moderate day — ${f} bowel movement${f !== 1 ? "s" : ""}, pain level ${d.pain}/3. The 7–14 day trend matters more than any single entry.`;
  }
  if (d.flags?.steroids) assessment += ` Steroids flagged. Steroids suppress symptoms but don't achieve mucosal healing — they are a bridge, not a treatment.`;

  let plan = "";
  if (d.blood >= 2) {
    plan = `Rectal bleeding at this level needs clinical review — do not attempt to manage it with dietary changes alone. Contact your gastroenterologist. If you are not on a biologic or immunomodulator, this is a good time to discuss escalation. The treat-to-target approach — aiming for mucosal healing confirmed by calprotectin or endoscopy, not just symptom relief — is the current standard of care in IBD.`;
  } else if (d.flags?.steroids) {
    plan = `If you have needed steroids more than once in the past year, discuss biologic therapy with your gastroenterologist. Steroid-dependence is a recognised indication for escalation — biologics achieve mucosal healing that steroids do not. Log your steroid courses with dates — this is clinically useful data for that conversation.`;
  } else if (f >= 5) {
    plan = `High stool frequency warrants a calprotectin check — it distinguishes active mucosal inflammation from functional urgency. If calprotectin is elevated above 250 µg/g, that is an objective signal for treatment review. Log your calprotectin results in the app when you have them. Ensure adequate hydration — oral rehydration sachets replace electrolytes more effectively than plain water at high stool output.`;
  } else if (d.quality === "great") {
    plan = `Maintain your current regimen exactly. Do not adjust medications during a good period without discussing with your IBD team — loss of biologic response from missed doses can be difficult to reverse. Log biologic dose dates consistently.`;
  } else {
    plan = `Continue logging daily. A calprotectin level at your next opportunity will help distinguish symptom-driven concern from objective mucosal activity. Bring your Clinician Report to your next IBD appointment — the trend data is more useful to your doctor than recall.`;
  }

  g.innerHTML = `
    <div style="margin-bottom:12px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Assessment</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${assessment}</div>
    </div>
    <div>
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Plan</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${plan}</div>
    </div>
    <div style="font-size:11px;color:var(--muted2);margin-top:10px;border-top:1px solid var(--border);padding-top:8px;">This is patient education based on your logged data — not a medical diagnosis. Discuss any changes to your treatment with your gastroenterologist.</div>
  `;

  const cardTitle = pickInlineCard(d);
  if (cardTitle) renderInlineCard(cardTitle);
  else { const ic = document.getElementById("inlineCard"); if (ic) ic.style.display = "none"; }

  if (scoreRes && sp) {
    sp.classList.remove("hidden");
    const big = $("#scoreBig"), sub = $("#scoreSubLabel"), interp = $("#scoreInterp"), idx = $("#scoreIndexLabel");
    if (big) { big.textContent = scoreRes.score; big.style.color = scoreRes.interp.color; }
    if (sub) sub.textContent = scoreRes.interp.label;
    if (idx) idx.textContent = scoreRes.index;
    if (interp) {
      interp.className = "p-callout " + (scoreRes.interp.cls || "");
      const tips = {
        ok:     "Consistent with clinical remission. Maintain current therapy and dietary protocol.",
        warn:   "Mild to moderate activity. Review therapy adherence and dietary deviations with your physician.",
        danger: "Significant disease activity. Contact your gastroenterologist. Do not adjust therapy without medical guidance."
      };
      interp.innerHTML = `<b>${scoreRes.interp.label}:</b> ${tips[scoreRes.interp.cls] || ""}`;
    }
  } else sp?.classList.add("hidden");
}

function setDiseaseUI(d) {
  State.disease = d;
  $$("[data-disease]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.disease === d)));
  const lbl = $("#diseaseLabel");
  if (lbl) lbl.textContent = diseaseLabel(d);
  $("#diseaseConfirm")?.classList.toggle("hidden", !d);
}

function setPremium(on) {
  State.premium = !!on;
  State.store?.setSetting("premium", State.premium);
}

function resetDraft() {
  State.draft = defaultDraft();
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$("[data-freq]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$("[data-blood]").forEach(b => b.setAttribute("aria-selected","false"));
  $$("[data-symptom] .p-chip").forEach(c => c.setAttribute("aria-pressed", String(c.dataset.level === "0")));
  $$(".p-chip[data-flag]").forEach(c => c.setAttribute("aria-pressed","false"));
  const notes = $("#notes"); if (notes) notes.value = "";
  const nc = $("#noteCount"); if (nc) nc.textContent = "0";
  const pl = $("#painLabel"); if (pl) pl.textContent = "none";
  const wl = $("#wellLabel"); if (wl) wl.textContent = "good";
  const ul = $("#urgLabel");  if (ul) ul.textContent = "none";
  updateProgress();
}

// ── SAVE / REPEAT ─────────────────────────────────────────────────
async function save() {
  try {
    if ($("#btnSave")) $("#btnSave").disabled = true;
    const d = State.draft;
    const entry = {
      ts: Util.nowISO(), dateKey: Util.dateKeyLocal(),
      disease: State.disease, quality: d.quality,
      frequency: d.frequency, blood: d.blood,
      pain: Util.clamp(d.pain,0,3), wellbeing: Util.clamp(d.wellbeing,0,3),
      urgency: Util.clamp(d.urgency,0,3),
      flags: {...d.flags}, notes: (d.notes||"").slice(0,800), deleted: 0
    };
    // Duplicate check
    const last = State.lastEntry;
    if (last) {
      const dt = Math.abs(+new Date(entry.ts) - +new Date(last.ts));
      if (dt < 90000 && entry.quality === last.quality && entry.frequency === last.frequency && entry.blood === last.blood) {
        Util.toast("Duplicate entry blocked"); return;
      }
    }
    const saved = await Perf.time("entry-save", async () => { await State.store.addEntry(entry); });
    State.lastEntry = saved;
    Util.toast("Entry saved");
  // First-time upgrade nudge at 14 entries
  const allEntries = await State.store.getEntriesAll();
  if (allEntries.length === 14 && !PremiumGate.isPremium()) {
    setTimeout(() => PremiumGate.showPaywall(MODULE_KEY, () => {
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      Util.toast("Premium unlocked ✦");
    }), 1200);
  }
    resetDraft();
    await refreshKPIs();
    await renderHistory();
  } catch(err) { console.error(err); Util.toast("Save failed"); }
  finally { updateProgress(); }
}

async function repeatLast() {
  const last = State.lastEntry || await State.store.getLastEntry();
  if (!last) return;
  State.lastEntry = last;
  if (last.disease) setDiseaseUI(last.disease);
  const d = State.draft;
  d.quality = last.quality; d.frequency = last.frequency; d.blood = last.blood;
  d.pain = last.pain||0; d.wellbeing = last.wellbeing||0; d.urgency = last.urgency||0;
  d.flags = {...defaultFlags(), ...(last.flags||{})}; d.notes = last.notes||"";
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.quality === d.quality)));
  $$("[data-freq]").forEach(b => b.setAttribute("aria-pressed", String(Number(b.dataset.freq) === d.frequency)));
  $$("[data-blood]").forEach(b => b.setAttribute("aria-selected", String(Number(b.dataset.blood) === d.blood)));
  const syncSym = (sym, val) => {
    const w = $(`.p-chips[data-symptom="${sym}"]`);
    if (w) w.querySelectorAll(".p-chip").forEach(c => c.setAttribute("aria-pressed", String(Number(c.dataset.level) === val)));
  };
  syncSym("pain", d.pain); syncSym("wellbeing", d.wellbeing); syncSym("urgency", d.urgency);
  $$(".p-chip[data-flag]").forEach(c => c.setAttribute("aria-pressed", String(!!d.flags[c.dataset.flag])));
  const notes = $("#notes"); if (notes) { notes.value = d.notes; const nc = $("#noteCount"); if (nc) nc.textContent = String(d.notes.length); }
  updateProgress();
  Util.toast("Repeated last entry");
}

// ── RENDERS ───────────────────────────────────────────────────────
async function refreshKPIs() {
  const kpis = await KPI.compute(State.store);
  const el = (id, v) => { const e = $(id); if (e) e.textContent = String(v); };
  el("#kpiTotal", kpis.total);
  el("#kpi7d", kpis.last7days);
  el("#kpiStreak", kpis.streak);
}

async function renderHistory() {
  const list = $("#histList"); if (!list) return;
  const all = (await State.store.getEntriesAll()).sort((a,b) => b.ts.localeCompare(a.ts));
  if (!all.length) { list.innerHTML = `<div class="p-callout">No entries yet.</div>`; return; }
  list.innerHTML = all.slice(0, 80).map(e => {
    const sc = e.disease === "cd" ? calcHBI(e) : calcSCCAI(e);
    const interp = e.disease === "cd" ? interpHBI(sc) : interpSCCAI(sc);
    const flags = FLAG_KEYS.filter(k => e.flags?.[k]).slice(0, 6);
    return `<div class="p-item">
      <div class="p-itemTop">
        <div class="ts">${Util.esc(e.dateKey)}</div>
        <div class="q">${Util.esc(diseaseLabel(e.disease))} · ${Util.esc(e.quality||"")} · freq ${Util.esc(String(e.frequency??"-"))} · Mayo ${Util.esc(String(e.blood??"-"))}</div>
      </div>
      <div class="p-itemBody">Pain: <b>${Util.esc(Util.levelToText(e.pain))}</b> · Wellbeing: <b>${Util.esc(Util.levelToText(e.wellbeing))}</b> · Urgency: <b>${Util.esc(Util.levelToText(e.urgency))}</b> · Score: <b style="color:${Util.cssVal(interp.color)}">${sc} (${Util.esc(interp.label)})</b></div>
      ${flags.length ? `<div class="p-itemBody" style="margin-top:4px;font-family:var(--font-mono);font-size:11px;color:var(--muted2);">${Util.esc(flags.join(", "))}</div>` : ""}
      ${e.notes ? `<div class="p-itemBody" style="margin-top:4px;">${Util.esc(e.notes)}</div>` : ""}
    </div>`;
  }).join("");
}

async function renderCalp() {
  const list = $("#calpList"); if (!list) return;
  const readings = await State.store.getCalpAll();
  const kpi = $("#kpiCalp"); if (kpi) kpi.textContent = String(readings.length);
  const chart = $("#chartCalp"); if (chart) Charts.drawCalprotectin(chart, readings);
  Calprotectin.renderList(list, readings);
}

async function renderInsights() {
  const all = (await State.store.getEntriesAll()).sort((a,b) => a.ts.localeCompare(b.ts));
  const body = $("#insightsBody");

  if (all.length < 5) {
    if (body) body.textContent = `Log at least 5 entries to unlock insights. (${all.length} so far)`;
    return;
  }
  if (body) body.innerHTML = `<b>${all.length}</b> total entries logged.`;

  // Free: frequency distribution last 28 days
  const cut28 = new Date(); cut28.setDate(cut28.getDate()-27); cut28.setHours(0,0,0,0);
  const last28 = all.filter(e => new Date(e.ts) >= cut28);
  const freqDist = Array(8).fill(0);
  last28.forEach(e => freqDist[Math.min(7, e.frequency||0)]++);
  const fc = $("#chartFreq"); if (fc) Charts.drawBars(fc, ["0","1","2","3","4","5","6","7+"], freqDist);

  if (!PremiumGate.isPremium()) {
    const pp = $("#premiumPanel"); pp?.classList.add("hidden");
    // Show inline paywall nudge
    const body = $("#insightsBody");
    if (body && !body.querySelector(".pw-inline-nudge")) {
      const nudge = document.createElement("div");
      nudge.className = "pw-inline-nudge p-callout";
      nudge.style.cssText = "margin-top:12px;cursor:pointer;border-color:rgba(245,200,66,.25);background:rgba(245,200,66,.04);";
      nudge.innerHTML = `<b style="color:#f5c842;">✦ Unlock Premium to see your full Insights</b><br><span style="font-size:var(--font-size-sm);color:var(--muted);">Trend charts · trigger correlation · next steps · what's driving your symptoms</span><br><span style="display:inline-block;margin-top:8px;font-size:var(--font-size-sm);font-family:var(--font-mono);color:#f5c842;">Tap to upgrade →</span>`;
      nudge.addEventListener("click", () => PremiumGate.showPaywall(MODULE_KEY, () => { nudge.remove(); renderInsights(); }));
      body.appendChild(nudge);
    }
    return;
  }

  const pp = $("#premiumPanel"); pp?.classList.remove("hidden");
  const last30 = all.slice(-30);
  const freqVals = last30.map(e => e.frequency||0);
  const scoreVals = last30.map(e => e.disease === "cd" ? calcHBI(e) : calcSCCAI(e));

  const ft = $("#chartFreqTrend"); if (ft) Charts.drawLine(ft, freqVals, { maxV:10 });
  const st = $("#chartScoreTrend"); if (st) Charts.drawLine(st, scoreVals, { maxV:20 });

  const stab = $("#stabilityBox");
  if (stab) {
    const fm = Stats.mean(freqVals), fsd = Stats.std(freqVals);
    const stable = fsd < 1.5;
    stab.className = "p-callout " + (stable ? "ok" : "warn");
    stab.innerHTML = `<b>Frequency stability:</b> Mean ${fm.toFixed(1)}/day, SD ${fsd.toFixed(1)}. ${stable ? "Consistent pattern — good signal quality." : "High variability — stabilize confounders before adding dietary changes."}`;
  }

  const calpBox = $("#calpInsightBox");
  if (calpBox) {
    const calps = await State.store.getCalpAll();
    if (calps.length >= 2) {
      const last = calps[calps.length-1], prev = calps[calps.length-2];
      const trend = last.value - prev.value;
      const interp = Calprotectin.interpret(last.value);
      calpBox.className = "p-callout " + (last.value < 150 ? "ok" : "danger");
      calpBox.innerHTML = `<b>Latest calprotectin:</b> ${last.value} µg/g (${interp.label}). Trend vs prior: ${trend > 0 ? "↑ +" : "↓ "}${trend} µg/g. ${trend > 50 ? "Rising — clinical review recommended." : trend < -50 ? "Falling — positive direction." : "Stable."}`;
    } else {
      calpBox.className = "p-callout";
      calpBox.innerHTML = "<b>Calprotectin:</b> Log at least 2 readings for trend analysis.";
    }
  }

  // Next steps
  const ns = $("#nextStepsList");
  if (ns) {
    const steps = [];
    const lastScore = scoreVals[scoreVals.length-1] || 0;
    if (lastScore >= 8) steps.push({ p:"danger", t:"Disease activity score indicates moderate-to-severe activity. Contact your gastroenterologist before next scheduled appointment." });
    const eimFlagged = all.slice(-14).filter(e => EIM_FLAGS.some(k => e.flags?.[k])).length;
    if (eimFlagged >= 3) steps.push({ p:"warn", t:`EIM flags documented ${eimFlagged} times in 14 days. Raise at next gastroenterology visit — specialist referral may be indicated.` });
    const nocFlagged = all.slice(-7).filter(e => e.flags?.nocturnal).length;
    if (nocFlagged >= 2) steps.push({ p:"danger", t:"Nocturnal stools flagged multiple times this week. This is a clinical red flag — contact your gastroenterologist promptly." });
    const fm = Stats.mean(freqVals);
    if (fm > 4) steps.push({ p:"warn", t:"Mean stool frequency above 4/day. Consider calprotectin testing if not done in past 4–6 weeks." });
    if (!steps.length) steps.push({ p:"ok", t:"No high-priority clinical signals detected. Continue monitoring and maintain dietary protocol." });
    const colors = { danger:"var(--danger)", warn:"var(--warn)", ok:"var(--ok)" };
    ns.innerHTML = steps.map(s => `<div class="p-item"><div class="p-itemBody"><b style="color:${colors[s.p]}">${s.p.toUpperCase()}:</b> ${Util.esc(s.t)}</div></div>`).join("");
  }

  const eimBox = $("#eimSummaryBox");
  if (eimBox) {
    const counts = { joints:0, eyes:0, skin:0 };
    all.slice(-30).forEach(e => { EIM_FLAGS.forEach(k => { if (e.flags?.[k]) counts[k]++; }); });
    const total = Object.values(counts).reduce((a,b) => a+b, 0);
    eimBox.className = "p-callout" + (total >= 5 ? " warn" : "");
    eimBox.innerHTML = total === 0
      ? "No EIM flags in last 30 entries."
      : `<b>EIM flags:</b> Joints: ${counts.joints} · Eyes: ${counts.eyes} · Skin: ${counts.skin}. ${total >= 5 ? "Persistent extraintestinal symptoms — raise at next gastroenterology visit." : "Document and monitor."}`;
  }
}

function showTab(tab) {
  ["log","calp","history","library","insights"].forEach(t => {
    $("#tab-"+t)?.setAttribute("aria-selected", String(t === tab));
    $("#view-"+t)?.classList.toggle("hidden", t !== tab);
  });
  if (tab === "history") renderHistory();
  if (tab === "calp") renderCalp();
  if (tab === "library") {
    LibRenderer.renderCats($("#libCats"), LIB_CATS, State.libCat, cat => {
      State.libCat = cat;
      renderLibrary();
    });
    renderLibrary();
  }
  if (tab === "insights") renderInsights();
}

function renderLibrary() {
  const grid = $("#libGrid"); if (!grid) return;
  const kpi = $("#kpiCards"); if (kpi) kpi.textContent = String(LIBRARY.cards.length);
  const filtered = LibRenderer.filterCards(LIBRARY.cards, State.libCat, State.libQuery);
  LibRenderer.render(grid, filtered);
}

// ── WIRE EVENTS ───────────────────────────────────────────────────
function wireEvents() {
  // Tabs
  $$(".p-tab").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));

  // Disease
  $$("[data-disease]").forEach(b => b.addEventListener("click", () => {
    setDiseaseUI(b.dataset.disease);
    State.store.setSetting("disease", b.dataset.disease);
    updateProgress();
    setTimeout(() => Util.scroll($("#stepQuality")), 80);
  }));
  $("#btnChangeDx")?.addEventListener("click", () => {
    State.disease = null;
    $$("[data-disease]").forEach(b => b.setAttribute("aria-pressed","false"));
    $("#diseaseConfirm")?.classList.add("hidden");
    updateProgress();
  });

  // Quality
  $$("[data-quality]").forEach(b => b.addEventListener("click", () => {
    State.draft.quality = b.dataset.quality;
    $$("[data-quality]").forEach(x => x.setAttribute("aria-pressed", String(x === b)));
    updateProgress();
    setTimeout(() => Util.scroll($("#stepFreq")), 80);
  }));

  // Frequency
  $$("[data-freq]").forEach(b => b.addEventListener("click", () => {
    State.draft.frequency = Number(b.dataset.freq);
    $$("[data-freq]").forEach(x => x.setAttribute("aria-pressed", String(x === b)));
    updateProgress();
    setTimeout(() => Util.scroll($("#stepBlood")), 80);
  }));

  // Blood
  $$("[data-blood]").forEach(b => b.addEventListener("click", () => {
    State.draft.blood = Number(b.dataset.blood);
    $$("[data-blood]").forEach(x => x.setAttribute("aria-selected", String(x === b)));
    updateProgress();
    setTimeout(() => Util.scroll($("#stepSymptoms")), 80);
  }));

  // Symptom chips
  $$("[data-symptom]").forEach(wrap => wrap.addEventListener("click", e => {
    const btn = e.target.closest(".p-chip"); if (!btn) return;
    const sym = wrap.dataset.symptom, level = Number(btn.dataset.level);
    State.draft[sym] = Util.clamp(level, 0, 3);
    wrap.querySelectorAll(".p-chip").forEach(c => c.setAttribute("aria-pressed", String(c === btn)));
    const labels = { pain:"painLabel", wellbeing:"wellLabel", urgency:"urgLabel" };
    const lblEl = labels[sym] ? $(`#${labels[sym]}`) : null;
    if (lblEl) lblEl.textContent = Util.levelToText(level);
    updateProgress();
  }));

  // Flag chips
  $$(".p-chip[data-flag]").forEach(b => b.addEventListener("click", () => {
    const k = b.dataset.flag;
    State.draft.flags[k] = !State.draft.flags[k];
    b.setAttribute("aria-pressed", String(State.draft.flags[k]));
    updateProgress();
  }));

  // Notes
  const notes = $("#notes");
  if (notes) notes.addEventListener("input", () => {
    State.draft.notes = notes.value;
    const nc = $("#noteCount"); if (nc) nc.textContent = String(notes.value.length);
  });

  // Actions
  $("#btnSave")?.addEventListener("click", save);
  $("#btnRepeat")?.addEventListener("click", repeatLast);
  $("#btnReset")?.addEventListener("click", resetDraft);

  // Export/Import
  const doCSV = () => IO.exportCSV(State.store, MODULE_KEY, FLAG_KEYS);
  const doJSON = () => IO.exportJSON(State.store, MODULE_KEY);
  // INVARIANT: clinician report is always free — do not gate on PremiumGate.isPremium()
  $("#btnReport")?.addEventListener("click", () => Report.generate(MODULE_KEY));
  ["#btnExportCsv","#btnExportCsv2"].forEach(s => $(s)?.addEventListener("click", doCSV));
  ["#btnExportJson","#btnExportJson2"].forEach(s => $(s)?.addEventListener("click", doJSON));
  const btnImport = $("#btnImport"), importFile = $("#importFile");
  if (btnImport && importFile) {
    btnImport.addEventListener("click", () => importFile.click());
    importFile.addEventListener("change", async e => {
      const f = e.target.files?.[0]; if (!f) return;
      await IO.importJSON(f, State.store, FLAG_KEYS, async () => {
        await refreshKPIs(); await renderHistory();
      });
      e.target.value = "";
    });
  }

  // Calprotectin
  const calpVal = $("#calpVal"), calpDate = $("#calpDate"), calpPreview = $("#calpPreview");
  calpVal?.addEventListener("input", () => {
    const v = Number(calpVal.value);
    if (!isNaN(v) && v > 0 && calpPreview) {
      const interp = Calprotectin.interpret(v);
      calpPreview.className = "p-calpBadge " + interp.cls;
      calpPreview.textContent = `${interp.label} (${v} µg/g)`;
      calpPreview.style.display = "block";
    } else if (calpPreview) calpPreview.style.display = "none";
  });
  $("#btnSaveCalp")?.addEventListener("click", async () => {
    const v = Number(calpVal?.value), d = calpDate?.value;
    if (!v || v <= 0) { Util.toast("Enter a valid value"); return; }
    if (!d) { Util.toast("Enter a collection date"); return; }
    await State.store.addCalp({ value:v, date:d });
    Util.toast("Calprotectin saved");
    if (calpVal) calpVal.value = "";
    if (calpDate) calpDate.value = "";
    if (calpPreview) calpPreview.style.display = "none";
    await renderCalp();
  });

  // Library search
  $("#libSearch")?.addEventListener("input", e => {
    State.libQuery = e.target.value || "";
    renderLibrary();
  });

  // Premium CTA — wire paywall
  $("#premiumCta")?.addEventListener("click", () => {
    PremiumGate.showPaywall(MODULE_KEY, () => {
      const sl = $("#premStatusLabel");
      if (sl) sl.textContent = "✦ Premium active";
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      renderInsights?.();
      Util.toast("Premium unlocked ✦");
    });
  });

  // Insights
  $("#btnRefresh")?.addEventListener("click", renderInsights);

}

// ── BOOT ─────────────────────────────────────────────────────────
async function boot() {
  // Render HTML first
  renderHTML();

  const todayEl = $("#todayLabel");
  if (todayEl) todayEl.textContent = Util.dateKeyLocal();

  // Init storage
  const { store, mode } = await initStorage(MODULE_KEY);
  State.store = store;
  State.storageMode = mode;
  updateStorageModeUI(mode);
  if (typeof GIOSNotifications !== "undefined") GIOSNotifications.init("ibd", "IBD OS");

  // Restore persisted settings
  const savedPremium = await store.getSetting("premium", false);
  setPremium(!!savedPremium);
  const savedDisease = await store.getSetting("disease", null);
  if (savedDisease) setDiseaseUI(savedDisease);
  State.lastEntry = await store.getLastEntry();
  
  // Apply progressive disclosure state
  const allForDisclosure = await store.getEntriesAll();
  const hasAlarm = allForDisclosure.slice(-7).some(e => 
    e.flags && Object.values(e.flags).some(v => v === true)
  );
  const disclosureState = Disclosure.getState(allForDisclosure.length, hasAlarm);
  Disclosure.applyToDOM(disclosureState, MODULE_KEY);
  // Show onboarding on first run
  setTimeout(() => Onboarding.show(MODULE_KEY, store), 400);

  // Update premium CTA label based on current gate state
  const { state, trialDaysLeft } = PremiumGate.getState();
  const sl = $("#premStatusLabel");
  if (sl) {
    if (state === "active") sl.textContent = "✦ Premium active";
    else if (state === "trial") sl.textContent = `✦ Trial active · ${trialDaysLeft}d remaining`;
    else sl.textContent = "Unlock Premium — trend analytics · trigger correlation · next steps";
  }
  PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();


  // Wire everything
  wireEvents();
  resetDraft();
  await refreshKPIs();
  await renderHistory();

  // Init library UI
  LibRenderer.renderCats($("#libCats"), LIB_CATS, State.libCat, cat => {
    State.libCat = cat;
    renderLibrary();
  });
  renderLibrary();

  Util.toast("IBD OS ready");
}

boot();
})();
