/**
 * GI OS — Clinician Share Report Generator
 * ═══════════════════════════════════════════════════════════
 * Generates a print-ready one-page clinical summary from
 * any GI OS module's localStorage data.
 *
 * Called from each module via:
 *   Report.generate(moduleKey)
 *
 * Opens a new window with a print-optimised HTML report
 * the patient can print or save as PDF to share with
 * their gastroenterologist.
 * ═══════════════════════════════════════════════════════════
 */

const Report = (() => {
"use strict";


// ── HELPERS ───────────────────────────────────────────────────
function escHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, c =>
    ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

const MODULE_CONFIGS = {
  ibs: {
    name: "Irritable Bowel Syndrome",
    abbr: "IBS OS", accent: "#78c2a4",
    scoreField: "ibssss", scoreLabel: "IBS-SSS", scoreMax: 500,
    interp:    s => s<=75?"Remission":s<=175?"Mild":s<=300?"Moderate":"Severe",
    interpCls: s => s<=175?"ok":s<=300?"warn":"danger",
    remissionTarget: "IBS-SSS ≤ 75 (remission)",
    subtypeLabel: {ibs_c:"IBS-C",ibs_d:"IBS-D",ibs_m:"IBS-M",ibs_u:"IBS-U"},
    primaryFlags: ["lowfodmap","reintroducing","stress","anxiety","poorslep","skippedmed"],
    alarmFlags:   ["rectalblood","nightwake","unintentionalwl","progressivepain","newonset"],
    summaryFields: e => [
      {label:"Pain",     val:["None","Mild","Moderate","Severe"][e.pain||0]},
      {label:"Bristol",  val:e.stool?`Type ${e.stool}`:"—"},
      {label:"Bloating", val:["None","Mild","Moderate","Severe"][e.bloat||0]},
    ]
  },
  ibd: {
    name: "Inflammatory Bowel Disease",
    abbr: "IBD OS", accent: "#e07a5f",
    scoreField: null, scoreLabel: "HBI / SCCAI", scoreMax: 20,
    interp:    s => s<=4?"Remission":s<=7?"Mild":s<=12?"Moderate":"Severe",
    interpCls: s => s<=7?"ok":s<=12?"warn":"danger",
    remissionTarget: "HBI ≤ 4 (CD remission) · SCCAI ≤ 2 (UC remission)",
    subtypeLabel: {cd:"Crohn's Disease",uc:"Ulcerative Colitis",ibdu:"IBD-U"},
    primaryFlags: ["biologic","skippedmed","stress","infection"],
    alarmFlags:   ["rectalblood","fever","severeabdpain","unintentionalwl","abscess","fistula"],
    summaryFields: e => [
      {label:"Stools/day",  val:e.stoolFreq!=null?String(e.stoolFreq):"—"},
      {label:"Abd pain",    val:["None","Mild","Moderate","Severe"][e.pain||0]},
      {label:"Wellbeing",   val:["Good","Below par","Poor","Very poor"][e.wellbeing||0]||"—"},
    ],
    getScore: e => {
      if (!e) return {score:0,label:"HBI/SCCAI"};
      const isCD = e.disease==="cd";
      return {score: isCD?(e.hbi||0):(e.sccai||0), label: isCD?"HBI":"SCCAI"};
    }
  },
  gerd: {
    name: "GERD & Barrett's Oesophagus",
    abbr: "GERD OS", accent: "#c97dd4",
    scoreField: "gerdq", scoreLabel: "GERD-Q", scoreMax: 18,
    interp:    s => s<=2?"Controlled":s<=7?"Partially controlled":"Uncontrolled",
    interpCls: s => s<=2?"ok":s<=7?"warn":"danger",
    remissionTarget: "GERD-Q ≤ 2 (controlled)",
    subtypeLabel: {gerd:"GERD",barrett:"Barrett's Oesophagus",lpr:"LPR"},
    primaryFlags: ["lateeating","fattyfoods","alcohol","coffee","skippedppi"],
    alarmFlags:   ["dysphagia","odynophagia","hematemesis","unintentionalwl","irondeficiency"],
    summaryFields: e => [
      {label:"Heartburn",    val:["None","Mild","Moderate","Severe"][e.heartburn||0]},
      {label:"Regurgitation",val:["None","Mild","Moderate","Severe"][e.regurg||0]},
      {label:"Sleep impact", val:e.flags?.sleepimpact?"Yes":"No"},
    ]
  },
  celiac: {
    name: "Coeliac Disease",
    abbr: "Celiac OS", accent: "#e8a44a",
    scoreField: null, scoreLabel: "GFD Adherence", scoreMax: null,
    interp: null, interpCls: null,
    remissionTarget: "Strict GFD — zero confirmed gluten exposures",
    subtypeLabel: {},
    primaryFlags: ["strictgfd","labelcheck","eatout"],
    alarmFlags:   ["exposure","hematemesis","severeabdpain","unintentionalwl","newrash","neuro"],
    summaryFields: e => [
      {label:"GFD adherent",   val:e.gfdAdherent?"Yes":"No"},
      {label:"Gluten exposure",val:e.flags?.exposure?"Yes — logged":"No"},
      {label:"Fatigue",        val:["None","Mild","Moderate","Severe"][e.fatigue||0]},
    ],
    getScore: () => ({score:null,label:"GFD Adherence"})
  },
  fd: {
    name: "Functional Dyspepsia",
    abbr: "FD OS", accent: "#5b9bd5",
    scoreField: "lpds", scoreLabel: "LPDS", scoreMax: 18,
    interp:    s => s<=2?"Minimal":s<=6?"Mild":s<=10?"Moderate":"Severe",
    interpCls: s => s<=6?"ok":s<=10?"warn":"danger",
    remissionTarget: "LPDS ≤ 2 (minimal symptoms)",
    subtypeLabel: {eps:"EPS",pds:"PDS",mixed:"EPS/PDS Overlap"},
    primaryFlags: ["stress","anxiety","fattyfoods","coffee","skippedmed","nsaids"],
    alarmFlags:   ["dysphagia","unintentionalwl","hematemesis","melena","progressivevomit","newanemia"],
    summaryFields: e => [
      {label:"Epigastric pain",val:["None","Mild","Moderate","Severe"][e.epipain||0]},
      {label:"Fullness",       val:["None","Mild","Moderate","Severe"][e.fullness||0]},
      {label:"Nausea",         val:["None","Mild","Moderate","Severe"][e.nausea||0]},
    ]
  },
  eoe: {
    name: "Eosinophilic Oesophagitis",
    abbr: "EoE OS", accent: "#e06b6b",
    scoreField: "eoeai", scoreLabel: "EoEAI", scoreMax: 15,
    interp:    s => s<=2?"Remission":s<=6?"Mild":s<=10?"Moderate":"Severe",
    interpCls: s => s<=6?"ok":s<=10?"warn":"danger",
    remissionTarget: "EoEAI ≤ 2 (remission)",
    subtypeLabel: {},
    primaryFlags: ["dryfood","largeportion","fasting","skippedppi","skippedsteroid"],
    alarmFlags:   ["impaction"],
    summaryFields: e => [
      {label:"Dysphagia",    val:["None","Mild","Moderate","Severe"][e.dysphagia||0]},
      {label:"Chest pain",   val:["None","Mild","Moderate","Severe"][e.pain||0]},
      {label:"Regurgitation",val:["None","Mild","Moderate","Severe"][e.regurg||0]},
    ]
  },
  nv: {
    name: "Nausea & Vomiting (CVS)",
    abbr: "N&V OS", accent: "#6b9de8",
    scoreField: "rinvr", scoreLabel: "RINVR", scoreMax: 20,
    interp:    s => s===0?"None":s<=4?"Mild":s<=10?"Moderate":s<=16?"Severe":"Very severe",
    interpCls: s => s<=4?"ok":s<=10?"warn":"danger",
    remissionTarget: "RINVR ≤ 4 (mild or no symptoms)",
    subtypeLabel: {cvs:"CVS",functional:"Functional nausea",mixed:"Mixed"},
    primaryFlags: ["stress","anxiety","skippedmed","fasting","cannabis","hotshower"],
    alarmFlags:   ["hematemesis","coffeegrd","severeabdpain","fever","neuro"],
    summaryFields: e => [
      {label:"Vomiting episodes",val:String(e.vomitCount||0)},
      {label:"Nausea distress",  val:["None","No distress","Mild","Moderate","Severe"][e.nauseaDistress||0]},
      {label:"Fluid intake",     val:e.fluidIntake||"—"},
    ]
  },
  mc: {
    name: "Microscopic Colitis",
    abbr: "MC OS", accent: "#7eb8a4",
    scoreField: "mcai", scoreLabel: "MCAI", scoreMax: 20,
    interp:    s => s<=2?"Remission":s<=6?"Mild":s<=11?"Moderate":"High activity",
    interpCls: s => s<=6?"ok":s<=11?"warn":"danger",
    remissionTarget: "MCAI ≤ 2 (remission) · ≤ 3 stools/day",
    subtypeLabel: {cc:"Collagenous Colitis",lc:"Lymphocytic Colitis",mc:"MC-Unclassified"},
    primaryFlags: ["nocturnal","urgency","incontinence","skippedmed"],
    alarmFlags:   ["blood","fever","severeabdpain","unintentionalwl"],
    summaryFields: e => [
      {label:"Stools/day", val:["0","1–2","3–4","5–6","7–9","≥10"][e.stoolFreq||0]},
      {label:"Nocturnal",  val:e.flags?.nocturnal?"Yes ⚠":"No"},
      {label:"Consistency",val:["Formed","Soft","Loose","Watery"][e.consistency||0]},
    ]
  }
};

// ── DATA HELPERS ──────────────────────────────────────────────
function readLS(key, fb) {
  try { const r=localStorage.getItem(key); return r?JSON.parse(r):fb; }
  catch { return fb; }
}
function loadEntries(k) {
  return readLS(`giplatform_e_${k}`,[]).filter(e=>!e.deleted);
}
function loadSettings(k) {
  return readLS(`giplatform_s_${k}`,{});
}
function filterDays(entries, days) {
  const cut=new Date(); cut.setDate(cut.getDate()-days); cut.setHours(0,0,0,0);
  return entries.filter(e=>new Date(e.ts)>=cut);
}
function mean(arr) {
  return arr.length ? arr.reduce((a,b)=>a+b,0)/arr.length : 0;
}
function trend(arr) {
  if (arr.length<4) return "insufficient data";
  const h=Math.floor(arr.length/2);
  const diff=mean(arr.slice(-h))-mean(arr.slice(0,h));
  if (Math.abs(diff)<0.5) return "stable";
  return diff>0?"worsening":"improving";
}
function countFlag(entries,flag) {
  return entries.filter(e=>e.flags?.[flag]).length;
}
function topFlags(entries,keys,n=5) {
  const cnt={}; keys.forEach(k=>cnt[k]=0);
  entries.forEach(e=>keys.forEach(k=>{if(e.flags?.[k])cnt[k]++;}));
  return Object.entries(cnt).sort((a,b)=>b[1]-a[1])
    .filter(([,v])=>v>0).slice(0,n).map(([k,v])=>({key:k,count:v}));
}
const FLAG_LABELS = {
  stress:"Stress/anxiety",anxiety:"Anxiety",poorslep:"Poor sleep",
  lowfodmap:"Low-FODMAP",reintroducing:"Reintroduction phase",
  skippedmed:"Missed medication",biologic:"Biologic dose",
  lateeating:"Late eating",fattyfoods:"High-fat meal",coffee:"Caffeine",
  alcohol:"Alcohol",nsaids:"NSAIDs",ppitiming:"PPI timing",
  nocturnal:"Nocturnal diarrhoea",urgency:"Urgency",incontinence:"Incontinence",
  cannabis:"Cannabis",hotshower:"Hot shower relief",fasting:"Skipped meal",
  dryfood:"Dry/fibrous food",largeportion:"Large portion",
  exposure:"Gluten exposure",infection:"Infection/illness",
  menstrual:"Menstrual cycle",impaction:"Bolus impaction",
  skippedppi:"Missed PPI",skippedsteroid:"Missed steroid",
  drug_nsaids:"NSAIDs",drug_ppi:"PPIs",drug_ssri:"SSRIs",
  drug_statins:"Statins",drug_aspirin:"Aspirin"
};
function flagLabel(k) { return FLAG_LABELS[k]||(k.replace(/_/g," ")); }

// ── SVG SPARKLINE ─────────────────────────────────────────────
function sparkline(values, max, accent, W=660, H=48) {
  if (!values.length) return "";
  const p=4, w=W-p*2, h=H-p*2;
  const pts=values.map((v,i)=>{
    const x=p+(i/Math.max(values.length-1,1))*w;
    const y=p+h-(Math.min(v,max)/max)*h;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  const line="M "+pts.join(" L ");
  const fill=`M ${pts[0]} L ${pts.join(" L ")} L ${(p+w).toFixed(1)},${(p+h).toFixed(1)} L ${p},${(p+h).toFixed(1)} Z`;
  const [lx,ly]=pts[pts.length-1].split(",");
  return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" style="display:block;">
    <path d="${fill}" fill="${accent}" fill-opacity=".1"/>
    <path d="${line}" fill="none" stroke="${accent}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="${lx}" cy="${ly}" r="3" fill="${accent}"/>
  </svg>`;
}

// ── REPORT HTML ───────────────────────────────────────────────
function buildHTML(key, cfg, entries, settings) {
  const now     = new Date();
  const dateStr = now.toLocaleDateString("en-GB",{day:"numeric",month:"long",year:"numeric"});
  const DAYS    = 42;
  const recent  = filterDays(entries, DAYS);
  const last7   = filterDays(entries, 7);

  if (!entries.length) return `<html><body style="font-family:sans-serif;padding:40px;color:#333;">
    <h2>No data logged yet</h2><p>Log at least a few entries before generating a report.</p></body></html>`;

  // Score helpers
  const getScore = e => {
    if (cfg.getScore) return cfg.getScore(e).score;
    return e[cfg.scoreField]??0;
  };
  const getScoreLabel = e => {
    if (cfg.getScore) return cfg.getScore(e).label;
    return cfg.scoreLabel;
  };

  const rScores  = recent.map(getScore).filter(s=>s!=null);
  const l7Scores = last7.map(getScore).filter(s=>s!=null);
  const meanR    = rScores.length?mean(rScores):null;
  const meanL7   = l7Scores.length?mean(l7Scores):null;
  const scoreTrend = trend(rScores.slice(-14));

  const latest   = [...entries].sort((a,b)=>b.ts.localeCompare(a.ts))[0];
  const latestSc = latest?getScore(latest):null;
  const latestLbl= latest?getScoreLabel(latest):cfg.scoreLabel;
  const subtype  = settings.subtype;
  const subtypeLbl = subtype?(cfg.subtypeLabel?.[subtype]||subtype):"Not specified";

  const alarmDetails = cfg.alarmFlags
    .map(f=>({label:flagLabel(f),count:countFlag(recent,f)}))
    .filter(x=>x.count>0);

  const triggers   = topFlags(recent,cfg.primaryFlags,5);
  const skippedCnt = countFlag(recent,"skippedmed");
  const adherPct   = recent.length?Math.round(((recent.length-skippedCnt)/recent.length)*100):null;
  const goodDays   = recent.filter(e=>e.quality==="great").length;
  const roughDays  = recent.filter(e=>e.quality==="rough").length;
  const lastFive   = [...entries].sort((a,b)=>b.ts.localeCompare(a.ts)).slice(0,5);

  // Sparkline
  const sparkVals = [...entries].sort((a,b)=>a.ts.localeCompare(b.ts))
    .slice(-28).map(getScore).filter(s=>s!=null);
  const sparkMax  = cfg.scoreMax||Math.max(...sparkVals,1);

  // Colours
  const clrMap = {ok:"#1a7a50",warn:"#a06000",danger:"#9b2335"};
  const ic     = cfg.interpCls&&latestSc!=null?cfg.interpCls(latestSc):"ok";
  const scColor= clrMap[ic]||"#333";
  const scInterp= cfg.interp&&latestSc!=null?cfg.interp(latestSc):"—";
  const trendClr = scoreTrend==="improving"?"#1a7a50":scoreTrend==="worsening"?"#9b2335":"#888";
  const trendIcon= scoreTrend==="improving"?"↓ Improving":scoreTrend==="worsening"?"↑ Worsening":"→ Stable";

  // Table
  const fields0  = lastFive.length&&cfg.summaryFields?cfg.summaryFields(lastFive[0]):[];
  const theads   = `<tr><th>Date</th><th>Day</th><th>${latestLbl||"Score"}</th>${fields0.map(f=>`<th>${escHtml(f.label)}</th>`).join("")}<th>Note</th></tr>`;
  const trows    = lastFive.map(e=>{
    const sc  = getScore(e);
    const eci = cfg.interpCls?cfg.interpCls(sc):"ok";
    const eil = cfg.interp?cfg.interp(sc):"—";
    const flds= cfg.summaryFields?cfg.summaryFields(e):[];
    const flag= e.flags?.nocturnal?"⚠ Nocturnal":e.flags?.impaction?"⚠ Impaction":e.flags?.blood?"⚠ Blood":"";
    return `<tr>
      <td>${new Date(e.ts).toLocaleDateString("en-GB",{day:"numeric",month:"short"})}</td>
      <td>${e.quality||"—"}</td>
      ${sc!=null?`<td style="color:${clrMap[eci]};font-weight:600;">${sc}<span style="font-weight:400;font-size:9px;color:#888;"> ${eil}</span></td>`:"<td>—</td>"}
      ${flds.map(f=>`<td>${f.val}</td>`).join("")}
      <td style="color:${flag?"#a06000":"#ccc"}">${flag||""}</td>
    </tr>`;
  }).join("");

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${cfg.name} — Clinician Report · ${dateStr}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',system-ui,sans-serif;background:#fff;color:#1a1a1a;font-size:11px;line-height:1.5;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.page{max-width:780px;margin:0 auto;padding:32px 32px 24px}

/* HEADER */
.hdr{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:14px;border-bottom:2.5px solid ${cfg.accent};margin-bottom:18px}
.hdr-title{font-size:17px;font-weight:600}
.hdr-sub{font-size:10px;color:#888;margin-top:2px}
.hdr-bar{width:32px;height:3px;background:${cfg.accent};border-radius:2px;margin-top:6px}
.hdr-meta{text-align:right;font-size:10px;color:#888;line-height:1.9}
.hdr-meta b{color:#1a1a1a}

/* ALARM */
.alarm{background:#fff5f5;border:1px solid #fcc;border-left:3px solid #9b2335;border-radius:6px;padding:9px 12px;margin-bottom:14px}
.alarm-t{font-weight:600;color:#9b2335;font-size:11px;margin-bottom:3px}
.alarm-d{color:#666;font-size:10px}

/* GRID */
.g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:12px}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px}
.card{border:1px solid #e8e8e8;border-radius:7px;padding:11px 13px}
.card-top{border-top:2.5px solid ${cfg.accent}}
.clbl{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:#aaa;margin-bottom:5px}
.cval{font-size:26px;font-weight:700;line-height:1}
.csub{font-size:10px;color:#888;margin-top:3px}

/* SCORE BIG */
.sc-big{font-size:44px;font-weight:700;line-height:1;color:${cfg.accent}}
.sc-interp{font-size:11px;font-weight:600;margin-top:3px}
.sc-date{font-size:10px;color:#aaa;margin-top:2px}

/* TREND */
.trend-pill{display:inline-flex;align-items:center;padding:2px 8px;border-radius:100px;font-size:10px;font-weight:500;background:#f5f5f5;color:${trendClr}}

/* SECTION */
.sh{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#bbb;margin:14px 0 7px;padding-bottom:4px;border-bottom:1px solid #f0f0f0}

/* TABLE */
table{width:100%;border-collapse:collapse;font-size:10px}
th{text-align:left;padding:5px 7px;background:#f8f8f8;font-weight:500;color:#666;font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.05em;text-transform:uppercase}
td{padding:5px 7px;border-bottom:1px solid #f5f5f5;color:#333}
tr:last-child td{border-bottom:none}

/* TRIGGERS */
.pills{display:flex;flex-wrap:wrap;gap:5px;margin-top:5px}
.pill{padding:3px 8px;border-radius:100px;background:#f5f5f5;color:#555;font-size:10px;font-family:'DM Mono',monospace}

/* QUAL BARS */
.qrow{display:flex;justify-content:space-between;align-items:center;margin-bottom:3px;font-size:10px}
.qbar-wrap{flex:1;height:4px;background:#f0f0f0;border-radius:2px;margin:0 8px;overflow:hidden}
.qbar{height:100%;border-radius:2px}

/* DISCLAIMER */
.disc{margin-top:18px;padding-top:12px;border-top:1px solid #eee;font-size:9px;color:#ccc;line-height:1.7;text-align:center}

/* PRINT BUTTON */
.print-btn{text-align:center;margin-top:20px}
.print-btn button{padding:11px 28px;border:none;border-radius:5px;cursor:pointer;font-family:'DM Sans',sans-serif;font-size:12px;font-weight:500}
.btn-dark{background:#1a1a1a;color:#fff;margin-right:8px}
.btn-light{background:#f5f5f5;color:#333;border:1px solid #ddd}

@media print{
  .print-btn{display:none}
  body{font-size:10px}
  .page{padding:18px}
  @page{margin:1.5cm;size:A4}
}
</style>
</head>
<body>
<div class="page">

<!-- HEADER -->
<div class="hdr">
  <div>
    <div class="hdr-title">${cfg.name}</div>
    <div class="hdr-sub">Clinician Summary Report · GI OS</div>
    <div class="hdr-bar"></div>
  </div>
  <div class="hdr-meta">
    <div>Generated: <b>${dateStr}</b></div>
    <div>Period: <b>Last ${DAYS} days</b></div>
    <div>Entries this period: <b>${recent.length}</b> of <b>${entries.length}</b> total</div>
    ${subtype!=="Not specified"?`<div>Diagnosis: <b>${escHtml(String(subtypeLbl))}</b></div>`:""}
  </div>
</div>

${alarmDetails.length?`
<div class="alarm">
  <div class="alarm-t">⚠ Alarm features logged — past ${DAYS} days</div>
  <div class="alarm-d">${alarmDetails.map(a=>`${escHtml(a.label)} (${a.count} day${a.count>1?"s":""})`).join(" · ")}</div>
</div>`:""}

<!-- SCORE -->
<div class="sh">Clinical score — ${latestLbl||cfg.scoreLabel}</div>
<div class="g3">

  <div class="card card-top">
    <div class="clbl">Latest score</div>
    ${latestSc!=null?`
    <div class="sc-big">${latestSc}</div>
    <div class="sc-interp" style="color:${scColor}">${scInterp}</div>
    <div class="sc-date">${new Date(latest.ts).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"})}</div>
    `:`<div class="cval" style="color:#ccc">—</div><div class="csub">No data</div>`}
  </div>

  <div class="card">
    <div class="clbl">${DAYS}-day mean</div>
    <div class="cval" style="color:${cfg.accent}">${meanR!=null?meanR.toFixed(1):"—"}</div>
    <div class="csub">7-day mean: ${meanL7!=null?meanL7.toFixed(1):"—"}</div>
    <div style="margin-top:8px"><span class="trend-pill">${trendIcon}</span></div>
  </div>

  <div class="card">
    <div class="clbl">Days logged</div>
    <div style="margin-top:3px">
      <div class="qrow"><span style="color:#1a7a50">Good</span><div class="qbar-wrap"><div class="qbar" style="width:${recent.length?Math.round(goodDays/recent.length*100):0}%;background:#78c2a4"></div></div><b style="color:#1a7a50">${goodDays}</b></div>
      <div class="qrow"><span style="color:#9b2335">Rough</span><div class="qbar-wrap"><div class="qbar" style="width:${recent.length?Math.round(roughDays/recent.length*100):0}%;background:#e07a5f"></div></div><b style="color:#9b2335">${roughDays}</b></div>
      ${adherPct!=null?`<div class="qrow" style="margin-top:5px;padding-top:5px;border-top:1px solid #f0f0f0"><span>Med adherence</span><div class="qbar-wrap"><div class="qbar" style="width:${adherPct}%;background:${cfg.accent}"></div></div><b>${adherPct}%</b></div>`:""}
    </div>
  </div>

</div>

${sparkVals.length>=4?`
<div class="card" style="margin-bottom:12px;padding:10px 12px 7px">
  <div class="clbl">${latestLbl||cfg.scoreLabel} trend — last ${sparkVals.length} entries · max ${sparkMax}</div>
  ${sparkline(sparkVals,sparkMax,cfg.accent)}
  <div style="display:flex;justify-content:space-between;font-size:9px;color:#ccc;margin-top:1px"><span>${entries.length>=28?"28 entries ago":"First entry"}</span><span>Today</span></div>
  <div style="margin-top:4px;font-size:9px;color:#aaa">Remission target: ${cfg.remissionTarget}</div>
</div>`:""}

<!-- TRIGGERS + TREATMENT -->
<div class="g2">
  <div class="card">
    <div class="clbl">Top triggers — ${DAYS} days</div>
    ${triggers.length?`<div class="pills">${triggers.map(t=>`<span class="pill">${flagLabel(t.key)} · ${t.count}d</span>`).join("")}</div>`
    :`<div style="color:#aaa;margin-top:5px;font-size:10px">No consistent triggers flagged.</div>`}
  </div>
  <div class="card">
    <div class="clbl">Treatment snapshot</div>
    <div style="font-size:10px;color:#444;margin-top:3px;line-height:2">
      ${subtype!=="Not specified"?`<div>Diagnosis: <b>${escHtml(String(subtypeLbl))}</b></div>`:""}
      ${settings.dietPhase?`<div>Diet phase: <b>${escHtml(String(settings.dietPhase))}</b></div>`:""}
      ${adherPct!=null?`<div>Medication adherence: <b>${adherPct}%</b></div>`:""}
      ${skippedCnt>0?`<div style="color:#a06000">Missed doses: <b>${skippedCnt}</b> of ${recent.length} days</div>`:""}
    </div>
  </div>
</div>

<!-- RECENT ENTRIES -->
<div class="sh">Recent entries — last 5 logged</div>
<table><thead>${theads}</thead><tbody>${trows}</tbody></table>

<!-- DISCLAIMER -->
<div class="disc">
  This report was generated by GI OS, a patient symptom tracking application built by a practicing gastroenterologist.
  It is intended to supplement clinical consultation, not replace it. Scores are patient-reported and have not been
  independently verified. Clinical decisions should be made by a qualified healthcare professional following full
  clinical assessment. GI OS is a symptom diary tool — not a diagnostic or treatment recommendation system.
</div>

${typeof PremiumGate !== 'undefined' && !PremiumGate.isPremium() ? `
<div style="margin:16px 0 8px;padding:10px 14px;border:1px solid #ddd;border-radius:6px;font-size:11px;color:#888;text-align:center;">
  Generated on GI OS free tier &nbsp;·&nbsp; Upgrade for trend analysis and personalized next steps &nbsp;·&nbsp; <strong>giOS.app</strong>
</div>` : ''}

<div class="print-btn">
  <button class="btn-dark" onclick="window.print()">Print / Save as PDF</button>
  <button class="btn-light" onclick="window.close()">Close</button>
</div>

</div>
</body>
</html>`;
}

// ── PUBLIC API ────────────────────────────────────────────────
function generate(moduleKey) {
  const cfg = MODULE_CONFIGS[moduleKey];
  if (!cfg) { alert("Unknown module: "+moduleKey); return; }
  const entries  = loadEntries(moduleKey);
  const settings = loadSettings(moduleKey);
  const html     = buildHTML(moduleKey, cfg, entries, settings);
  const win      = window.open("","_blank","width=880,height=940,scrollbars=yes");
  if (!win) { alert("Allow popups to generate the clinician report."); return; }
  win.document.write(html);
  win.document.close();
}

return { generate };
})();
