/* META
 * @title      Microscopic Colitis OS — Clinical Tracker
 * @accent     #7eb8a4
 * @accent2    #e8c56b
 * @accentGlow rgba(126,184,164,.12)
 */

/**
 * Microscopic Colitis OS — Module
 * ═══════════════════════════════════════════════════════════
 * Collagenous colitis / lymphocytic colitis subtyping,
 * stool frequency and consistency (Bristol), nocturnal
 * diarrhea tracking (pathognomonic feature), medication
 * tracking (budesonide, cholestyramine, bismuth),
 * drug trigger identification, MCA Activity Index proxy,
 * library covering diagnosis, drug triggers, budesonide
 * maintenance, bile acid malabsorption overlap,
 * dietary management, associated conditions, red flags.
 * ═══════════════════════════════════════════════════════════
 */

(() => {
"use strict";

const { Util, Stats, Charts, LibRenderer, IO, KPI, Perf, Disclosure, initStorage, updateStorageModeUI } = Platform;
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

const MODULE_KEY = "mc";

// Histological subtypes
const SUBTYPES = {
  cc:   "CC — Collagenous Colitis",
  lc:   "LC — Lymphocytic Colitis",
  mc:   "MC — Unclassified / Pending biopsy"
};

// Stool frequency bands (key metric in MC)
const STOOL_FREQ = [
  { val:0, label:"0",      desc:"None" },
  { val:1, label:"1–2",    desc:"Normal range" },
  { val:2, label:"3–4",    desc:"Mildly elevated" },
  { val:3, label:"5–6",    desc:"Moderate — consistent with active MC" },
  { val:4, label:"7–9",    desc:"High — active disease" },
  { val:5, label:"≥10",    desc:"Very high — consider hospitalization if persistent" }
];

// Drug triggers (most important modifiable cause)
const DRUG_TRIGGERS = [
  { id:"nsaids",      label:"NSAIDs",           risk:"high",  note:"Strongest association — ibuprofen, naproxen, diclofenac" },
  { id:"aspirin",     label:"Aspirin",          risk:"high",  note:"Low-dose aspirin also implicated" },
  { id:"ppi",         label:"PPIs",             risk:"high",  note:"Lansoprazole highest risk; omeprazole, pantoprazole also implicated" },
  { id:"ssri",        label:"SSRIs",            risk:"mod",   note:"Sertraline, paroxetine — mechanism unclear" },
  { id:"statins",     label:"Statins",          risk:"mod",   note:"Simvastatin, atorvastatin" },
  { id:"acarbose",    label:"Acarbose",         risk:"mod",   note:"Strong individual case evidence" },
  { id:"ticlopidine", label:"Ticlopidine",      risk:"high",  note:"Strongest individual drug association reported" },
  { id:"newmed",      label:"New medication",   risk:"flag",  note:"Any new drug started within 3 months of symptom onset" }
];

const FLAG_KEYS = [
  "nocturnal","urgency","incontinence","cramping","bloating",
  "fatigue","weightloss","nausea","skippedmed","stress","dairy","gluten","coffee","alcohol"
];

const ALARM_FLAGS = ["blood","fever","severeabdpain","unintentionalwl","newonset"];

// MC Activity Index proxy
// Based on Hjortswang et al. / Miehlke criteria
// Primary: stool frequency. Secondary: nocturnal, urgency, cramping, consistency
function calcMCAI(d) {
  let s = 0;
  s += Util.clamp(d.stoolFreq, 0, 5) * 2;   // stool frequency — dominant
  s += Util.clamp(d.consistency, 0, 3);       // Bristol (inverted: watery = 3)
  s += d.flags?.nocturnal ? 2 : 0;            // nocturnal diarrhea — pathognomonic weight
  s += d.flags?.urgency   ? 1 : 0;
  s += d.flags?.cramping  ? 1 : 0;
  s += d.flags?.incontinence ? 2 : 0;
  return Math.min(20, s);
}

function interpMCAI(score) {
  if (score <= 2)  return { label:"Remission",         cls:"ok",     color:"var(--ok)" };
  if (score <= 6)  return { label:"Mild activity",     cls:"ok",     color:"var(--ok)" };
  if (score <= 11) return { label:"Moderate activity", cls:"warn",   color:"var(--warn)" };
  return                  { label:"High activity",     cls:"danger", color:"var(--danger)" };
}

// Bristol consistency (diarrhea-focused labelling)
const BRISTOL_OPTS = [
  { val:0, label:"Formed",      bris:"3–4", desc:"Normal" },
  { val:1, label:"Soft",        bris:"5",   desc:"Slightly loose" },
  { val:2, label:"Loose",       bris:"6",   desc:"Mushy / poorly formed" },
  { val:3, label:"Watery",      bris:"7",   desc:"Liquid — no solid pieces" }
];

function defaultFlags() {
  const f = {};
  [...FLAG_KEYS, ...ALARM_FLAGS].forEach(k => f[k] = false);
  DRUG_TRIGGERS.forEach(d => f["drug_"+d.id] = false);
  return f;
}

function defaultDraft() {
  return {
    subtype: null, quality: null,
    stoolFreq: 0, consistency: 0,
    budesonidePhase: null,
    flags: defaultFlags(), notes: ""
  };
}

// ── LIBRARY ──────────────────────────────────────────────────────
const LIBRARY = (() => {
  const cards = [];
  const add = o => cards.push({ id:(o.cat+"::"+o.title).toLowerCase().replace(/[^a-z0-9]+/g,"-"), ...o });

  add({ cat:"About MC", tag:"dx", title:"What Is Microscopic Colitis",
    why:"Microscopic Colitis is one of the most common causes of chronic non-bloody watery diarrhea in adults over 50 — yet it is frequently overlooked or labelled as IBS-D for years because the colon looks completely normal on colonoscopy. Biopsy is required to confirm it.",
    bullets:[
      "Definition: chronic inflammatory condition of the colon characterised by watery, non-bloody diarrhea with a macroscopically normal or near-normal colonoscopy. Diagnosis is histological — biopsy is mandatory. Two subtypes: Collagenous Colitis (CC) — thickened subepithelial collagen band >10 μm on biopsy; Lymphocytic Colitis (LC) — increased intraepithelial lymphocytes >20 per 100 epithelial cells. Both subtypes have identical clinical presentation and treatment.",
      "Epidemiology: prevalence approximately 100–200 per 100,000. Peak incidence in women aged 60–70. Strong female predominance (CC 8:1 female:male; LC 3:1). Incidence has risen substantially over past three decades — likely reflects both improved diagnosis and true increase. Associated with autoimmune conditions (thyroid disease, celiac disease, rheumatoid arthritis, type 1 diabetes) and drug exposure.",
      "The key diagnostic feature: watery non-bloody diarrhea, frequently nocturnal, with a normal-appearing colon on colonoscopy. Nocturnal diarrhea is a critical clinical clue — it strongly suggests an organic rather than functional cause. IBS does not cause nocturnal diarrhea. Any patient labelled IBS-D who reports nocturnal symptoms should be biopsied."
    ],
    action:"If you are awaiting biopsy results: log stool frequency and nocturnal episodes daily. This baseline data is the primary outcome measure for treatment response once your biopsy results are available. If you have been biopsied and told the colon 'looks normal' but results are pending — this is expected in MC. The condition is only visible under the microscope, not on visual inspection.",
    more:"MC can coexist with IBS and celiac disease. An IBS label does not exclude MC — both can be present simultaneously. Any IBS-D patient who develops nocturnal diarrhea, has lost weight, or has not responded to dietary modification should be investigated for MC with colonoscopy and biopsy.",
    evidence:"Bonderup et al., Gut 2003; Pardi et al., Gastroenterology 2007; Rasmussen et al., Aliment Pharmacol Ther 2016; Münch et al., J Crohns Colitis 2012 (European guidelines)"
  });

  add({ cat:"Diagnosis", tag:"dx", title:"Nocturnal Diarrhea — The Key Clinical Clue",
    why:"Nocturnal diarrhea is the single most important symptom that distinguishes organic diarrhea from functional diarrhea. It is present in the majority of active MC patients and is essentially absent in IBS.",
    bullets:[
      "Clinical significance: the enteric nervous system normally suppresses colonic motility during sleep. Organic inflammatory conditions — MC, IBD, bile acid malabsorption — override this suppression. Functional conditions (IBS) do not. Waking from sleep to pass stool is therefore a red flag for organic disease that must be investigated, not attributed to IBS.",
      "Frequency in MC: nocturnal diarrhea occurs in approximately 40–70% of active MC patients. It is often the symptom that most impacts quality of life — disrupted sleep compounds the fatigue already caused by active disease and malabsorption.",
      "Log nocturnal episodes separately: the nocturnal flag in this app is tracked independently from daytime stool frequency. In the Insights tab, nocturnal episode frequency correlates with overall MCAI score and treatment response — it is the most sensitive marker of disease activity in many patients."
    ],
    action:"Log nocturnal episodes every day — even if it feels like the same answer. Over 30 entries, the pattern of nocturnal episodes before and after treatment changes is the clearest signal of whether budesonide is working. This is the data your gastroenterologist most needs.",
    evidence:"Pardi et al., Gastroenterology 2007; Olesen & Münch, Gut 2004; Bohr et al., Gut 1996"
  });

  add({ cat:"Drug Triggers", tag:"drugs", title:"Drug-Induced Microscopic Colitis",
    why:"Drug exposure is the most important and most actionable cause of MC. Identifying and stopping the causative drug is the only intervention that can produce permanent remission without ongoing medication.",
    bullets:[
      "Highest-risk drugs: NSAIDs (ibuprofen, naproxen, diclofenac, celecoxib — all implicated), low-dose aspirin, PPIs (lansoprazole has the strongest evidence — OR 4.5 in population studies; omeprazole and pantoprazole also implicated), ticlopidine (strongest individual drug association), SSRIs (sertraline, paroxetine), statins (simvastatin, atorvastatin), acarbose.",
      "Mechanism: drug-induced MC is not a simple allergic reaction. The proposed mechanisms include direct epithelial toxicity, alteration of the mucosal immune response, and bile acid metabolism disruption. The latency between drug initiation and symptom onset can be months to years — making the association easy to miss.",
      "Drug withdrawal: stopping the causative drug produces complete clinical and histological remission in a significant proportion of patients — without budesonide. This should always be the first step when a plausible drug trigger is identified. Allow 4–8 weeks after drug cessation before assessing response — histological recovery lags clinical improvement."
    ],
    action:"Use the Drug Triggers section to log every medication you take. The most important question to answer: was any drug started within 3–12 months of symptom onset? Discuss drug rationalisation with your gastroenterologist and prescribing doctor before starting budesonide — stopping the trigger may be all that is needed.",
    more:"The PPI-MC association is particularly important because PPIs are ubiquitous and often prescribed indefinitely without review. Lansoprazole has the highest reported risk. Switching from lansoprazole to omeprazole or rabeprazole, or stopping PPI entirely if clinically safe, is a reasonable first step in PPI-exposed MC patients before committing to budesonide therapy.",
    evidence:"Fernández-Bañares et al., Aliment Pharmacol Ther 2007; Riddell & Tanaka, Histopathology 1992; Bonderup et al., Gut 2014; Münch et al., J Crohns Colitis 2012"
  });

  add({ cat:"Medical Therapy", tag:"meds", title:"Budesonide in Microscopic Colitis",
    why:"Budesonide is the most effective treatment for MC and has the strongest evidence base of any intervention. It achieves clinical remission in 80–85% of patients. Understanding the induction and maintenance distinction is key to avoiding the most common treatment error.",
    bullets:[
      "Induction: budesonide 9mg daily for 8 weeks. Clinical response (defined as <3 stools/day) typically within 2 weeks. Histological remission lags clinical response. Do not stop at 8 weeks without reassessment — premature discontinuation is the most common cause of relapse.",
      "Maintenance: MC has a high relapse rate after stopping budesonide — approximately 60–80% relapse within 6 months of discontinuation. Maintenance therapy at 6mg or 3mg daily (tapered dose) significantly reduces relapse risk. Duration of maintenance is individualised — some patients require long-term low-dose budesonide indefinitely. Discuss with your gastroenterologist.",
      "Why budesonide, not prednisolone: budesonide has >90% first-pass hepatic metabolism — it acts topically in the gut with minimal systemic corticosteroid exposure. Long-term budesonide at maintenance doses has a substantially better safety profile than systemic corticosteroids. Osteoporosis risk exists but is significantly lower than prednisolone equivalent."
    ],
    action:"Log budesonide dose and adherence daily. Missing doses during induction is the most common cause of treatment failure. Track stool frequency weekly — response within 2 weeks is a good prognostic sign. If no response at 4 weeks on 9mg, contact your gastroenterologist — reconsider diagnosis, drug triggers, or coexisting celiac.",
    more:"Bismuth subsalicylate (Pepto-Bismol) has open-label evidence for MC — 8 tablets daily for 8 weeks produces remission in approximately 80% of patients in small trials. It is useful when budesonide is not available, not tolerated, or as an adjunct. Cholestyramine addresses the bile acid malabsorption component that coexists in some MC patients.",
    evidence:"Bonderup et al., Gut 2003; Miehlke et al., Gastroenterology 2009; Gentile et al., Am J Gastroenterol 2013; Münch et al., J Crohns Colitis 2012"
  });

  add({ cat:"Medical Therapy", tag:"meds", title:"Alternatives When Budesonide Fails or Is Not Available",
    why:"A minority of patients do not respond to budesonide or relapse despite maintenance. Several alternatives have evidence in this setting.",
    bullets:[
      "Bismuth subsalicylate: 8 tablets (262mg each) daily for 8 weeks. Open-label evidence — remission in 77–100% of small cohorts. Mechanism: mucosal protective and anti-inflammatory effects. Side effects: darkening of stool and tongue (harmless, bismuth-related), constipation. Tinnitus at high doses — stop if this occurs.",
      "Cholestyramine: bile acid sequestrant. Addresses the bile acid malabsorption component that is present in a subset of MC patients (particularly post-cholecystectomy or with terminal ileal disease). 4g one to three times daily with meals. Particularly useful in patients with documented bile acid malabsorption on SeHCAT scan.",
      "Immunomodulators (azathioprine, methotrexate): reserved for budesonide-refractory MC. Small case series evidence. Reserved for specialist centre management. Anti-TNF agents (infliximab, adalimumab) have been used in severe refractory cases — very limited evidence but mechanistically plausible given the inflammatory pathophysiology."
    ],
    action:"If budesonide has failed twice or relapse occurs on maintenance: log this clearly in Notes and request specialist GI review. Budesonide-refractory MC needs investigation for coexisting celiac disease (present in 5–10% of MC patients), drug triggers not yet addressed, and consideration of immunomodulator therapy.",
    evidence:"Fine et al., Ann Intern Med 1998 (bismuth); Ung et al., Aliment Pharmacol Ther 2000 (cholestyramine); Münch et al., J Crohns Colitis 2012"
  });

  add({ cat:"Associated Conditions", tag:"assoc", title:"Celiac Disease and MC — A Critical Overlap",
    why:"Celiac disease coexists with MC in 5–10% of patients — far higher than population prevalence. Every MC patient should be tested for celiac disease. Missing celiac as a coexisting diagnosis is the most common reason for MC treatment failure.",
    bullets:[
      "Prevalence: celiac disease is found in 5–10% of MC patients vs approximately 1% of the general population. The association is bidirectional — MC patients have higher celiac prevalence and celiac patients have higher MC prevalence. Shared autoimmune mechanisms and HLA associations underlie both.",
      "Clinical significance: celiac disease in an MC patient drives ongoing diarrhea regardless of budesonide therapy. If MC is not responding to budesonide, celiac must be excluded. TTG-IgA serology (with total IgA to exclude IgA deficiency) should be checked in all MC patients — ideally at diagnosis.",
      "Management: if celiac is confirmed, a strict gluten-free diet addresses both conditions simultaneously. GFD adherence in a patient with both conditions is even more critical — gluten exposure perpetuates both the enteric inflammation driving diarrhea and the intestinal permeability amplifying MC activity."
    ],
    action:"If you have MC and have not been tested for celiac: ask your gastroenterologist for TTG-IgA serology. If positive, request upper GI endoscopy with duodenal biopsy. If you have both MC and celiac: strict GFD is mandatory, not optional — it is treating two conditions simultaneously.",
    evidence:"Olesen & Münch, Gut 2004; Fernández-Bañares et al., Aliment Pharmacol Ther 2007; Stewart et al., Am J Gastroenterol 2011"
  });

  add({ cat:"Associated Conditions", tag:"assoc", title:"Bile Acid Malabsorption in MC",
    why:"Bile acid malabsorption (BAM) coexists with MC in approximately 30–40% of patients and contributes to diarrhea independently of colonic inflammation. Treating MC without addressing BAM produces incomplete symptom control.",
    bullets:[
      "Mechanism: bile acids normally reabsorbed in the terminal ileum. In BAM, excess bile acids reach the colon and cause secretory diarrhea by stimulating chloride and water secretion. This is a separate mechanism from eosinophilic/collagenous inflammation — both can drive diarrhea simultaneously.",
      "Diagnosis: SeHCAT (75Se-homotaurocholic acid) nuclear medicine test is the gold standard — measures bile acid retention at 7 days (<15% retention = BAM). FGF19 serum level and 7α-hydroxy-4-cholesten-3-one (C4) are alternative biomarkers. If SeHCAT is unavailable, an empirical trial of cholestyramine is diagnostically informative.",
      "Treatment: cholestyramine (bile acid sequestrant) 4g with meals, or colesevelam (better tolerated). If diarrhea partially responds to budesonide but residual symptoms persist, BAM should be considered — adding cholestyramine to budesonide addresses both mechanisms."
    ],
    action:"If your diarrhea has not fully resolved on budesonide: discuss SeHCAT testing or empirical cholestyramine with your gastroenterologist. BAM is frequently overlooked in MC — it accounts for a significant proportion of cases that appear treatment-resistant but actually involve dual-mechanism diarrhea.",
    evidence:"Ung et al., Aliment Pharmacol Ther 2000; Pardi & Kelly, Gastroenterology 2011; Miehlke & Madisch, Dtsch Med Wochenschr 2014"
  });

  add({ cat:"Dietary Management", tag:"diet", title:"Diet in Microscopic Colitis",
    why:"No dietary intervention has been shown to induce histological remission in MC. However, dietary modification can reduce symptom burden and identify dietary cofactors that worsen diarrhea.",
    bullets:[
      "Lactose: lactose intolerance is common in active MC due to secondary disaccharidase deficiency from mucosal inflammation. A 4-week lactose-free trial during active disease is reasonable — not because dairy causes MC but because damaged mucosa cannot process lactose efficiently. Reintroduce once remission is achieved.",
      "Gluten: only avoid gluten if celiac disease is confirmed on biopsy. Empirical gluten avoidance without a celiac diagnosis is not evidence-based in MC and may interfere with celiac serology if later tested.",
      "Caffeine and alcohol: both stimulate colonic motility and can worsen diarrhea during active disease. Reduction during flares is pragmatic — neither cause MC but both amplify symptom severity. Reintroduce cautiously during remission.",
      "Fibre: soluble fiber (oats, psyllium) may help stool consistency by absorbing excess fluid. Insoluble fiber (bran, raw vegetables) may worsen diarrhea during active disease. A low-residue diet during active flares reduces colonic load and may reduce urgency."
    ],
    action:"Log dietary flags consistently. The Insights tab will show whether dairy, gluten, coffee, or alcohol flags correlate with higher MCAI scores on the following day. This is personal data — what worsens your symptoms may differ from another MC patient.",
    evidence:"Münch et al., J Crohns Colitis 2012; Pardi & Kelly, Gastroenterology 2011"
  });

  add({ cat:"Red Flags", tag:"safety", title:"When to Seek Urgent Review in MC",
    why:"MC is a chronic manageable condition. These features require prompt evaluation.",
    bullets:[
      "Urgent: blood in stool — MC causes non-bloody diarrhea. Any rectal bleeding requires investigation for an alternative or coexisting diagnosis (IBD, colorectal cancer, haemorrhoids do not cause MC-pattern diarrhea). Fever with diarrhea — suggests infectious colitis requiring stool culture before empirical treatment. Unintentional weight loss >5% — investigate for celiac, malabsorption, or alternative diagnosis.",
      "Same day: severe dehydration from very high stool frequency (≥10/day) unresponsive to oral rehydration. Signs of dehydration: dizziness on standing, reduced urine output, confusion.",
      "This month: no response to budesonide 9mg after 4 weeks — reconsider diagnosis, drug triggers, coexisting celiac. New onset symptoms after previously established remission — check for reintroduction of a drug trigger, new medication, or dietary change."
    ],
    action:"Blood in stool in a patient with known MC = contact gastroenterologist within 24–48 hours. This is not a normal feature of MC and requires investigation. Watery diarrhea ≥10 times per day for >48 hours without response to oral fluids = consider emergency department for IV rehydration.",
    evidence:"Münch et al., J Crohns Colitis 2012; Pardi et al., Gastroenterology 2007"
  });

  return { cards };
})();

const LIB_CATS = ["all", ...new Set(LIBRARY.cards.map(c => c.cat))];

// ── STATE ────────────────────────────────────────────────────────
const State = {
  store: null, premium: false,
  subtype: null,
  draft: defaultDraft(), lastEntry: null,
  libCat: "all", libQuery: ""
};

// ── HTML ─────────────────────────────────────────────────────────
function renderHTML() {
  document.getElementById("module-root").innerHTML = `
<div class="p-app">
  <header class="p-header">
    <div class="p-brand">
      <div class="p-logo-dot" aria-hidden="true"></div>
      <div>
        <h1 class="p-brand-name">Microscopic Colitis OS</h1>
        <div class="p-brand-sub">Symptom tracker</div>
      </div>
    </div>
    <div class="p-header-right">
      <div class="p-pill">🔥 <b id="kpiStreak">0</b>&nbsp;·&nbsp;7d <b id="kpi7d">0</b>&nbsp;·&nbsp;<b id="kpiTotal">0</b> total</div>
    </div>
  </header>

  <nav class="p-nav">
    <div class="p-tabs" role="tablist">
      <button class="p-tab" role="tab" id="tab-log"      aria-selected="true"  data-tab="log"      type="button">Log</button>
      <button class="p-tab" role="tab" id="tab-history"  aria-selected="false" data-tab="history"  type="button">History</button>
      <button class="p-tab" role="tab" id="tab-library"  aria-selected="false" data-tab="library"  type="button">Library</button>
      <button class="p-tab" role="tab" id="tab-insights" aria-selected="false" data-tab="insights" type="button">Insights</button>
    </div>
  </nav>

  <!-- LOG -->
  <section id="view-log">
    <div class="p-grid two">
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>How are you today?</h2><p>Takes about a minute</p></div>
          <div class="p-kpis"><div class="p-kpi">Date <b id="todayLabel"></b></div></div>
        </div>
        <div class="p-card-b">

          <!-- Step 1: Subtype -->
          <div id="stepSubtype">
            <div class="p-labelrow"><div class="p-lbl">First — what's your MC type?</div><div class="p-hint">saved permanently</div></div>
            <div class="p-seg">
              ${Object.entries(SUBTYPES).map(([k,v]) =>
                `<button class="p-segBtn" type="button" data-sub="${k}" aria-pressed="false" style="font-size:11px;">${v.split(" — ")[0]}</button>`
              ).join("")}
            </div>
            <div id="subtypeConfirm" class="hidden" style="margin-top:8px;">
              <div class="p-callout" style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
                <span>Subtype: <b id="subtypeLabel">—</b></span>
                <button class="p-btn ghost sm" type="button" id="btnChangeSub">Change</button>
              </div>
            </div>
          </div>

          <!-- Step 2: Overall day -->
          <div id="stepQuality" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">How was today overall?</div><div class="p-hint">required</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-quality="great" aria-pressed="false">Great</button>
              <button class="p-segBtn" type="button" data-quality="okay"  aria-pressed="false">Okay</button>
              <button class="p-segBtn" type="button" data-quality="rough" aria-pressed="false">Rough</button>
            </div>
          </div>

          <!-- Step 3: Stool frequency -->
          <div id="stepFreq" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">How many bowel movements today?</div><div class="p-hint">tap to select</div></div>
            <div style="display:flex;flex-direction:column;gap:6px;">
              ${STOOL_FREQ.map(f => `
              <button class="p-freqOpt" type="button" data-freq="${f.val}" aria-selected="${f.val===0?"true":"false"}">
                <div style="display:flex;align-items:center;justify-content:space-between;">
                  <span style="font-weight:700;font-size:13px;">${Util.esc(f.label)} <span style="font-family:var(--font-mono);font-size:10px;color:var(--muted2);">stools/day</span></span>
                  <span style="font-size:11px;color:var(--muted2);">${Util.esc(f.desc)}</span>
                </div>
              </button>`).join("")}
            </div>

            <!-- Nocturnal — immediately after frequency, given its diagnostic weight -->
            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;">
              <div class="p-lbl" style="font-size:11px;color:var(--accent);">Nocturnal diarrhea</div>
              <div class="p-hint">woken from sleep to pass stool?</div>
            </div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-noc="no"  aria-pressed="true">No</button>
              <button class="p-segBtn warn" type="button" data-noc="yes" aria-pressed="false">Yes — woken from sleep</button>
            </div>
            <div id="nocAlert" class="p-callout warn hidden" style="margin-top:8px;font-size:12px;">
              Nocturnal diarrhea logged. This is a key marker of active MC — log it consistently. It is the most sensitive indicator of disease activity and treatment response.
            </div>
          </div>

          <!-- Step 4: Stool consistency -->
          <div id="stepConsistency" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">What was the consistency like?</div><div class="p-hint">worst episode</div></div>
            <div class="p-chips" data-symptom="consistency">
              ${BRISTOL_OPTS.map(b => `
              <button class="p-chip" type="button" data-level="${b.val}" aria-pressed="${b.val===0?"true":"false"}">
                <span style="font-weight:700;">${Util.esc(b.label)}</span>
                <span style="font-size:10px;color:var(--muted2);font-family:var(--font-mono);"> B${Util.esc(b.bris)}</span>
              </button>`).join("")}
            </div>
          </div>

          <!-- Step 5: Symptoms -->
          <div id="stepSymptoms" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Any other symptoms?</div><div class="p-hint">tick all that apply</div></div>
            <div class="p-chips">
              <button class="p-chip warn" type="button" data-flag="urgency"      aria-pressed="false">Urgency</button>
              <button class="p-chip warn" type="button" data-flag="incontinence" aria-pressed="false">Incontinence</button>
              <button class="p-chip"      type="button" data-flag="cramping"     aria-pressed="false">Cramping</button>
              <button class="p-chip"      type="button" data-flag="bloating"     aria-pressed="false">Bloating</button>
              <button class="p-chip"      type="button" data-flag="fatigue"      aria-pressed="false">Fatigue</button>
              <button class="p-chip"      type="button" data-flag="nausea"       aria-pressed="false">Nausea</button>
              <button class="p-chip warn" type="button" data-flag="weightloss"   aria-pressed="false">Weight loss</button>
            </div>
          </div>

          <!-- Step 6: Drug triggers -->
          <div id="stepDrugs" class="p-section hidden">
            <div class="p-labelrow">
              <div class="p-lbl">Medications and triggers</div>
              <div class="p-hint">MC drug triggers</div>
            </div>
            <div class="p-callout" style="margin-bottom:10px;font-size:12px;">
              Mark any medications you are currently taking. Drug exposure is the most important modifiable cause of MC — identifying a trigger may produce permanent remission without budesonide.
            </div>
            <div style="display:flex;flex-direction:column;gap:8px;">
              ${DRUG_TRIGGERS.map(d => `
              <div class="p-drugRow" style="--risk-color:${d.risk==="high"?"var(--danger)":d.risk==="mod"?"var(--warn)":"var(--muted)"};">
                <div style="flex:1;">
                  <div style="font-size:13px;font-weight:600;color:var(--ink);">${Util.esc(d.label)}</div>
                  <div style="font-size:11px;color:var(--muted2);font-family:var(--font-mono);">${Util.esc(d.note)}</div>
                </div>
                <div style="display:flex;align-items:center;gap:8px;">
                  <span style="font-size:9px;letter-spacing:.08em;text-transform:uppercase;font-family:var(--font-mono);color:var(--risk-color);">${d.risk==="high"?"HIGH RISK":d.risk==="mod"?"MOD RISK":"FLAG"}</span>
                  <button class="p-chip${d.risk==="high"?" danger":d.risk==="mod"?" warn":""}" type="button" data-flag="drug_${d.id}" aria-pressed="false" style="flex-shrink:0;">Taking</button>
                </div>
              </div>`).join("")}
            </div>
          </div>

          <!-- Step 7: Budesonide phase -->
          <div id="stepBud" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Budesonide today</div><div class="p-hint">current treatment phase</div></div>
            <div class="p-seg" style="flex-wrap:wrap;">
              <button class="p-segBtn" type="button" data-bud="induction" aria-pressed="false" style="font-size:11px;">Induction 9mg</button>
              <button class="p-segBtn" type="button" data-bud="maintenance6" aria-pressed="false" style="font-size:11px;">Maintenance 6mg</button>
              <button class="p-segBtn" type="button" data-bud="maintenance3" aria-pressed="false" style="font-size:11px;">Maintenance 3mg</button>
              <button class="p-segBtn" type="button" data-bud="skipped" aria-pressed="false" style="font-size:11px;">Skipped today</button>
              <button class="p-segBtn" type="button" data-bud="none" aria-pressed="false" style="font-size:11px;">Not on budesonide</button>
            </div>
            <div id="skipAlert" class="p-callout warn hidden" style="margin-top:8px;font-size:12px;">
              Budesonide missed. Missing doses during induction significantly reduces remission rates. During maintenance, missed doses increase relapse risk. Resume tomorrow and do not double dose.
            </div>

            <!-- Lifestyle flags -->
            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Dietary / lifestyle factors</div></div>
            <div class="p-chips">
              <button class="p-chip" type="button" data-flag="dairy"   aria-pressed="false">Dairy consumed</button>
              <button class="p-chip" type="button" data-flag="gluten"  aria-pressed="false">Gluten consumed</button>
              <button class="p-chip" type="button" data-flag="coffee"  aria-pressed="false">Caffeine↑</button>
              <button class="p-chip" type="button" data-flag="alcohol" aria-pressed="false">Alcohol</button>
              <button class="p-chip" type="button" data-flag="stress"  aria-pressed="false">Stress↑</button>
            </div>

            <!-- Alarm flags -->
            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;">
              <div class="p-lbl" style="font-size:11px;color:var(--danger);">Alarm features</div>
            </div>
            <div class="p-chips">
              <button class="p-chip danger" type="button" data-flag="blood"         aria-pressed="false">Blood in stool</button>
              <button class="p-chip danger" type="button" data-flag="fever"         aria-pressed="false">Fever</button>
              <button class="p-chip danger" type="button" data-flag="severeabdpain" aria-pressed="false">Severe abdominal pain</button>
              <button class="p-chip danger" type="button" data-flag="unintentionalwl" aria-pressed="false">Unintentional weight loss</button>
            </div>
            <div id="alarmAlert" class="p-callout danger hidden" style="margin-top:8px;">
              <b>Alarm feature flagged.</b> Blood in stool is not a feature of MC — it requires urgent investigation. Contact your gastroenterologist today.
            </div>

            <div class="p-section">
              <div class="p-labelrow"><div class="p-lbl">Notes</div><div class="p-hint"><span id="noteCount">0</span>/600</div></div>
              <textarea id="notes" class="p-note" maxlength="600" placeholder="Specific foods, medication details, new prescriptions, symptom timing (optional)"></textarea>
            </div>
          </div>

          <!-- Actions -->
          <div id="stepActions" class="p-section hidden">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnSave" disabled>Done</button>
              <button class="p-btn" type="button" id="btnRepeat" disabled>Repeat last</button>
              <button class="p-btn ghost" type="button" id="btnReset">Reset</button>
            </div>
          </div>
        </div>
      </div>

      <!-- RIGHT -->
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>Today's Guidance</h2><p>Personalized to what you logged</p></div>
          
        </div>
        <div class="p-card-b">
          <div id="guidance" class="p-callout">Select subtype and complete the log. MC Activity Index and guidance will appear here.</div>
          <div id="inlineCard" class="p-section" style="display:none;"></div>

          <div id="scorePanel" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">MC Activity Index</div><div class="p-hint">0–20 scale</div></div>
            <div class="p-scoreWrap">
              <div class="p-scoreBig" id="scoreBig">—</div>
              <div class="p-scoreSubLabel">MCAI Proxy (stool frequency · nocturnal · urgency)</div>
            </div>
            <div id="scoreInterp" class="p-callout" style="margin-top:8px;"></div>
          </div>

          <!-- Drug trigger summary -->
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">High-risk medications</div><div class="p-hint">currently taking</div></div>
            <div id="drugSummary" style="font-size:12px;color:var(--muted);line-height:1.8;">No high-risk medications flagged.</div>
          </div>

          <!-- Nocturnal summary -->
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Nocturnal episodes</div><div class="p-hint">last 30 days</div></div>
            <div id="nocturnalCount" class="p-kpis"></div>
          </div>

          <div class="p-section">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnReport">Clinician report</button>
              <button class="p-btn" type="button" id="btnExportCsv">Export CSV</button>
              <button class="p-btn" type="button" id="btnExportJson">Export JSON</button>
              <button class="p-btn" type="button" id="btnImport">Import</button>
              <input id="importFile" type="file" accept="application/json" class="sr">
            </div>
          </div>
          <div class="p-section">
            <div class="p-premRow" id="premiumCta" style="cursor:pointer;">
              <div class="p-premLabel" id="premStatusLabel">Unlock Premium — trend analytics · trigger correlation · next steps</div>
              <div style="font-family:var(--font-mono);font-size:10px;letter-spacing:.08em;color:#f5c842;">UPGRADE ✦</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- HISTORY -->
  <section id="view-history" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>History</h2><p>Most recent first</p></div>
        <div class="p-rowBtns" style="margin:0;">
          <button class="p-btn" type="button" id="btnExportCsv2">Export CSV</button>
          <button class="p-btn" type="button" id="btnExportJson2">Export JSON</button>
        </div>
      </div>
      <div class="p-card-b"><div class="p-list" id="histList"></div></div>
    </div>
  </section>

  <!-- LIBRARY -->
  <section id="view-library" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Clinical Library</h2><p>Diagnosis · nocturnal diarrhea · drug triggers · budesonide · celiac overlap · BAM · diet · red flags</p></div>
        <div style="display:flex;gap:10px;align-items:center;">
          <div class="p-kpis"><div class="p-kpi">Cards <b id="kpiCards">0</b></div></div>
          <input id="libSearch" type="search" class="p-search" placeholder="Search budesonide, NSAIDs, celiac, nocturnal…">
        </div>
      </div>
      <div class="p-card-b">
        <div class="p-libCats" id="libCats"></div>
        <div class="p-libGrid" id="libGrid"></div>
      </div>
    </div>
  </section>

  <!-- INSIGHTS -->
  <section id="view-insights" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Insights</h2><p>Free: stool frequency trend · Premium: MCAI trend + nocturnal pattern + next steps</p></div>
        <button class="p-btn" type="button" id="btnRefresh" style="margin:0;">Refresh</button>
      </div>
      <div class="p-card-b">
        <div id="insightsBody" class="p-callout">Log at least 5 entries to unlock insights.</div>
        <div class="p-section">
          <div class="p-chartWrap"><canvas id="chartFreq" height="200"></canvas><div class="p-chartMeta">Stool frequency / day (last 28 entries) — remission target: ≤3</div></div>
        </div>
        <div id="premiumPanel" class="p-section hidden">
          <div class="p-grid two">
            <div class="p-chartWrap"><canvas id="chartMCAI" height="200"></canvas><div class="p-chartMeta">MCAI score (last 30 entries)</div></div>
            <div class="p-chartWrap"><canvas id="chartNoc" height="200"></canvas><div class="p-chartMeta">Nocturnal episodes (last 30 entries)</div></div>
          </div>
          <div class="p-section p-grid two">
            <div class="p-callout" id="drugBox"></div>
            <div class="p-callout" id="budBox"></div>
          </div>
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Ranked next steps</div></div>
            <div class="p-list" id="nextStepsList"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>`;
}

// ── EXTRA STYLES ─────────────────────────────────────────────────
function injectStyles() {
  const s = document.createElement("style");
  s.textContent = `
    .p-freqOpt {
      padding:10px 14px; border-radius:12px;
      border:1px solid var(--line); background:rgba(255,255,255,.02);
      color:var(--muted); cursor:pointer; text-align:left; width:100%;
      transition:border-color .12s,background .12s;
    }
    .p-freqOpt[aria-selected="true"] {
      border-color:rgba(126,184,164,.5);
      background:rgba(126,184,164,.10);
      color:var(--ink);
    }
    .p-segBtn.warn { border-color:rgba(232,197,107,.5); color:var(--warn); }
    .p-segBtn.warn[aria-pressed="true"] { background:rgba(232,197,107,.15); border-color:rgba(232,197,107,.8); }
    .p-drugRow {
      display:flex; align-items:center; gap:12px;
      padding:10px 14px; border-radius:12px;
      border:1px solid var(--line);
      border-left:3px solid var(--risk-color);
      background:rgba(255,255,255,.01);
    }
  `;
  document.head.appendChild(s);
}

// ── LOGIC ────────────────────────────────────────────────────────
function setSubtypeUI(sub) {
  State.subtype = sub;
  $$("[data-sub]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.sub === sub)));
  const lbl = $("#subtypeLabel"); if(lbl) lbl.textContent = SUBTYPES[sub]?.split(" — ")[0] || sub;
  $("#subtypeConfirm")?.classList.toggle("hidden", !sub);
}

function updateProgress() {
  const d = State.draft;
  const hasSub = !!State.subtype;
  const hasQ   = !!d.quality;

  $("#stepQuality")?.classList.toggle("hidden", !hasSub);
  $("#stepFreq")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepConsistency")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepSymptoms")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepDrugs")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepBud")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepActions")?.classList.toggle("hidden", !(hasSub && hasQ));

  // INVARIANT: red flags always visible — never gated on premium. MDR compliance.
  const hasAlarm = ALARM_FLAGS.some(k => d.flags?.[k]);
  $("#alarmAlert")?.classList.toggle("hidden", !hasAlarm);
  $("#nocAlert")?.classList.toggle("hidden", !d.flags?.nocturnal);
  $("#skipAlert")?.classList.toggle("hidden", d.budesonidePhase !== "skipped");

  const btnSave = $("#btnSave"); if(btnSave) btnSave.disabled = !(hasSub && hasQ);
  const btnRepeat = $("#btnRepeat"); if(btnRepeat) btnRepeat.disabled = !State.lastEntry;

  // Drug summary on right panel
  const ds = $("#drugSummary");
  if (ds) {
    const active = DRUG_TRIGGERS.filter(dt => d.flags?.["drug_"+dt.id] && dt.risk === "high").map(dt => dt.label);
    ds.innerHTML = active.length
      ? `<span style="color:var(--danger);">⚠ ${Util.esc(active.join(", "))}</span> — discuss with your gastroenterologist and prescribing doctor`
      : `<span style="color:var(--muted);">No high-risk medications flagged.</span>`;
  }

  updateGuidance(d);
}


function renderInlineCard(cardTitle) {
  const container = document.getElementById("inlineCard");
  if (!container) return;

  const card = LIBRARY.cards.find(c => c.title === cardTitle);
  if (!card) { container.style.display = "none"; return; }

  container.style.display = "block";
  const safeTitle = card.title.split("—")[0].trim().replace(/'/g, "\'");

  const bulletsHTML = (card.bullets || []).map(b =>
    `<li style="font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:6px;">${b}</li>`
  ).join("");

  const moreHTML = card.more
    ? `<div style="font-size:12px;color:var(--muted2);line-height:1.5;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);">${card.more}</div>`
    : "";

  const evidenceHTML = card.evidence
    ? `<div style="font-size:11px;color:var(--muted2);font-family:var(--font-mono);margin-top:8px;line-height:1.5;">${card.evidence}</div>`
    : "";

  container.innerHTML = `
    <div style="border-left:3px solid var(--accent);padding-left:14px;margin-top:8px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px;">Your doctor says</div>
      <div style="font-size:15px;font-weight:600;color:var(--fg);margin-bottom:8px;">${card.title}</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;margin-bottom:10px;">${card.why}</div>
      ${bulletsHTML ? `<ul style="margin:0 0 10px 0;padding-left:16px;">${bulletsHTML}</ul>` : ""}
      ${card.action ? `
        <div style="padding:12px 14px;background:var(--surface2);border-radius:10px;margin-bottom:10px;">
          <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">What to do</div>
          <div style="font-size:13px;color:var(--fg);line-height:1.6;">${card.action}</div>
        </div>` : ""}
      ${moreHTML}
      ${evidenceHTML}
      <button type="button"
        style="font-size:12px;color:var(--accent);background:none;border:none;padding:4px 0 0 0;cursor:pointer;text-decoration:underline;display:block;margin-top:6px;"
        onclick="(function(){document.getElementById('tab-library')?.click();var s=document.getElementById('libSearch');if(s){s.value='${safeTitle}';s.dispatchEvent(new Event('input'));}})()">
        Browse all library cards →
      </button>
    </div>
  `;
}


function pickInlineCard(d) {
  if (d.flags?.nocturnal) return "Bile Acid Malabsorption — The Overlooked Contributor in MC";
  if (d.stoolFreq >= 3) return "Bile Acid Malabsorption — The Overlooked Contributor in MC";
  return "Bile Acid Malabsorption — The Overlooked Contributor in MC";
}
function updateGuidance(d) {
  const g = $("#guidance"), sp = $("#scorePanel");
  if (!g) return;
  if (!State.subtype || !d.quality) {
    g.innerHTML = "Select subtype and complete the log. MC Activity Index and guidance will appear here.";
    sp?.classList.add("hidden"); return;
  }

  // Premium gate — guidance is gated after 14-day trial
  if (!PremiumGate.isPremium()) {
    PremiumGate.showGuidanceGate(g, MODULE_KEY, () => updateGuidance(d));
    sp?.classList.add("hidden");
    return;
  }


  const score = calcMCAI(d);
  const interp = interpMCAI(score);

  const freq = d.stoolFreq || 0;
  const highDrugs = (d.drugs || []).filter(x => ["nsaids","aspirin","ppi","ticlopidine","sertraline","lansoprazole"].includes(x.id || x));
  const FREQ_LABELS = ["0","1–2","3–4","5–6","7–9","≥10"];
  let assessment = "";
  if (d.flags?.nocturnal && freq >= 3) {
    assessment = `Your log shows nocturnal diarrhea alongside high daytime frequency — ${FREQ_LABELS[freq] || freq} bowel movements. Nocturnal diarrhea is the most sensitive clinical marker of active microscopic colitis. This combination suggests the disease is not adequately controlled.`;
  } else if (d.flags?.nocturnal) {
    assessment = `Nocturnal diarrhea flagged today. In microscopic colitis, waking from sleep to have a bowel movement is a specific indicator of active mucosal inflammation — it does not occur in functional diarrhea. This is an important signal to log consistently.`;
  } else if (freq >= 4) {
    assessment = `Your log shows ${FREQ_LABELS[freq] || freq} bowel movements today — consistent with active microscopic colitis. Stool frequency is the primary disease activity marker in MC.`;
  } else if (d.flags?.blood) {
    assessment = `Blood in stool flagged today. Microscopic colitis characteristically causes non-bloody watery diarrhea — rectal bleeding is not a feature of MC and requires separate evaluation. Contact your gastroenterologist.`;
  } else if (d.quality === "great" && freq <= 1) {
    assessment = `Your log shows a low-symptom day — minimal stool frequency, no nocturnal diarrhea. This is consistent with MC remission. Consistent entries like this confirm your current treatment is working.`;
  } else {
    assessment = `Your log shows ${FREQ_LABELS[freq] || "low"} bowel movements today. ${freq <= 2 ? "This is within or near the normal range — a positive sign." : "Continue monitoring the frequency trend."}`;
  }

  let plan = "";
  if (highDrugs.length) {
    plan = `High-risk medications are flagged in your log. Stopping the causative drug often produces remission without budesonide — this should be the first intervention if any flagged medication can be safely stopped or substituted. NSAIDs and aspirin carry the strongest association with MC. Among PPIs, lansoprazole carries the highest risk — omeprazole or pantoprazole are lower-risk alternatives if a PPI is still required. Discuss with both your prescribing doctor and your gastroenterologist before stopping any medication.`;
  } else if (d.flags?.nocturnal || freq >= 4) {
    plan = `Active MC at this level warrants budesonide therapy — 9mg daily for 8 weeks is the standard induction course. If you are already on budesonide, ensure you are taking it consistently and at the correct dose. Do not stop budesonide abruptly — taper as instructed. Hydration and electrolytes are important at high stool frequency: oral rehydration solution is more effective than plain water. If frequency is not improving within 2 weeks of starting budesonide, contact your gastroenterologist.`;
  } else if (d.budesonidePhase === "skipped") {
    plan = `Budesonide missed today — resume tomorrow at your normal dose, do not double up. Consistent adherence is required for mucosal healing in MC. Set a daily alarm at the same time each day. If side effects are causing you to miss doses, discuss this with your gastroenterologist — dose adjustment or formulation change may help.`;
  } else {
    plan = `Continue current management and log consistently. The key indicators are nocturnal diarrhea frequency and total daily bowel movements — these are your primary disease activity markers. A reducing trend over 4–8 weeks of treatment is the expected trajectory on budesonide.`;
  }

  g.innerHTML = `
    <div style="margin-bottom:12px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Assessment</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${assessment}</div>
    </div>
    <div>
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Plan</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${plan}</div>
    </div>
    <div style="font-size:11px;color:var(--muted2);margin-top:10px;border-top:1px solid var(--border);padding-top:8px;">This is patient education based on your logged data — not a medical diagnosis. Discuss any changes to your treatment with your gastroenterologist.</div>
  `;

  const cardTitle = pickInlineCard(d);
  if (cardTitle) renderInlineCard(cardTitle);
  else { const ic = document.getElementById("inlineCard"); if (ic) ic.style.display = "none"; }

  if (sp) {
    sp.classList.remove("hidden");
    const big = $("#scoreBig");
    if(big) { big.textContent = score; big.style.color = interp.color; }
    const si = $("#scoreInterp");
    if(si) {
      si.className = "p-callout " + (interp.cls||"");
      const tips = {
        ok:     "Remission or mild activity. Continue current treatment phase.",
        warn:   "Moderate activity. Review budesonide adherence and drug triggers.",
        danger: "High activity. Discuss treatment with your gastroenterologist."
      };
      si.innerHTML = `<b>${interp.label}:</b> ${tips[interp.cls]||""}`;
    }
  }
}

function resetDraft() {
  State.draft = defaultDraft();
  if (State.subtype) State.draft.subtype = State.subtype;
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$(".p-freqOpt").forEach(b => b.setAttribute("aria-selected", String(b.dataset.freq==="0")));
  $$("[data-noc]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.noc==="no")));
  $$("[data-symptom] .p-chip").forEach(c => c.setAttribute("aria-pressed", String(c.dataset.level==="0")));
  $$(".p-chip[data-flag]").forEach(c => c.setAttribute("aria-pressed","false"));
  $$("[data-bud]").forEach(b => b.setAttribute("aria-pressed","false"));
  const notes=$("#notes"); if(notes) notes.value="";
  const nc=$("#noteCount"); if(nc) nc.textContent="0";
  updateProgress();
}

async function save() {
  try {
    if($("#btnSave")) $("#btnSave").disabled = true;
    const d = State.draft;
    const entry = {
      ts: Util.nowISO(), dateKey: Util.dateKeyLocal(),
      subtype: State.subtype, quality: d.quality,
      stoolFreq: d.stoolFreq||0,
      consistency: d.consistency||0,
      budesonidePhase: d.budesonidePhase||null,
      mcai: calcMCAI(d),
      flags: {...d.flags}, notes: (d.notes||"").slice(0,600), deleted: 0
    };
    const last = State.lastEntry;
    if(last){
      const dt=Math.abs(+new Date(entry.ts)-+new Date(last.ts));
      if(dt<90000&&entry.quality===last.quality&&entry.stoolFreq===last.stoolFreq){
        Util.toast("Duplicate entry blocked"); return;
      }
    }
    const saved = await Perf.time("entry-save", async () => { await State.store.addEntry(entry); });
    State.lastEntry = saved;
    Util.toast("Entry saved");
  // First-time upgrade nudge at 14 entries
  const allEntries = await State.store.getEntriesAll();
  if (allEntries.length === 14 && !PremiumGate.isPremium()) {
    setTimeout(() => PremiumGate.showPaywall(MODULE_KEY, () => {
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      Util.toast("Premium unlocked ✦");
    }), 1200);
  }
    resetDraft();
    if(State.subtype) setSubtypeUI(State.subtype);
    await refreshKPIs();
    await renderNocturnalCount();
  } catch(err){ console.error(err); Util.toast("Save failed"); }
  finally { updateProgress(); }
}

async function repeatLast() {
  const last = State.lastEntry || await State.store.getLastEntry();
  if(!last) return;
  State.lastEntry = last;
  const d = State.draft;
  if(last.subtype) setSubtypeUI(last.subtype);
  d.quality=last.quality; d.stoolFreq=last.stoolFreq||0;
  d.consistency=last.consistency||0; d.budesonidePhase=last.budesonidePhase||null;
  d.flags={...defaultFlags(),...(last.flags||{})};
  d.notes=last.notes||"";
  $$("[data-quality]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.quality===d.quality)));
  $$(".p-freqOpt").forEach(b=>b.setAttribute("aria-selected",String(Number(b.dataset.freq)===d.stoolFreq)));
  $$("[data-noc]").forEach(b=>b.setAttribute("aria-pressed",String((b.dataset.noc==="yes")===!!d.flags?.nocturnal)));
  const cw=$(".p-chips[data-symptom='consistency']");
  if(cw) cw.querySelectorAll(".p-chip").forEach(c=>c.setAttribute("aria-pressed",String(Number(c.dataset.level)===d.consistency)));
  $$(".p-chip[data-flag]").forEach(c=>c.setAttribute("aria-pressed",String(!!d.flags[c.dataset.flag])));
  if(d.budesonidePhase) $$("[data-bud]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.bud===d.budesonidePhase)));
  const notes=$("#notes"); if(notes){notes.value=d.notes;const nc=$("#noteCount");if(nc)nc.textContent=String(d.notes.length);}
  updateProgress();
  Util.toast("Repeated last entry");
}

async function refreshKPIs() {
  const kpis = await KPI.compute(State.store);
  const el=(id,v)=>{const e=$(id);if(e)e.textContent=String(v);};
  el("#kpiTotal",kpis.total); el("#kpi7d",kpis.last7days); el("#kpiStreak",kpis.streak);
}

async function renderNocturnalCount() {
  const el=$("#nocturnalCount"); if(!el) return;
  const cut=new Date(); cut.setDate(cut.getDate()-30); cut.setHours(0,0,0,0);
  const all=await State.store.getEntriesAll();
  const count=all.filter(e=>new Date(e.ts)>=cut&&e.flags?.nocturnal).length;
  const cls=count===0?"ok":count<=5?"warn":"danger";
  el.innerHTML=`<div class="p-kpi">Nocturnal <b style="color:var(--${cls})">${count}</b> / 30 days</div>`;
}

async function renderHistory() {
  const list=$("#histList"); if(!list) return;
  const all=(await State.store.getEntriesAll()).sort((a,b)=>b.ts.localeCompare(a.ts));
  if(!all.length){list.innerHTML=`<div class="p-callout">No entries yet.</div>`;return;}
  list.innerHTML=all.slice(0,80).map(e=>{
    const interp=interpMCAI(e.mcai||0);
    const freq=STOOL_FREQ[e.stoolFreq||0];
    const bris=BRISTOL_OPTS[e.consistency||0];
    const noc=e.flags?.nocturnal;
    const drugs=DRUG_TRIGGERS.filter(d=>e.flags?.["drug_"+d.id]&&d.risk==="high").map(d=>d.label);
    return `<div class="p-item">
      <div class="p-itemTop">
        <div class="ts">${Util.esc(e.dateKey)}</div>
        <div class="q">${Util.esc(e.quality||"")} · MCAI: <span style="color:${Util.cssVal(interp.color)}">${Util.esc(String(e.mcai||0))}</span></div>
      </div>
      <div class="p-itemBody">Stools: <b>${Util.esc(freq?.label||"0")}/day</b> · ${Util.esc(bris?.label||"—")}${noc?` · <b style="color:var(--warn)">Nocturnal ⚠</b>`:""}${e.budesonidePhase?` · ${Util.esc(e.budesonidePhase)}`:""}
      </div>
      ${drugs.length?`<div class="p-itemBody" style="color:var(--danger);margin-top:4px;font-family:var(--font-mono);font-size:11px;">Drug trigger: ${Util.esc(drugs.join(", "))}</div>`:""}
      ${e.notes?`<div class="p-itemBody" style="margin-top:4px;">${Util.esc(e.notes)}</div>`:""}
    </div>`;
  }).join("");
}

async function renderInsights() {
  const all=(await State.store.getEntriesAll()).sort((a,b)=>a.ts.localeCompare(b.ts));
  const body=$("#insightsBody");
  if(all.length<5){if(body)body.textContent=`Log at least 5 entries. (${all.length} so far)`;return;}
  if(body)body.innerHTML=`<b>${all.length}</b> total entries logged.`;

  const last28=all.slice(-28);
  const freqVals=last28.map(e=>{
    const bands=[0,1.5,3.5,5.5,8,10];
    return bands[e.stoolFreq||0]||0;
  });
  const fc=$("#chartFreq");
  if(fc) Charts.drawLine(fc,freqVals,{maxV:12,lc:"rgba(126,184,164,.8)",dc:"rgba(126,184,164,.9)",
    thresholds:[{y:3,label:"Remission target"}]});

  if(!State.premium){$("#premiumPanel")?.classList.add("hidden");return;}
  const pp=$("#premiumPanel"); pp?.classList.remove("hidden");
  const last30=all.slice(-30);

  const mcaiVals=last30.map(e=>e.mcai||0);
  const nocVals=last30.map(e=>e.flags?.nocturnal?1:0);
  const mc=$("#chartMCAI"); if(mc) Charts.drawLine(mc,mcaiVals,{maxV:20});
  const nc=$("#chartNoc");
  if(nc) Charts.drawBars(nc,last30.map((_,i)=>String(i+1)),nocVals,{c1:"rgba(232,197,107,.8)",c2:"rgba(232,197,107,.4)"});

  // Drug analysis
  const db=$("#drugBox");
  if(db){
    const drugDays={};
    DRUG_TRIGGERS.forEach(d=>drugDays[d.id]=0);
    last30.forEach(e=>DRUG_TRIGGERS.forEach(d=>{if(e.flags?.["drug_"+d.id])drugDays[d.id]++;}));
    const active=DRUG_TRIGGERS.filter(d=>drugDays[d.id]>=15&&d.risk==="high");
    db.className="p-callout"+(active.length?" danger":"");
    db.innerHTML=active.length
      ?`<b style="color:var(--danger)">High-risk medication(s) on ≥15/30 days:</b><br>${active.map(d=>`${Util.esc(d.label)}: ${drugDays[d.id]} days`).join("<br>")}<br><br>Discuss rationalisation with your gastroenterologist.`
      :"No consistently taken high-risk medications identified.";
  }

  // Budesonide adherence
  const bb=$("#budBox");
  if(bb){
    const skipDays=last30.filter(e=>e.budesonidePhase==="skipped").length;
    const cls=skipDays===0?"ok":skipDays<=3?"warn":"danger";
    bb.className="p-callout "+cls;
    bb.innerHTML=`<b>Budesonide adherence:</b> Skipped ${skipDays}/30 days. ${skipDays===0?"Full adherence — good.":skipDays<=3?"Minor gaps — aim for zero missed doses during induction.":"Significant adherence gap — missing budesonide is the most common cause of treatment failure."}`;
  }

  // Next steps
  const ns=$("#nextStepsList");
  if(ns){
    const steps=[];
    const noc30=last30.filter(e=>e.flags?.nocturnal).length;
    if(noc30>=10) steps.push({p:"danger",t:`Nocturnal diarrhea on ${noc30}/30 days. This level of nocturnal activity indicates inadequately controlled MC — discuss treatment escalation with your gastroenterologist.`});
    const highDrugDays=last30.filter(e=>DRUG_TRIGGERS.some(d=>d.risk==="high"&&e.flags?.["drug_"+d.id])).length;
    if(highDrugDays>=20) steps.push({p:"danger",t:"High-risk medication consistently present. Stopping the causative drug is the single most important intervention — discuss with your gastroenterologist and prescribing doctor urgently."});
    const skipBud=last30.filter(e=>e.budesonidePhase==="skipped").length;
    if(skipBud>=4) steps.push({p:"warn",t:`Budesonide missed ${skipBud}/30 days. Missing doses during induction significantly reduces remission rates.`});
    const meanMCAI=Stats.mean(last30.map(e=>e.mcai||0));
    if(meanMCAI>=10) steps.push({p:"warn",t:`Mean MCAI ${meanMCAI.toFixed(1)} — moderate-high activity sustained. If on budesonide 9mg for >4 weeks without response, discuss coexisting celiac disease and bile acid malabsorption with your gastroenterologist.`});
    if(!steps.length) steps.push({p:"ok",t:"No high-priority signals. Continue current treatment and daily logging."});
    const colors={danger:"var(--danger)",warn:"var(--warn)",ok:"var(--ok)"};
    ns.innerHTML=steps.map(s=>`<div class="p-item"><div class="p-itemBody"><b style="color:${colors[s.p]}">${s.p.toUpperCase()}:</b> ${Util.esc(s.t)}</div></div>`).join("");
  }
}

function showTab(tab) {
  ["log","history","library","insights"].forEach(t=>{
    $("#tab-"+t)?.setAttribute("aria-selected",String(t===tab));
    $("#view-"+t)?.classList.toggle("hidden",t!==tab);
  });
  if(tab==="history") renderHistory();
  if(tab==="library"){
    LibRenderer.renderCats($("#libCats"),LIB_CATS,State.libCat,cat=>{State.libCat=cat;renderLibrary();});
    renderLibrary();
  }
  if(tab==="insights") renderInsights();
}

function renderLibrary() {
  const grid=$("#libGrid"); if(!grid) return;
  const kpi=$("#kpiCards"); if(kpi) kpi.textContent=String(LIBRARY.cards.length);
  LibRenderer.render(grid,LibRenderer.filterCards(LIBRARY.cards,State.libCat,State.libQuery));
}

// ── EVENTS ───────────────────────────────────────────────────────
function wireEvents() {
  $$(".p-tab").forEach(b=>b.addEventListener("click",()=>showTab(b.dataset.tab)));

  $$("[data-sub]").forEach(b=>b.addEventListener("click",()=>{
    setSubtypeUI(b.dataset.sub);
    State.store.setSetting("subtype",b.dataset.sub);
    updateProgress();
    setTimeout(()=>Util.scroll($("#stepQuality")),80);
  }));
  $("#btnChangeSub")?.addEventListener("click",()=>{
    State.subtype=null;
    $$("[data-sub]").forEach(b=>b.setAttribute("aria-pressed","false"));
    $("#subtypeConfirm")?.classList.add("hidden");
    updateProgress();
  });

  $$("[data-quality]").forEach(b=>b.addEventListener("click",()=>{
    State.draft.quality=b.dataset.quality;
    $$("[data-quality]").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
    updateProgress();
    setTimeout(()=>Util.scroll($("#stepFreq")),80);
  }));

  $$(".p-freqOpt").forEach(b=>b.addEventListener("click",()=>{
    State.draft.stoolFreq=Number(b.dataset.freq);
    $$(".p-freqOpt").forEach(x=>x.setAttribute("aria-selected",String(x===b)));
    updateProgress();
  }));

  $$("[data-noc]").forEach(b=>b.addEventListener("click",()=>{
    const isYes=b.dataset.noc==="yes";
    State.draft.flags.nocturnal=isYes;
    $$("[data-noc]").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
    updateProgress();
  }));

  const cw=$(".p-chips[data-symptom='consistency']");
  if(cw) cw.addEventListener("click",e=>{
    const btn=e.target.closest(".p-chip"); if(!btn) return;
    State.draft.consistency=Util.clamp(Number(btn.dataset.level),0,3);
    cw.querySelectorAll(".p-chip").forEach(c=>c.setAttribute("aria-pressed",String(c===btn)));
    updateProgress();
  });

  $$(".p-chip[data-flag]").forEach(b=>b.addEventListener("click",()=>{
    const k=b.dataset.flag;
    State.draft.flags[k]=!State.draft.flags[k];
    b.setAttribute("aria-pressed",String(State.draft.flags[k]));
    updateProgress();
  }));

  $$("[data-bud]").forEach(b=>b.addEventListener("click",()=>{
    State.draft.budesonidePhase=b.dataset.bud;
    $$("[data-bud]").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
    updateProgress();
  }));

  const notes=$("#notes");
  if(notes) notes.addEventListener("input",()=>{
    State.draft.notes=notes.value;
    const nc=$("#noteCount"); if(nc) nc.textContent=String(notes.value.length);
  });

  $("#btnSave")?.addEventListener("click",save);
  $("#btnRepeat")?.addEventListener("click",repeatLast);
  $("#btnReset")?.addEventListener("click",resetDraft);

  const allFlags=[...FLAG_KEYS,...ALARM_FLAGS,...DRUG_TRIGGERS.map(d=>"drug_"+d.id)];
  // INVARIANT: clinician report is always free — do not gate on PremiumGate.isPremium()
  $("#btnReport")?.addEventListener("click", () => Report.generate(MODULE_KEY));

  const doCSV=()=>IO.exportCSV(State.store,MODULE_KEY,allFlags);
  const doJSON=()=>IO.exportJSON(State.store,MODULE_KEY);
  ["#btnExportCsv","#btnExportCsv2"].forEach(s=>$(s)?.addEventListener("click",doCSV));
  ["#btnExportJson","#btnExportJson2"].forEach(s=>$(s)?.addEventListener("click",doJSON));
  const btnImport=$("#btnImport"),importFile=$("#importFile");
  if(btnImport&&importFile){
    btnImport.addEventListener("click",()=>importFile.click());
    importFile.addEventListener("change",async e=>{
      const f=e.target.files?.[0]; if(!f) return;
      await IO.importJSON(f,State.store,allFlags,async()=>{await refreshKPIs();await renderHistory();});
      e.target.value="";
    });
  }

  $("#libSearch")?.addEventListener("input",e=>{State.libQuery=e.target.value||"";renderLibrary();});
  $("#btnRefresh")?.addEventListener("click",renderInsights);

  // Premium CTA — wire paywall
  $("#premiumCta")?.addEventListener("click", () => {
    PremiumGate.showPaywall(MODULE_KEY, () => {
      const sl = $("#premStatusLabel");
      if (sl) sl.textContent = "✦ Premium active";
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      renderInsights?.();
      Util.toast("Premium unlocked ✦");
    });
  });

}

// ── BOOT ─────────────────────────────────────────────────────────
async function boot() {
  injectStyles();
  renderHTML();
  const todayEl=$("#todayLabel"); if(todayEl) todayEl.textContent=Util.dateKeyLocal();

  const {store,mode}=await initStorage(MODULE_KEY);
  State.store=store;
  if (typeof GIOSNotifications !== "undefined") GIOSNotifications.init("mc", "Microscopic Colitis OS");
  updateStorageModeUI(mode);

  const savedPremium=await store.getSetting("premium",false);
  State.premium=!!savedPremium;
  const m=$("#modeLabel"); if(m) m.textContent=State.premium?"Premium":"Free";

  const savedSub=await store.getSetting("subtype",null);
  if(savedSub) setSubtypeUI(savedSub);

  State.lastEntry=await store.getLastEntry();
  wireEvents();
  resetDraft();
  if(State.subtype) setSubtypeUI(State.subtype);
  await refreshKPIs();
  await renderNocturnalCount();

  LibRenderer.renderCats($("#libCats"),LIB_CATS,State.libCat,cat=>{State.libCat=cat;renderLibrary();});
  renderLibrary();

  Util.toast("Microscopic Colitis OS ready");
}

boot();
})();
