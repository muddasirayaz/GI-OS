/**
 * GI OS — Premium Gate
 * ═══════════════════════════════════════════════════════════
 * Enforced freemium. Modules ask the gate — they don't
 * manage state themselves.
 *
 * States:
 *   free     — default, log + history + library only
 *   active   — premium unlocked (paid or trial)
 *   trial    — clinician activation code, expires after N days
 *   pending  — RevenueCat verification in progress
 *
 * RevenueCat integration point:
 *   When RevenueCat is wired, replace PremiumGate._rcPurchase()
 *   with the real purchase flow. Everything else stays the same.
 *
 * Free tier includes:
 *   - Daily logging (unlimited entries)
 *   - History view (last 30 entries)
 *   - Library (all cards)
 *   - Clinician report ← deliberately free (growth mechanic)
 *   - CSV/JSON export
 *   - Streak counter
 *
 * Premium tier adds:
 *   - Insights tab (trend charts, pattern analysis)
 *   - Next steps (ranked clinical actions)
 *   - Full history (unlimited)
 *   - Extended KPI panel
 * ═══════════════════════════════════════════════════════════
 */

const PremiumGate = (() => {
"use strict";

// ── CONSTANTS ─────────────────────────────────────────────────────
const SK             = "giplatform_premium";   // global key — not per-module
const GRACE_DAYS     = 7;                      // offline grace period
const TRIAL_DAYS     = 90;                     // clinician code trial
const AUTO_TRIAL_DAYS = 14;                    // free trial on first install

// Clinician activation codes → trial duration in days
// Replace with API lookup when clinician programme launches
const VALID_CODES = {
  "GASTRO2024": 90,
  "IBDOS2024":  90,
  "IBSOS2024":  90,
  "COELIAC90":  90,
  "GIOS-DEMO":  30,
};

// ── STORAGE ───────────────────────────────────────────────────────
function _read() {
  try {
    const r = localStorage.getItem(SK);
    return r ? JSON.parse(r) : {};
  } catch { return {}; }
}

function _write(obj) {
  try { localStorage.setItem(SK, JSON.stringify(obj)); }
  catch(e) { console.warn("PremiumGate write error:", e); }
}

// ── STATE RESOLUTION ──────────────────────────────────────────────
function _resolve() {
  const s = _read();
  const now = Date.now();

  // Auto-start 14-day trial on first install if no state exists
  if (!s.state) {
    const expiry = now + AUTO_TRIAL_DAYS * 86400000;
    _write({ state: "trial", trialCode: "AUTO_14DAY", trialExpiry: expiry, activatedAt: now });
    return "trial";
  }

  // Hard active (paid subscription or RC verified)
  if (s.state === "active") {
    // Check grace period if RC verification pending
    if (s.rcVerifiedAt) {
      const elapsed = (now - s.rcVerifiedAt) / 86400000;
      if (elapsed > GRACE_DAYS && !s.rcActive) {
        return "free"; // grace expired, not verified
      }
    }
    return "active";
  }

  // Trial via clinician code
  if (s.state === "trial" && s.trialExpiry) {
    if (now < s.trialExpiry) return "trial";
    // Trial expired — downgrade gracefully
    _write({ ...s, state: "free", trialExpiry: null, trialCode: null });
    return "free";
  }

  return "free";
}

// ── PUBLIC API ────────────────────────────────────────────────────

/**
 * isPremium() — call before rendering any gated feature
 * Returns true for both "active" and "trial" states
 */
function isPremium() {
  const state = _resolve();
  return state === "active" || state === "trial";
}

/**
 * getState() — returns full state object for UI rendering
 */
function getState() {
  const s    = _read();
  const state = _resolve();
  const now  = Date.now();

  let trialDaysLeft = null;
  if (state === "trial" && s.trialExpiry) {
    trialDaysLeft = Math.max(0, Math.ceil((s.trialExpiry - now) / 86400000));
  }

  return { state, trialDaysLeft, trialCode: s.trialCode || null };
}

/**
 * activate(token) — called by RevenueCat on purchase success
 * token: RevenueCat entitlement identifier
 */
function activate(token) {
  _write({
    state:         "active",
    activatedAt:   Date.now(),
    rcToken:       token || "manual",
    rcVerifiedAt:  Date.now(),
    rcActive:      true,
  });
}

/**
 * activateCode(code) — clinician activation code
 * Returns { success, message, daysGranted }
 */
function activateCode(code) {
  const clean = (code || "").trim().toUpperCase();
  const days  = VALID_CODES[clean];

  if (!days) {
    return { success: false, message: "Code not recognised. Check the code and try again." };
  }

  const s = _read();
  if (s.state === "active") {
    return { success: false, message: "You already have an active premium subscription." };
  }

  _write({
    state:       "trial",
    trialCode:   clean,
    trialExpiry: Date.now() + days * 86400000,
    activatedAt: Date.now(),
  });

  return { success: true, message: `${days}-day premium trial activated.`, daysGranted: days };
}

/**
 * deactivate() — called on subscription cancellation / refund
 */
function deactivate() {
  _write({ state: "free" });
}

/**
 * refreshRC(isActive) — called when RevenueCat returns entitlement status
 * isActive: boolean from RevenueCat entitlement check
 */
function refreshRC(isActive) {
  const s = _read();
  if (isActive) {
    _write({ ...s, state: "active", rcActive: true, rcVerifiedAt: Date.now() });
  } else {
    if (s.state === "active" && s.rcActive) {
      // Was active, now not — check grace period
      const elapsed = s.rcVerifiedAt ? (Date.now() - s.rcVerifiedAt) / 86400000 : 999;
      if (elapsed > GRACE_DAYS) {
        _write({ ...s, state: "free", rcActive: false });
      }
      // else: still within grace — stay active
    }
  }
}

// ── REVENUECAT INTEGRATION ────────────────────────────────────────
/**
 * RevenueCat product identifiers.
 * These must exactly match the product IDs created in App Store Connect.
 *
 * App Store Connect setup required before going live:
 *   1. Create subscription group "GI OS Premium" in App Store Connect
 *   2. Create two products within the group:
 *        - gios_premium_monthly  (£7.99/month)
 *        - gios_premium_annual   (£47.99/year)
 *   3. Create RevenueCat project at app.revenuecat.com
 *   4. Add App Store app to RevenueCat, paste App Store shared secret
 *   5. Create entitlement named "premium", attach both products to it
 *   6. Copy your RevenueCat public iOS API key below
 *   7. npm install @revenuecat/purchases-capacitor in each module project
 *   8. npx cap sync ios
 */
const RC_API_KEY        = "REPLACE_WITH_REVENUECAT_IOS_API_KEY";
const RC_ENTITLEMENT    = "premium";
const RC_PRODUCT_ANNUAL  = "gios_premium_annual";
const RC_PRODUCT_MONTHLY = "gios_premium_monthly";

/**
 * _rcAvailable() — true when running inside Capacitor with RC plugin loaded
 */
function _rcAvailable() {
  return !!(window.Capacitor?.isNativePlatform?.() && window.Purchases);
}

/**
 * _rcConfigure() — initialise RC SDK once per session
 * Safe to call multiple times — RC ignores subsequent calls.
 */
async function _rcConfigure() {
  if (!_rcAvailable()) return false;
  try {
    await window.Purchases.configure({ apiKey: RC_API_KEY });
    return true;
  } catch(e) {
    console.warn("RevenueCat configure error:", e);
    return false;
  }
}

/**
 * _rcCheckEntitlement() — verify active entitlement with RC servers
 * Updates local state. Call on boot and after any purchase.
 * Returns true if entitlement is active.
 */
async function _rcCheckEntitlement() {
  if (!_rcAvailable()) return false;
  try {
    await _rcConfigure();
    const { customerInfo } = await window.Purchases.getCustomerInfo();
    const isActive = !!customerInfo?.entitlements?.active?.[RC_ENTITLEMENT];
    refreshRC(isActive);
    return isActive;
  } catch(e) {
    console.warn("RevenueCat entitlement check error:", e);
    return false;
  }
}

/**
 * purchase(plan) — RevenueCat purchase flow
 * plan: "annual" | "monthly"
 * Returns Promise<{ success: bool, error?: string }>
 *
 * In non-Capacitor environments (web preview), falls back to stub
 * so development workflow is unaffected.
 */
async function purchase(plan) {
  // ── Non-Capacitor fallback (web preview / dev) ─────────────
  if (!_rcAvailable()) {
    return new Promise(resolve => {
      setTimeout(() => {
        activate("dev_stub_token");
        resolve({ success: true });
      }, 800);
    });
  }

  // ── RevenueCat purchase ─────────────────────────────────────
  const productId = plan === "monthly" ? RC_PRODUCT_MONTHLY : RC_PRODUCT_ANNUAL;

  try {
    await _rcConfigure();

    // Fetch available offerings to get the Package object RC needs
    const { current } = await window.Purchases.getOfferings();
    if (!current) {
      return { success: false, error: "No offerings available. Please try again later." };
    }

    // Find the right package from the current offering
    const pkg = current.availablePackages?.find(p =>
      p.product?.productIdentifier === productId ||
      (plan === "annual"  && p.packageType === "ANNUAL") ||
      (plan === "monthly" && p.packageType === "MONTHLY")
    );

    if (!pkg) {
      return { success: false, error: "Product not found. Please contact support." };
    }

    // Trigger StoreKit purchase sheet
    const { customerInfo } = await window.Purchases.purchasePackage({ aPackage: pkg });

    const isActive = !!customerInfo?.entitlements?.active?.[RC_ENTITLEMENT];
    if (isActive) {
      activate(customerInfo.originalAppUserId || "rc_verified");
      return { success: true };
    }

    return { success: false, error: "Purchase completed but entitlement not found. Tap 'Restore' below." };

  } catch(e) {
    // RevenueCat throws with a userCancelled flag — don't show error for cancellation
    if (e?.userCancelled === true || e?.code === "1") {
      return { success: false, error: null }; // silent — user chose to cancel
    }
    const msg = e?.message || "Purchase failed. Please try again.";
    console.warn("RevenueCat purchase error:", e);
    return { success: false, error: msg };
  }
}

/**
 * restore() — restore existing App Store purchases via RevenueCat
 * Returns Promise<{ success: bool, error?: string }>
 */
async function restore() {
  if (!_rcAvailable()) {
    return { success: false, error: "Restore is only available in the iOS app." };
  }

  try {
    await _rcConfigure();
    const { customerInfo } = await window.Purchases.restorePurchases();
    const isActive = !!customerInfo?.entitlements?.active?.[RC_ENTITLEMENT];

    if (isActive) {
      activate(customerInfo.originalAppUserId || "rc_restored");
      return { success: true };
    }

    return {
      success: false,
      error: "No active subscription found for this Apple ID. If you believe this is an error, contact support."
    };
  } catch(e) {
    console.warn("RevenueCat restore error:", e);
    return { success: false, error: e?.message || "Restore failed. Please try again." };
  }
}

/**
 * checkOnBoot() — call once at module boot after RC is configured
 * Silently refreshes entitlement state from RC servers.
 * Non-blocking — module boots normally regardless of outcome.
 */
async function checkOnBoot() {
  if (!_rcAvailable()) return;
  try {
    await _rcConfigure();
    await _rcCheckEntitlement();
  } catch(e) {
    // Non-fatal — local state persists within grace period
    console.warn("RevenueCat boot check error:", e);
  }
}

// ── PAYWALL UI ────────────────────────────────────────────────────
/**
 * showPaywall(moduleKey, onSuccess) — renders the upgrade screen
 * Call this instead of rendering the gated content
 */
function showPaywall(moduleKey, onSuccess) {
  _injectPaywallStyles();

  const existing = document.getElementById("gios-paywall");
  if (existing) existing.remove();

  const { trialDaysLeft, state } = getState();

  const overlay = document.createElement("div");
  overlay.id = "gios-paywall";
  overlay.className = "pw-overlay";
  overlay.innerHTML = `
    <div class="pw-modal">
      <div class="pw-header">
        <div class="pw-icon">✦</div>
        <div class="pw-title">GI OS Premium</div>
        <div class="pw-sub">Unlock your clinical insights</div>
      </div>

      <div class="pw-features">
        <div class="pw-feature">
          <span class="pw-check">✓</span>
          <div>
            <div class="pw-fname">Personalized guidance after every log</div>
            <div class="pw-fdesc">Specific recommendations based on what you logged today</div>
          </div>
        </div>
        <div class="pw-feature">
          <span class="pw-check">✓</span>
          <div>
            <div class="pw-fname">Insights & trend charts</div>
            <div class="pw-fdesc">Score trends, pattern analysis, clinical trajectory</div>
          </div>
        </div>
        <div class="pw-feature">
          <span class="pw-check">✓</span>
          <div>
            <div class="pw-fname">Next steps</div>
            <div class="pw-fdesc">Ranked clinical actions based on your logged data</div>
          </div>
        </div>
        <div class="pw-feature pw-free-note">
          <span class="pw-check pw-check-free">✓</span>
          <div>
            <div class="pw-fname">Clinician report — always free</div>
            <div class="pw-fdesc">Generate and share with your gastroenterologist any time</div>
          </div>
        </div>
      </div>

      <div class="pw-pricing">
        <button class="pw-btn pw-btn-annual" id="pwBtnAnnual" type="button">
          <div class="pw-btn-label">£47.99 / year</div>
          <div class="pw-btn-sub">Best value · 5 months free</div>
        </button>
        <button class="pw-btn pw-btn-monthly" id="pwBtnMonthly" type="button">
          <div class="pw-btn-label">£7.99 / month</div>
          <div class="pw-btn-sub">Cancel any time</div>
        </button>
      </div>

      <div class="pw-code-row">
        <input class="pw-code-input" id="pwCodeInput" type="text"
          placeholder="Clinician activation code"
          autocomplete="off" autocorrect="off" autocapitalize="characters" />
        <button class="pw-code-btn" id="pwCodeBtn" type="button">Apply</button>
      </div>
      <div class="pw-code-msg" id="pwCodeMsg"></div>

      <button class="pw-dismiss" id="pwDismiss" type="button">Continue with free version</button>

      <div class="pw-legal">
        Subscriptions managed via App Store. Cancel any time in Settings.
        Restoring a purchase? <span class="pw-restore" id="pwRestore">Tap here.</span>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  // Annual purchase
  overlay.querySelector("#pwBtnAnnual").addEventListener("click", async () => {
    await _handlePurchase(overlay, onSuccess, "annual");
  });

  // Monthly purchase
  overlay.querySelector("#pwBtnMonthly").addEventListener("click", async () => {
    await _handlePurchase(overlay, onSuccess, "monthly");
  });

  // Activation code
  overlay.querySelector("#pwCodeBtn").addEventListener("click", () => {
    const code = overlay.querySelector("#pwCodeInput").value;
    const result = activateCode(code);
    const msgEl = overlay.querySelector("#pwCodeMsg");
    msgEl.textContent = result.message;
    msgEl.className = "pw-code-msg " + (result.success ? "ok" : "err");
    if (result.success) {
      setTimeout(() => {
        overlay.remove();
        if (onSuccess) onSuccess();
      }, 1200);
    }
  });

  // Code input — enter key
  overlay.querySelector("#pwCodeInput").addEventListener("keydown", e => {
    if (e.key === "Enter") overlay.querySelector("#pwCodeBtn").click();
  });

  // Dismiss
  overlay.querySelector("#pwDismiss").addEventListener("click", () => {
    overlay.remove();
  });

  // Restore purchases via RevenueCat
  overlay.querySelector("#pwRestore").addEventListener("click", async () => {
    const msgEl = overlay.querySelector("#pwCodeMsg");
    const restoreBtn = overlay.querySelector("#pwRestore");
    msgEl.textContent = "Checking for existing subscription…";
    msgEl.className = "pw-code-msg";
    restoreBtn.style.pointerEvents = "none";

    const result = await restore();

    restoreBtn.style.pointerEvents = "";
    if (result.success) {
      msgEl.textContent = "Subscription restored successfully.";
      msgEl.className = "pw-code-msg ok";
      setTimeout(() => {
        overlay.remove();
        if (onSuccess) onSuccess();
      }, 900);
    } else {
      msgEl.textContent = result.error || "No active subscription found.";
      msgEl.className = "pw-code-msg err";
    }
  });
}

async function _handlePurchase(overlay, onSuccess, plan) {
  const btn = overlay.querySelector(plan === "annual" ? "#pwBtnAnnual" : "#pwBtnMonthly");
  btn.disabled = true;
  btn.querySelector(".pw-btn-label").textContent = "Processing…";

  try {
    const result = await purchase();
    if (result.success) {
      overlay.remove();
      if (onSuccess) onSuccess();
    } else {
      btn.disabled = false;
      btn.querySelector(".pw-btn-label").textContent = plan === "annual" ? "£47.99 / year" : "£7.99 / month";
      const msgEl = overlay.querySelector("#pwCodeMsg");
      msgEl.textContent = result.error || "Purchase failed. Please try again.";
      msgEl.className = "pw-code-msg err";
    }
  } catch(e) {
    btn.disabled = false;
    btn.querySelector(".pw-btn-label").textContent = plan === "annual" ? "£47.99 / year" : "£7.99 / month";
  }
}

// ── PAYWALL STYLES ────────────────────────────────────────────────
function _injectPaywallStyles() {
  if (document.getElementById("pw-styles")) return;
  const s = document.createElement("style");
  s.id = "pw-styles";
  s.textContent = `
    .pw-overlay {
      position: fixed; inset: 0; z-index: 9998;
      background: rgba(8,12,20,.88);
      backdrop-filter: blur(8px);
      display: flex; align-items: center; justify-content: center;
      padding: 20px;
      animation: pwFadeIn .2s ease;
    }
    @keyframes pwFadeIn { from { opacity:0 } to { opacity:1 } }

    .pw-modal {
      background: linear-gradient(160deg, rgba(20,30,44,.98), rgba(14,22,34,.98));
      border: 1px solid rgba(255,255,255,.1);
      border-radius: 22px;
      width: 100%; max-width: 400px;
      padding: 28px 24px 20px;
      animation: pwSlide .28s ease;
    }
    @keyframes pwSlide { from { transform:translateY(16px);opacity:0 } to { transform:translateY(0);opacity:1 } }

    .pw-header { text-align: center; margin-bottom: 22px; }
    .pw-icon {
      font-size: 28px; color: #f5c842;
      margin-bottom: 8px;
    }
    .pw-title {
      font-size: 20px; font-weight: 700;
      color: #e8ecf4; margin-bottom: 4px;
    }
    .pw-sub { font-size: 13px; color: #6b7a94; }

    .pw-features { display: flex; flex-direction: column; gap: 12px; margin-bottom: 22px; }
    .pw-feature {
      display: flex; align-items: flex-start; gap: 12px;
    }
    .pw-check {
      width: 20px; height: 20px; border-radius: 50%;
      background: rgba(120,194,164,.2); color: #78c2a4;
      display: flex; align-items: center; justify-content: center;
      font-size: 11px; font-weight: 700; flex-shrink: 0;
      margin-top: 1px;
    }
    .pw-check-free { background: rgba(255,255,255,.06); color: #6b7a94; }
    .pw-fname { font-size: 13px; font-weight: 600; color: #e8ecf4; margin-bottom: 2px; }
    .pw-fdesc { font-size: 11px; color: #6b7a94; line-height: 1.4; }
    .pw-free-note .pw-fname { color: #6b7a94; }

    .pw-pricing { display: flex; flex-direction: column; gap: 8px; margin-bottom: 14px; }
    .pw-btn {
      width: 100%; padding: 13px 16px;
      border-radius: 12px; border: 1px solid rgba(255,255,255,.08);
      cursor: pointer; text-align: left;
      transition: opacity .12s, transform .1s;
    }
    .pw-btn:hover { opacity: .9; transform: translateY(-1px); }
    .pw-btn:disabled { opacity: .5; cursor: not-allowed; transform: none; }
    .pw-btn-annual {
      background: linear-gradient(135deg, rgba(120,194,164,.18), rgba(120,194,164,.08));
      border-color: rgba(120,194,164,.35);
    }
    .pw-btn-monthly {
      background: rgba(255,255,255,.03);
    }
    .pw-btn-label { font-size: 15px; font-weight: 700; color: #e8ecf4; }
    .pw-btn-sub { font-size: 11px; color: #6b7a94; margin-top: 2px; }

    .pw-code-row {
      display: flex; gap: 8px; margin-bottom: 6px;
    }
    .pw-code-input {
      flex: 1; height: 40px; border-radius: 8px;
      border: 1px solid rgba(255,255,255,.1);
      background: rgba(255,255,255,.04); color: #e8ecf4;
      padding: 0 12px; font-size: 13px;
      font-family: monospace; letter-spacing: .08em;
      text-transform: uppercase; outline: none;
    }
    .pw-code-input:focus { border-color: rgba(120,194,164,.4); }
    .pw-code-input::placeholder { text-transform: none; letter-spacing: 0; color: #4a5568; }
    .pw-code-btn {
      height: 40px; padding: 0 14px; border-radius: 8px;
      border: 1px solid rgba(255,255,255,.1);
      background: rgba(255,255,255,.06); color: #e8ecf4;
      font-size: 13px; cursor: pointer;
    }
    .pw-code-msg {
      font-size: 12px; min-height: 18px;
      margin-bottom: 10px; padding: 0 2px;
    }
    .pw-code-msg.ok { color: #78c2a4; }
    .pw-code-msg.err { color: #e07a7a; }

    .pw-dismiss {
      width: 100%; padding: 10px; border: none;
      background: transparent; color: #4a5568;
      font-size: 12px; cursor: pointer;
      margin-bottom: 10px;
    }
    .pw-dismiss:hover { color: #6b7a94; }

    .pw-legal {
      font-size: 10px; color: #3a4558; text-align: center;
      line-height: 1.5;
    }
    .pw-restore { text-decoration: underline; cursor: pointer; }
    .pw-restore:hover { color: #6b7a94; }

    /* Premium badge in header */
    .pw-status-badge {
      display: inline-flex; align-items: center; gap: 5px;
      padding: 3px 10px; border-radius: 100px;
      font-family: var(--font-mono, monospace);
      font-size: 10px; letter-spacing: .08em; text-transform: uppercase;
      background: rgba(245,200,66,.12); border: 1px solid rgba(245,200,66,.25);
      color: #f5c842;
    }
    .pw-status-badge.trial {
      background: rgba(120,194,164,.10); border-color: rgba(120,194,164,.25);
      color: #78c2a4;
    }
  `;
  document.head.appendChild(s);
}

// ── HEADER BADGE ──────────────────────────────────────────────────
/**
 * renderBadge(container) — inserts premium/trial status badge
 * Pass the header-right container element
 */
function renderBadge(container) {
  if (!container) return;
  const existing = container.querySelector(".pw-status-badge");
  if (existing) existing.remove();

  const { state, trialDaysLeft } = getState();
  if (state === "free") return;

  const badge = document.createElement("span");
  if (state === "trial") {
    badge.className = "pw-status-badge trial";
    badge.textContent = trialDaysLeft !== null ? `Trial · ${trialDaysLeft}d left` : "Trial";
  } else {
    badge.className = "pw-status-badge";
    badge.textContent = "✦ Premium";
  }
  container.prepend(badge);
}

// ── CLINICIAN REPORT WATERMARK ────────────────────────────────────
/**
 * getReportWatermark() — returns watermark HTML for free tier reports
 * Returns empty string for premium users
 */
function getReportWatermark() {
  if (isPremium()) return "";
  return `<div style="margin-top:24px;padding:10px 14px;border:1px solid #ddd;border-radius:6px;font-size:11px;color:#888;text-align:center;">
    Generated on GI OS free tier · Upgrade for trend analysis and personalized next steps · <strong>giOS.app</strong>
  </div>`;
}

// ── GUIDANCE GATE ─────────────────────────────────────────────────
/**
 * showGuidanceGate(container, moduleKey, onUnlock)
 * Renders a soft paywall nudge inside the guidance panel for free-tier users
 * after the 14-day trial has expired.
 */
function showGuidanceGate(container, moduleKey, onUnlock) {
  if (!container) return;
  const { trialDaysLeft } = getState();
  container.innerHTML = `
    <div style="text-align:center;padding:12px 8px;">
      <div style="font-size:18px;margin-bottom:6px;">✦</div>
      <div style="font-size:13px;font-weight:600;color:var(--fg);margin-bottom:4px;">Personalized guidance is a premium feature</div>
      <div style="font-size:12px;color:var(--muted);margin-bottom:14px;">Your 14-day trial has ended. Upgrade to see specific recommendations based on what you log.</div>
      <button type="button" style="background:var(--accent);color:#000;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:600;cursor:pointer;" id="guidanceUpgradeBtn">See plans</button>
      <div style="font-size:11px;color:var(--muted2);margin-top:10px;">Logging, history, library and clinician report remain free.</div>
    </div>
  `;
  container.querySelector("#guidanceUpgradeBtn")?.addEventListener("click", () => {
    showPaywall(moduleKey, () => { if (onUnlock) onUnlock(); });
  });
}

// ── DEV HELPERS ───────────────────────────────────────────────────
/** Reset to free — dev only */
function _devReset() {
  localStorage.removeItem(SK);
  console.log("PremiumGate reset to free");
}

/** Force active — dev only */
function _devActivate() {
  activate("dev_token");
  console.log("PremiumGate forced to active");
}

return {
  isPremium,
  getState,
  activate,
  activateCode,
  deactivate,
  refreshRC,
  purchase,
  restore,
  checkOnBoot,
  showPaywall,
  renderBadge,
  getReportWatermark,
  showGuidanceGate,
  _devReset,
  _devActivate,
};

})();
