/**
 * GI OS — Onboarding System
 * ═══════════════════════════════════════════════════════════
 * First-run experience for each module.
 * Shows once on first open, never again.
 * Stored in localStorage per module key.
 *
 * Usage (called from each module's boot() function):
 *   Onboarding.show(MODULE_KEY, ONBOARDING_CONFIG);
 * ═══════════════════════════════════════════════════════════
 */

const Onboarding = (() => {
"use strict";

const CONFIGS = {
  ibs: {
    accent:  "#78c2a4",
    title:   "IBS OS",
    badge:   "IBS-SSS · Bristol Scale · Low-FODMAP",
    steps: [
      {
        icon: "📋",
        heading: "What this tracks",
        body: "Daily symptoms scored using the IBS Symptom Severity Score (IBS-SSS) — the same instrument your gastroenterologist uses to measure disease activity. Bristol stool typing, pain severity, bloating, and quality of life logged in under 60 seconds."
      },
      {
        icon: "🎯",
        heading: "The one thing that matters most",
        body: "Log every day, even good days. A good day logged is data. A good day skipped is a gap that makes your patterns harder to read. The streak counter keeps you honest."
      },
      {
        icon: "📊",
        heading: "What to bring to your appointment",
        body: "Use the Clinician Report button to generate a one-page PDF summary. Your gastroenterologist needs your IBS-SSS trend, your top triggers, and whether your symptoms are worse on high-stress days or random — that difference changes treatment."
      },
      {
        icon: "⚠️",
        heading: "When to act immediately",
        body: "IBS does not cause rectal bleeding, waking you from sleep, or unintentional weight loss. If you flag any of these, contact your gastroenterologist — do not assume it is IBS."
      }
    ]
  },
  ibd: {
    accent:  "#e07a5f",
    title:   "IBD OS",
    badge:   "HBI · SCCAI · Calprotectin · Biologics",
    steps: [
      {
        icon: "📋",
        heading: "What this tracks",
        body: "Harvey-Bradshaw Index (Crohn's) or SCCAI (Ulcerative Colitis) scored daily. Calprotectin results logged and trended. Biologic dose adherence tracked. The same instruments your IBD team uses to make treatment decisions."
      },
      {
        icon: "🎯",
        heading: "The one thing that matters most",
        body: "Symptom scores and calprotectin tell different stories. You can feel well with active mucosal inflammation, and feel rough in remission. Log both. The divergence between how you feel and what the score says is often the most important clinical signal."
      },
      {
        icon: "💉",
        heading: "Biologic adherence",
        body: "Log every biologic dose. Missing doses — even occasionally — can trigger loss of response and antibody formation that is difficult to reverse. The app flags missed doses and tracks your injection interval against the prescribed schedule."
      },
      {
        icon: "⚠️",
        heading: "When to act immediately",
        body: "Fever, severe abdominal pain, abscess, or fistula symptoms require same-day contact with your IBD team. Do not manage these at home."
      }
    ]
  },
  gerd: {
    accent:  "#c97dd4",
    title:   "GERD OS",
    badge:   "GERD-Q · Barrett's surveillance · PPI adherence",
    steps: [
      {
        icon: "📋",
        heading: "What this tracks",
        body: "GERD-Q score daily — the validated 6-item questionnaire used in clinics to measure reflux control. PPI timing adherence (the most common cause of treatment failure). Barrett's surveillance interval tracking if applicable."
      },
      {
        icon: "⏰",
        heading: "The one thing that matters most",
        body: "PPI timing. Taking your PPI at breakfast instead of 30–60 minutes before eating halves its effectiveness. Log when you take it, not just whether you took it. If your GERD-Q is not improving on PPI, timing is the first thing to check."
      },
      {
        icon: "🔬",
        heading: "If you have Barrett's",
        body: "Log your endoscopy results and the surveillance interval your gastroenterologist gave you. The app tracks when your next endoscopy is due and alerts you as it approaches. Surveillance intervals matter — a missed endoscopy in Barrett's has serious consequences."
      },
      {
        icon: "⚠️",
        heading: "When to act immediately",
        body: "Dysphagia (difficulty swallowing), odynophagia (painful swallowing), or hematemesis (vomiting blood) are alarm features that require urgent evaluation. Do not manage these with antacids."
      }
    ]
  },
  celiac: {
    accent:  "#e8a44a",
    title:   "Celiac OS",
    badge:   "GFD adherence · TTG-IgA · Exposure log",
    steps: [
      {
        icon: "📋",
        heading: "What this tracks",
        body: "Gluten-free diet adherence day by day. Accidental gluten exposures logged with context (restaurant, cross-contamination, hidden source). Serology results (TTG-IgA) trended over time. Nutritional deficiency monitoring."
      },
      {
        icon: "🎯",
        heading: "The one thing most patients get wrong",
        body: "Symptom improvement is not the same as mucosal healing. You can feel well on a GFD while your villi are still damaged — and vice versa. TTG-IgA normalisation (12–18 months on strict GFD) is the target, not symptom resolution. Log your serology, not just your symptoms."
      },
      {
        icon: "📍",
        heading: "Log every exposure",
        body: "Even small accidental exposures — a shared fryer, a kiss from someone who ate wheat, communion wafers — set back mucosal recovery. Log them. Over time the pattern shows where your exposure risk is highest so you can target it."
      },
      {
        icon: "⚠️",
        heading: "When to act immediately",
        body: "Neurological symptoms, a new skin rash (dermatitis herpetiformis), or severe abdominal pain in a coeliac patient require prompt evaluation. Refractory coeliac disease is a recognised complication requiring specialist review."
      }
    ]
  },
  fd: {
    accent:  "#5b9bd5",
    title:   "Functional Dyspepsia OS",
    badge:   "LPDS · EPS/PDS · Rome IV",
    steps: [
      {
        icon: "📋",
        heading: "What this tracks",
        body: "Leuven Postprandial Distress Score (LPDS) daily — covering epigastric pain, early satiation, postprandial fullness, nausea, belching, and burning. Meal timing and size logged to separate EPS (epigastric pain syndrome) from PDS (postprandial distress syndrome) — they respond to different treatments."
      },
      {
        icon: "🍽️",
        heading: "The one thing that matters most",
        body: "When do your symptoms peak relative to eating? Symptoms during or immediately after meals suggest PDS (prokinetics, dietary modification). Symptoms between meals or unrelated to eating suggest EPS (PPIs, neuromodulators). Log meal timing on every entry — that pattern drives your treatment."
      },
      {
        icon: "🧪",
        heading: "H. pylori",
        body: "If you haven't been tested for H. pylori, ask your gastroenterologist. Eradication produces long-term remission in approximately 10% of FD patients — a small proportion but the only intervention that is potentially curative. Log any H. pylori treatment course in Notes."
      },
      {
        icon: "⚠️",
        heading: "When to act immediately",
        body: "Dysphagia, unintentional weight loss, hematemesis, progressive vomiting, or new iron deficiency anaemia are not features of functional dyspepsia and require urgent investigation."
      }
    ]
  },
  eoe: {
    accent:  "#e06b6b",
    title:   "EoE OS",
    badge:   "EoEAI · Elimination diet · EREFS",
    steps: [
      {
        icon: "📋",
        heading: "What this tracks",
        body: "EoE Activity Index (EoEAI) daily — dysphagia severity, chest pain, regurgitation. Food bolus impaction events logged as discrete clinical records. Elimination diet phase tracked (6FED, 4FED, 2FED, reintroduction). Endoscopy results with peak eosinophil count and EREFS score."
      },
      {
        icon: "🍽️",
        heading: "The most important thing to understand",
        body: "Symptoms do not predict histological activity in EoE. You can have severe dysphagia with <15 eos/hpf, and minimal symptoms with active eosinophilic inflammation. Endoscopy with biopsy is required to confirm remission — symptom improvement alone is not sufficient."
      },
      {
        icon: "🥗",
        heading: "Elimination diet",
        body: "Log your current diet phase and which foods you ate or avoided every day. After each reintroduction endoscopy, the app helps you identify which food group triggered your eosinophilia. This is your personal trigger map — it takes months to build but changes your management permanently."
      },
      {
        icon: "🚨",
        heading: "Food bolus impaction — emergency",
        body: "Complete dysphagia (unable to swallow liquids, pooling saliva) is a medical emergency. Go to the emergency department immediately — do not wait. Every impaction is a signal that your disease is not adequately controlled."
      }
    ]
  },
  nv: {
    accent:  "#6b9de8",
    title:   "N&V OS",
    badge:   "RINVR · CVS phases · Episode log",
    steps: [
      {
        icon: "📋",
        heading: "What this tracks",
        body: "Rhodes Index of Nausea, Vomiting and Retching (RINVR) daily — five domains: nausea frequency, duration, distress, vomiting frequency, and retching. CVS phase (interictal, prodrome, emetic, recovery) logged separately. Discrete episode records for CVS."
      },
      {
        icon: "⏱️",
        heading: "The prodrome is your window",
        body: "In CVS, the prodrome phase — the warning before full emesis begins — is when treatment is most effective. Learn your personal prodrome signs (nausea quality, pallor, specific sensations) and log them. Taking sumatriptan or ondansetron at prodrome onset, not when vomiting has started, dramatically improves outcomes."
      },
      {
        icon: "💊",
        heading: "Prophylaxis adherence",
        body: "Amitriptyline and topiramate build protective effect over weeks. Missing doses — even occasionally — erodes that protection faster than it builds. Log every dose. The most common cause of CVS treatment failure is inconsistent prophylaxis."
      },
      {
        icon: "⚠️",
        heading: "Cannabis and hot showers",
        body: "If you use cannabis regularly and find hot showers relieve your nausea during episodes, this pattern suggests cannabis hyperemesis syndrome rather than CVS. These conditions require different treatment. Be honest in your trigger logging — it matters for your diagnosis."
      }
    ]
  },
  mc: {
    accent:  "#7eb8a4",
    title:   "Microscopic Colitis OS",
    badge:   "MCAI · Nocturnal diarrhoea · Drug triggers",
    steps: [
      {
        icon: "📋",
        heading: "What this tracks",
        body: "MC Activity Index daily — stool frequency, consistency, nocturnal episodes, urgency, and incontinence. Drug triggers logged against your current medication list. Budesonide phase and adherence tracked. Nocturnal diarrhoea flagged as a priority clinical signal."
      },
      {
        icon: "🌙",
        heading: "Nocturnal diarrhoea — log it every day",
        body: "Being woken from sleep to pass stool is the single most important symptom in microscopic colitis. IBS never causes nocturnal diarrhoea. MC frequently does. This one flag, logged consistently, is the primary indicator of disease activity and the clearest signal of whether budesonide is working."
      },
      {
        icon: "💊",
        heading: "Check your medications",
        body: "Drug exposure causes a significant proportion of MC cases. NSAIDs, PPIs (especially lansoprazole), SSRIs, statins, and aspirin are all implicated. Log every medication you take. Stopping the causative drug can produce permanent remission without budesonide — but only if you identify it."
      },
      {
        icon: "⚠️",
        heading: "Blood in stool is not MC",
        body: "Microscopic colitis causes watery, non-bloody diarrhoea. Any rectal bleeding requires investigation for an alternative or coexisting diagnosis. Contact your gastroenterologist today if you notice blood."
      }
    ]
  }
};

// ── STYLES ────────────────────────────────────────────────────────
function injectOnboardingStyles() {
  if (document.getElementById("onboarding-styles")) return;
  const s = document.createElement("style");
  s.id = "onboarding-styles";
  s.textContent = `
    .ob-overlay {
      position: fixed; inset: 0; z-index: 9999;
      background: rgba(10,12,18,.82);
      backdrop-filter: blur(6px);
      display: flex; align-items: center; justify-content: center;
      padding: 20px;
      animation: obFadeIn .25s ease;
    }
    @keyframes obFadeIn { from { opacity:0 } to { opacity:1 } }

    .ob-modal {
      background: var(--surface, #151922);
      border: 1px solid var(--line, rgba(255,255,255,.08));
      border-radius: 20px;
      width: 100%; max-width: 460px;
      overflow: hidden;
      animation: obSlideUp .3s ease;
    }
    @keyframes obSlideUp { from { transform:translateY(20px);opacity:0 } to { transform:translateY(0);opacity:1 } }

    .ob-header {
      padding: 24px 24px 0;
    }
    .ob-badge {
      display: inline-flex; align-items: center; gap: 6px;
      padding: 4px 10px;
      border-radius: 100px;
      font-family: var(--font-mono, monospace);
      font-size: 10px; letter-spacing: .08em;
      text-transform: uppercase;
      margin-bottom: 12px;
    }
    .ob-title {
      font-size: 22px; font-weight: 700;
      color: var(--ink, #e8ecf4);
      line-height: 1.2; margin-bottom: 4px;
    }
    .ob-subtitle {
      font-size: 11px; color: var(--muted, #8892a4);
      font-family: var(--font-mono, monospace);
    }

    .ob-steps {
      padding: 20px 24px;
      display: flex; flex-direction: column; gap: 0;
    }
    .ob-step {
      display: none;
      animation: obStepIn .2s ease;
    }
    .ob-step.active { display: flex; gap: 14px; }
    @keyframes obStepIn { from { opacity:0;transform:translateX(8px) } to { opacity:1;transform:translateX(0) } }

    .ob-icon {
      font-size: 28px; line-height: 1; flex-shrink: 0;
      width: 44px; height: 44px;
      display: flex; align-items: center; justify-content: center;
      background: rgba(255,255,255,.04);
      border-radius: 12px;
    }
    .ob-step-body {}
    .ob-step-heading {
      font-size: 14px; font-weight: 600;
      color: var(--ink, #e8ecf4);
      margin-bottom: 6px;
    }
    .ob-step-text {
      font-size: 13px; line-height: 1.65;
      color: var(--muted, #8892a4);
    }

    .ob-footer {
      padding: 16px 24px 22px;
      display: flex; align-items: center; justify-content: space-between;
      border-top: 1px solid var(--line, rgba(255,255,255,.06));
    }
    .ob-dots {
      display: flex; gap: 6px;
    }
    .ob-dot {
      width: 6px; height: 6px; border-radius: 50%;
      background: var(--line, rgba(255,255,255,.12));
      transition: background .2s, width .2s;
    }
    .ob-dot.active {
      width: 18px; border-radius: 3px;
    }
    .ob-btns { display: flex; gap: 8px; }

    .ob-btn {
      padding: 9px 18px;
      border-radius: 8px;
      font-family: var(--font-mono, monospace);
      font-size: 11px; letter-spacing: .06em; text-transform: uppercase;
      cursor: pointer; border: none;
      transition: opacity .12s, transform .12s;
    }
    .ob-btn:hover { opacity: .85; transform: translateY(-1px); }
    .ob-btn-ghost {
      background: transparent;
      color: var(--muted, #8892a4);
      border: 1px solid var(--line, rgba(255,255,255,.1));
    }
    .ob-btn-primary {
      color: #fff;
    }

    .ob-progress {
      height: 2px;
      background: var(--line, rgba(255,255,255,.06));
      margin: 0 24px 16px;
      border-radius: 1px;
      overflow: hidden;
    }
    
    .ob-time-row {
      padding: 12px 24px 0;
      border-top: 1px solid var(--line, rgba(255,255,255,.06));
      margin-top: 4px;
    }
    .ob-time-label {
      font-size: 12px; color: var(--muted, #8892a4);
      margin-bottom: 8px;
    }
    .ob-time-pick { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .ob-time-input {
      height: 36px; border-radius: 8px;
      border: 1px solid var(--line, rgba(255,255,255,.1));
      background: rgba(255,255,255,.05); color: var(--ink, #e8ecf4);
      padding: 0 10px; font-size: 14px; font-family: monospace;
      outline: none;
    }
    .ob-progress-bar {
      height: 100%; border-radius: 1px;
      transition: width .3s ease;
    }
  `;
  document.head.appendChild(s);
}


// ── NOTIFICATION SCHEDULING ───────────────────────────────────────
/**
 * scheduleReminder(hour, minute)
 * Schedules a daily logging reminder via Capacitor Local Notifications.
 * Falls back gracefully if not in Capacitor environment.
 */
async function scheduleReminder(hour, minute) {
  try {
    // Capacitor Local Notifications (available when wrapped in native app)
    if (window.Capacitor?.isNativePlatform?.() && window.CapacitorLocalNotifications) {
      const { LocalNotifications } = window.CapacitorLocalNotifications;
      await LocalNotifications.requestPermissions();
      await LocalNotifications.schedule({
        notifications: [{
          title: "Time to log",
          body: "How are you feeling today? Takes 60 seconds.",
          id: 42,
          schedule: {
            on: { hour, minute },
            repeats: true,
            every: "day",
            allowWhileIdle: true,
          },
          channelId: "logging-reminder",
        }]
      });
      return true;
    }
    // Web fallback: store preference, platform will handle later
    localStorage.setItem('giplatform_reminder', JSON.stringify({ hour, minute, set: true }));
    return true;
  } catch(e) {
    console.warn('Notification scheduling failed:', e);
    return false;
  }
}

// ── RENDER ────────────────────────────────────────────────────────
function show(moduleKey, store) {
  const cfg = CONFIGS[moduleKey];
  if (!cfg) return;

  // Check if already seen
  const seenKey = `giplatform_s_${moduleKey}`;
  try {
    const s = JSON.parse(localStorage.getItem(seenKey) || "{}");
    if (s.onboardingSeen) return;
  } catch { /* first open */ }

  injectOnboardingStyles();

  let currentStep = 0;
  const totalSteps = cfg.steps.length;

  // Build overlay
  const overlay = document.createElement("div");
  overlay.className = "ob-overlay";
  overlay.setAttribute("role", "dialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-label", `${cfg.title} introduction`);

  overlay.innerHTML = `
    <div class="ob-modal">
      <div class="ob-header">
        <div class="ob-badge" style="background:${cfg.accent}22;color:${cfg.accent};border:1px solid ${cfg.accent}44;">
          <span style="width:6px;height:6px;border-radius:50%;background:${cfg.accent};display:inline-block;"></span>
          ${escHtml(cfg.badge)}
        </div>
        <div class="ob-title">${escHtml(cfg.title)}</div>
        <div class="ob-subtitle">Quick start — 4 things to know</div>
      </div>

      <div class="ob-progress" style="margin-top:16px;">
        <div class="ob-progress-bar" id="obProgressBar" style="background:${cfg.accent};width:${Math.round((1/totalSteps)*100)}%"></div>
      </div>

      <div class="ob-steps" id="obSteps">
        ${cfg.steps.map((step, i) => `
        <div class="ob-step${i===0?" active":""}" data-step="${i}">
          <div class="ob-icon">${step.icon}</div>
          <div class="ob-step-body">
            <div class="ob-step-heading">${escHtml(step.heading)}</div>
            <div class="ob-step-text">${escHtml(step.body)}</div>
          </div>
        </div>`).join("")}
      </div>

      <div class="ob-time-row" id="obTimeRow" style="display:none;">
        <div class="ob-time-label">Set your daily logging reminder</div>
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
          <input type="time" class="ob-time-input" id="obTimeInput" value="08:00" />
          <button class="ob-btn ob-btn-primary" id="obSetReminder" type="button" style="background:${cfg.accent};">Set reminder</button>
          <button class="ob-btn ob-btn-ghost" id="obSkipReminder" type="button">Skip</button>
        </div>
      </div>
      <div class="ob-footer">
        <div class="ob-dots">
          ${cfg.steps.map((_, i) => `<div class="ob-dot${i===0?" active":""}" data-dot="${i}" style="${i===0?`background:${cfg.accent};`:""}"></div>`).join("")}
        </div>
        <div class="ob-btns">
          <button class="ob-btn ob-btn-ghost" id="obSkip" type="button">Skip</button>
          <button class="ob-btn ob-btn-primary" id="obNext" type="button" style="background:${cfg.accent};">Next</button>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  function goTo(step) {
    currentStep = step;
    // Update steps
    overlay.querySelectorAll(".ob-step").forEach((el, i) => {
      el.classList.toggle("active", i === step);
    });
    // Update dots
    overlay.querySelectorAll(".ob-dot").forEach((el, i) => {
      el.classList.toggle("active", i === step);
      el.style.background = i === step ? cfg.accent : "";
    });
    // Update progress bar
    const bar = overlay.querySelector("#obProgressBar");
    if (bar) bar.style.width = Math.round(((step+1)/totalSteps)*100) + "%";
    // Update next button
    const nextBtn = overlay.querySelector("#obNext");
    if (nextBtn) nextBtn.textContent = step === totalSteps-1 ? "Get started" : "Next";
    // Show time picker on final step
    const timeRow = overlay.querySelector("#obTimeRow");
    if (timeRow) timeRow.style.display = step === totalSteps-1 ? "block" : "none";
  }

  function dismiss() {
    overlay.style.animation = "obFadeIn .2s ease reverse";
    setTimeout(() => {
      overlay.remove();
    }, 200);
    // Mark as seen
    try {
      const sk = `giplatform_s_${moduleKey}`;
      const s = JSON.parse(localStorage.getItem(sk) || "{}");
      s.onboardingSeen = true;
      localStorage.setItem(sk, JSON.stringify(s));
    } catch { /* storage unavailable */ }
    // Also try via store if available
    if (store && store.setSetting) {
      store.setSetting("onboardingSeen", true).catch(() => {});
    }
  }

  overlay.querySelector("#obNext").addEventListener("click", () => {
    if (currentStep < totalSteps - 1) {
      goTo(currentStep + 1);
    } else {
      dismiss();
    }
  });

  overlay.querySelector("#obSkip").addEventListener("click", dismiss);

  // Set reminder button
  const setReminderBtn = overlay.querySelector("#obSetReminder");
  const skipReminderBtn = overlay.querySelector("#obSkipReminder");
  if (setReminderBtn) {
    setReminderBtn.addEventListener("click", async () => {
      const timeInput = overlay.querySelector("#obTimeInput");
      const [hour, minute] = (timeInput?.value || "08:00").split(":").map(Number);
      await scheduleReminder(hour, minute);
      setReminderBtn.textContent = "✓ Reminder set";
      setReminderBtn.disabled = true;
      setTimeout(dismiss, 800);
    });
  }
  if (skipReminderBtn) {
    skipReminderBtn.addEventListener("click", dismiss);
  }

  // Keyboard navigation
  overlay.addEventListener("keydown", e => {
    if (e.key === "ArrowRight" || e.key === "Enter") {
      if (currentStep < totalSteps - 1) goTo(currentStep + 1);
      else dismiss();
    }
    if (e.key === "ArrowLeft" && currentStep > 0) goTo(currentStep - 1);
    if (e.key === "Escape") dismiss();
  });
  overlay.focus();
}

function escHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

// ── RESET (dev helper) ────────────────────────────────────────────
function reset(moduleKey) {
  try {
    const sk = `giplatform_s_${moduleKey}`;
    const s = JSON.parse(localStorage.getItem(sk) || "{}");
    delete s.onboardingSeen;
    localStorage.setItem(sk, JSON.stringify(s));
  } catch { /* ignore */ }
}

return { show, reset };
})();
