/**
 * GI OS — Local Push Notifications
 * ════════════════════════════════════════════════════════════════
 * Capacitor local notifications plugin.
 * No backend. No server. Fires entirely from the device.
 * 
 * Setup requirements:
 *   npm install @capacitor/local-notifications
 *   npx cap sync
 * 
 * Usage (called from each module's boot() function):
 *   GIOSNotifications.init(MODULE_KEY, MODULE_DISPLAY_NAME);
 * ════════════════════════════════════════════════════════════════
 */

const GIOSNotifications = (() => {
  "use strict";

  // ── CONFIG ──────────────────────────────────────────────────
  const STORAGE_KEY_PREFIX = "giplatform_notif_";
  const DEFAULT_HOUR = 20;   // 8pm default reminder
  const DEFAULT_MIN  = 0;

  // Rotating reminder messages — avoids habituation
  // Clinically grounded, never alarmist
  const MESSAGES = [
    "Time to log today. 60 seconds keeps your pattern data accurate.",
    "Daily log — your gastroenterologist needs this trend data.",
    "Haven't logged yet today. Tap to record how you're feeling.",
    "Log your symptoms today. Consistency is what makes the data useful.",
    "Good days are worth logging too. Tap to record a quick entry.",
    "Your streak is on the line. 60 seconds to keep it going.",
    "Today's entry is waiting. Your symptom pattern builds one day at a time.",
  ];

  // ── STATE ────────────────────────────────────────────────────
  let _moduleKey = null;
  let _moduleName = null;
  let _plugin = null; // Capacitor LocalNotifications plugin

  // ── HELPERS ──────────────────────────────────────────────────
  function _storageKey() {
    return `${STORAGE_KEY_PREFIX}${_moduleKey}`;
  }

  function _getPrefs() {
    try {
      return JSON.parse(localStorage.getItem(_storageKey()) || "{}");
    } catch { return {}; }
  }

  function _savePrefs(prefs) {
    localStorage.setItem(_storageKey(), JSON.stringify(prefs));
  }

  function _randomMessage() {
    return MESSAGES[Math.floor(Math.random() * MESSAGES.length)];
  }

  function _isCapacitor() {
    return typeof window !== "undefined" &&
           window.Capacitor &&
           window.Capacitor.isNativePlatform &&
           window.Capacitor.isNativePlatform();
  }

  // ── CORE ─────────────────────────────────────────────────────

  /**
   * Request permission and load plugin.
   * Returns true if notifications are available and permitted.
   */
  async function _requestPermission() {
    if (!_isCapacitor()) return false;

    try {
      const { LocalNotifications } = window.Capacitor.Plugins;
      if (!LocalNotifications) return false;
      _plugin = LocalNotifications;

      const perm = await LocalNotifications.requestPermissions();
      return perm.display === "granted";
    } catch (e) {
      console.warn("GIOSNotifications: permission error", e);
      return false;
    }
  }

  /**
   * Schedule daily repeating notification.
   * Cancels any existing notification for this module first.
   */
  async function _schedule(hour, minute) {
    if (!_plugin) return false;

    try {
      // Cancel existing for this module
      await _cancel();

      // Build notification ID from module key (stable integer)
      const notifId = _moduleKey.split("").reduce((a,c) => a + c.charCodeAt(0), 0);

      await _plugin.schedule({
        notifications: [
          {
            id: notifId,
            title: `${_moduleName} — Daily Log`,
            body: _randomMessage(),
            schedule: {
              on: { hour, minute },
              repeats: true,
              allowWhileIdle: true,
            },
            sound: null,
            actionTypeId: "",
            extra: { moduleKey: _moduleKey },
          }
        ]
      });

      return true;
    } catch (e) {
      console.warn("GIOSNotifications: schedule error", e);
      return false;
    }
  }

  /**
   * Cancel scheduled notification for this module.
   */
  async function _cancel() {
    if (!_plugin) return;
    try {
      const notifId = _moduleKey.split("").reduce((a,c) => a + c.charCodeAt(0), 0);
      await _plugin.cancel({ notifications: [{ id: notifId }] });
    } catch (e) { /* ok */ }
  }

  // ── PUBLIC API ───────────────────────────────────────────────

  /**
   * init(moduleKey, moduleName)
   * Called from each module's boot(). Silently sets up notifications
   * if permission was previously granted. Shows no UI on first run —
   * the user must actively enable via the settings UI.
   */
  async function init(moduleKey, moduleName) {
    _moduleKey = moduleKey;
    _moduleName = moduleName;

    const prefs = _getPrefs();
    if (!prefs.enabled) return; // never show uninvited

    const permitted = await _requestPermission();
    if (!permitted) return;

    await _schedule(prefs.hour ?? DEFAULT_HOUR, prefs.min ?? DEFAULT_MIN);
  }

  /**
   * showSettings(containerEl)
   * Renders a notification settings UI into the given container element.
   * Call from each module's settings/onboarding flow.
   */
  async function showSettings(containerEl) {
    if (!containerEl) return;

    const prefs = _getPrefs();
    const isCapacitor = _isCapacitor();

    const h = prefs.hour ?? DEFAULT_HOUR;
    const m = prefs.min ?? DEFAULT_MIN;
    const timeStr = `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;

    containerEl.innerHTML = `
      <div style="padding:16px 0;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
          <div>
            <div style="font-size:14px;font-weight:600;color:var(--fg);">Daily logging reminder</div>
            <div style="font-size:12px;color:var(--muted);margin-top:2px;">Local notification — no account needed</div>
          </div>
          <label style="position:relative;display:inline-block;width:44px;height:26px;cursor:pointer;">
            <input type="checkbox" id="notifToggle" ${prefs.enabled ? "checked" : ""}
              style="opacity:0;width:0;height:0;position:absolute;"
              ${!isCapacitor ? "disabled" : ""}>
            <span id="notifTrack" style="
              position:absolute;inset:0;border-radius:13px;
              background:${prefs.enabled ? "var(--accent)" : "var(--surface2)"};
              transition:background .2s;
            ">
              <span style="
                position:absolute;top:3px;left:${prefs.enabled ? "21px" : "3px"};
                width:20px;height:20px;border-radius:50%;background:white;
                transition:left .2s;box-shadow:0 1px 3px rgba(0,0,0,.3);
              " id="notifThumb"></span>
            </span>
          </label>
        </div>

        <div id="notifTimeRow" style="display:${prefs.enabled ? "flex" : "none"};align-items:center;gap:12px;margin-bottom:12px;">
          <div style="font-size:13px;color:var(--muted);">Remind me at</div>
          <input type="time" id="notifTime" value="${timeStr}"
            style="font-size:14px;background:var(--surface2);border:1px solid var(--border);
                   border-radius:8px;padding:6px 10px;color:var(--fg);font-family:var(--font-mono);">
        </div>

        ${!isCapacitor ? `<div style="font-size:12px;color:var(--muted);font-style:italic;">Notifications are available in the iOS app.</div>` : ""}
      </div>
    `;

    // Wire toggle
    const toggle = containerEl.querySelector("#notifToggle");
    const track = containerEl.querySelector("#notifTrack");
    const thumb = containerEl.querySelector("#notifThumb");
    const timeRow = containerEl.querySelector("#notifTimeRow");
    const timeInput = containerEl.querySelector("#notifTime");

    if (toggle) {
      toggle.addEventListener("change", async () => {
        const enabled = toggle.checked;
        track.style.background = enabled ? "var(--accent)" : "var(--surface2)";
        thumb.style.left = enabled ? "21px" : "3px";
        timeRow.style.display = enabled ? "flex" : "none";

        if (enabled) {
          const permitted = await _requestPermission();
          if (!permitted) {
            toggle.checked = false;
            track.style.background = "var(--surface2)";
            thumb.style.left = "3px";
            _savePrefs({ enabled: false });
            return;
          }
          const [hh, mm] = (timeInput?.value || `${DEFAULT_HOUR}:${DEFAULT_MIN}`)
            .split(":").map(Number);
          await _schedule(hh, mm);
          _savePrefs({ enabled: true, hour: hh, min: mm });
        } else {
          await _cancel();
          _savePrefs({ enabled: false });
        }
      });
    }

    if (timeInput) {
      timeInput.addEventListener("change", async () => {
        if (!prefs.enabled) return;
        const [hh, mm] = timeInput.value.split(":").map(Number);
        await _schedule(hh, mm);
        _savePrefs({ enabled: true, hour: hh, min: mm });
      });
    }
  }

  /**
   * quickEnable(hour, minute)
   * Programmatically enable at a given time — used by onboarding flow.
   */
  async function quickEnable(hour = DEFAULT_HOUR, minute = DEFAULT_MIN) {
    const permitted = await _requestPermission();
    if (!permitted) return false;
    const ok = await _schedule(hour, minute);
    if (ok) _savePrefs({ enabled: true, hour, min: minute });
    return ok;
  }

  return { init, showSettings, quickEnable };

})();

// Export for build system
if (typeof module !== "undefined") module.exports = GIOSNotifications;
