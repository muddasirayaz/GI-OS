/* META
 * @title      Nausea & Vomiting OS — Clinical Tracker
 * @accent     #6b9de8
 * @accent2    #78c2a4
 * @accentGlow rgba(107,157,232,.12)
 */

/**
 * Nausea & Vomiting OS — Module
 * ═══════════════════════════════════════════════════════════
 * Rhodes Index of Nausea, Vomiting and Retching (RINVR),
 * vomiting episode counter, CVS cycle tracking,
 * trigger identification, antiemetic adherence logging,
 * prodrome detection, functional nausea vs CVS differentiation,
 * library covering CVS Rome IV criteria, antiemetics,
 * prophylaxis, dietary management, cannabis hyperemesis,
 * red flags.
 * ═══════════════════════════════════════════════════════════
 */

(() => {
"use strict";

const { Util, Stats, Charts, LibRenderer, IO, KPI, Perf, Disclosure, initStorage, updateStorageModeUI } = Platform;
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

const MODULE_KEY = "nv";

// Clinical subtypes
const SUBTYPES = {
  cvs:        "CVS — Cyclic Vomiting Syndrome",
  functional: "Functional nausea / chronic nausea",
  mixed:      "Mixed / undifferentiated"
};

// CVS phase tracking
const CVS_PHASES = {
  interictal:  { label:"Interictal",   desc:"Between episodes — symptom-free baseline", cls:"ok" },
  prodrome:    { label:"Prodrome",     desc:"Warning phase — nausea building, episode imminent", cls:"warn" },
  emetic:      { label:"Emetic phase", desc:"Active vomiting episode", cls:"danger" },
  recovery:    { label:"Recovery",     desc:"Episode resolving — residual nausea", cls:"warn" }
};

// Trigger categories
const FLAG_KEYS = [
  "stress","anxiety","excitement","infection","menstrual","travel",
  "hotshower","cannabis","alcohol","skippedmed","poorslep","fasting",
  "motion","odour","fatty","spicy"
];

const ALARM_FLAGS = [
  "hematemesis","coffeegrd","severeabdpain","fever","neuro","newonset"
];

// Rhodes Index of Nausea, Vomiting and Retching (RINVR)
// Rhodes & McDaniel, Oncol Nurs Forum 1999
// 8 items × 5-point scale (0–4 each) = 0–32 total
// We use a simplified 5-domain proxy appropriate for daily logging
// Domains: nausea frequency, nausea duration, nausea distress,
//          vomiting frequency, retching frequency
function calcRINVR(d) {
  let s = 0;
  // Nausea frequency (0=none, 1=1-2 occasions, 2=3-4, 3=5-6, 4=>6)
  s += Util.clamp(d.nauseaFreq, 0, 4);
  // Nausea duration (0=none, 1=<1h, 2=1-3h, 3=>3h, 4=constant)
  s += Util.clamp(d.nauseaDur, 0, 4);
  // Nausea distress (0=no nausea, 1=no distress, 2=mild, 3=moderate, 4=severe)
  s += Util.clamp(d.nauseaDistress, 0, 4);
  // Vomiting frequency (0=none, 1=1-2, 2=3-4, 3=5-6, 4=>6 episodes)
  s += Util.clamp(d.vomitFreq, 0, 4);
  // Retching (0=none, 1=mild, 2=moderate, 3=frequent, 4=severe/constant)
  s += Util.clamp(d.retching, 0, 4);
  return Math.min(20, s);
}

function interpRINVR(score) {
  if (score === 0)  return { label:"None",              cls:"ok",     color:"var(--ok)" };
  if (score <= 4)   return { label:"Mild",              cls:"ok",     color:"var(--ok)" };
  if (score <= 10)  return { label:"Moderate",          cls:"warn",   color:"var(--warn)" };
  if (score <= 16)  return { label:"Severe",            cls:"danger", color:"var(--danger)" };
  return                   { label:"Very severe",       cls:"danger", color:"var(--danger)" };
}

// RINVR item descriptors for UI
const NAUSEA_FREQ_OPTS = [
  { val:0, label:"None" }, { val:1, label:"1–2×" },
  { val:2, label:"3–4×" }, { val:3, label:"5–6×" }, { val:4, label:">6×" }
];
const NAUSEA_DUR_OPTS = [
  { val:0, label:"None" }, { val:1, label:"<1 hour" },
  { val:2, label:"1–3 hours" }, { val:3, label:">3 hours" }, { val:4, label:"Constant" }
];
const DISTRESS_OPTS = [
  { val:0, label:"No nausea" }, { val:1, label:"No distress" },
  { val:2, label:"Mild" }, { val:3, label:"Moderate" }, { val:4, label:"Severe" }
];
const VOMIT_FREQ_OPTS = [
  { val:0, label:"None" }, { val:1, label:"1–2 episodes" },
  { val:2, label:"3–4 episodes" }, { val:3, label:"5–6 episodes" }, { val:4, label:">6 episodes" }
];
const RETCHING_OPTS = [
  { val:0, label:"None" }, { val:1, label:"Mild" },
  { val:2, label:"Moderate" }, { val:3, label:"Frequent" }, { val:4, label:"Severe / constant" }
];

function defaultFlags() {
  const f = {};
  [...FLAG_KEYS, ...ALARM_FLAGS].forEach(k => f[k] = false);
  return f;
}

function defaultDraft() {
  return {
    subtype: null, quality: null, cvsPhase: null,
    nauseaFreq: 0, nauseaDur: 0, nauseaDistress: 0,
    vomitFreq: 0, retching: 0,
    vomitCount: 0,       // raw episode counter
    fluidIntake: null,   // adequate/reduced/minimal/nil
    antiemeticTaken: null,
    flags: defaultFlags(), notes: ""
  };
}

// ── LIBRARY ──────────────────────────────────────────────────────
const LIBRARY = (() => {
  const cards = [];
  const add = o => cards.push({ id:(o.cat+"::"+o.title).toLowerCase().replace(/[^a-z0-9]+/g,"-"), ...o });

  // CVS
  add({ cat:"Cyclic Vomiting Syndrome", tag:"cvs", title:"CVS — Rome IV Criteria and Clinical Features",
    why:"CVS is a chronic functional disorder characterised by stereotypic episodes of severe vomiting separated by completely symptom-free intervals. It is frequently overlooked in adults — median time to clinical recognition is 2.7 years from symptom onset.",
    bullets:[
      "Rome IV diagnostic criteria (all required): stereotypic episodes of vomiting with acute onset and lasting <1 week; three or more discrete episodes in the prior year; absence of vomiting between episodes (though other milder symptoms may occur in the interictal phase); criteria fulfilled for >6 months.",
      "Episode characteristics: episodes are remarkably stereotypic in each individual patient — same prodrome, same timing, same peak severity, same duration, same termination. This stereotypy is diagnostically valuable. Onset often at the same time of day (frequently early morning). Peak vomiting frequency can reach 6–12 episodes per hour at the height of the emetic phase.",
      "Associated features: strong association with migraine (in patients or first-degree relatives), autonomic dysfunction (pallor, diaphoresis, temperature dysregulation), photophobia and phonophobia during episodes, abdominal pain in some patients. CVS is now considered part of the migraine spectrum — shared pathophysiology with mitochondrial dysfunction and hypothalamic-autonomic dysregulation."
    ],
    action:"Log every episode with start time, peak, and resolution. The stereotypy of your episodes — logged over time — is the key diagnostic evidence. CVS is a clinical diagnosis; imaging and endoscopy are normal by definition. Your episode log accelerates diagnosis and treatment.",
    more:"CVS was historically considered a paediatric diagnosis. Adult CVS is now well-recognized and has the same pathophysiology. The adult literature is growing rapidly. CVS in adults is associated with a higher prevalence of cannabis use — cannabis hyperemesis syndrome (CHS) is a distinct but related entity that must be excluded (see CHS library card).",
    evidence:"Stanghellini et al., Gastroenterology 2016 (Rome IV); Cyclic Vomiting Syndrome Association (CVSA); Hejazi & McCallum, J Clin Gastroenterol 2011; Abell et al., Neurogastroenterol Motil 2008"
  });

  add({ cat:"Cyclic Vomiting Syndrome", tag:"cvs", title:"CVS Phases and Their Management",
    why:"CVS has four distinct phases requiring different management strategies. Treating the emetic phase the same as prodrome management fails both.",
    bullets:[
      "Interictal phase (between episodes): the goal is prophylaxis — preventing the next episode. Triggers identified from episode logs should be actively avoided. Prophylactic medications (amitriptyline, topiramate, cyproheptadine, coenzyme Q10) are taken daily regardless of symptoms. This is the phase where lifestyle modification and stress management have the highest impact.",
      "Prodrome phase (minutes to hours before episode): early intervention is critical — abort the episode if possible. Antiemetics (ondansetron, promethazine) and triptans (sumatriptan — particularly effective given migraine overlap) given at first prodrome sign abort or significantly attenuate episodes in many patients. Also: move to a quiet dark room, apply heat to abdomen, reduce sensory stimulation.",
      "Emetic phase (active vomiting): supportive care. IV fluids if unable to maintain oral hydration (dehydration is the main complication). Antiemetics IV if oral not tolerated. Ondansetron, promethazine, chlorpromazine (the latter has the strongest evidence for CVS-specific treatment). Triptans — sumatriptan nasal spray or SC injection if oral not feasible. Benzodiazepines for anxiety/agitation component.",
      "Recovery phase: gradual reintroduction of clear fluids, then soft foods. Avoid triggers. Do not prematurely return to normal diet — incomplete recovery triggers relapse."
    ],
    action:"Log CVS phase in every daily entry. Your prodrome symptoms are a personal early warning system — learn them, log them, act on them. The faster you intervene in the prodrome, the better the chance of aborting the episode before the emetic phase begins.",
    evidence:"Abell et al., Neurogastroenterol Motil 2008; Venkatesan et al., Neurogastroenterol Motil 2014; Kovacic et al., J Pediatr 2018; CVSA Adult CVS Guidelines"
  });

  add({ cat:"Cyclic Vomiting Syndrome", tag:"cvs", title:"CVS Triggers — Identification and Avoidance",
    why:"CVS episodes are almost always trigger-mediated. Systematic trigger identification through episode logging is the most impactful intervention available — more so than any single medication.",
    bullets:[
      "Most common triggers in adults: psychological stress and anxiety (most consistent — present in >80% of patients), infections (particularly upper respiratory), menstrual cycle (perimenstrual episodes in women — hormonal trigger), sleep disruption, physical exhaustion, travel, hot weather or hot showers (autonomic trigger — heat exposure triggers hypothalamic dysregulation in susceptible individuals), fasting (skipping meals).",
      "Food triggers: less common than in migraine but relevant. Cheese (tyramine), chocolate, MSG, alcohol, and high-fat meals have been reported. Cannabis — initial antiemetic effect with regular use, paradoxical hyperemesis with chronic heavy use (cannabis hyperemesis syndrome). Hot showers relieving symptoms is the hallmark of CHS, not CVS.",
      "Excitement and positive stress: often overlooked — positive anticipatory excitement (holidays, celebrations, competitive events) triggers episodes as reliably as negative stress. The pathway is hypothalamic activation, not psychological distress."
    ],
    action:"Use the trigger flags in every log entry. After 3–5 episodes logged with prodrome to recovery, compare flags across episodes to identify your personal consistent triggers. This log is what your gastroenterologist needs to optimise prophylaxis.",
    evidence:"Abell et al., Neurogastroenterol Motil 2008; Hejazi & McCallum, J Clin Gastroenterol 2011; CVSA trigger survey data"
  });

  // FUNCTIONAL NAUSEA
  add({ cat:"Functional Nausea", tag:"functional", title:"Functional Nausea — Rome IV Definition",
    why:"Chronic idiopathic nausea and functional vomiting are distinct Rome IV clinical categories. Understanding these categories helps avoid years of unnecessary investigation and inappropriate treatment.",
    bullets:[
      "Chronic idiopathic nausea (Rome IV): bothersome nausea occurring at least several times per week, not consistently associated with vomiting, not explained by another diagnosis. Absent or minimal vomiting. Nausea often worse in the morning, exacerbated by stress and anxiety.",
      "Functional vomiting (Rome IV): average of one or more episodes of vomiting per week, not self-induced, not explained by another medical or psychiatric diagnosis (eating disorders excluded). Normal gastric emptying study distinguishes from gastroparesis.",
      "Pathophysiology: visceral hypersensitivity (heightened sensitivity of gastric and duodenal afferents), impaired gastric accommodation (overlap with functional dyspepsia), gut-brain axis dysregulation with central sensitisation to nausea signals. High comorbidity with anxiety disorders — nausea is a somatic manifestation of the autonomic stress response."
    ],
    action:"Distinguish functional nausea from CVS: functional nausea is present most days without discrete discrete episodes; CVS has stereotypic discrete episodes with complete symptom-free intervals. The distinction matters for treatment — functional nausea responds to neuromodulators and gut-brain approaches; CVS responds to migraine-class prophylaxis.",
    evidence:"Stanghellini et al., Gastroenterology 2016 (Rome IV); Tack et al., Gastroenterology 2016; Van Oudenhove et al., Gastroenterology 2011"
  });

  // ANTIEMETICS
  add({ cat:"Antiemetic Therapy", tag:"meds", title:"Antiemetics — Class by Class",
    why:"Antiemetic selection in CVS and functional nausea is mechanism-based. Using the wrong class for the wrong mechanism produces inferior results.",
    bullets:[
      "5-HT3 antagonists (ondansetron, granisetron): block serotonin receptors in the gut and CTZ. Most effective for acute vomiting. Ondansetron (Zofran) is the most widely used — available as oral dissolvable wafer (useful when oral tolerance is limited). Minimal sedation. First choice for acute CVS emetic phase.",
      "Phenothiazines (prochlorperazine, chlorpromazine): dopamine D2 antagonism in the CTZ and vomiting centre. Chlorpromazine IV has the strongest specific evidence for CVS episode termination. Sedating — useful for patients with anxiety/agitation component. Extrapyramidal side effects possible with repeated use.",
      "Triptans (sumatriptan): 5-HT1B/1D agonists. Originally migraine-specific but highly effective in CVS given the shared pathophysiology. Sumatriptan SC or nasal spray given at prodrome onset aborts CVS episodes in approximately 70% of cases. Standard migraine contraindications apply (cardiovascular disease, uncontrolled hypertension).",
      "Antihistamines (promethazine, cyclizine): H1 antagonism. Sedating. Useful for vestibular component and motion-associated nausea. Less effective for severe CVS vomiting than 5-HT3 antagonists."
    ],
    action:"Log which antiemetic you take and at which phase. The timing matters as much as the drug — ondansetron at prodrome is far more effective than ondansetron during peak emetic phase. Track response (did the episode abort, shorten, or continue unchanged) in Notes.",
    evidence:"Venkatesan et al., Neurogastroenterol Motil 2014; Hejazi & McCallum, J Clin Gastroenterol 2011; Fleisher et al., Pediatrics 1995 (chlorpromazine in CVS)"
  });

  add({ cat:"Antiemetic Therapy", tag:"meds", title:"CVS Prophylaxis — Preventing Episodes",
    why:"Prophylactic therapy in CVS is taken daily between episodes to reduce episode frequency and severity. It is the most impactful long-term intervention.",
    bullets:[
      "Amitriptyline (TCA): the most widely used and evidence-supported CVS prophylactic in adults. Dose: 10–75mg at night. Mechanism: central neuromodulation, migraine prophylaxis, autonomic stabilisation, anxiolysis. Onset 4–8 weeks — do not judge efficacy before 8 weeks. Side effects: sedation, dry mouth, weight gain, QTc prolongation at higher doses.",
      "Topiramate: anticonvulsant with migraine prophylaxis evidence. Dose: 25–100mg daily. Useful when amitriptyline fails or is not tolerated. Side effects: cognitive slowing ('dopa-max'), weight loss (occasionally useful), paresthesia, kidney stones.",
      "Coenzyme Q10 + L-carnitine: mitochondrial cofactors. Evidence from small open-label studies — some patients show significant reduction in episode frequency. Low side effect profile. Rationale: CVS has mitochondrial dysfunction as a proposed mechanism. Dose: CoQ10 100–400mg daily, L-carnitine 1–3g daily.",
      "Cyproheptadine: antihistamine + antiserotonin. More commonly used in paediatric CVS. Can be useful in adults who do not tolerate TCAs."
    ],
    action:"Log prophylactic medication daily. The Skipped medication flag tracks adherence. Missing prophylaxis is a common cause of breakthrough episodes — the protective effect of amitriptyline takes weeks to build and days to lose. Track episode frequency monthly — the primary outcome measure of prophylaxis.",
    evidence:"Venkatesan et al., Neurogastroenterol Motil 2014; Tack et al., Gut 2012; Van Calcar et al., J Pediatr Gastroenterol Nutr 2002 (CoQ10); Hejazi & McCallum, J Clin Gastroenterol 2011"
  });

  // CANNABIS HYPEREMESIS
  add({ cat:"Cannabis Hyperemesis", tag:"chs", title:"Cannabis Hyperemesis Syndrome — Distinguishing from CVS",
    why:"Cannabis hyperemesis syndrome (CHS) mimics CVS and is frequently overlooked or attributed to CVS incorrectly. The distinction is clinically critical — CVS is treated with antiemetics and prophylaxis; CHS resolves only with cannabis cessation.",
    bullets:[
      "Diagnostic features of CHS: cyclic vomiting episodes identical to CVS, in a patient with chronic heavy cannabis use (typically daily use for >1 year). The pathognomonic feature: compulsive hot bathing or showering during episodes, with temporary relief of nausea (hot water activates TRPV1 receptors in the skin, transiently overriding the nausea signal). This feature is present in >90% of CHS but is not a feature of CVS.",
      "Mechanism: paradoxical hyperemesis from chronic cannabis use. THC is acutely antiemetic (acting on CB1 receptors in the gut and CTZ). Chronic high-dose exposure causes CB1 receptor downregulation and altered hypothalamic thermoregulation — producing the opposite effect. The gut becomes hypersensitive to nausea stimuli rather than suppressed.",
      "Treatment: cannabis cessation is the only effective treatment. Haloperidol (D2 antagonist) has emerging evidence for acute episode management — more effective than standard antiemetics in CHS specifically. Topical capsaicin cream applied to the abdomen also shows benefit (TRPV1 mechanism). Ondansetron is largely ineffective in CHS."
    ],
    action:"If you are a regular cannabis user with cyclic vomiting: log cannabis use in Notes and honestly assess whether hot showering during episodes provides relief. CHS cannot be managed long-term — it will not improve with antiemetics, prophylaxis, or dietary changes. Cannabis cessation is the only effective intervention.",
    more:"CHS was first described by Allen et al. (Gut 2004). Its prevalence has increased substantially with higher-potency cannabis products and increased use. It is now estimated to account for a significant proportion of ED presentations for cyclic vomiting in regions with high cannabis prevalence.",
    evidence:"Allen et al., Gut 2004; Galli et al., Mayo Clin Proc 2011; Richards et al., Ann Emerg Med 2017 (haloperidol); Dezieck et al., Basic Clin Pharmacol Toxicol 2017 (capsaicin)"
  });

  // GUT-BRAIN
  add({ cat:"Gut-Brain Axis", tag:"gutbrain", title:"Anxiety, Stress and Nausea — The Mechanism",
    why:"Nausea is one of the most sensitive somatic manifestations of the autonomic stress response. Understanding this helps avoid misattribution and enables effective treatment.",
    bullets:[
      "Mechanism: the vagus nerve carries nausea signals bidirectionally — the gut sends nausea signals to the brain, and the brain (via the dorsal vagal complex) amplifies or suppresses them. Anxiety activates the sympathetic nervous system and simultaneously sensitises the vagal afferents that carry nausea signals. This produces nausea without any gastric pathology.",
      "Anticipatory nausea: a classically conditioned response. Nausea provoked by cues associated with previous nausea-inducing experiences (a specific place, smell, time of day, social situation). Extremely common in CVS (anticipatory anxiety before known trigger situations) and in functional nausea.",
      "Treatment implication: gut-directed hypnotherapy, CBT, and diaphragmatic breathing directly target the vagal hypersensitivity driving functional nausea. These are not alternative therapies — they have the same mechanistic rationale as neuromodulator medications, operating at the gut-brain interface rather than the gut alone."
    ],
    action:"Log stress and anxiety flags consistently. Track whether nausea-dominant days consistently follow flagged stress days. This data supports the case for psychological co-treatment and helps quantify the gut-brain contribution to your symptom pattern.",
    evidence:"Van Oudenhove et al., Gastroenterology 2011; Tack et al., Gastroenterology 2016; Palsson & Whitehead, Gastroenterology 2013"
  });

  // DIETARY
  add({ cat:"Dietary Management", tag:"diet", title:"Dietary Approach to Nausea",
    why:"Dietary modification reduces nausea trigger load. The principles differ by phase — interictal maintenance vs acute episode management.",
    bullets:[
      "Interictal / prevention: small frequent meals (every 3–4 hours) prevent fasting-induced nausea. Low-fat meals (fat delays gastric emptying and increases nausea sensitivity). Avoid identified food triggers. Ginger (1–1.5g daily) has RCT evidence for nausea reduction — can be taken as capsules, tea, or crystallised ginger.",
      "Acute nausea / prodrome: clear fluids only initially — water, dilute fruit juice, electrolyte drinks. Ice chips or frozen fluids often better tolerated than room-temperature liquids. Small amounts frequently rather than large volumes. Cold foods generally better tolerated than hot (reduced odour stimulus).",
      "Recovery phase: BRAT diet (banana, rice, applesauce, toast) as a transitional step. Introduce protein before fat. Avoid high-fat, spicy, or strongly odoured foods until fully recovered."
    ],
    action:"Log fluid intake using the Fluid intake field in each daily entry. Dehydration accelerates during emetic phases and worsens nausea through a positive feedback loop. Tracking minimum fluid intake across episodes helps identify whether IV fluids were needed and when.",
    evidence:"Ernst & Pittler, Br J Anaesth 2000 (ginger); Vutyavanich et al., Obstet Gynecol 2001 (ginger); Pertz et al., J Planta Med 2011"
  });

  // RED FLAGS
  add({ cat:"Red Flags", tag:"safety", title:"When Nausea and Vomiting Require Urgent Investigation",
    why:"CVS and functional nausea are clinical conclusions reached after excluding structural causes. These features mandate urgent evaluation.",
    bullets:[
      "Emergency: hematemesis (vomiting blood — any amount). Coffee-ground vomit (digested blood — upper GI bleed). Severe abdominal pain with vomiting (bowel obstruction, pancreatitis, appendicitis, mesenteric ischaemia). Vomiting with severe headache or neurological symptoms (raised ICP, subarachnoid haemorrhage).",
      "Urgent: new-onset cyclic vomiting without prior diagnosis — requires full investigation before CVS is assumed. Vomiting with weight loss >5% unexplained. Vomiting with fever and right iliac fossa pain (appendicitis). Projectile vomiting without nausea (suggests CNS cause or pyloric obstruction).",
      "Not CVS until proven: the first episode of cyclic vomiting must be investigated. CVS is a pattern diagnosis — the stereotypy must be established over multiple episodes. A single dramatic episode of severe vomiting requires urgent evaluation."
    ],
    action:"Hematemesis = emergency department immediately. New-onset severe vomiting without prior diagnosis = urgent medical review. Do not assume CVS or functional nausea without a prior established diagnosis.",
    evidence:"NICE guidelines; Hejazi & McCallum, J Clin Gastroenterol 2011; Stanghellini et al., Gastroenterology 2016"
  });

  return { cards };
})();

const LIB_CATS = ["all", ...new Set(LIBRARY.cards.map(c => c.cat))];

// ── STATE ────────────────────────────────────────────────────────
const State = {
  store: null, premium: false,
  subtype: null,
  draft: defaultDraft(), lastEntry: null,
  libCat: "all", libQuery: ""
};

// ── HELPERS ──────────────────────────────────────────────────────
function makeRINVRChips(opts, field, labelId) {
  return `<div class="p-chips" data-rinvr="${field}">
    ${opts.map(o => `<button class="p-chip" type="button" data-level="${o.val}" aria-pressed="${o.val===0?"true":"false"}">${Util.esc(o.label)}</button>`).join("")}
  </div>`;
}

// ── HTML ─────────────────────────────────────────────────────────
function renderHTML() {
  document.getElementById("module-root").innerHTML = `
<div class="p-app">
  <header class="p-header">
    <div class="p-brand">
      <div class="p-logo-dot" aria-hidden="true"></div>
      <div>
        <h1 class="p-brand-name">Nausea & Vomiting OS</h1>
        <div class="p-brand-sub">Symptom tracker</div>
      </div>
    </div>
    <div class="p-header-right">
      <div class="p-pill">🔥 <b id="kpiStreak">0</b>&nbsp;·&nbsp;7d <b id="kpi7d">0</b>&nbsp;·&nbsp;<b id="kpiTotal">0</b> total</div>
    </div>
  </header>

  <nav class="p-nav">
    <div class="p-tabs" role="tablist">
      <button class="p-tab" role="tab" id="tab-log"      aria-selected="true"  data-tab="log"      type="button">Log</button>
      <button class="p-tab" role="tab" id="tab-episodes" aria-selected="false" data-tab="episodes" type="button">Episodes</button>
      <button class="p-tab" role="tab" id="tab-history"  aria-selected="false" data-tab="history"  type="button">History</button>
      <button class="p-tab" role="tab" id="tab-library"  aria-selected="false" data-tab="library"  type="button">Library</button>
      <button class="p-tab" role="tab" id="tab-insights" aria-selected="false" data-tab="insights" type="button">Insights</button>
    </div>
  </nav>

  <!-- LOG -->
  <section id="view-log">
    <div class="p-grid two">
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>How are you today?</h2><p>Takes about a minute</p></div>
          <div class="p-kpis"><div class="p-kpi">Date <b id="todayLabel"></b></div></div>
        </div>
        <div class="p-card-b">

          <!-- Step 1: Subtype -->
          <div id="stepSubtype">
            <div class="p-labelrow"><div class="p-lbl">First — what's your diagnosis?</div><div class="p-hint">saved permanently</div></div>
            <div class="p-seg">
              ${Object.entries(SUBTYPES).map(([k,v]) =>
                `<button class="p-segBtn" type="button" data-sub="${k}" aria-pressed="false" style="font-size:11px;">${v.split(" — ")[0]}</button>`
              ).join("")}
            </div>
            <div id="subtypeConfirm" class="hidden" style="margin-top:8px;">
              <div class="p-callout" style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
                <span>Diagnosis: <b id="subtypeLabel">—</b></span>
                <button class="p-btn ghost sm" type="button" id="btnChangeSub">Change</button>
              </div>
            </div>
          </div>

          <!-- Step 2: Overall day -->
          <div id="stepQuality" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">How was today overall?</div><div class="p-hint">required</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-quality="great" aria-pressed="false">Great</button>
              <button class="p-segBtn" type="button" data-quality="okay"  aria-pressed="false">Okay</button>
              <button class="p-segBtn" type="button" data-quality="rough" aria-pressed="false">Rough</button>
            </div>
          </div>

          <!-- Step 3: CVS Phase (CVS only) -->
          <div id="stepPhase" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Which phase are you in today?</div><div class="p-hint">tap to select</div></div>
            <div style="display:flex;flex-direction:column;gap:6px;">
              ${Object.entries(CVS_PHASES).map(([k,v]) => `
              <button class="p-phaseBtn" type="button" data-phase="${k}" aria-selected="false">
                <div style="font-weight:700;font-size:12px;color:var(--${v.cls})">${Util.esc(v.label)}</div>
                <div style="font-size:11px;color:var(--muted2);">${Util.esc(v.desc)}</div>
              </button>`).join("")}
            </div>
          </div>

          <!-- Step 4: Rhodes Index RINVR -->
          <div id="stepRINVR" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Step ${State.subtype==="cvs"?"4":"3"} — Nausea and vomiting today</div><div class="p-hint">tap to select</div></div>

            <div class="p-labelrow" style="margin-top:8px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Nausea frequency today</div><div class="p-hint" id="nfLabel">none</div></div>
            ${makeRINVRChips(NAUSEA_FREQ_OPTS,"nauseaFreq","nfLabel")}

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Nausea duration (longest episode)</div><div class="p-hint" id="ndLabel">none</div></div>
            ${makeRINVRChips(NAUSEA_DUR_OPTS,"nauseaDur","ndLabel")}

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Nausea distress level</div><div class="p-hint" id="nxLabel">none</div></div>
            ${makeRINVRChips(DISTRESS_OPTS,"nauseaDistress","nxLabel")}

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Vomiting frequency</div><div class="p-hint" id="vfLabel">none</div></div>
            ${makeRINVRChips(VOMIT_FREQ_OPTS,"vomitFreq","vfLabel")}

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Retching</div><div class="p-hint" id="rrLabel">none</div></div>
            ${makeRINVRChips(RETCHING_OPTS,"retching","rrLabel")}
          </div>

          <!-- Step 5: Vomiting counter -->
          <div id="stepCounter" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Vomiting episodes today</div><div class="p-hint">tap to count</div></div>
            <div class="p-counterRow">
              <button class="p-counterBtn minus" type="button" id="btnMinus" aria-label="Decrease">−</button>
              <div class="p-counterVal" id="counterVal">0</div>
              <button class="p-counterBtn plus" type="button" id="btnPlus" aria-label="Increase">+</button>
            </div>
            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Fluid intake today</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-fluid="adequate"  aria-pressed="false" style="font-size:11px;">Adequate</button>
              <button class="p-segBtn" type="button" data-fluid="reduced"   aria-pressed="false" style="font-size:11px;">Reduced</button>
              <button class="p-segBtn" type="button" data-fluid="minimal"   aria-pressed="false" style="font-size:11px;">Minimal</button>
              <button class="p-segBtn" type="button" data-fluid="nil"       aria-pressed="false" style="font-size:11px;">Nil by mouth</button>
            </div>
            <div id="fluidAlert" class="p-callout danger hidden" style="margin-top:8px;font-size:12px;">
              Nil by mouth or minimal fluid intake: if this persists beyond 12–24 hours, IV fluid replacement may be needed. Contact your medical team.
            </div>
          </div>

          <!-- Step 6: Antiemetic -->
          <div id="stepMeds" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Antiemetic taken today?</div><div class="p-hint">adherence tracking</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-antiemetic="yes"     aria-pressed="false">✓ Taken</button>
              <button class="p-segBtn" type="button" data-antiemetic="rescue"  aria-pressed="false">Rescue dose</button>
              <button class="p-segBtn" type="button" data-antiemetic="skipped" aria-pressed="false">Skipped</button>
              <button class="p-segBtn" type="button" data-antiemetic="none"    aria-pressed="false">Not prescribed</button>
            </div>
          </div>

          <!-- Step 7: Triggers & flags -->
          <div id="stepTriggers" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Triggers today</div><div class="p-hint">mark all that apply</div></div>
            <div class="p-chips">
              <button class="p-chip warn" type="button" data-flag="stress"      aria-pressed="false">Stress / anxiety</button>
              <button class="p-chip warn" type="button" data-flag="excitement"  aria-pressed="false">Excitement / anticipation</button>
              <button class="p-chip warn" type="button" data-flag="poorslep"    aria-pressed="false">Poor sleep</button>
              <button class="p-chip warn" type="button" data-flag="fasting"     aria-pressed="false">Skipped meal / fasting</button>
              <button class="p-chip"      type="button" data-flag="infection"   aria-pressed="false">Infection / illness</button>
              <button class="p-chip"      type="button" data-flag="menstrual"   aria-pressed="false">Menstrual cycle</button>
              <button class="p-chip"      type="button" data-flag="travel"      aria-pressed="false">Travel / motion</button>
              <button class="p-chip warn" type="button" data-flag="hotshower"   aria-pressed="false">Hot shower relief</button>
              <button class="p-chip warn" type="button" data-flag="cannabis"    aria-pressed="false">Cannabis use</button>
              <button class="p-chip"      type="button" data-flag="alcohol"     aria-pressed="false">Alcohol</button>
              <button class="p-chip warn" type="button" data-flag="skippedmed"  aria-pressed="false">Skipped prophylaxis</button>
              <button class="p-chip"      type="button" data-flag="odour"       aria-pressed="false">Strong odour</button>
              <button class="p-chip"      type="button" data-flag="fatty"       aria-pressed="false">High-fat meal</button>
              <button class="p-chip"      type="button" data-flag="spicy"       aria-pressed="false">Spicy food</button>
            </div>

            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;">
              <div class="p-lbl" style="font-size:11px;color:var(--danger);">Alarm features</div>
              <div class="p-hint">urgent if present</div>
            </div>
            <div class="p-chips">
              <button class="p-chip danger" type="button" data-flag="hematemesis"   aria-pressed="false">Blood in vomit</button>
              <button class="p-chip danger" type="button" data-flag="coffeegrd"     aria-pressed="false">Coffee-ground vomit</button>
              <button class="p-chip danger" type="button" data-flag="severeabdpain" aria-pressed="false">Severe abdominal pain</button>
              <button class="p-chip danger" type="button" data-flag="fever"         aria-pressed="false">Fever</button>
              <button class="p-chip danger" type="button" data-flag="neuro"         aria-pressed="false">Neurological symptoms</button>
              <button class="p-chip danger" type="button" data-flag="newonset"      aria-pressed="false">First-ever episode</button>
            </div>

            <div id="alarmAlert" class="p-callout danger hidden" style="margin-top:10px;">
              <b>Alarm feature flagged.</b> Blood in vomit, severe abdominal pain, neurological symptoms, or a first-ever episode require urgent medical evaluation. Do not manage at home.
            </div>

            <div class="p-section">
              <div class="p-labelrow"><div class="p-lbl">Notes</div><div class="p-hint"><span id="noteCount">0</span>/600</div></div>
              <textarea id="notes" class="p-note" maxlength="600" placeholder="Specific triggers, food eaten, prodrome timing, medication taken, episode timeline (optional)"></textarea>
            </div>
          </div>

          <!-- Actions -->
          <div id="stepActions" class="p-section hidden">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnSave" disabled>Done</button>
              <button class="p-btn" type="button" id="btnRepeat" disabled>Repeat last</button>
              <button class="p-btn ghost" type="button" id="btnReset">Reset</button>
            </div>
          </div>
        </div>
      </div>

      <!-- RIGHT -->
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>Today's Guidance</h2><p>Personalized to what you logged</p></div>
          
        </div>
        <div class="p-card-b">
          <div id="guidance" class="p-callout">Select your diagnosis and complete the log. Rhodes Index score and guidance will appear here.</div>
          <div id="inlineCard" class="p-section" style="display:none;"></div>

          <div id="scorePanel" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Nausea and vomiting today</div><div class="p-hint">0–20 scale</div></div>
            <div class="p-scoreWrap">
              <div class="p-scoreBig" id="scoreBig">—</div>
              <div class="p-scoreSubLabel">Rhodes Index of Nausea, Vomiting & Retching</div>
            </div>
            <div id="scoreInterp" class="p-callout" style="margin-top:8px;"></div>
          </div>

          <!-- Episode summary -->
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Episode summary</div><div class="p-hint">last 30 days</div></div>
            <div id="episodeSummary" class="p-kpis"></div>
          </div>

          <!-- CVS phase quick ref -->
          <div class="p-section" id="phaseRef">
            <div class="p-labelrow"><div class="p-lbl">Phase action guide</div></div>
            <div style="font-size:12px;color:var(--muted);line-height:1.9;">
              <div><b style="color:var(--ok)">Interictal:</b> prophylaxis daily, avoid triggers</div>
              <div><b style="color:var(--warn)">Prodrome:</b> antiemetic NOW, dark quiet room</div>
              <div><b style="color:var(--danger)">Emetic:</b> fluids, IV if needed, ondansetron/chlorpromazine</div>
              <div><b style="color:var(--warn)">Recovery:</b> clear fluids, soft foods, rest</div>
            </div>
          </div>

          <div class="p-section">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnReport">Clinician report</button>
              <button class="p-btn" type="button" id="btnExportCsv">Export CSV</button>
              <button class="p-btn" type="button" id="btnExportJson">Export JSON</button>
              <button class="p-btn" type="button" id="btnImport">Import</button>
              <input id="importFile" type="file" accept="application/json" class="sr">
            </div>
          </div>
          <div class="p-section">
            <div class="p-premRow" id="premiumCta" style="cursor:pointer;">
              <div class="p-premLabel" id="premStatusLabel">Unlock Premium — trend analytics · trigger correlation · next steps</div>
              <div style="font-family:var(--font-mono);font-size:10px;letter-spacing:.08em;color:#f5c842;">UPGRADE ✦</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- EPISODES -->
  <section id="view-episodes" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Episode Log</h2><p>CVS episode records · start / peak / resolution</p></div>
        <div class="p-kpis"><div class="p-kpi">Episodes <b id="kpiEpisodes">0</b></div></div>
      </div>
      <div class="p-card-b">
        <div class="p-callout" style="margin-bottom:14px;">
          <b>Clinical basis:</b> Log each CVS episode as a discrete record. Stereotypy across episodes — same prodrome, same peak timing, same duration — is the diagnostic hallmark of CVS. This log builds the evidence base for diagnosis and treatment optimisation.
        </div>
        <div class="p-calpRow">
          <div class="p-calpField"><label>Episode start</label><input type="datetime-local" id="epStart"></div>
          <div class="p-calpField"><label>Episode peak</label><input type="datetime-local" id="epPeak"></div>
          <div class="p-calpField"><label>Episode end</label><input type="datetime-local" id="epEnd"></div>
        </div>
        <div class="p-calpRow" style="margin-top:8px;">
          <div class="p-calpField"><label>Max vomits/hour at peak</label><input type="number" id="epPeakRate" placeholder="e.g. 6" min="0" max="30"></div>
          <div class="p-calpField"><label>Prodrome warning (mins)</label><input type="number" id="epProdrome" placeholder="e.g. 30" min="0" max="480"></div>
          <div class="p-calpField" style="flex:2;"><label>Suspected trigger</label><input type="text" id="epTrigger" placeholder="e.g. stress, menstrual, infection" style="width:100%;height:44px;border-radius:10px;border:1px solid var(--line);background:rgba(231,237,245,.03);color:var(--ink);padding:0 12px;outline:none;font-size:13px;"></div>
        </div>
        <div class="p-rowBtns"><button class="p-btn primary" type="button" id="btnSaveEpisode">Save episode</button></div>

        <div class="p-section">
          <div class="p-labelrow"><div class="p-lbl">Episode history</div><div class="p-hint">most recent first</div></div>
          <div class="p-list" id="episodeList"></div>
        </div>
      </div>
    </div>
  </section>

  <!-- HISTORY -->
  <section id="view-history" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>History</h2><p>Most recent first</p></div>
        <div class="p-rowBtns" style="margin:0;">
          <button class="p-btn" type="button" id="btnExportCsv2">Export CSV</button>
          <button class="p-btn" type="button" id="btnExportJson2">Export JSON</button>
        </div>
      </div>
      <div class="p-card-b"><div class="p-list" id="histList"></div></div>
    </div>
  </section>

  <!-- LIBRARY -->
  <section id="view-library" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Clinical Library</h2><p>CVS · functional nausea · antiemetics · prophylaxis · CHS · gut-brain · red flags</p></div>
        <div style="display:flex;gap:10px;align-items:center;">
          <div class="p-kpis"><div class="p-kpi">Cards <b id="kpiCards">0</b></div></div>
          <input id="libSearch" type="search" class="p-search" placeholder="Search CVS, ondansetron, amitriptyline, CHS…">
        </div>
      </div>
      <div class="p-card-b">
        <div class="p-libCats" id="libCats"></div>
        <div class="p-libGrid" id="libGrid"></div>
      </div>
    </div>
  </section>

  <!-- INSIGHTS -->
  <section id="view-insights" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Insights</h2><p>Free: RINVR trend · Premium: episode pattern + trigger correlation + next steps</p></div>
        <button class="p-btn" type="button" id="btnRefresh" style="margin:0;">Refresh</button>
      </div>
      <div class="p-card-b">
        <div id="insightsBody" class="p-callout">Log at least 5 entries to unlock insights.</div>
        <div class="p-section">
          <div class="p-chartWrap"><canvas id="chartRINVR" height="200"></canvas><div class="p-chartMeta">RINVR score trend (last 28 entries)</div></div>
        </div>
        <div id="premiumPanel" class="p-section hidden">
          <div class="p-grid two">
            <div class="p-chartWrap"><canvas id="chartNausea" height="200"></canvas><div class="p-chartMeta">Nausea distress (last 30 entries)</div></div>
            <div class="p-chartWrap"><canvas id="chartVomit" height="200"></canvas><div class="p-chartMeta">Vomiting episodes / day (last 30 entries)</div></div>
          </div>
          <div class="p-section p-grid two">
            <div class="p-callout" id="triggerBox"></div>
            <div class="p-callout" id="chsBox"></div>
          </div>
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Ranked next steps</div></div>
            <div class="p-list" id="nextStepsList"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>`;
}

// ── EXTRA STYLES ─────────────────────────────────────────────────
function injectStyles() {
  const s = document.createElement("style");
  s.textContent = `
    .p-phaseBtn {
      padding:10px 14px; border-radius:12px;
      border:1px solid var(--line); background:rgba(255,255,255,.02);
      color:var(--muted); cursor:pointer; text-align:left;
      transition:border-color .12s,background .12s;
    }
    .p-phaseBtn[aria-selected="true"] {
      border-color:rgba(107,157,232,.5);
      background:rgba(107,157,232,.08);
      color:var(--ink);
    }
    .p-counterRow {
      display:flex; align-items:center; gap:16px;
      justify-content:center; padding:12px 0;
    }
    .p-counterBtn {
      width:48px; height:48px; border-radius:50%;
      border:2px solid var(--line); background:rgba(255,255,255,.03);
      color:var(--ink); font-size:24px; cursor:pointer;
      display:flex; align-items:center; justify-content:center;
      transition:border-color .12s,background .12s;
    }
    .p-counterBtn:hover { border-color:var(--accent); background:var(--accentGlow); }
    .p-counterVal {
      font-size:48px; font-weight:800; font-family:var(--font-mono);
      color:var(--accent); min-width:64px; text-align:center;
      line-height:1;
    }
    .p-calpRow { display:flex; gap:10px; flex-wrap:wrap; }
    .p-calpField { display:flex; flex-direction:column; gap:4px; flex:1; min-width:120px; }
    .p-calpField label { font-size:11px; color:var(--muted); }
    .p-calpField input[type=number], .p-calpField input[type=datetime-local], .p-calpField input[type=text] {
      height:44px; border-radius:10px; border:1px solid var(--line);
      background:rgba(231,237,245,.03); color:var(--ink);
      padding:0 12px; outline:none; font-size:13px; width:100%;
    }
  `;
  document.head.appendChild(s);
}

// ── LOGIC ────────────────────────────────────────────────────────
function setSubtypeUI(sub) {
  State.subtype = sub;
  State.draft.subtype = sub;
  $$("[data-sub]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.sub === sub)));
  const lbl = $("#subtypeLabel"); if(lbl) lbl.textContent = SUBTYPES[sub]?.split(" — ")[0] || sub;
  $("#subtypeConfirm")?.classList.toggle("hidden", !sub);
}

function updateProgress() {
  const d = State.draft;
  const hasSub = !!State.subtype;
  const hasQ   = !!d.quality;
  const isCVS  = State.subtype === "cvs";

  $("#stepQuality")?.classList.toggle("hidden", !hasSub);
  $("#stepPhase")?.classList.toggle("hidden", !(hasSub && hasQ && isCVS));
  $("#stepRINVR")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepCounter")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepMeds")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepTriggers")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepActions")?.classList.toggle("hidden", !(hasSub && hasQ));

  // INVARIANT: red flags always visible — never gated on premium. MDR compliance.
  const hasAlarm = ALARM_FLAGS.some(k => d.flags?.[k]);
  $("#alarmAlert")?.classList.toggle("hidden", !hasAlarm);

  const fluidNil = d.fluidIntake === "nil" || d.fluidIntake === "minimal";
  $("#fluidAlert")?.classList.toggle("hidden", !fluidNil);

  const btnSave = $("#btnSave"); if(btnSave) btnSave.disabled = !(hasSub && hasQ);
  const btnRepeat = $("#btnRepeat"); if(btnRepeat) btnRepeat.disabled = !State.lastEntry;

  updateGuidance(d);
}


function renderInlineCard(cardTitle) {
  const container = document.getElementById("inlineCard");
  if (!container) return;

  const card = LIBRARY.cards.find(c => c.title === cardTitle);
  if (!card) { container.style.display = "none"; return; }

  container.style.display = "block";
  const safeTitle = card.title.split("—")[0].trim().replace(/'/g, "\'");

  const bulletsHTML = (card.bullets || []).map(b =>
    `<li style="font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:6px;">${b}</li>`
  ).join("");

  const moreHTML = card.more
    ? `<div style="font-size:12px;color:var(--muted2);line-height:1.5;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);">${card.more}</div>`
    : "";

  const evidenceHTML = card.evidence
    ? `<div style="font-size:11px;color:var(--muted2);font-family:var(--font-mono);margin-top:8px;line-height:1.5;">${card.evidence}</div>`
    : "";

  container.innerHTML = `
    <div style="border-left:3px solid var(--accent);padding-left:14px;margin-top:8px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px;">Your doctor says</div>
      <div style="font-size:15px;font-weight:600;color:var(--fg);margin-bottom:8px;">${card.title}</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;margin-bottom:10px;">${card.why}</div>
      ${bulletsHTML ? `<ul style="margin:0 0 10px 0;padding-left:16px;">${bulletsHTML}</ul>` : ""}
      ${card.action ? `
        <div style="padding:12px 14px;background:var(--surface2);border-radius:10px;margin-bottom:10px;">
          <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">What to do</div>
          <div style="font-size:13px;color:var(--fg);line-height:1.6;">${card.action}</div>
        </div>` : ""}
      ${moreHTML}
      ${evidenceHTML}
      <button type="button"
        style="font-size:12px;color:var(--accent);background:none;border:none;padding:4px 0 0 0;cursor:pointer;text-decoration:underline;display:block;margin-top:6px;"
        onclick="(function(){document.getElementById('tab-library')?.click();var s=document.getElementById('libSearch');if(s){s.value='${safeTitle}';s.dispatchEvent(new Event('input'));}})()">
        Browse all library cards →
      </button>
    </div>
  `;
}


function pickInlineCard(d) {
  if (d.flags?.cannabis && d.flags?.hotshower) return "Cannabis Hyperemesis Syndrome — When Cannabis Is the Cause";
  const phase = State.phase;
  if (phase === "prodrome" || phase === "emetic") return "Cyclic Vomiting Syndrome — Recognizing the Pattern";
  return "Cyclic Vomiting Syndrome — Recognizing the Pattern";
}
function updateGuidance(d) {
  const g = $("#guidance"), sp = $("#scorePanel");
  if (!g) return;

  if (!State.subtype || !d.quality) {
    g.innerHTML = "Select your diagnosis and complete the log. Rhodes Index score and guidance will appear here.";
    sp?.classList.add("hidden"); return;
  }

  // Premium gate — guidance is gated after 14-day trial
  if (!PremiumGate.isPremium()) {
    PremiumGate.showGuidanceGate(g, MODULE_KEY, () => updateGuidance(d));
    sp?.classList.add("hidden");
    return;
  }


  const score = calcRINVR(d);
  const interp = interpRINVR(score);

  const phase = State.phase || d.phase;
  let assessment = "";
  if (d.flags?.cannabis && d.flags?.hotshower) {
    assessment = `Your log shows both cannabis use and hot shower relief today. This combination is the cardinal clinical signal of Cannabis Hyperemesis Syndrome. CHS is clinically indistinguishable from CVS — the only diagnostic test is complete cannabis abstinence for 2–3 months. If symptoms resolve with abstinence, CHS is confirmed.`;
  } else if (phase === "emetic") {
    assessment = `Your log records an emetic phase today — ${d.vomitCount || "multiple"} vomiting episode${(d.vomitCount || 2) !== 1 ? "s" : ""}. The emetic phase is the highest-risk period for dehydration and electrolyte imbalance. Oral intake is often not possible — assess whether IV fluid support is needed.`;
  } else if (phase === "prodrome") {
    assessment = `Your log records a prodrome phase today — the warning period before an emetic episode. This is the most important window for intervention. Antiemetics taken during prodrome are significantly more effective than those taken during active vomiting.`;
  } else if (phase === "recovery") {
    assessment = `Your log records a recovery phase. The recovery phase carries a risk of relapse if diet is advanced too quickly. Clear fluids first, then light foods, before returning to a normal diet over 24–48 hours.`;
  } else if (d.vomitCount >= 4) {
    assessment = `Your log shows ${d.vomitCount} vomiting episodes today in the interictal phase. Breakthrough vomiting outside a defined CVS episode may indicate an unrecognized trigger, inadequate prophylaxis, or a separate cause.`;
  } else if (d.flags?.skippedmed) {
    assessment = `Prophylaxis medication missed today. CVS prevention depends on consistent daily prophylaxis — amitriptyline or topiramate require consistent blood levels to maintain efficacy. Missed doses reduce protection against future episodes.`;
  } else if (d.quality === "great") {
    assessment = `Good interictal day — low nausea, no vomiting, medication taken. Consistent symptom-free days in the interictal phase confirm your prophylaxis regimen is working. Log your triggers even on good days.`;
  } else {
    assessment = `Your log shows a moderate symptom day in the interictal phase. Track any potential prodromal signals — unusual fatigue, appetite change, or anxiety — these often precede an episode by 24–48 hours.`;
  }

  let plan = "";
  if (d.flags?.cannabis && d.flags?.hotshower) {
    plan = `The only treatment for CHS is complete cannabis cessation. Topical capsaicin cream applied to the abdomen has emerging evidence for acute symptom relief in CHS — the mechanism involves desensitising the same TRPV1 receptors that cannabis activates. Haloperidol has the strongest evidence for acute CHS management in the emergency setting. Discuss CHS explicitly with your gastroenterologist — it is commonly misdiagnosed as CVS for years.`;
  } else if (phase === "emetic") {
    plan = `During the emetic phase: ondansetron (wafer or IV) is the first-line antiemetic. If oral route is not feasible, IM or IV administration is appropriate — discuss with your medical team. For hydration, IV fluids with dextrose are preferred over plain saline in CVS. If you have a rescue medication plan from your gastroenterologist, use it now. If vomiting has continued for more than 4 hours without any fluid retention, contact your medical team.`;
  } else if (phase === "prodrome") {
    plan = `Act now — don't wait. Take your prescribed antiemetic immediately. Sumatriptan (nasal spray or subcutaneous) is effective for migraine-variant CVS when taken at prodrome onset. Move to a quiet, dark room — sensory stimulation prolongs and intensifies CVS episodes. Apply whatever has helped in previous prodromes: cold compress, heat pad, positioning. Early intervention during prodrome can abort the emetic phase entirely in some patients.`;
  } else if (d.flags?.skippedmed) {
    plan = `Set a daily alarm for your prophylaxis medication — the same time every day. Amitriptyline and topiramate require consistent dosing to maintain therapeutic levels. If side effects are causing you to skip doses, this is worth discussing with your gastroenterologist — dose adjustment or switching to an alternative prophylactic agent may help.`;
  } else {
    plan = `Continue prophylaxis consistently and log interictal triggers — sleep disruption, psychological stress, and hormonal fluctuations are among the most consistent CVS triggers. Identifying your personal trigger pattern is the most useful thing you can do in the interictal phase. Bring your Clinician Report to your next appointment — episode frequency and severity trend over time is the primary treatment outcome measure in CVS.`;
  }

  g.innerHTML = `
    <div style="margin-bottom:12px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Assessment</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${assessment}</div>
    </div>
    <div>
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Plan</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${plan}</div>
    </div>
    <div style="font-size:11px;color:var(--muted2);margin-top:10px;border-top:1px solid var(--border);padding-top:8px;">This is patient education based on your logged data — not a medical diagnosis. Discuss any changes to your treatment with your gastroenterologist.</div>
  `;

  const cardTitle = pickInlineCard(d);
  if (cardTitle) renderInlineCard(cardTitle);
  else { const ic = document.getElementById("inlineCard"); if (ic) ic.style.display = "none"; }

  if (sp) {
    sp.classList.remove("hidden");
    const big = $("#scoreBig");
    if(big) { big.textContent = score; big.style.color = interp.color; }
    const si = $("#scoreInterp");
    if(si) {
      si.className = "p-callout " + (interp.cls||"");
      const tips = {
        ok:     "Mild or no symptoms. Continue prophylaxis and trigger avoidance.",
        warn:   "Moderate symptoms. Review antiemetic timing and trigger exposures.",
        danger: "Severe symptoms. Ensure hydration. Discuss rescue medication plan with your gastroenterologist."
      };
      si.innerHTML = `<b>${interp.label}:</b> ${tips[interp.cls]||""}`;
    }
  }
}

function resetDraft() {
  State.draft = defaultDraft();
  if (State.subtype) State.draft.subtype = State.subtype;
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$(".p-phaseBtn").forEach(b => b.setAttribute("aria-selected","false"));
  $$("[data-rinvr] .p-chip").forEach(c => c.setAttribute("aria-pressed", String(c.dataset.level==="0")));
  $$("[data-fluid]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$("[data-antiemetic]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$(".p-chip[data-flag]").forEach(c => c.setAttribute("aria-pressed","false"));
  const cv = $("#counterVal"); if(cv) cv.textContent = "0";
  const notes = $("#notes"); if(notes) notes.value = "";
  const nc = $("#noteCount"); if(nc) nc.textContent = "0";
  ["nfLabel","ndLabel","nxLabel","vfLabel","rrLabel"].forEach(id => {
    const el=$(`#${id}`); if(el) el.textContent="none";
  });
  updateProgress();
}

async function save() {
  try {
    if($("#btnSave")) $("#btnSave").disabled = true;
    const d = State.draft;
    const entry = {
      ts: Util.nowISO(), dateKey: Util.dateKeyLocal(),
      subtype: State.subtype, quality: d.quality,
      cvsPhase: d.cvsPhase||null,
      nauseaFreq: d.nauseaFreq, nauseaDur: d.nauseaDur, nauseaDistress: d.nauseaDistress,
      vomitFreq: d.vomitFreq, retching: d.retching,
      rinvr: calcRINVR(d),
      vomitCount: d.vomitCount||0,
      fluidIntake: d.fluidIntake||null,
      antiemeticTaken: d.antiemeticTaken||null,
      flags: {...d.flags}, notes: (d.notes||"").slice(0,600), deleted: 0
    };
    const last = State.lastEntry;
    if(last){
      const dt = Math.abs(+new Date(entry.ts)-+new Date(last.ts));
      if(dt<90000 && entry.quality===last.quality && entry.rinvr===last.rinvr){
        Util.toast("Duplicate entry blocked"); return;
      }
    }
    const saved = await Perf.time("entry-save", async () => { await State.store.addEntry(entry); });
    State.lastEntry = saved;
    Util.toast("Entry saved");
  // First-time upgrade nudge at 14 entries
  const allEntries = await State.store.getEntriesAll();
  if (allEntries.length === 14 && !PremiumGate.isPremium()) {
    setTimeout(() => PremiumGate.showPaywall(MODULE_KEY, () => {
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      Util.toast("Premium unlocked ✦");
    }), 1200);
  }
    resetDraft();
    if(State.subtype) setSubtypeUI(State.subtype);
    await refreshKPIs();
    await renderEpisodeSummary();
  } catch(err){ console.error(err); Util.toast("Save failed"); }
  finally { updateProgress(); }
}

async function repeatLast() {
  const last = State.lastEntry || await State.store.getLastEntry();
  if(!last) return;
  State.lastEntry = last;
  const d = State.draft;
  if(last.subtype) setSubtypeUI(last.subtype);
  d.quality = last.quality; d.cvsPhase = last.cvsPhase||null;
  d.nauseaFreq=last.nauseaFreq||0; d.nauseaDur=last.nauseaDur||0; d.nauseaDistress=last.nauseaDistress||0;
  d.vomitFreq=last.vomitFreq||0; d.retching=last.retching||0;
  d.vomitCount=last.vomitCount||0; d.fluidIntake=last.fluidIntake||null;
  d.antiemeticTaken=last.antiemeticTaken||null;
  d.flags={...defaultFlags(),...(last.flags||{})};
  d.notes=last.notes||"";
  $$("[data-quality]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.quality===d.quality)));
  if(d.cvsPhase) $$(".p-phaseBtn").forEach(b=>b.setAttribute("aria-selected",String(b.dataset.phase===d.cvsPhase)));
  const syncRINVR=(field,val)=>{const w=$(`[data-rinvr="${field}"]`);if(w)w.querySelectorAll(".p-chip").forEach(c=>c.setAttribute("aria-pressed",String(Number(c.dataset.level)===val)));};
  ["nauseaFreq","nauseaDur","nauseaDistress","vomitFreq","retching"].forEach(f=>syncRINVR(f,d[f]));
  const cv=$("#counterVal"); if(cv) cv.textContent=String(d.vomitCount);
  if(d.fluidIntake) $$("[data-fluid]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.fluid===d.fluidIntake)));
  if(d.antiemeticTaken) $$("[data-antiemetic]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.antiemetic===d.antiemeticTaken)));
  $$(".p-chip[data-flag]").forEach(c=>c.setAttribute("aria-pressed",String(!!d.flags[c.dataset.flag])));
  const notes=$("#notes"); if(notes){notes.value=d.notes;const nc=$("#noteCount");if(nc)nc.textContent=String(d.notes.length);}
  updateProgress();
  Util.toast("Repeated last entry");
}

async function refreshKPIs() {
  const kpis = await KPI.compute(State.store);
  const el=(id,v)=>{const e=$(id);if(e)e.textContent=String(v);};
  el("#kpiTotal",kpis.total); el("#kpi7d",kpis.last7days); el("#kpiStreak",kpis.streak);
}

async function renderEpisodeSummary() {
  const el=$("#episodeSummary"); if(!el) return;
  const cut=new Date(); cut.setDate(cut.getDate()-30); cut.setHours(0,0,0,0);
  const all=await State.store.getEntriesAll();
  const last30=all.filter(e=>new Date(e.ts)>=cut);
  const emeticDays=last30.filter(e=>e.cvsPhase==="emetic").length;
  const totalVomits=last30.reduce((s,e)=>s+(e.vomitCount||0),0);
  const meanRINVR=last30.length?Stats.mean(last30.map(e=>e.rinvr||0)):0;
  const cls=emeticDays===0?"ok":emeticDays<=3?"warn":"danger";
  el.innerHTML=`<div class="p-kpi">Emetic days <b style="color:var(--${cls})">${emeticDays}</b></div>
    <div class="p-kpi">Total vomits <b>${totalVomits}</b></div>
    <div class="p-kpi">Mean RINVR <b>${meanRINVR.toFixed(1)}</b></div>`;
}

async function renderEpisodes() {
  const episodes = await State.store.getSetting("episodes",[]);
  const kpi=$("#kpiEpisodes"); if(kpi) kpi.textContent=String(episodes.length);
  const list=$("#episodeList"); if(!list) return;
  if(!episodes.length){list.innerHTML=`<div class="p-callout">No episodes logged yet. Use this tab to record each CVS episode as a discrete event.</div>`;return;}
  list.innerHTML=[...episodes].reverse().map(e=>{
    const start=e.start?new Date(e.start):null;
    const end=e.end?new Date(e.end):null;
    const dur=start&&end?Math.round((end-start)/3600000):null;
    return `<div class="p-item">
      <div class="p-itemTop">
        <div class="ts">${e.start?Util.esc(e.start.slice(0,16).replace("T"," ")):"—"}</div>
        ${dur!==null?`<div class="q">Duration: <b>${dur}h</b></div>`:""}
      </div>
      <div class="p-itemBody">Peak rate: <b>${Util.esc(String(e.peakRate||"—"))} vomits/hr</b> · Prodrome: <b>${Util.esc(String(e.prodrome||"—"))} min</b></div>
      ${e.trigger?`<div class="p-itemBody" style="margin-top:4px;font-family:var(--font-mono);font-size:11px;color:var(--muted2);">Trigger: ${Util.esc(e.trigger)}</div>`:""}
    </div>`;
  }).join("");
}

async function renderHistory() {
  const list=$("#histList"); if(!list) return;
  const all=(await State.store.getEntriesAll()).sort((a,b)=>b.ts.localeCompare(a.ts));
  if(!all.length){list.innerHTML=`<div class="p-callout">No entries yet.</div>`;return;}
  list.innerHTML=all.slice(0,80).map(e=>{
    const interp=interpRINVR(e.rinvr||0);
    const phase=e.cvsPhase?CVS_PHASES[e.cvsPhase]?.label:"—";
    return `<div class="p-item">
      <div class="p-itemTop">
        <div class="ts">${Util.esc(e.dateKey)}</div>
        <div class="q">${Util.esc(e.quality||"")}${phase!=="—"?" · "+Util.esc(phase):""} · RINVR: <span style="color:${Util.cssVal(interp.color)}">${Util.esc(String(e.rinvr||0))}</span></div>
      </div>
      <div class="p-itemBody">Nausea: <b>${Util.esc(DISTRESS_OPTS[e.nauseaDistress||0]?.label||"None")}</b> · Vomiting: <b>${Util.esc(String(e.vomitCount||0))} episodes</b> · Fluid: <b>${Util.esc(e.fluidIntake||"—")}</b></div>
      ${e.notes?`<div class="p-itemBody" style="margin-top:4px;">${Util.esc(e.notes)}</div>`:""}
    </div>`;
  }).join("");
}

async function renderInsights() {
  const all=(await State.store.getEntriesAll()).sort((a,b)=>a.ts.localeCompare(b.ts));
  const body=$("#insightsBody");
  if(all.length<5){if(body)body.textContent=`Log at least 5 entries. (${all.length} so far)`;return;}
  if(body)body.innerHTML=`<b>${all.length}</b> total entries logged.`;

  const last28=all.slice(-28);
  const rinvrVals=last28.map(e=>e.rinvr||0);
  const rc=$("#chartRINVR"); if(rc) Charts.drawLine(rc,rinvrVals,{maxV:20,lc:"rgba(107,157,232,.8)",dc:"rgba(107,157,232,.9)"});

  if(!State.premium){$("#premiumPanel")?.classList.add("hidden");return;}
  const pp=$("#premiumPanel"); pp?.classList.remove("hidden");
  const last30=all.slice(-30);

  const nauseaVals=last30.map(e=>e.nauseaDistress||0);
  const vomitVals=last30.map(e=>e.vomitCount||0);
  const nc=$("#chartNausea"); if(nc) Charts.drawLine(nc,nauseaVals,{maxV:4,lc:"rgba(224,107,107,.8)",dc:"rgba(224,107,107,.9)"});
  const vc=$("#chartVomit"); if(vc) Charts.drawBars(vc,last30.map((_,i)=>String(i+1)),vomitVals,{c1:"rgba(107,157,232,.75)",c2:"rgba(107,157,232,.45)"});

  // Trigger analysis
  const tb=$("#triggerBox");
  if(tb){
    const cnt={}; FLAG_KEYS.forEach(k=>cnt[k]=0);
    last30.forEach(e=>FLAG_KEYS.forEach(k=>{if(e.flags?.[k])cnt[k]++;}));
    const top=Object.entries(cnt).sort((a,b)=>b[1]-a[1]).filter(([,v])=>v>0).slice(0,4);
    tb.className="p-callout";
    tb.innerHTML=top.length
      ?`<b>Top triggers (30 days):</b><br>${top.map(([k,v])=>`${Util.esc(k)}: ${v} days`).join("<br>")}`
      :"No consistent triggers flagged yet.";
  }

  // CHS signal
  const cb=$("#chsBox");
  if(cb){
    const cannabisDays=last30.filter(e=>e.flags?.cannabis).length;
    const hotshowerDays=last30.filter(e=>e.flags?.hotshower).length;
    const chsSignal=cannabisDays>=5&&hotshowerDays>=3;
    cb.className="p-callout"+(chsSignal?" danger":"");
    cb.innerHTML=chsSignal
      ?`<b style="color:var(--danger)">⚠ CHS signal:</b> Cannabis flagged ${cannabisDays} days, hot shower relief ${hotshowerDays} days. Cannabis hyperemesis syndrome should be discussed with your gastroenterologist.`
      :`Cannabis: ${cannabisDays} days · Hot shower relief: ${hotshowerDays} days. ${cannabisDays===0?"No cannabis signal.":"Monitor — see CHS library card if this pattern continues."}`;
  }

  // Next steps
  const ns=$("#nextStepsList");
  if(ns){
    const steps=[];
    const emeticDays=last30.filter(e=>e.cvsPhase==="emetic").length;
    if(emeticDays>=4) steps.push({p:"danger",t:`${emeticDays} emetic-phase days in 30 days. This frequency warrants review of prophylactic therapy — discuss escalation of amitriptyline dose or switch to topiramate.`});
    const skipMed=last30.filter(e=>e.flags?.skippedmed).length;
    if(skipMed>=5) steps.push({p:"warn",t:`Prophylaxis skipped ${skipMed}/30 days. Missing amitriptyline/topiramate reduces protection — the effect builds over weeks and is lost over days.`});
    const nilDays=last30.filter(e=>e.fluidIntake==="nil"||e.fluidIntake==="minimal").length;
    if(nilDays>=2) steps.push({p:"warn",t:`Minimal/nil fluid intake on ${nilDays} days. Discuss a rescue plan including when to attend for IV hydration before dehydration becomes severe.`});
    const stressDays=last30.filter(e=>e.flags?.stress||e.flags?.anxiety).length;
    if(stressDays>=12) steps.push({p:"warn",t:`Stress/anxiety flagged ${stressDays}/30 days. Psychological stress is the most consistent CVS trigger. Discuss gut-directed CBT or hypnotherapy as an adjunct to pharmacotherapy.`});
    if(!steps.length) steps.push({p:"ok",t:"No high-priority signals. Continue daily logging and prophylaxis adherence."});
    const colors={danger:"var(--danger)",warn:"var(--warn)",ok:"var(--ok)"};
    ns.innerHTML=steps.map(s=>`<div class="p-item"><div class="p-itemBody"><b style="color:${colors[s.p]}">${s.p.toUpperCase()}:</b> ${Util.esc(s.t)}</div></div>`).join("");
  }
}

function showTab(tab) {
  ["log","episodes","history","library","insights"].forEach(t=>{
    $("#tab-"+t)?.setAttribute("aria-selected",String(t===tab));
    $("#view-"+t)?.classList.toggle("hidden",t!==tab);
  });
  if(tab==="history") renderHistory();
  if(tab==="episodes") renderEpisodes();
  if(tab==="library"){
    LibRenderer.renderCats($("#libCats"),LIB_CATS,State.libCat,cat=>{State.libCat=cat;renderLibrary();});
    renderLibrary();
  }
  if(tab==="insights") renderInsights();
}

function renderLibrary() {
  const grid=$("#libGrid"); if(!grid) return;
  const kpi=$("#kpiCards"); if(kpi) kpi.textContent=String(LIBRARY.cards.length);
  LibRenderer.render(grid,LibRenderer.filterCards(LIBRARY.cards,State.libCat,State.libQuery));
}

// ── EVENTS ───────────────────────────────────────────────────────
function wireEvents() {
  $$(".p-tab").forEach(b=>b.addEventListener("click",()=>showTab(b.dataset.tab)));

  $$("[data-sub]").forEach(b=>b.addEventListener("click",()=>{
    setSubtypeUI(b.dataset.sub);
    State.store.setSetting("subtype",b.dataset.sub);
    updateProgress();
    setTimeout(()=>Util.scroll($("#stepQuality")),80);
  }));
  $("#btnChangeSub")?.addEventListener("click",()=>{
    State.subtype=null;
    $$("[data-sub]").forEach(b=>b.setAttribute("aria-pressed","false"));
    $("#subtypeConfirm")?.classList.add("hidden");
    updateProgress();
  });

  $$("[data-quality]").forEach(b=>b.addEventListener("click",()=>{
    State.draft.quality=b.dataset.quality;
    $$("[data-quality]").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
    updateProgress();
    setTimeout(()=>Util.scroll(State.subtype==="cvs"?$("#stepPhase"):$("#stepRINVR")),80);
  }));

  $$(".p-phaseBtn").forEach(b=>b.addEventListener("click",()=>{
    State.draft.cvsPhase=b.dataset.phase;
    $$(".p-phaseBtn").forEach(x=>x.setAttribute("aria-selected",String(x===b)));
    updateProgress();
    setTimeout(()=>Util.scroll($("#stepRINVR")),80);
  }));

  // RINVR chips
  $$("[data-rinvr]").forEach(wrap=>wrap.addEventListener("click",e=>{
    const btn=e.target.closest(".p-chip"); if(!btn) return;
    const field=wrap.dataset.rinvr, val=Number(btn.dataset.level);
    State.draft[field]=Util.clamp(val,0,4);
    wrap.querySelectorAll(".p-chip").forEach(c=>c.setAttribute("aria-pressed",String(c===btn)));
    const lmap={nauseaFreq:"nfLabel",nauseaDur:"ndLabel",nauseaDistress:"nxLabel",vomitFreq:"vfLabel",retching:"rrLabel"};
    const allOpts={nauseaFreq:NAUSEA_FREQ_OPTS,nauseaDur:NAUSEA_DUR_OPTS,nauseaDistress:DISTRESS_OPTS,vomitFreq:VOMIT_FREQ_OPTS,retching:RETCHING_OPTS};
    const lel=lmap[field]?$(`#${lmap[field]}`):null;
    if(lel) lel.textContent=allOpts[field]?.find(o=>o.val===val)?.label||"";
    updateProgress();
  }));

  // Counter
  $("#btnPlus")?.addEventListener("click",()=>{
    State.draft.vomitCount=Math.min(99,(State.draft.vomitCount||0)+1);
    const cv=$("#counterVal"); if(cv) cv.textContent=String(State.draft.vomitCount);
    updateProgress();
  });
  $("#btnMinus")?.addEventListener("click",()=>{
    State.draft.vomitCount=Math.max(0,(State.draft.vomitCount||0)-1);
    const cv=$("#counterVal"); if(cv) cv.textContent=String(State.draft.vomitCount);
    updateProgress();
  });

  $$("[data-fluid]").forEach(b=>b.addEventListener("click",()=>{
    State.draft.fluidIntake=b.dataset.fluid;
    $$("[data-fluid]").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
    updateProgress();
  }));

  $$("[data-antiemetic]").forEach(b=>b.addEventListener("click",()=>{
    State.draft.antiemeticTaken=b.dataset.antiemetic;
    $$("[data-antiemetic]").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
  }));

  $$(".p-chip[data-flag]").forEach(b=>b.addEventListener("click",()=>{
    const k=b.dataset.flag;
    State.draft.flags[k]=!State.draft.flags[k];
    b.setAttribute("aria-pressed",String(State.draft.flags[k]));
    updateProgress();
  }));

  const notes=$("#notes");
  if(notes) notes.addEventListener("input",()=>{
    State.draft.notes=notes.value;
    const nc=$("#noteCount"); if(nc) nc.textContent=String(notes.value.length);
  });

  $("#btnSave")?.addEventListener("click",save);
  $("#btnRepeat")?.addEventListener("click",repeatLast);
  $("#btnReset")?.addEventListener("click",resetDraft);

  // INVARIANT: clinician report is always free — do not gate on PremiumGate.isPremium()
  $("#btnReport")?.addEventListener("click", () => Report.generate(MODULE_KEY));

  const doCSV=()=>IO.exportCSV(State.store,MODULE_KEY,[...FLAG_KEYS,...ALARM_FLAGS]);
  const doJSON=()=>IO.exportJSON(State.store,MODULE_KEY);
  ["#btnExportCsv","#btnExportCsv2"].forEach(s=>$(s)?.addEventListener("click",doCSV));
  ["#btnExportJson","#btnExportJson2"].forEach(s=>$(s)?.addEventListener("click",doJSON));
  const btnImport=$("#btnImport"),importFile=$("#importFile");
  if(btnImport&&importFile){
    btnImport.addEventListener("click",()=>importFile.click());
    importFile.addEventListener("change",async e=>{
      const f=e.target.files?.[0]; if(!f) return;
      await IO.importJSON(f,State.store,[...FLAG_KEYS,...ALARM_FLAGS],async()=>{await refreshKPIs();await renderHistory();});
      e.target.value="";
    });
  }

  // Episode form
  $("#btnSaveEpisode")?.addEventListener("click",async()=>{
    const start=$("#epStart")?.value;
    if(!start){Util.toast("Enter episode start time");return;}
    const episodes=await State.store.getSetting("episodes",[]);
    episodes.push({
      start, peak:$("#epPeak")?.value||null, end:$("#epEnd")?.value||null,
      peakRate:parseInt($("#epPeakRate")?.value)||null,
      prodrome:parseInt($("#epProdrome")?.value)||null,
      trigger:$("#epTrigger")?.value||""
    });
    await State.store.setSetting("episodes",episodes);
    Util.toast("Episode saved");
    ["epStart","epPeak","epEnd","epPeakRate","epProdrome","epTrigger"].forEach(id=>{
      const el=$($("#"+id)??"#"+id); if(el) el.value="";
    });
    const kpi=$("#kpiEpisodes"); if(kpi) kpi.textContent=String(episodes.length);
    await renderEpisodes();
  });

  $("#libSearch")?.addEventListener("input",e=>{State.libQuery=e.target.value||"";renderLibrary();});
  $("#btnRefresh")?.addEventListener("click",renderInsights);

  // Premium CTA — wire paywall
  $("#premiumCta")?.addEventListener("click", () => {
    PremiumGate.showPaywall(MODULE_KEY, () => {
      const sl = $("#premStatusLabel");
      if (sl) sl.textContent = "✦ Premium active";
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      renderInsights?.();
      Util.toast("Premium unlocked ✦");
    });
  });

}

// ── BOOT ─────────────────────────────────────────────────────────
async function boot() {
  injectStyles();
  renderHTML();
  const todayEl=$("#todayLabel"); if(todayEl) todayEl.textContent=Util.dateKeyLocal();

  const {store,mode}=await initStorage(MODULE_KEY);
  State.store=store;
  if (typeof GIOSNotifications !== "undefined") GIOSNotifications.init("nv", "Nausea & Vomiting OS");
  updateStorageModeUI(mode);

  const savedPremium=await store.getSetting("premium",false);
  State.premium=!!savedPremium;
  const m=$("#modeLabel"); if(m) m.textContent=State.premium?"Premium":"Free";

  const savedSub=await store.getSetting("subtype",null);
  if(savedSub) setSubtypeUI(savedSub);

  State.lastEntry=await store.getLastEntry();
  wireEvents();
  resetDraft();
  if(State.subtype) setSubtypeUI(State.subtype);
  await refreshKPIs();
  await renderEpisodeSummary();

  LibRenderer.renderCats($("#libCats"),LIB_CATS,State.libCat,cat=>{State.libCat=cat;renderLibrary();});
  renderLibrary();

  Util.toast("Nausea & Vomiting OS ready");
}

boot();
})();
