/* META
 * @title      EoE OS — Clinical Tracker
 * @accent     #e06b6b
 * @accent2    #7ecba1
 * @accentGlow rgba(224,107,107,.12)
 */

/**
 * EoE OS — Eosinophilic Esophagitis Module
 * ═══════════════════════════════════════════════════════════
 * Dysphagia logging with food bolus impaction tracking,
 * elimination diet phase tracking (6-food, 4-food, 2-food,
 * 1-food/elemental), PPI response monitoring, endoscopy
 * interval tracking, EoE Activity Index (EoEAI) proxy,
 * food reintroduction logging, steroid adherence tracking.
 * Library: elimination diets, PPI-REE, dupilumab, 
 * endoscopy/dilation, trigger foods, red flags.
 * ═══════════════════════════════════════════════════════════
 */

(() => {
"use strict";

const { Util, Stats, Charts, LibRenderer, IO, KPI, Perf, Disclosure, initStorage, updateStorageModeUI } = Platform;
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

const MODULE_KEY = "eoe";

// Elimination diet phases
const DIET_PHASES = {
  none:       { label:"No elimination diet",    short:"None" },
  sixfood:    { label:"6-food elimination",     short:"6FED",  foods:["Wheat/gluten","Milk/dairy","Eggs","Soy","Nuts/peanuts","Seafood/fish"] },
  fourfood:   { label:"4-food elimination",     short:"4FED",  foods:["Wheat/gluten","Milk/dairy","Eggs","Soy/legumes"] },
  twofood:    { label:"2-food elimination",     short:"2FED",  foods:["Wheat/gluten","Milk/dairy"] },
  onefood:    { label:"1-food / milk-only",     short:"1FED",  foods:["Milk/dairy"] },
  elemental:  { label:"Elemental formula",      short:"EF",    foods:[] },
  reintro:    { label:"Reintroduction phase",   short:"Reintro" },
  maintenance:{ label:"Maintenance diet",       short:"Maintenance" }
};

// EoE trigger foods (6FED framework)
const TRIGGER_GROUPS = [
  { id:"wheat",   label:"Wheat / gluten",   icon:"🌾" },
  { id:"dairy",   label:"Milk / dairy",     icon:"🥛" },
  { id:"eggs",    label:"Eggs",             icon:"🥚" },
  { id:"soy",     label:"Soy / legumes",    icon:"🌱" },
  { id:"nuts",    label:"Nuts / peanuts",   icon:"🥜" },
  { id:"seafood", label:"Seafood / fish",   icon:"🐟" }
];

// Dysphagia severity
const DYSPHAGIA_LEVELS = [
  { level:0, label:"None",     desc:"No difficulty swallowing" },
  { level:1, label:"Mild",     desc:"Occasional, with specific foods only" },
  { level:2, label:"Moderate", desc:"Most solid foods, requires modification" },
  { level:3, label:"Severe",   desc:"All solids, or food bolus impaction today" }
];

const FLAG_KEYS = [
  "dryfood","largeportion","fasting","stress","illness","skippedppi",
  "skippedsteroid","newexposure","restaurant","social"
];

// Food bolus impaction — emergency flag
const IMPACTION_FLAG = "impaction";

// EoE Activity Index proxy (Schoepfer et al., Gastroenterology 2014)
// Dysphagia frequency + severity + dietary modification + quality of life impact
function calcEoEAI(d) {
  let s = 0;
  s += Util.clamp(d.dysphagia, 0, 3) * 2;   // weighted — dysphagia is primary
  s += Util.clamp(d.pain, 0, 3);
  s += Util.clamp(d.regurg, 0, 3);
  s += Util.clamp(d.nausea, 0, 3);
  if (d.flags?.dryfood)     s += 1;          // dietary modification
  if (d.flags?.fasting)     s += 1;          // avoidance eating
  return Math.min(15, s);
}

function interpEoEAI(score) {
  if (score <= 2)  return { label:"Remission / minimal",   cls:"ok",     color:"var(--ok)" };
  if (score <= 6)  return { label:"Mild EoE activity",     cls:"ok",     color:"var(--ok)" };
  if (score <= 10) return { label:"Moderate EoE activity", cls:"warn",   color:"var(--warn)" };
  return                  { label:"Severe EoE activity",   cls:"danger", color:"var(--danger)" };
}

function defaultFlags() {
  const f = {};
  [...FLAG_KEYS, IMPACTION_FLAG].forEach(k => f[k] = false);
  return f;
}

function defaultDraft() {
  return {
    quality: null, dietPhase: null,
    dysphagia: 0, pain: 0, regurg: 0, nausea: 0,
    triggersEaten: [],    // which trigger groups consumed today
    triggersAvoided: [],  // which trigger groups avoided today
    flags: defaultFlags(), notes: ""
  };
}

// ── LIBRARY ──────────────────────────────────────────────────────
const LIBRARY = (() => {
  const cards = [];
  const add = o => cards.push({ id:(o.cat+"::"+o.title).toLowerCase().replace(/[^a-z0-9]+/g,"-"), ...o });

  // DISEASE OVERVIEW
  add({ cat:"EoE Overview", tag:"overview", title:"What Is Eosinophilic Esophagitis",
    why:"EoE is a chronic, immune-mediated disease of the esophagus driven by food antigen sensitisation. It is not an allergic disease in the IgE sense — it is a Th2-mediated eosinophilic inflammation that causes progressive esophageal remodelling if untreated.",
    bullets:[
      "Definition: chronic eosinophilic inflammation of the esophageal epithelium (≥15 eosinophils per high-power field on biopsy) in the absence of other causes (GERD, infection, drug reaction). Confirmed by clinical findings and biopsy — endoscopy is required. Symptoms alone are not sufficient to confirm EoE — biopsy is required.",
      "Epidemiology: prevalence approximately 1 in 2000 in Western countries. Rising incidence — likely driven by increased food antigen sensitisation from early childhood, altered microbiome, and 'old friends' hypothesis. Male predominance (3:1). Strong association with atopic disease (asthma, eczema, allergic rhinitis, food allergy) — 70–80% of EoE patients have at least one atopic condition.",
      "Natural history without treatment: chronic eosinophilic inflammation drives progressive subepithelial fibrosis and esophageal remodelling — strictures, rings, reduced esophageal compliance. Food bolus impaction risk increases with untreated disease duration. The fibrostenotic complications are largely irreversible — prevention requires ongoing treatment."
    ],
    action:"EoE requires ongoing management — it does not resolve spontaneously. The two goals of treatment are symptom control (dysphagia, pain) and histological remission (<15 eos/hpf) to prevent fibrostenotic complications. Log symptoms daily. Endoscopic follow-up with biopsy is the only way to confirm histological remission.",
    more:"The EREFS endoscopic scoring system (Exudates, Rings, Edema, Furrows, Stricture) grades EoE severity on endoscopy. Ask your gastroenterologist for your EREFS score — it correlates with histological severity and provides an objective baseline for monitoring treatment response.",
    evidence:"Liacouras et al., J Allergy Clin Immunol 2011; Dellon & Hirano, Gastroenterology 2018; Lucendo et al., United European Gastroenterol J 2017 (EUREOS guidelines)"
  });

  // ELIMINATION DIETS
  add({ cat:"Elimination Diets", tag:"diet", title:"6-Food Elimination Diet (6FED)",
    why:"The 6-food elimination diet is the most comprehensive empirical elimination approach for EoE. It achieves histological remission in approximately 70% of patients but requires stringent avoidance of six major allergen groups.",
    bullets:[
      "The six foods eliminated: wheat/gluten, cow's milk/dairy, eggs, soy/legumes, nuts and peanuts, seafood/fish. All six groups eliminated simultaneously for 6–8 weeks, followed by endoscopy with biopsy. Histological response (not symptom response) determines next steps.",
      "Reintroduction protocol: foods reintroduced one group at a time. Each group: consume the food for 6 weeks, then endoscopy with biopsy. If histology remains in remission (<15 eos/hpf): food is safe, keep it in diet, reintroduce next group. If histology flares: food is a trigger, eliminate permanently, return to elimination phase before testing next group.",
      "Trigger identification rates in 6FED: wheat and dairy are the most common triggers (wheat ~60%, dairy ~50% of EoE patients). Eggs ~30%, soy ~25%, nuts ~10–15%, seafood/fish ~5%. Identifying personal triggers allows transition from 6FED to a targeted long-term elimination of only confirmed triggers."
    ],
    action:"6FED requires meticulous dietary discipline and endoscopic follow-up after each reintroduction phase. This is a structured diagnostic protocol, not a permanent diet. Log which trigger groups you are currently avoiding and any inadvertent exposures using the Trigger Foods section in each daily log entry.",
    more:"Step-down approaches (4FED, 2FED) are increasingly used as first-line to reduce the burden of 6FED while maintaining reasonable efficacy. A 2022 RCT (Molina-Infante et al., Gastroenterology) demonstrated equivalent efficacy between 6FED (73%) and step-up from 2FED with endoscopic re-testing at each step. Discuss the step-down approach with your gastroenterologist.",
    evidence:"Gonsalves et al., Gastroenterology 2012; Molina-Infante et al., Gastroenterology 2014 (step-up); Kagalwalla et al., Gastroenterology 2022; Lucendo et al., Gut 2016"
  });

  add({ cat:"Elimination Diets", tag:"diet", title:"Step-Down Approach — 2FED and 4FED",
    why:"Starting with fewer eliminations and escalating only if needed reduces the dietary and quality-of-life burden while maintaining diagnostic accuracy for most patients.",
    bullets:[
      "2FED (wheat + dairy): remission rates approximately 43–50%. Targets the two most common EoE triggers. Simplest to implement. Appropriate first-line approach given most patients' triggers are captured by these two eliminations. If endoscopy at 6–8 weeks shows remission: proceed to reintroduction of one food at a time.",
      "4FED (wheat + dairy + eggs + soy): remission approximately 54%. Adds eggs and soy to 2FED. Appropriate if 2FED fails to achieve histological remission on biopsy.",
      "6FED: reserved for 4FED failures. Adds nuts and seafood — the two lowest-prevalence triggers. Most patients do not need all six eliminations to achieve remission.",
      "Elemental formula: amino acid-based formula with no food antigens. Remission rates >90%. Reserved for diet failures or as a diagnostic bridge. Palatability is poor — most adults cannot maintain elemental formula long-term without nasogastric tube feeding."
    ],
    action:"If starting dietary therapy: discuss beginning with 2FED. It achieves remission in approximately half of patients with far less dietary disruption than 6FED. Each step requires endoscopy with biopsy to confirm histological response — symptom improvement alone is not sufficient evidence of remission.",
    evidence:"Molina-Infante et al., Gastroenterology 2014; Arias et al., Aliment Pharmacol Ther 2014; Kagalwalla et al., Gastroenterology 2022; Lucendo et al., Gut 2016"
  });

  add({ cat:"Elimination Diets", tag:"diet", title:"Reintroduction Phase — Protocol and Pitfalls",
    why:"Reintroduction is the most important and most error-prone phase of elimination diet therapy. Mistakes here lead to missed triggers or unnecessary permanent restrictions.",
    bullets:[
      "Principle: reintroduce one food group at a time. Each food group consumed for 6 weeks (standard duration — allows enough mucosal exposure to drive eosinophilic response if the food is a trigger). Endoscopy with biopsy at end of each 6-week reintroduction period.",
      "Do not use symptoms to judge reintroduction: dysphagia and pain are insensitive and non-specific markers of histological activity in EoE. Symptom improvement or stability during reintroduction does NOT mean the food is safe — histology must confirm.",
      "Trigger confirmed (eos ≥15/hpf): eliminate that food permanently, allow 6 weeks of washout back to elimination diet (allow mucosa to recover), then begin testing the next food group.",
      "Order of reintroduction: typically least-likely triggers first (seafood, nuts) to allow patients to eat more freely first — psychologically easier. Some centres prefer most-likely triggers first (wheat, dairy) to identify the most impactful restriction early."
    ],
    action:"Log every reintroduction phase in the Endoscopy tab — food group reintroduced, date started, date of post-reintroduction endoscopy, and histological result. This is your personal EoE map. After completing reintroduction, you will know exactly which foods to eliminate permanently and which are safe.",
    evidence:"Gonsalves et al., Gastroenterology 2012; Lucendo et al., Gut 2016; Molina-Infante et al., Gastroenterology 2014"
  });

  // MEDICAL THERAPY
  add({ cat:"Medical Therapy", tag:"meds", title:"PPI Therapy in EoE — PPI-REE",
    why:"A subgroup of EoE patients achieve histological remission on PPI alone — termed PPI-responsive esophageal eosinophilia (PPI-REE). PPIs are now a first-line treatment option in EoE guidelines.",
    bullets:[
      "Mechanism: PPIs reduce eosinophilic inflammation in EoE via acid-independent anti-inflammatory mechanisms — specifically, inhibition of eotaxin-3 (CCL26) production by esophageal epithelial cells. This is distinct from GERD acid suppression. PPIs reduce the chemoattractant signal driving eosinophil recruitment.",
      "Evidence: PPI trial (double dose, 8 weeks) achieves histological remission (< 15 eos/hpf) in approximately 30–50% of EoE patients. Response cannot be predicted by symptoms, endoscopic appearance, or allergy testing. All EoE patients should complete a PPI trial before dietary elimination or steroid therapy.",
      "Maintenance: PPI-responsive patients require ongoing PPI therapy to maintain histological remission. Stopping PPI leads to relapse. There is no evidence that PPI-responsive EoE is a different disease from steroid-responsive EoE — the distinction is mechanism of response, not pathophysiology."
    ],
    action:"Log PPI dose and adherence daily. Skipped PPI doses in PPI-responsive EoE are equivalent to missed steroid doses — they allow eosinophilic inflammation to recur. Use the Skipped PPI flag to track adherence.",
    evidence:"Molina-Infante et al., Gastroenterology 2011; Lucendo et al., Gut 2016; Dellon & Hirano, Gastroenterology 2018; Rank et al., Am J Gastroenterol 2020"
  });

  add({ cat:"Medical Therapy", tag:"meds", title:"Topical Steroids — Swallowed Fluticasone and Budesonide",
    why:"Topical corticosteroids are highly effective for inducing and maintaining histological remission in EoE. They are the primary pharmacological treatment for diet-refractory or diet-averse patients.",
    bullets:[
      "Swallowed fluticasone: inhaled fluticasone actuated directly into the mouth and swallowed (not inhaled). 440–880 mcg twice daily. Avoid eating or drinking for 30 minutes after administration — the medication must coat the esophageal mucosa. Histological remission achieved in 50–70% at 8 weeks.",
      "Oral viscous budesonide (OVB): budesonide mixed with sucralose/honey to form a viscous preparation that coats the esophagus. 1mg twice daily. Superior esophageal mucosal contact compared to swallowed fluticasone due to viscosity. Orodispersible budesonide tablets (Jorveza — approved in Europe for EoE) are the most evidence-based formulation.",
      "Side effects: esophageal candidiasis (5–10% — present as odynophagia, white plaques on endoscopy; treat with fluconazole). Adrenal suppression at high doses with long-term use — check morning cortisol if on high-dose long-term. Rinse mouth after administration. Do not switch to systemic steroids for EoE — they have more side effects with no superior efficacy for this indication."
    ],
    action:"Log steroid administration timing daily. The 30-minute post-dose fasting window is critical — food immediately after administration washes medication away before mucosal absorption occurs. Use the Skipped steroid flag to track adherence and correlate with symptom flares.",
    more:"Jorveza (orodispersible budesonide 1mg) is the only EoE-specific licensed pharmaceutical formulation in Europe. It provides reproducible esophageal drug delivery without compounding. If available, it is preferred over compounded preparations or inhaler-based administration.",
    evidence:"Dohil et al., Gastroenterology 2010; Straumann et al., Gastroenterology 2010; Miehlke et al., Lancet Gastroenterol Hepatol 2022 (Jorveza); Lucendo et al., United European Gastroenterol J 2017"
  });

  add({ cat:"Medical Therapy", tag:"meds", title:"Dupilumab — Biologics in EoE",
    why:"Dupilumab (Dupixent) is the first biologic approved specifically for EoE. It represents a step-change for patients with severe or refractory EoE.",
    bullets:[
      "Mechanism: dupilumab is a monoclonal antibody blocking IL-4Rα — the shared receptor subunit for IL-4 and IL-13, the two key Th2 cytokines driving EoE inflammation. By blocking both IL-4 and IL-13 signalling simultaneously, dupilumab suppresses the fundamental immunological driver of EoE.",
      "Evidence: PART A (Dellon et al., N Engl J Med 2020) and PART B (Hirano et al., N Engl J Med 2023) demonstrated significant histological remission (< 6 eos/hpf) in 60% of patients at 24 weeks vs 5% placebo. Also improves dysphagia scores, endoscopic appearance, and esophageal compliance. FDA approved August 2022, EMA 2023.",
      "Patient selection: appropriate for patients with inadequate response to dietary therapy AND topical steroids, or who are unable to comply with dietary therapy, or who have significant atopic comorbidities (dupilumab also treats eczema, asthma, CRSwNP — single biologic may address multiple conditions). Administered subcutaneously every 2 weeks."
    ],
    action:"Log dupilumab injection dates in Notes. If starting dupilumab: track dysphagia score and quality-of-life weekly for the first 12 weeks — response is typically evident by 12 weeks. Endoscopy with biopsy at 24 weeks confirms histological response.",
    more:"Dupilumab does not eliminate the need for dietary awareness — it suppresses the inflammatory response to food antigens but does not prevent antigen sensitisation. Patients on dupilumab may tolerate previously triggering foods, but this does not mean EoE is cured — inflammation recurs on discontinuation.",
    evidence:"Dellon et al., N Engl J Med 2020; Hirano et al., N Engl J Med 2023; Dellon et al., Gastroenterology 2022 (long-term data)"
  });

  // ENDOSCOPY & DILATION
  add({ cat:"Endoscopy & Dilation", tag:"scope", title:"Endoscopy in EoE — What to Expect",
    why:"Endoscopy with biopsy is the primary way to confirm and assess EoE — symptom scores alone are not sufficient. Understanding what is being assessed at each endoscopy helps patients engage with the surveillance process.",
    bullets:[
      "EREFS scoring: the validated endoscopic grading system for EoE. E = Exudates (white plaques/specks — active eosinophilic inflammation), R = Rings (concentric rings / trachealization — fibromuscular remodelling), E = Edema (loss of vascular pattern — mucosal inflammation), F = Furrows (vertical lines — active inflammation), S = Stricture. Each domain 0–2. Higher EREFS = more severe disease. Ask for your score.",
      "Biopsy protocol: minimum 6 biopsies from two esophageal levels (proximal and distal). EoE can be patchy — single-level biopsy misses up to 30% of cases. If endoscopy is being performed for EoE monitoring, confirm with your endoscopist that multi-level biopsies are taken.",
      "Monitoring intervals: active EoE — endoscopy after 8 weeks of treatment to assess histological response. Remission — endoscopy every 1–2 years. Post-dilation — follow-up endoscopy at 3–6 months."
    ],
    action:"Log every endoscopy result in the Endoscopy tab with date, EREFS score if available, peak eosinophil count (eos/hpf), and management change. Histological remission is defined as < 15 eos/hpf (some centres use the stricter < 6 eos/hpf threshold from dupilumab trials).",
    evidence:"Hirano et al., Gut 2013 (EREFS validation); Dellon et al., Am J Gastroenterol 2022 (guidelines); Lucendo et al., United European Gastroenterol J 2017"
  });

  add({ cat:"Endoscopy & Dilation", tag:"scope", title:"Esophageal Dilation in EoE",
    why:"Dilation treats fibrostenotic complications (strictures, rings that cause persistent dysphagia) but does not treat the underlying inflammation. It is a symptomatic treatment, not a disease-modifying one.",
    bullets:[
      "Indication: symptomatic esophageal stricture or persistent dysphagia despite histological remission on medical/dietary therapy. Dilation improves dysphagia in approximately 85% of patients — effect is durable (median 12 months before re-dilation needed).",
      "Safety: EoE esophagus is fragile — dilation carries higher perforation and post-procedure chest pain risk than standard esophageal dilation. Must be performed by an endoscopist experienced in EoE. Deep mucosal tears are common and usually benign, but transmural perforation (rare) requires surgical management.",
      "Post-dilation: chest pain and odynophagia for 2–5 days is normal and expected — the esophagus has been mechanically stretched. Liquid or soft diet for 48 hours. Seek emergency care for: fever, severe chest pain, subcutaneous emphysema, or inability to swallow liquids at 48 hours."
    ],
    action:"Log dilation procedures in the Endoscopy tab with the maximum diameter achieved and any complications. Post-dilation anti-inflammatory therapy (PPI or topical steroid) should be continued or optimised — dilation without addressing inflammation leads to rapid re-stenosis.",
    evidence:"Moawad et al., Gastroenterology 2017 (meta-analysis); Schoepfer et al., Endoscopy 2013; Dellon et al., Am J Gastroenterol 2022"
  });

  // RED FLAGS
  add({ cat:"Red Flags", tag:"safety", title:"Food Bolus Impaction — Emergency Management",
    why:"Food bolus impaction (food getting stuck in the esophagus and unable to pass) is the most common acute complication of EoE and the most frequent presentation to emergency departments.",
    bullets:[
      "Recognition: complete dysphagia — unable to swallow any food or liquid. Excessive saliva production (patient cannot swallow their own secretions). Often precipitated by dry, fibrous, or poorly chewed food (steak, chicken breast, bread, dense vegetables).",
      "Immediate management: do not attempt to force the bolus down with liquids (aspiration risk). Do not use effervescent agents. Sit upright. Go to the emergency department immediately — the bolus may dislodge spontaneously but may require emergency endoscopic removal.",
      "Post-impaction: every food bolus impaction in a patient with EoE is a signal that disease is not adequately controlled. Impaction requires review of dietary adherence, histological status, and whether treatment escalation is needed. Do not normalize impaction events."
    ],
    action:"Log every food bolus impaction in this app using the Impaction flag. Any impaction event should prompt urgent gastroenterology review — it indicates either active eosinophilic inflammation or fibrostenotic disease requiring evaluation. Impaction frequency is a key metric of disease control.",
    evidence:"Hiremath et al., Am J Gastroenterol 2015; Dellon et al., Am J Gastroenterol 2022; Schoepfer et al., Gastroenterology 2014 (EoEAI)"
  });

  add({ cat:"Red Flags", tag:"safety", title:"When to Seek Urgent Care in EoE",
    why:"Most EoE management is elective. These situations require same-day or emergency attention.",
    bullets:[
      "Emergency (go immediately): complete food bolus impaction — unable to swallow any liquid. Severe chest pain with new onset complete dysphagia. Signs of esophageal perforation post-dilation (fever, severe chest pain, subcutaneous emphysema in neck).",
      "Urgent (same day or next day): new progressive dysphagia (worsening over days-weeks). Any episode of complete, even brief, dysphagia to liquids. Post-dilation inability to tolerate liquids at 48 hours.",
      "This month: increasing frequency of dysphagia episodes on established treatment. New odynophagia (painful swallowing) — may indicate esophageal candidiasis from topical steroid."
    ],
    action:"The Impaction flag in this app triggers a prompt to seek urgent care. Any impaction event = emergency department. Any new or worsening dysphagia on established treatment = gastroenterology contact within 48 hours.",
    evidence:"Dellon et al., Am J Gastroenterol 2022; Lucendo et al., United European Gastroenterol J 2017"
  });

  return { cards };
})();

const LIB_CATS = ["all", ...new Set(LIBRARY.cards.map(c => c.cat))];

// ── STATE ────────────────────────────────────────────────────────
const State = {
  store: null, premium: false,
  dietPhase: null,
  draft: defaultDraft(), lastEntry: null,
  libCat: "all", libQuery: ""
};

// ── HTML ─────────────────────────────────────────────────────────
function renderHTML() {
  document.getElementById("module-root").innerHTML = `
<div class="p-app">
  <header class="p-header">
    <div class="p-brand">
      <div class="p-logo-dot" aria-hidden="true"></div>
      <div>
        <h1 class="p-brand-name">EoE OS</h1>
        <div class="p-brand-sub">Symptom tracker</div>
      </div>
    </div>
    <div class="p-header-right">
      <div class="p-pill">🔥 <b id="kpiStreak">0</b>&nbsp;·&nbsp;7d <b id="kpi7d">0</b>&nbsp;·&nbsp;<b id="kpiTotal">0</b> total</div>
    </div>
  </header>

  <nav class="p-nav">
    <div class="p-tabs" role="tablist">
      <button class="p-tab" role="tab" id="tab-log"        aria-selected="true"  data-tab="log"        type="button">Log</button>
      <button class="p-tab" role="tab" id="tab-endoscopy"  aria-selected="false" data-tab="endoscopy"  type="button">Endoscopy</button>
      <button class="p-tab" role="tab" id="tab-history"    aria-selected="false" data-tab="history"    type="button">History</button>
      <button class="p-tab" role="tab" id="tab-library"    aria-selected="false" data-tab="library"    type="button">Library</button>
      <button class="p-tab" role="tab" id="tab-insights"   aria-selected="false" data-tab="insights"   type="button">Insights</button>
    </div>
  </nav>

  <!-- LOG -->
  <section id="view-log">
    <div class="p-grid two">
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>How are you today?</h2><p>Takes about a minute</p></div>
          <div class="p-kpis"><div class="p-kpi">Date <b id="todayLabel"></b></div></div>
        </div>
        <div class="p-card-b">

          <!-- Step 1: Diet phase -->
          <div id="stepDiet">
            <div class="p-labelrow"><div class="p-lbl">Which diet phase are you in?</div><div class="p-hint">saved permanently</div></div>
            <div class="p-seg" id="dietSegs" style="flex-wrap:wrap;">
              ${Object.entries(DIET_PHASES).map(([k,v]) =>
                `<button class="p-segBtn" type="button" data-diet="${k}" aria-pressed="false" style="font-size:11px;flex:1 1 100px;">${v.short}</button>`
              ).join("")}
            </div>
            <div id="dietConfirm" class="hidden" style="margin-top:8px;">
              <div class="p-callout" style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
                <span>Diet: <b id="dietLabel">—</b></span>
                <button class="p-btn ghost sm" type="button" id="btnChangeDiet">Change</button>
              </div>
              <div id="dietFoodsNote" class="hidden" style="margin-top:6px;font-size:12px;color:var(--muted2);font-family:var(--font-mono);"></div>
            </div>
          </div>

          <!-- Step 2: Overall day -->
          <div id="stepQuality" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">How was today overall?</div><div class="p-hint">required</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-quality="great" aria-pressed="false">Great</button>
              <button class="p-segBtn" type="button" data-quality="okay"  aria-pressed="false">Okay</button>
              <button class="p-segBtn" type="button" data-quality="rough" aria-pressed="false">Rough</button>
            </div>
          </div>

          <!-- IMPACTION ALERT — shown prominently -->
          <div id="stepImpaction" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl" style="color:var(--danger);">⚠ Food bolus impaction?</div><div class="p-hint">emergency if current</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-impaction="no"  aria-pressed="true">No impaction</button>
              <button class="p-segBtn danger" type="button" data-impaction="yes" aria-pressed="false">Yes — impaction today</button>
            </div>
            <div id="impactionAlert" class="p-callout danger hidden" style="margin-top:8px;">
              <b>Food bolus impaction requires emergency evaluation.</b> If currently unable to swallow any liquid or your own saliva — go to the emergency department now. If the impaction has passed: log it here and contact your gastroenterologist urgently.
            </div>
          </div>

          <!-- Step 3: Core symptoms -->
          <div id="stepSymptoms" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Any symptoms today?</div><div class="p-hint">tap to select</div></div>

            <div class="p-labelrow" style="margin-top:4px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Dysphagia (difficulty swallowing)</div><div class="p-hint" id="dysLabel">none</div></div>
            <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:10px;" id="dysGrid">
              ${DYSPHAGIA_LEVELS.map(d => `
              <button class="p-dysOpt" type="button" data-dys="${d.level}" aria-selected="${d.level===0?"true":"false"}">
                <div style="font-weight:700;font-size:12px;">${Util.esc(d.label)}</div>
                <div style="font-size:11px;color:var(--muted2);">${Util.esc(d.desc)}</div>
              </button>`).join("")}
            </div>

            <div class="p-labelrow" style="margin-top:4px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Chest / epigastric pain</div><div class="p-hint" id="painLabel">none</div></div>
            <div class="p-chips" data-symptom="pain">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Regurgitation / reflux</div><div class="p-hint" id="regurgLabel">none</div></div>
            <div class="p-chips" data-symptom="regurg">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Nausea</div><div class="p-hint" id="nauseaLabel">none</div></div>
            <div class="p-chips" data-symptom="nausea">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>
          </div>

          <!-- Step 4: Trigger foods -->
          <div id="stepTriggers" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Which food groups did you eat today?</div><div class="p-hint">tap all that apply</div></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px;">
              ${TRIGGER_GROUPS.map(t => `
              <div class="p-trigRow">
                <div class="p-trigLabel">${t.icon} ${Util.esc(t.label)}</div>
                <div style="display:flex;gap:4px;">
                  <button class="p-chip" type="button" data-trig="${t.id}" data-trigstate="avoided" aria-pressed="false" style="font-size:11px;padding:4px 8px;">Avoided</button>
                  <button class="p-chip ok" type="button" data-trig="${t.id}" data-trigstate="eaten" aria-pressed="false" style="font-size:11px;padding:4px 8px;">Ate</button>
                </div>
              </div>`).join("")}
            </div>

            <div class="p-labelrow" style="margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Flags</div></div>
            <div class="p-chips">
              <button class="p-chip warn" type="button" data-flag="dryfood"      aria-pressed="false">Dry/fibrous food</button>
              <button class="p-chip"      type="button" data-flag="largeportion" aria-pressed="false">Large portion</button>
              <button class="p-chip warn" type="button" data-flag="skippedppi"   aria-pressed="false">Skipped PPI</button>
              <button class="p-chip warn" type="button" data-flag="skippedsteroid" aria-pressed="false">Skipped steroid</button>
              <button class="p-chip warn" type="button" data-flag="newexposure"  aria-pressed="false">New food exposure</button>
              <button class="p-chip"      type="button" data-flag="restaurant"   aria-pressed="false">Restaurant</button>
              <button class="p-chip"      type="button" data-flag="social"       aria-pressed="false">Social event</button>
              <button class="p-chip"      type="button" data-flag="stress"       aria-pressed="false">Stress↑</button>
              <button class="p-chip"      type="button" data-flag="fasting"      aria-pressed="false">Avoided eating (fear)</button>
            </div>

            <div class="p-section">
              <div class="p-labelrow"><div class="p-lbl">Notes</div><div class="p-hint"><span id="noteCount">0</span>/600</div></div>
              <textarea id="notes" class="p-note" maxlength="600" placeholder="Specific foods, meal timing, reintroduction phase notes, medication details (optional)"></textarea>
            </div>
          </div>

          <!-- Actions -->
          <div id="stepActions" class="p-section hidden">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnSave" disabled>Done</button>
              <button class="p-btn" type="button" id="btnRepeat" disabled>Repeat last</button>
              <button class="p-btn ghost" type="button" id="btnReset">Reset</button>
            </div>
          </div>
        </div>
      </div>

      <!-- RIGHT -->
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>Today's Guidance</h2><p>Personalized to what you logged</p></div>
          
        </div>
        <div class="p-card-b">
          <div id="guidance" class="p-callout">Select your diet phase and complete the log. EoE Activity Index and guidance will appear here.</div>
          <div id="inlineCard" class="p-section" style="display:none;"></div>

          <div id="scorePanel" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">EoE Activity Index</div><div class="p-hint">0–15 scale</div></div>
            <div class="p-scoreWrap">
              <div class="p-scoreBig" id="scoreBig">—</div>
              <div class="p-scoreSubLabel">EoEAI Proxy</div>
            </div>
            <div id="scoreInterp" class="p-callout" style="margin-top:8px;"></div>
          </div>

          <!-- Impaction count -->
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Impaction events</div><div class="p-hint">last 90 days</div></div>
            <div id="impactionCount" class="p-kpis"></div>
          </div>

          <!-- Current diet quick ref -->
          <div class="p-section" id="dietRef">
            <div class="p-labelrow"><div class="p-lbl">Current elimination</div><div class="p-hint" id="dietRefLabel">—</div></div>
            <div id="dietRefFoods" style="font-size:12px;color:var(--muted);line-height:1.8;"></div>
          </div>

          <div class="p-section">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnReport">Clinician report</button>
              <button class="p-btn" type="button" id="btnExportCsv">Export CSV</button>
              <button class="p-btn" type="button" id="btnExportJson">Export JSON</button>
              <button class="p-btn" type="button" id="btnImport">Import</button>
              <input id="importFile" type="file" accept="application/json" class="sr">
            </div>
          </div>
          <div class="p-section">
            <div class="p-premRow" id="premiumCta" style="cursor:pointer;">
              <div class="p-premLabel" id="premStatusLabel">Unlock Premium — trend analytics · trigger correlation · next steps</div>
              <div style="font-family:var(--font-mono);font-size:10px;letter-spacing:.08em;color:#f5c842;">UPGRADE ✦</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ENDOSCOPY -->
  <section id="view-endoscopy" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Endoscopy Record</h2><p>EREFS score · eosinophil count · reintroduction tracking</p></div>
        <div class="p-kpis"><div class="p-kpi">Scopes <b id="kpiScopes">0</b></div></div>
      </div>
      <div class="p-card-b">
        <div class="p-callout" style="margin-bottom:14px;">
          <b>Clinical basis:</b> Histological remission in EoE = &lt;15 eos/hpf (most guidelines) or &lt;6 eos/hpf (dupilumab trial threshold). Symptoms alone do not confirm remission — biopsy is required. Log every endoscopy result with eosinophil count and EREFS score.
        </div>
        <div class="p-calpRow">
          <div class="p-calpField">
            <label>Date of endoscopy</label>
            <input type="date" id="scopeDate">
          </div>
          <div class="p-calpField">
            <label>Peak eos/hpf</label>
            <input type="number" id="scopeEos" placeholder="e.g. 12" min="0" max="500">
          </div>
          <div class="p-calpField">
            <label>EREFS score</label>
            <input type="number" id="scopeEREFS" placeholder="0–8" min="0" max="8">
          </div>
        </div>
        <div class="p-calpRow" style="margin-top:8px;">
          <div class="p-calpField" style="flex:2;">
            <label>Context / indication</label>
            <input type="text" id="scopeContext" placeholder="e.g. Post-2FED, post-wheat reintro, surveillance" style="width:100%;height:44px;border-radius:10px;border:1px solid var(--line);background:rgba(231,237,245,.03);color:var(--ink);padding:0 12px;outline:none;font-size:13px;">
          </div>
          <div class="p-calpField">
            <label>Treatment at time</label>
            <input type="text" id="scopeTreat" placeholder="e.g. 2FED, PPI, budesonide" style="width:100%;height:44px;border-radius:10px;border:1px solid var(--line);background:rgba(231,237,245,.03);color:var(--ink);padding:0 12px;outline:none;font-size:13px;">
          </div>
        </div>
        <div id="scopePreview" class="p-callout hidden" style="margin-top:8px;"></div>
        <div class="p-rowBtns"><button class="p-btn primary" type="button" id="btnSaveScope">Save scope record</button></div>

        <div class="p-section">
          <div class="p-labelrow"><div class="p-lbl">Eosinophil count trend</div><div class="p-hint">&lt;15 eos/hpf = histological remission</div></div>
          <div class="p-chartWrap" style="margin-bottom:12px;">
            <canvas id="chartEos" height="200"></canvas>
            <div class="p-chartMeta">Peak eos/hpf over time (dashed line = 15 eos/hpf remission threshold)</div>
          </div>
          <div class="p-list" id="scopeList"></div>
        </div>
      </div>
    </div>
  </section>

  <!-- HISTORY -->
  <section id="view-history" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>History</h2><p>Most recent first</p></div>
        <div class="p-rowBtns" style="margin:0;">
          <button class="p-btn" type="button" id="btnExportCsv2">Export CSV</button>
          <button class="p-btn" type="button" id="btnExportJson2">Export JSON</button>
        </div>
      </div>
      <div class="p-card-b"><div class="p-list" id="histList"></div></div>
    </div>
  </section>

  <!-- LIBRARY -->
  <section id="view-library" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Clinical Library</h2><p>EoE overview · elimination diets · reintroduction · PPI-REE · topical steroids · dupilumab · endoscopy · red flags</p></div>
        <div style="display:flex;gap:10px;align-items:center;">
          <div class="p-kpis"><div class="p-kpi">Cards <b id="kpiCards">0</b></div></div>
          <input id="libSearch" type="search" class="p-search" placeholder="Search 6FED, dupilumab, EREFS, dilation…">
        </div>
      </div>
      <div class="p-card-b">
        <div class="p-libCats" id="libCats"></div>
        <div class="p-libGrid" id="libGrid"></div>
      </div>
    </div>
  </section>

  <!-- INSIGHTS -->
  <section id="view-insights" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Insights</h2><p>Free: dysphagia trend · Premium: EoEAI trend + trigger analysis + next steps</p></div>
        <button class="p-btn" type="button" id="btnRefresh" style="margin:0;">Refresh</button>
      </div>
      <div class="p-card-b">
        <div id="insightsBody" class="p-callout">Log at least 5 entries to unlock insights.</div>
        <div class="p-section">
          <div class="p-chartWrap"><canvas id="chartDys" height="200"></canvas><div class="p-chartMeta">Dysphagia severity (last 28 entries)</div></div>
        </div>
        <div id="premiumPanel" class="p-section hidden">
          <div class="p-grid two">
            <div class="p-chartWrap"><canvas id="chartEoEAI" height="200"></canvas><div class="p-chartMeta">EoEAI score trend (last 30 entries)</div></div>
            <div class="p-chartWrap"><canvas id="chartPain2" height="200"></canvas><div class="p-chartMeta">Chest/epigastric pain (last 30 entries)</div></div>
          </div>
          <div class="p-section p-grid two">
            <div class="p-callout" id="triggerBox"></div>
            <div class="p-callout" id="impactionBox"></div>
          </div>
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Ranked next steps</div></div>
            <div class="p-list" id="nextStepsList"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>`;
}

// ── EXTRA STYLES ────────────────────────────────────────────────
function injectStyles() {
  const s = document.createElement("style");
  s.textContent = `
    .p-dysOpt {
      padding:10px 14px; border-radius:12px;
      border:1px solid var(--line); background:rgba(255,255,255,.02);
      color:var(--muted); cursor:pointer; text-align:left;
      transition:border-color .12s,background .12s;
    }
    .p-dysOpt[aria-selected="true"] {
      border-color:rgba(224,107,107,.5);
      background:rgba(224,107,107,.10);
      color:var(--ink);
    }
    .p-trigRow {
      display:flex; align-items:center; justify-content:space-between;
      padding:8px 10px; border-radius:10px;
      border:1px solid var(--line); background:rgba(255,255,255,.01);
    }
    .p-trigLabel { font-size:12px; color:var(--muted); }
    .p-segBtn.danger {
      border-color:rgba(224,107,107,.4);
      color:var(--danger);
    }
    .p-segBtn.danger[aria-pressed="true"] {
      background:rgba(224,107,107,.15);
      border-color:rgba(224,107,107,.7);
      color:var(--danger);
    }
    .p-calpRow { display:flex; gap:10px; flex-wrap:wrap; }
    .p-calpField { display:flex; flex-direction:column; gap:4px; flex:1; min-width:120px; }
    .p-calpField label { font-size:11px; color:var(--muted); }
    .p-calpField input[type=number], .p-calpField input[type=date] {
      height:44px; border-radius:10px; border:1px solid var(--line);
      background:rgba(231,237,245,.03); color:var(--ink);
      padding:0 12px; outline:none; font-size:13px;
    }
  `;
  document.head.appendChild(s);
}

// ── LOGIC ────────────────────────────────────────────────────────
function setDietUI(diet) {
  State.dietPhase = diet;
  State.draft.dietPhase = diet;
  $$("[data-diet]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.diet === diet)));
  const ph = DIET_PHASES[diet];
  const lbl = $("#dietLabel"); if (lbl) lbl.textContent = ph?.label || diet;
  $("#dietConfirm")?.classList.toggle("hidden", !diet);

  const fn = $("#dietFoodsNote");
  if (fn && ph?.foods?.length) {
    fn.textContent = "Avoiding: " + ph.foods.join(", ");
    fn.classList.remove("hidden");
  } else fn?.classList.add("hidden");

  // Update right panel diet ref
  const drl = $("#dietRefLabel"); if (drl) drl.textContent = ph?.short || "—";
  const drf = $("#dietRefFoods");
  if (drf) {
    if (ph?.foods?.length) {
      drf.innerHTML = ph.foods.map(f => `<div>✗ ${Util.esc(f)}</div>`).join("");
    } else {
      drf.innerHTML = diet === "elemental"
        ? "<div>Amino acid formula only — no food antigens</div>"
        : diet === "reintro" ? "<div>Reintroduction phase — log each test food in Notes</div>"
        : diet === "maintenance" ? "<div>Maintenance — identified triggers eliminated only</div>"
        : "<div>No elimination</div>";
    }
  }
}

function updateProgress() {
  // INVARIANT: red flags always visible — never gated on premium. MDR compliance.
  // Note: EoE OS uses impactionAlert for its acute safety flag (food bolus impaction = emergency).
  const d = State.draft;
  const hasDiet = !!State.dietPhase;
  const hasQ    = !!d.quality;

  $("#stepQuality")?.classList.toggle("hidden", !hasDiet);
  $("#stepImpaction")?.classList.toggle("hidden", !(hasDiet && hasQ));
  $("#stepSymptoms")?.classList.toggle("hidden", !(hasDiet && hasQ));
  $("#stepTriggers")?.classList.toggle("hidden", !(hasDiet && hasQ));
  $("#stepActions")?.classList.toggle("hidden", !(hasDiet && hasQ));

  const isImpaction = d.flags?.[IMPACTION_FLAG];
  $("#impactionAlert")?.classList.toggle("hidden", !isImpaction);

  const canSave = hasDiet && hasQ;
  const btnSave = $("#btnSave"); if (btnSave) btnSave.disabled = !canSave;
  const btnRepeat = $("#btnRepeat"); if (btnRepeat) btnRepeat.disabled = !State.lastEntry;

  updateGuidance(d);
}


function renderInlineCard(cardTitle) {
  const container = document.getElementById("inlineCard");
  if (!container) return;

  const card = LIBRARY.cards.find(c => c.title === cardTitle);
  if (!card) { container.style.display = "none"; return; }

  container.style.display = "block";
  const safeTitle = card.title.split("—")[0].trim().replace(/'/g, "\'");

  const bulletsHTML = (card.bullets || []).map(b =>
    `<li style="font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:6px;">${b}</li>`
  ).join("");

  const moreHTML = card.more
    ? `<div style="font-size:12px;color:var(--muted2);line-height:1.5;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);">${card.more}</div>`
    : "";

  const evidenceHTML = card.evidence
    ? `<div style="font-size:11px;color:var(--muted2);font-family:var(--font-mono);margin-top:8px;line-height:1.5;">${card.evidence}</div>`
    : "";

  container.innerHTML = `
    <div style="border-left:3px solid var(--accent);padding-left:14px;margin-top:8px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px;">Your doctor says</div>
      <div style="font-size:15px;font-weight:600;color:var(--fg);margin-bottom:8px;">${card.title}</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;margin-bottom:10px;">${card.why}</div>
      ${bulletsHTML ? `<ul style="margin:0 0 10px 0;padding-left:16px;">${bulletsHTML}</ul>` : ""}
      ${card.action ? `
        <div style="padding:12px 14px;background:var(--surface2);border-radius:10px;margin-bottom:10px;">
          <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">What to do</div>
          <div style="font-size:13px;color:var(--fg);line-height:1.6;">${card.action}</div>
        </div>` : ""}
      ${moreHTML}
      ${evidenceHTML}
      <button type="button"
        style="font-size:12px;color:var(--accent);background:none;border:none;padding:4px 0 0 0;cursor:pointer;text-decoration:underline;display:block;margin-top:6px;"
        onclick="(function(){document.getElementById('tab-library')?.click();var s=document.getElementById('libSearch');if(s){s.value='${safeTitle}';s.dispatchEvent(new Event('input'));}})()">
        Browse all library cards →
      </button>
    </div>
  `;
}


function pickInlineCard(d) {
  if (d.flags?.impaction) return null; // emergency, no card
  if (d.dysphagia >= 2) return "Medical Therapy in EoE — My Approach";
  if (d.flags?.newexposure) return "Medical Therapy in EoE — My Approach";
  return "Medical Therapy in EoE — My Approach";
}
function updateGuidance(d) {
  const g = $("#guidance"), sp = $("#scorePanel");
  if (!g) return;

  if (!State.dietPhase || !d.quality) {
    g.innerHTML = "Select your diet phase and complete the log. EoE Activity Index and guidance will appear here.";
    sp?.classList.add("hidden"); return;
  }

  // Premium gate — guidance is gated after 14-day trial
  if (!PremiumGate.isPremium()) {
    PremiumGate.showGuidanceGate(g, MODULE_KEY, () => updateGuidance(d));
    sp?.classList.add("hidden");
    return;
  }


  const score = calcEoEAI(d);
  const interp = interpEoEAI(score);

  const IMPACTION_FLAG = "impaction";
  let assessment = "";
  if (d.flags?.[IMPACTION_FLAG]) {
    assessment = `Food bolus impaction logged. If this is a current impaction: go to the emergency department immediately. If it resolved spontaneously: contact your gastroenterologist urgently — spontaneous impaction means your esophagus is narrowed and disease is not adequately controlled.`;
  } else if (d.dysphagia >= 3) {
    assessment = `Your log shows severe dysphagia today. Severe difficulty swallowing solids is the primary clinical indicator of active eosinophilic inflammation and possible esophageal narrowing. This level of symptom requires discussion with your gastroenterologist about whether endoscopy or dilation is indicated.`;
  } else if (d.dysphagia >= 2) {
    assessment = `Your log shows significant dysphagia today. Note which specific foods caused difficulty — dry, fibrous, or dense foods carry the highest impaction risk in EoE: steak, bread, chicken breast, raw vegetables. Chewing thoroughly and eating slowly reduces risk.`;
  } else if (d.flags?.skippedppi || d.flags?.skippedsteroid) {
    assessment = `Medication missed today. In EoE, histological remission — the treatment goal — requires consistent adherence to PPI or topical steroid therapy. Missing doses allows eosinophilic inflammation to recur at the mucosal level even before symptoms return.`;
  } else if (d.flags?.newexposure) {
    assessment = `New food exposure logged. Monitor for dysphagia or symptom change over the next 24–72 hours. If you are in the reintroduction phase, this entry is important data — log any symptom response carefully.`;
  } else if (d.quality === "great") {
    assessment = `Good day logged — minimal dysphagia, medication taken. Symptom-free days on treatment are the target in EoE. Note that symptoms don't always correlate with eosinophil counts — histological remission requires biopsy confirmation, not just symptom resolution.`;
  } else {
    assessment = `Your log shows a moderate EoE day. Track dysphagia frequency and severity consistently — the trend over 2–4 weeks is the most useful indicator of whether your current treatment is controlling mucosal inflammation.`;
  }

  let plan = "";
  if (d.flags?.[IMPACTION_FLAG]) {
    plan = `After any impaction episode, discuss urgent endoscopy with your gastroenterologist. Impaction indicates esophageal narrowing (stricture or rings) from active inflammation. Treatment escalation — higher-dose PPI, topical steroid, or biologic therapy such as dupilumab — is likely indicated. Do not manage post-impaction without clinical review.`;
  } else if (d.dysphagia >= 2) {
    plan = `For dysphagia management day to day: eat slowly, chew each bite thoroughly, drink with meals, and avoid the highest-risk food textures (dry bread, steak, fibrous chicken). Sitting upright for at least 30 minutes after eating reduces the risk of a bolus lodging. If you are not already on topical steroid therapy, discuss it with your gastroenterologist — fluticasone or budesonide swallowed (not inhaled) directly treats the esophageal mucosa and is the current standard of care for EoE.`;
  } else if (d.flags?.skippedppi || d.flags?.skippedsteroid) {
    plan = `Set a daily alarm for your EoE medication. Topical steroid therapy requires consistent daily dosing — the goal is histological remission below 15 eosinophils per high-power field on biopsy, which cannot be achieved with intermittent dosing. After taking your swallowed steroid, do not eat or drink for 30 minutes — rinsing or eating immediately reduces mucosal contact time and reduces efficacy.`;
  } else if (d.flags?.newexposure && State.dietPhase === "reintro") {
    plan = `In the reintroduction phase, introduce one food group at a time for 6 weeks before the next endoscopy confirms histological response. If symptoms worsen significantly during a trial, stop that food group and allow 2 weeks of symptom settling before trialling the next group. Log every exposure carefully — this data determines your long-term diet.`;
  } else {
    plan = `Continue current medication consistently and log dysphagia daily. Your next endoscopy with biopsies is the only way to confirm whether treatment is achieving histological remission. Symptom improvement alone is not sufficient — some patients have significant eosinophilia without prominent symptoms.`;
  }

  g.innerHTML = `
    <div style="margin-bottom:12px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Assessment</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${assessment}</div>
    </div>
    <div>
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Plan</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${plan}</div>
    </div>
    <div style="font-size:11px;color:var(--muted2);margin-top:10px;border-top:1px solid var(--border);padding-top:8px;">This is patient education based on your logged data — not a medical diagnosis. Discuss any changes to your treatment with your gastroenterologist.</div>
  `;

  const cardTitle = pickInlineCard(d);
  if (cardTitle) renderInlineCard(cardTitle);
  else { const ic = document.getElementById("inlineCard"); if (ic) ic.style.display = "none"; }

  if (sp) {
    sp.classList.remove("hidden");
    const big = $("#scoreBig");
    if (big) { big.textContent = score; big.style.color = interp.color; }
    const si = $("#scoreInterp");
    if (si) {
      si.className = "p-callout " + (interp.cls||"");
      const tips = {
        ok:     "Minimal EoE activity. Continue current treatment and maintain endoscopy schedule.",
        warn:   "Moderate activity. Review dietary adherence and medication compliance.",
        danger: "Significant EoE burden. Discuss endoscopy timing and treatment escalation with your gastroenterologist."
      };
      si.innerHTML = `<b>${interp.label}:</b> ${tips[interp.cls]||""}`;
    }
  }
}

function resetDraft() {
  State.draft = defaultDraft();
  if (State.dietPhase) State.draft.dietPhase = State.dietPhase;
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$("[data-impaction]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.impaction==="no")));
  $$(".p-dysOpt").forEach(b => b.setAttribute("aria-selected", String(b.dataset.dys==="0")));
  $$("[data-symptom] .p-chip").forEach(c => c.setAttribute("aria-pressed", String(c.dataset.level==="0")));
  $$("[data-trig]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$(".p-chip[data-flag]").forEach(c => c.setAttribute("aria-pressed","false"));
  const notes=$("#notes"); if(notes) notes.value="";
  const nc=$("#noteCount"); if(nc) nc.textContent="0";
  ["dysLabel","painLabel","regurgLabel","nauseaLabel"].forEach(id=>{
    const el=$(`#${id}`); if(el) el.textContent="none";
  });
  updateProgress();
}

async function save() {
  try {
    if ($("#btnSave")) $("#btnSave").disabled = true;
    const d = State.draft;
    const entry = {
      ts: Util.nowISO(), dateKey: Util.dateKeyLocal(),
      dietPhase: State.dietPhase, quality: d.quality,
      dysphagia: Util.clamp(d.dysphagia,0,3),
      pain: Util.clamp(d.pain,0,3), regurg: Util.clamp(d.regurg,0,3),
      nausea: Util.clamp(d.nausea,0,3),
      eoeai: calcEoEAI(d),
      triggersEaten: [...(d.triggersEaten||[])],
      triggersAvoided: [...(d.triggersAvoided||[])],
      flags: {...d.flags}, notes: (d.notes||"").slice(0,600), deleted: 0
    };
    const last = State.lastEntry;
    if (last) {
      const dt = Math.abs(+new Date(entry.ts)-+new Date(last.ts));
      if (dt<90000 && entry.quality===last.quality && entry.dysphagia===last.dysphagia) {
        Util.toast("Duplicate entry blocked"); return;
      }
    }
    const saved = await Perf.time("entry-save", async () => { await State.store.addEntry(entry); });
    State.lastEntry = saved;
    Util.toast("Entry saved");
  // First-time upgrade nudge at 14 entries
  const allEntries = await State.store.getEntriesAll();
  if (allEntries.length === 14 && !PremiumGate.isPremium()) {
    setTimeout(() => PremiumGate.showPaywall(MODULE_KEY, () => {
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      Util.toast("Premium unlocked ✦");
    }), 1200);
  }
    resetDraft();
    if (State.dietPhase) setDietUI(State.dietPhase);
    await refreshKPIs();
    await renderImpactionCount();
  } catch(err) { console.error(err); Util.toast("Save failed"); }
  finally { updateProgress(); }
}

async function repeatLast() {
  const last = State.lastEntry || await State.store.getLastEntry();
  if (!last) return;
  State.lastEntry = last;
  const d = State.draft;
  if (last.dietPhase) setDietUI(last.dietPhase);
  d.quality = last.quality;
  d.dysphagia = last.dysphagia||0; d.pain = last.pain||0;
  d.regurg = last.regurg||0; d.nausea = last.nausea||0;
  d.flags = {...defaultFlags(),...(last.flags||{})};
  d.notes = last.notes||"";
  $$("[data-quality]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.quality===d.quality)));
  $$(".p-dysOpt").forEach(b=>b.setAttribute("aria-selected",String(Number(b.dataset.dys)===d.dysphagia)));
  const syncSym=(sym,val)=>{const w=$(`.p-chips[data-symptom="${sym}"]`);if(w)w.querySelectorAll(".p-chip").forEach(c=>c.setAttribute("aria-pressed",String(Number(c.dataset.level)===val)));};
  ["pain","regurg","nausea"].forEach(s=>syncSym(s,d[s]));
  $$(".p-chip[data-flag]").forEach(c=>c.setAttribute("aria-pressed",String(!!d.flags[c.dataset.flag])));
  const notes=$("#notes"); if(notes){notes.value=d.notes;const nc=$("#noteCount");if(nc)nc.textContent=String(d.notes.length);}
  updateProgress();
  Util.toast("Repeated last entry");
}

async function refreshKPIs() {
  const kpis = await KPI.compute(State.store);
  const el=(id,v)=>{const e=$(id);if(e)e.textContent=String(v);};
  el("#kpiTotal",kpis.total); el("#kpi7d",kpis.last7days); el("#kpiStreak",kpis.streak);
}

async function renderImpactionCount() {
  const el=$("#impactionCount"); if(!el) return;
  const cut=new Date(); cut.setDate(cut.getDate()-90); cut.setHours(0,0,0,0);
  const all=await State.store.getEntriesAll();
  const count=all.filter(e=>new Date(e.ts)>=cut && e.flags?.[IMPACTION_FLAG]).length;
  const cls=count===0?"ok":count<=2?"warn":"danger";
  el.innerHTML=`<div class="p-kpi">Impactions <b style="color:var(--${cls})">${count}</b> in 90 days</div>`;
}

async function renderEndoscopy() {
  const scopes=await State.store.getSetting("scopes",[]);
  const kpi=$("#kpiScopes"); if(kpi) kpi.textContent=String(scopes.length);
  const list=$("#scopeList"); if(!list) return;

  if(scopes.length>=2){
    const chart=$("#chartEos");
    if(chart){
      const vals=scopes.map(s=>s.eos||0);
      Charts.drawLine(chart,vals,{maxV:Math.max(30,...vals)*1.1,
        thresholds:[{y:15,label:"Remission threshold"}]});
    }
  }

  if(!scopes.length){list.innerHTML=`<div class="p-callout">No endoscopy records yet.</div>`;return;}
  list.innerHTML=[...scopes].reverse().map(s=>{
    const rem=s.eos<=15?"ok":"danger";
    return `<div class="p-item">
      <div class="p-itemTop"><div class="ts">${Util.esc(s.date)}</div><div class="q">${Util.esc(s.context||"")}</div></div>
      <div class="p-itemBody">Peak eos: <b style="color:var(--${rem})">${Util.esc(String(s.eos))} eos/hpf</b> ${s.eos<=15?"✓ Remission":"✗ Active"} · EREFS: <b>${Util.esc(String(s.erefs||"—"))}</b> · Treatment: ${Util.esc(s.treat||"—")}</div>
    </div>`;
  }).join("");
}

async function renderHistory() {
  const list=$("#histList"); if(!list) return;
  const all=(await State.store.getEntriesAll()).sort((a,b)=>b.ts.localeCompare(a.ts));
  if(!all.length){list.innerHTML=`<div class="p-callout">No entries yet.</div>`;return;}
  list.innerHTML=all.slice(0,80).map(e=>{
    const interp=interpEoEAI(e.eoeai||0);
    const phase=DIET_PHASES[e.dietPhase]?.short||e.dietPhase||"—";
    const impaction=e.flags?.[IMPACTION_FLAG];
    return `<div class="p-item">
      <div class="p-itemTop">
        <div class="ts">${Util.esc(e.dateKey)}</div>
        <div class="q">${Util.esc(phase)} · ${Util.esc(e.quality||"")} · EoEAI: <span style="color:${Util.cssVal(interp.color)}">${Util.esc(String(e.eoeai||0))}</span></div>
      </div>
      <div class="p-itemBody">Dysphagia: <b>${Util.esc(DYSPHAGIA_LEVELS[e.dysphagia||0]?.label||"None")}</b> · Pain: <b>${Util.esc(Util.levelToText(e.pain))}</b></div>
      ${impaction?`<div class="p-itemBody" style="color:var(--danger);margin-top:4px;font-weight:700;">⚠ FOOD BOLUS IMPACTION LOGGED</div>`:""}
      ${e.notes?`<div class="p-itemBody" style="margin-top:4px;">${Util.esc(e.notes)}</div>`:""}
    </div>`;
  }).join("");
}

async function renderInsights() {
  const all=(await State.store.getEntriesAll()).sort((a,b)=>a.ts.localeCompare(b.ts));
  const body=$("#insightsBody");
  if(all.length<5){if(body)body.textContent=`Log at least 5 entries. (${all.length} so far)`;return;}
  if(body)body.innerHTML=`<b>${all.length}</b> total entries logged.`;

  const last28=all.slice(-28);
  const dysVals=last28.map(e=>e.dysphagia||0);
  const dc=$("#chartDys"); if(dc) Charts.drawLine(dc,dysVals,{maxV:3,lc:"rgba(224,107,107,.8)",dc:"rgba(224,107,107,.9)"});

  if(!State.premium){$("#premiumPanel")?.classList.add("hidden");return;}
  const pp=$("#premiumPanel"); pp?.classList.remove("hidden");
  const last30=all.slice(-30);

  const eoeaiVals=last30.map(e=>e.eoeai||0);
  const painVals=last30.map(e=>e.pain||0);
  const ec=$("#chartEoEAI"); if(ec) Charts.drawLine(ec,eoeaiVals,{maxV:15});
  const pc=$("#chartPain2"); if(pc) Charts.drawLine(pc,painVals,{maxV:3,lc:"rgba(232,164,74,.8)",dc:"rgba(232,164,74,.9)"});

  // Trigger analysis — which foods eaten on high-dysphagia days
  const tb=$("#triggerBox");
  if(tb){
    const highDysDays=last30.filter(e=>(e.dysphagia||0)>=2);
    const trigCount={};
    TRIGGER_GROUPS.forEach(t=>trigCount[t.id]=0);
    highDysDays.forEach(e=>(e.triggersEaten||[]).forEach(t=>{if(trigCount[t]!==undefined)trigCount[t]++;}));
    const top=Object.entries(trigCount).sort((a,b)=>b[1]-a[1]).filter(([,v])=>v>0).slice(0,3);
    tb.className="p-callout"+(top.length?" warn":"");
    tb.innerHTML=top.length
      ?`<b>Trigger foods on high-dysphagia days:</b><br>${top.map(([k,v])=>{const tg=TRIGGER_GROUPS.find(x=>x.id===k);return`${tg?.icon||""} ${Util.esc(tg?.label||k)}: ${v} days`;}).join("<br>")}`
      :"Insufficient data to identify trigger food patterns yet.";
  }

  // Impaction summary
  const ib=$("#impactionBox");
  if(ib){
    const cut=new Date(); cut.setDate(cut.getDate()-90); cut.setHours(0,0,0,0);
    const imp=all.filter(e=>new Date(e.ts)>=cut&&e.flags?.[IMPACTION_FLAG]).length;
    const cls=imp===0?"ok":imp<=2?"warn":"danger";
    ib.className="p-callout "+cls;
    ib.innerHTML=`<b>Impaction events (90 days):</b> ${imp}. ${imp===0?"No impaction events — good disease control.":imp<=2?"Low impaction rate. Continue current management.":"Frequent impaction events. Discuss endoscopy and treatment escalation urgently."}`;
  }

  // Next steps
  const ns=$("#nextStepsList");
  if(ns){
    const steps=[];
    const imp90=all.filter(e=>{const cut=new Date();cut.setDate(cut.getDate()-90);return new Date(e.ts)>=cut&&e.flags?.[IMPACTION_FLAG];}).length;
    if(imp90>=2) steps.push({p:"danger",t:`${imp90} impaction events in 90 days. This frequency indicates inadequate disease control. Discuss urgent endoscopy and treatment escalation with your gastroenterologist.`});
    const meanDys=Stats.mean(last30.map(e=>e.dysphagia||0));
    if(meanDys>=1.5) steps.push({p:"warn",t:"Persistent dysphagia pattern. If on dietary or medical treatment, discuss whether endoscopy is due to confirm histological response."});
    const skipDays=last30.filter(e=>e.flags?.skippedppi||e.flags?.skippedsteroid).length;
    if(skipDays>=5) steps.push({p:"warn",t:`Medication missed ${skipDays}/30 days. Consistent adherence is required for histological remission — missing doses allows eosinophil counts to rise.`});
    const meanEoEAI=Stats.mean(last30.map(e=>e.eoeai||0));
    if(meanEoEAI>=8) steps.push({p:"warn",t:"Significant EoE activity score. If current treatment has been ongoing for >8 weeks, endoscopy with biopsy may be needed to assess histological response."});
    if(!steps.length) steps.push({p:"ok",t:"No high-priority signals. Continue current diet phase and medication. Maintain endoscopy surveillance schedule."});
    const colors={danger:"var(--danger)",warn:"var(--warn)",ok:"var(--ok)"};
    ns.innerHTML=steps.map(s=>`<div class="p-item"><div class="p-itemBody"><b style="color:${colors[s.p]}">${s.p.toUpperCase()}:</b> ${Util.esc(s.t)}</div></div>`).join("");
  }
}

function showTab(tab) {
  ["log","endoscopy","history","library","insights"].forEach(t=>{
    $("#tab-"+t)?.setAttribute("aria-selected",String(t===tab));
    $("#view-"+t)?.classList.toggle("hidden",t!==tab);
  });
  if(tab==="history") renderHistory();
  if(tab==="endoscopy") renderEndoscopy();
  if(tab==="library"){
    LibRenderer.renderCats($("#libCats"),LIB_CATS,State.libCat,cat=>{State.libCat=cat;renderLibrary();});
    renderLibrary();
  }
  if(tab==="insights") renderInsights();
}

function renderLibrary() {
  const grid=$("#libGrid"); if(!grid) return;
  const kpi=$("#kpiCards"); if(kpi) kpi.textContent=String(LIBRARY.cards.length);
  LibRenderer.render(grid,LibRenderer.filterCards(LIBRARY.cards,State.libCat,State.libQuery));
}

// ── EVENTS ───────────────────────────────────────────────────────
function wireEvents() {
  $$(".p-tab").forEach(b=>b.addEventListener("click",()=>showTab(b.dataset.tab)));

  $$("[data-diet]").forEach(b=>b.addEventListener("click",()=>{
    setDietUI(b.dataset.diet);
    State.store.setSetting("dietPhase",b.dataset.diet);
    updateProgress();
    setTimeout(()=>Util.scroll($("#stepQuality")),80);
  }));
  $("#btnChangeDiet")?.addEventListener("click",()=>{
    State.dietPhase=null;
    $$("[data-diet]").forEach(b=>b.setAttribute("aria-pressed","false"));
    $("#dietConfirm")?.classList.add("hidden");
    updateProgress();
  });

  $$("[data-quality]").forEach(b=>b.addEventListener("click",()=>{
    State.draft.quality=b.dataset.quality;
    $$("[data-quality]").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
    updateProgress();
    setTimeout(()=>Util.scroll($("#stepImpaction")),80);
  }));

  $$("[data-impaction]").forEach(b=>b.addEventListener("click",()=>{
    const isYes=b.dataset.impaction==="yes";
    State.draft.flags[IMPACTION_FLAG]=isYes;
    $$("[data-impaction]").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
    updateProgress();
    setTimeout(()=>Util.scroll($("#stepSymptoms")),80);
  }));

  $$(".p-dysOpt").forEach(b=>b.addEventListener("click",()=>{
    State.draft.dysphagia=Number(b.dataset.dys);
    $$(".p-dysOpt").forEach(x=>x.setAttribute("aria-selected",String(x===b)));
    const dl=$("#dysLabel"); if(dl) dl.textContent=DYSPHAGIA_LEVELS[State.draft.dysphagia]?.label||"";
    updateProgress();
  }));

  $$("[data-symptom]").forEach(wrap=>wrap.addEventListener("click",e=>{
    const btn=e.target.closest(".p-chip"); if(!btn) return;
    const sym=wrap.dataset.symptom, level=Number(btn.dataset.level);
    State.draft[sym]=Util.clamp(level,0,3);
    wrap.querySelectorAll(".p-chip").forEach(c=>c.setAttribute("aria-pressed",String(c===btn)));
    const lmap={pain:"painLabel",regurg:"regurgLabel",nausea:"nauseaLabel"};
    const lel=lmap[sym]?$(`#${lmap[sym]}`):null;
    if(lel) lel.textContent=Util.levelToText(level);
    updateProgress();
  }));

  // Trigger food eaten/avoided toggles
  $$("[data-trig]").forEach(b=>b.addEventListener("click",()=>{
    const id=b.dataset.trig, state=b.dataset.trigstate;
    const pressed=b.getAttribute("aria-pressed")==="true";
    b.setAttribute("aria-pressed",String(!pressed));
    // Clear opposite button for same food
    const opp=state==="eaten"?"avoided":"eaten";
    const oppBtn=$(`[data-trig="${id}"][data-trigstate="${opp}"]`);
    if(!pressed&&oppBtn) oppBtn.setAttribute("aria-pressed","false");
    // Update draft lists
    const fn=state==="eaten"?"triggersEaten":"triggersAvoided";
    const onf=state==="eaten"?"triggersAvoided":"triggersEaten";
    if(!pressed){
      if(!State.draft[fn].includes(id)) State.draft[fn].push(id);
      State.draft[onf]=State.draft[onf].filter(x=>x!==id);
    } else {
      State.draft[fn]=State.draft[fn].filter(x=>x!==id);
    }
  }));

  $$(".p-chip[data-flag]").forEach(b=>b.addEventListener("click",()=>{
    const k=b.dataset.flag;
    State.draft.flags[k]=!State.draft.flags[k];
    b.setAttribute("aria-pressed",String(State.draft.flags[k]));
    updateProgress();
  }));

  const notes=$("#notes");
  if(notes) notes.addEventListener("input",()=>{
    State.draft.notes=notes.value;
    const nc=$("#noteCount"); if(nc) nc.textContent=String(notes.value.length);
  });

  $("#btnSave")?.addEventListener("click",save);
  $("#btnRepeat")?.addEventListener("click",repeatLast);
  $("#btnReset")?.addEventListener("click",resetDraft);

  // INVARIANT: clinician report is always free — do not gate on PremiumGate.isPremium()
  $("#btnReport")?.addEventListener("click", () => Report.generate(MODULE_KEY));

  const doCSV=()=>IO.exportCSV(State.store,MODULE_KEY,FLAG_KEYS);
  const doJSON=()=>IO.exportJSON(State.store,MODULE_KEY);
  ["#btnExportCsv","#btnExportCsv2"].forEach(s=>$(s)?.addEventListener("click",doCSV));
  ["#btnExportJson","#btnExportJson2"].forEach(s=>$(s)?.addEventListener("click",doJSON));
  const btnImport=$("#btnImport"),importFile=$("#importFile");
  if(btnImport&&importFile){
    btnImport.addEventListener("click",()=>importFile.click());
    importFile.addEventListener("change",async e=>{
      const f=e.target.files?.[0]; if(!f) return;
      await IO.importJSON(f,State.store,FLAG_KEYS,async()=>{await refreshKPIs();await renderHistory();});
      e.target.value="";
    });
  }

  // Endoscopy form
  const scopeEos=$("#scopeEos"),scopeEREFS=$("#scopeEREFS"),scopeDate=$("#scopeDate"),scopePreview=$("#scopePreview");
  const updateScopePreview=()=>{
    const v=parseInt(scopeEos?.value);
    if(!isNaN(v)&&scopePreview){
      const cls=v<15?"ok":v<30?"warn":"danger";
      scopePreview.className="p-callout "+cls;
      scopePreview.innerHTML=`${v} eos/hpf — ${v<15?"✓ Histological remission (<15 threshold)":v<30?"↑ Elevated — active inflammation":"↑↑ High activity"}`;
      scopePreview.classList.remove("hidden");
    } else scopePreview?.classList.add("hidden");
  };
  scopeEos?.addEventListener("input",updateScopePreview);

  $("#btnSaveScope")?.addEventListener("click",async()=>{
    const eos=parseInt(scopeEos?.value);
    const erefs=parseInt(scopeEREFS?.value);
    const date=scopeDate?.value;
    const context=$("#scopeContext")?.value;
    const treat=$("#scopeTreat")?.value;
    if(isNaN(eos)||!date){Util.toast("Enter eos count and date");return;}
    const scopes=await State.store.getSetting("scopes",[]);
    scopes.push({eos,erefs:isNaN(erefs)?null:erefs,date,context:context||"",treat:treat||""});
    await State.store.setSetting("scopes",scopes);
    Util.toast("Scope record saved");
    if(scopeEos) scopeEos.value="";
    if(scopeEREFS) scopeEREFS.value="";
    if(scopeDate) scopeDate.value="";
    if($("#scopeContext")) $("#scopeContext").value="";
    if($("#scopeTreat")) $("#scopeTreat").value="";
    scopePreview?.classList.add("hidden");
    await renderEndoscopy();
  });

  $("#libSearch")?.addEventListener("input",e=>{State.libQuery=e.target.value||"";renderLibrary();});
  $("#btnRefresh")?.addEventListener("click",renderInsights);

  // Premium CTA — wire paywall
  $("#premiumCta")?.addEventListener("click", () => {
    PremiumGate.showPaywall(MODULE_KEY, () => {
      const sl = $("#premStatusLabel");
      if (sl) sl.textContent = "✦ Premium active";
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      renderInsights?.();
      Util.toast("Premium unlocked ✦");
    });
  });

}

// ── BOOT ─────────────────────────────────────────────────────────
async function boot() {
  injectStyles();
  renderHTML();
  const todayEl=$("#todayLabel"); if(todayEl) todayEl.textContent=Util.dateKeyLocal();

  const {store,mode}=await initStorage(MODULE_KEY);
  State.store=store;
  if (typeof GIOSNotifications !== "undefined") GIOSNotifications.init("eoe", "EoE OS");
  updateStorageModeUI(mode);

  const savedPremium=await store.getSetting("premium",false);
  State.premium=!!savedPremium;
  const m=$("#modeLabel"); if(m) m.textContent=State.premium?"Premium":"Free";

  const savedDiet=await store.getSetting("dietPhase",null);
  if(savedDiet) setDietUI(savedDiet);

  State.lastEntry=await store.getLastEntry();
  wireEvents();
  resetDraft();
  if(State.dietPhase) setDietUI(State.dietPhase);
  await refreshKPIs();
  await renderImpactionCount();

  LibRenderer.renderCats($("#libCats"),LIB_CATS,State.libCat,cat=>{State.libCat=cat;renderLibrary();});
  renderLibrary();

  Util.toast("EoE OS ready");
}

boot();
})();
