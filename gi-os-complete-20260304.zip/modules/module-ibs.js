/* META
 * @title      IBS OS — Clinical Tracker
 * @accent     #78c2a4
 * @accent2    #87b6ff
 * @accentGlow rgba(120,194,164,.12)
 */

/**
 * IBS OS — Module
 * ═══════════════════════════════════════════════════════════
 * IBS-specific: Bristol stool typing, IBS subtypes,
 * IBS-SSS scoring, low-FODMAP library, stool color logging,
 * symptom pattern recognition.
 * Platform handles: storage, charts, export/import, KPIs.
 * ═══════════════════════════════════════════════════════════
 */

(() => {
"use strict";

const { Util, Stats, Charts, LibRenderer, IO, KPI, Perf, Disclosure, initStorage, updateStorageModeUI } = Platform;
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

// ── MODULE CONFIG ────────────────────────────────────────────────
const MODULE_KEY = "ibs";

const FLAG_KEYS = [
  "stress","travel","illness","hormonal","antibiotics","nsaids",
  "latemeal","alcohol","caffeine","dietdeviation","newmed","poorslep"
];

const RED_FLAGS = ["bleeding","unintentionalwl","nightsymptoms","fever","familyhist"];

// IBS subtypes
const SUBTYPES = {
  ibsc:  "IBS-C (Constipation predominant)",
  ibsd:  "IBS-D (Diarrhoea predominant)",
  ibsm:  "IBS-M (Mixed)",
  ibsu:  "IBS-U (Unsubtyped)"
};

// Bristol Stool Scale
const BRISTOL = [
  { type:1, label:"Type 1", desc:"Separate hard lumps (like nuts)", constipating:true },
  { type:2, label:"Type 2", desc:"Sausage-shaped, lumpy", constipating:true },
  { type:3, label:"Type 3", desc:"Sausage with surface cracks", constipating:false },
  { type:4, label:"Type 4", desc:"Smooth, soft sausage or snake", constipating:false },
  { type:5, label:"Type 5", desc:"Soft blobs with clear-cut edges", constipating:false },
  { type:6, label:"Type 6", desc:"Mushy, fluffy pieces, ragged edges", constipating:false },
  { type:7, label:"Type 7", desc:"Watery, no solid pieces", constipating:false }
];

// Stool colors with clinical significance
const COLORS = [
  { id:"brown",   label:"Brown",        dot:"#8B6346", note:"Normal" },
  { id:"yellow",  label:"Yellow",       dot:"#D4A843", note:"Bile malabsorption / fast transit" },
  { id:"green",   label:"Green",        dot:"#5C9E6B", note:"Fast transit / dietary (leafy veg, food dye)" },
  { id:"pale",    label:"Pale/Clay",    dot:"#D4C5A9", note:"Biliary — discuss with doctor" },
  { id:"black",   label:"Black/Tarry",  dot:"#2C2C2C", note:"Upper GI bleed — urgent if unexplained" },
  { id:"red",     label:"Red/Blood",    dot:"#CC4444", note:"Lower GI bleed — urgent" }
];

function defaultFlags() { const f={}; FLAG_KEYS.forEach(k=>f[k]=false); return f; }
function defaultDraft() {
  return { subtype:null, quality:null, bristolType:null, frequency:null,
           color:null, pain:0, bloating:0, urgency:0, satisfaction:0,
           flags:defaultFlags(), notes:"" };
}

// ── IBS-SSS SCORING ──────────────────────────────────────────────
// IBS Severity Scoring System (Francis et al., Gut 1997)
// Validated patient-reported outcome — 5 domains, 0–500 total
// Each domain 0–100: pain severity, pain days, bloating, satisfaction, bowel habit interference
function calcIBSSSS(draft) {
  let score = 0;
  // Pain severity proxy (0–3 → 0–100 scaled)
  score += Math.round((draft.pain / 3) * 100);
  // Bloating severity proxy
  score += Math.round((draft.bloating / 3) * 100);
  // Urgency/interference
  score += Math.round((draft.urgency / 3) * 100);
  // Satisfaction (inverse — lower satisfaction = higher score)
  score += Math.round(((3 - draft.satisfaction) / 3) * 100);
  // Bristol deviation from normal (4 = ideal, deviation increases score)
  if (draft.bristolType !== null) {
    const deviation = Math.abs(draft.bristolType - 4);
    score += Math.min(100, Math.round(deviation * 25));
  }
  return Math.min(500, score);
}

function interpIBSSSS(score) {
  if (score < 75)  return { label:"Symptom-free / remission", cls:"ok",     color:"var(--ok)" };
  if (score < 175) return { label:"Mild IBS",                  cls:"ok",     color:"var(--ok)" };
  if (score < 300) return { label:"Moderate IBS",              cls:"warn",   color:"var(--warn)" };
  return                  { label:"Severe IBS",                 cls:"danger", color:"var(--danger)" };
}

// ── LIBRARY ──────────────────────────────────────────────────────
const LIBRARY = (() => {
  const cards = [];
  const add = o => cards.push({
    id: (o.cat+"::"+o.title).toLowerCase().replace(/[^a-z0-9]+/g,"-"), ...o
  });

  // LOW-FODMAP
  add({ cat:"Low-FODMAP Diet", tag:"fodmap", title:"Low-FODMAP: The Evidence Base",
    why:"The low-FODMAP diet is the most evidence-supported dietary intervention for IBS, with the strongest RCT data of any dietary therapy for functional gut disorders.",
    bullets:[
      "Developed by Gibson & Shepherd at Monash University, Melbourne. The randomized controlled evidence base (Halmos et al., Gastroenterology 2014; Staudacher et al., Gut 2017) demonstrated significant symptom reduction in 50–86% of patients compared to standard dietary advice.",
      "FODMAP = Fermentable Oligosaccharides, Disaccharides, Monosaccharides And Polyols. These are short-chain carbohydrates that are poorly absorbed in the small intestine, rapidly fermented by colonic bacteria, and osmotically active — producing gas, distension, and accelerated transit in IBS.",
      "Three-phase protocol: Restriction (2–6 weeks), Reintroduction (systematic testing of each FODMAP class), Personalization (long-term maintenance with identified trigger foods excluded, others reintroduced)."
    ],
    action:"Low-FODMAP is a diagnostic and therapeutic tool, not a permanent diet. The restriction phase should be time-limited (maximum 8 weeks). Reintroduction is mandatory — it identifies which specific FODMAP classes trigger your symptoms so you can eat as widely as possible long-term.",
    more:"The Monash University FODMAP app is the most evidence-based food guide available and is updated as new lab testing is completed. It uses a traffic-light system and provides portion sizes that are safe vs triggering. The evidence base for low-FODMAP is substantially stronger than elimination diets, gluten-free (in non-celiac IBS), or other dietary approaches.",
    evidence:"Halmos et al., Gastroenterology 2014; Staudacher et al., Gut 2017; Gibson & Shepherd, J Gastroenterol Hepatol 2010; Monash University FODMAP app (live database)"
  });

  add({ cat:"Low-FODMAP Diet", tag:"fodmap", title:"FODMAP Categories — What to Restrict",
    why:"Understanding which foods contain which FODMAP class is essential for the restriction phase and for targeted reintroduction.",
    bullets:[
      "Oligosaccharides — Fructans (wheat, rye, garlic, onion, leek, shallot, asparagus, artichoke) and GOS (legumes: chickpeas, lentils, most beans). The most common IBS trigger class. Garlic and onion are extremely high and among the most frequent triggers.",
      "Disaccharides — Lactose (milk, soft cheeses, ice cream, yogurt). Note: hard aged cheeses (cheddar, parmesan) are negligible lactose and generally safe.",
      "Monosaccharides — Excess fructose (honey, mango, apple, pear, watermelon, high-fructose corn syrup). Fructose only triggers when it exceeds glucose content — many fruits with equal fructose:glucose are safe.",
      "Polyols — Sorbitol (apple, pear, stone fruits: peach, cherry, plum, apricot), mannitol (mushrooms, cauliflower, snow peas), and sugar alcohols in 'diet' products (xylitol, sorbitol, maltitol — check gum, mints, protein bars)."
    ],
    action:"During restriction: avoid all high-FODMAP foods. Use Monash University app for portion guidance — some foods are safe in small portions (threshold effect). Garlic and onion flavour can be obtained safely using garlic-/onion-infused oil (FODMAPs do not transfer into oil).",
    more:"The concept of FODMAP stacking is important: a single low-FODMAP serving of multiple foods eaten together can add up to a high total FODMAP load. Track meals as complete units, not individual ingredients. This is a frequent cause of ongoing symptoms in patients following the diet correctly in isolation.",
    evidence:"Monash University FODMAP Database; Staudacher et al., Gut 2017; Barrett & Gibson, J Hum Nutr Diet 2012"
  });

  add({ cat:"Low-FODMAP Diet", tag:"fodmap", title:"FODMAP Reintroduction — The Critical Phase",
    why:"Reintroduction is the most important and most commonly skipped phase. Without it, you remain unnecessarily restricted and don't know your actual triggers.",
    bullets:[
      "Systematic reintroduction: test one FODMAP class at a time. Standard protocol: consume a test food containing predominantly one FODMAP class for 3 days, then 3 days washout (back to restriction diet). Move to next class only after washout.",
      "Test order (Monash recommendation): fructans (wheat), then fructose, then lactose, then GOS, then sorbitol, then mannitol, then polyols together. Test within-class dose response — many patients tolerate small amounts.",
      "Pass means: symptoms no worse than baseline during the 3-day test. Fail means: clear symptom exacerbation within 24–48 hours. Equivocal: repeat with smaller portion before concluding."
    ],
    action:"Keep a detailed log during reintroduction — use this app. Record test food, portion size, and symptom scores for each day. After completing all classes, you will have a personalized FODMAP profile. Maintain restriction only for confirmed trigger classes.",
    more:"Approximately 30% of IBS patients who respond to low-FODMAP restriction are NOT actually FODMAP-sensitive — their response is due to other aspects of dietary change (reduced ultra-processed food, changed eating patterns, placebo). Reintroduction confirms whether FODMAP restriction is genuinely necessary for you.",
    evidence:"Staudacher et al., Gut 2017; Tuck & Barrett, J Gastroenterol Hepatol 2017; Lomer et al., Aliment Pharmacol Ther 2019"
  });

  add({ cat:"Low-FODMAP Diet", tag:"fodmap", title:"Safe Foods — Low-FODMAP Reference",
    why:"Knowing what you CAN eat helps avoid unnecessary restriction and nutritional gaps.",
    bullets:[
      "Grains/starches: rice (all types), oats (plain), quinoa, polenta, corn tortillas, gluten-free pasta and bread, sourdough spelt bread (traditional long-ferment — most fructans degraded by fermentation), plain potato, sweet potato.",
      "Protein: all plain unprocessed meat, poultry, fish, shellfish, eggs, firm tofu. Check marinades and sauces for garlic/onion/honey.",
      "Vegetables (per serve): carrot, courgette/zucchini, cucumber, tomato (1 medium), spinach, kale, lettuce, bell pepper, eggplant, green beans, bok choy, broccoli (stems, small portion of florets), canned chickpeas (rinsed, ¼ cup — canning reduces GOS).",
      "Fruit (per serve): strawberries, blueberries, raspberries, kiwi, orange, mandarin, grapes, banana (firm — ripe banana higher fructose), pineapple, papaya. Limit to 1 serving per sitting.",
      "Dairy alternatives: lactose-free milk and yogurt, almond milk (plain, no inulin), rice milk, hard cheeses (cheddar, parmesan, brie, camembert), butter."
    ],
    action:"Build meals from this list during restriction. Variety is important — do not eat the same few safe foods repeatedly, as this increases risk of nutritional inadequacy and microbiome narrowing.",
    evidence:"Monash University FODMAP App v4.0+; Gibson & Shepherd, J Gastroenterol Hepatol 2010"
  });

  add({ cat:"Low-FODMAP Diet", tag:"fodmap", title:"Garlic and Onion — The Most Important Avoidance",
    why:"Garlic and onion are among the highest-FODMAP foods and the most frequent symptom triggers in IBS. They appear in almost every savory dish.",
    bullets:[
      "Both are extremely high in fructans. Even small amounts (¼ clove garlic, 1 tbsp diced onion) exceed the safe threshold for most fructan-sensitive patients. Fructan sensitivity is the most common FODMAP class trigger in IBS.",
      "Critical: garlic and onion flavor CAN be safely used via infused oils. FODMAP compounds are water-soluble, not fat-soluble — they do not transfer into oil. Garlic-infused olive oil (commercially produced or homemade from fresh garlic removed before storage) is safe and provides full flavor.",
      "Hidden sources: almost all commercial sauces (pasta sauce, BBQ sauce, soy sauce blends, stock cubes), soups, restaurant meals, processed meats, ready meals, seasoning blends, chips, and crackers. Always read ingredient lists."
    ],
    action:"During restriction: garlic- and onion-infused oil only for cooking. Read every label. At restaurants: request no onion or garlic — or choose dishes where avoidance is feasible (grilled fish, plain rice, salads with dressing on the side). This single avoidance often has the most dramatic symptom impact.",
    evidence:"Staudacher et al., Gut 2017; Monash University FODMAP Database"
  });

  // GUT-BRAIN AXIS
  add({ cat:"Gut-Brain Axis", tag:"gutbrain", title:"The Gut-Brain Axis in IBS",
    why:"IBS is fundamentally a disorder of gut-brain interaction (DGBI), not a structural disease. Understanding this changes both the treatment approach and the patient's relationship with their symptoms.",
    bullets:[
      "Rome IV classification (2016) formally defines IBS as a disorder of gut-brain interaction — not 'functional' in the dismissive historic sense, but a genuine pathophysiologic state involving altered gut-brain signaling, visceral hypersensitivity, altered gut motility, microbiome changes, and low-grade mucosal immune activation.",
      "The bidirectional gut-brain axis: the gut sends signals to the brain via the vagus nerve (80% of signals are afferent — gut to brain), the enteric nervous system, and the hypothalamic-pituitary-adrenal axis. IBS is characterized by central sensitization — the brain amplifies normal gut signals into pain.",
      "Clinical implication: psychological approaches (gut-directed hypnotherapy, CBT, ACT) are disease-modifying, not just coping strategies. Gut-directed hypnotherapy (Whorwell et al., Lancet 1984; multiple RCTs) achieves 70–80% response rates comparable to pharmacotherapy."
    ],
    action:"Track stress and sleep as seriously as dietary triggers using the flags in this app. The gut-brain axis means that a stressful week will change your symptom pattern as predictably as a dietary transgression. This is not 'in your head' — it is neuroscience.",
    more:"The enteric nervous system contains approximately 500 million neurons — more than the spinal cord. It operates largely independently of the central nervous system. In IBS, altered serotonin signaling (5-HT in the gut) is a key mechanism — serotonin regulates gut motility and visceral sensation, and 90-95% of the body's serotonin is in the gut, not the brain.",
    evidence:"Rome IV Criteria, Gastroenterology 2016; Whorwell et al., Lancet 1984; Ford et al., Lancet Gastroenterol Hepatol 2014; Longstreth et al., Gastroenterology 2006"
  });

  add({ cat:"Gut-Brain Axis", tag:"gutbrain", title:"Gut-Directed Hypnotherapy",
    why:"Gut-directed hypnotherapy (GDH) is the most evidence-supported psychological intervention for IBS with long-term follow-up data — often underutilized.",
    bullets:[
      "Developed by Professor Peter Whorwell, Manchester. The original Lancet RCT (1984) showed 80% response vs 20% control. Multiple subsequent RCTs and 5-year follow-up data confirm durable benefit. Response rates 70–80% in compliant patients.",
      "Mechanism: directly targets visceral hypersensitivity — the central sensitization that amplifies gut signals into pain. GDH normalizes the brain's interpretation of gut sensory input, not the gut signals themselves. The effect is demonstrable on neuroimaging.",
      "Access options: therapist-delivered (10–12 sessions, 45 min each), app-based (Nerva app — RCT-validated, Riehl & Kinsinger, Neurogastroenterol Motil 2023), audio programs (Manchester protocol recordings available commercially)."
    ],
    action:"Consider Nerva app as a first-step accessible option if in-person GDH is unavailable or unaffordable. Requires daily practice (15–20 min) for 8–12 weeks. Track symptom score monthly. For severe IBS, discuss in-person GDH with your gastroenterologist.",
    evidence:"Whorwell et al., Lancet 1984; Palsson et al., Am J Gastroenterol 2002; Riehl & Kinsinger, Neurogastroenterol Motil 2023; Lövdahl et al., Am J Gastroenterol 2021"
  });

  add({ cat:"Gut-Brain Axis", tag:"gutbrain", title:"Stress, Sleep, and the IBS Flare",
    why:"Stress and sleep disruption are among the most consistent IBS triggers with clear mechanistic pathways — not coincidence.",
    bullets:[
      "Cortisol directly increases gut permeability ('leaky gut'), alters gut motility, and modulates the gut microbiome composition. Acute stress activates the HPA axis and ANS, increasing gut secretion, accelerating transit (IBS-D pattern), and amplifying visceral pain.",
      "Sleep disruption increases cytokine production and reduces vagal tone — both independently worsening visceral hypersensitivity. Even one night of poor sleep measurably increases next-day gut sensitivity in IBS patients (Heitkemper et al., J Clin Sleep Med 2012).",
      "Practical implication: consistent bedtime and wake time are IBS management. Regular mild-moderate exercise (30 min most days) is among the most consistent IBS symptom reducers in RCT data (Johannesson et al., Am J Gastroenterol 2011), likely via vagal tone improvement."
    ],
    action:"Use Poor sleep and Stress flags consistently. After 30+ entries, Insights will show whether these correlate with your symptom scores. For most patients with IBS-D, stress is among the top 3 triggers. Managing it is managing IBS.",
    evidence:"Heitkemper et al., J Clin Sleep Med 2012; Johannesson et al., Am J Gastroenterol 2011; Mayer et al., Nature Reviews Gastroenterology 2015"
  });

  // BRISTOL & STOOL
  add({ cat:"Bristol Scale & Stool", tag:"bristol", title:"The Bristol Stool Scale — Clinical Use",
    why:"The Bristol Stool Form Scale (BSS) is a validated clinical tool, not just a curiosity. It objectively measures colonic transit time and is used in clinical trials to subtype and monitor IBS.",
    bullets:[
      "Developed by Heaton & Lewis at the University of Bristol (Scand J Gastroenterol 1997). Each type correlates with colonic transit time: Types 1–2 = slow transit (constipation, >72h transit); Types 3–4 = normal transit (24–72h); Types 5–7 = fast transit (<24h, diarrhoea).",
      "Type 4 is the clinical ideal — smooth, soft, easy to pass, complete evacuation. Your goal during remission.",
      "IBS subtyping uses BSS: IBS-C = predominantly Types 1–2 (≥25% of stools). IBS-D = predominantly Types 6–7 (≥25%). IBS-M = mixed (≥25% each of hard and loose). Your daily BSS log builds an objective picture of your subtype and treatment response."
    ],
    action:"Log your predominant stool type each day even if you have multiple types — log the most common or most symptomatic. Over 30 days, your IBS subtype emerges from the data. This matters for treatment: IBS-C and IBS-D have different medication, probiotic, and dietary responses.",
    evidence:"Heaton & Lewis, Scand J Gastroenterol 1997; Lewis & Heaton, Scand J Gastroenterol 1997; Rome IV Criteria"
  });

  add({ cat:"Bristol Scale & Stool", tag:"bristol", title:"Stool Color — When It Matters",
    why:"Stool color provides additional clinical information. Most variation is dietary, but some patterns require medical attention.",
    bullets:[
      "Brown: normal. Bile pigments (bilirubin → stercobilin) produce brown color. Variation from dark to light brown is normal.",
      "Yellow: often fat malabsorption (bile salt insufficiency, exocrine pancreatic insufficiency, celiac disease) or very rapid transit. Occasional yellow stools in IBS-D are common and usually reflect transit speed rather than malabsorption.",
      "Green: rapid transit (bile not fully converted to stercobilin) or dietary (leafy greens, green food dyes, iron supplements). Usually benign.",
      "Pale/clay/white: absent or reduced bile flow — biliary obstruction, cholestasis, or rarely medications (antacids). Any persistent pale stool requires medical review.",
      "Black/tarry: iron supplements or bismuth are common causes. Melena (digested blood from upper GI bleeding) — medical emergency if no dietary explanation.",
      "Red: lower GI bleeding (hemorrhoids, fissure, colitis, polyp, cancer) or dietary (beetroot, red food dye). Any red stool not explained by recent diet requires evaluation."
    ],
    action:"Log stool color using the Color field. Black or red stool without a clear dietary explanation: contact your doctor. This is a red flag that must not be attributed to IBS without exclusion of structural cause.",
    evidence:"Cash, Dis Mon 2011; Azer, StatPearls 2023; BSG Guidelines on rectal bleeding 2021"
  });

  // SUBTYPES & TREATMENT
  add({ cat:"IBS Subtypes", tag:"subtypes", title:"IBS-D — Diarrhoea Predominant",
    why:"IBS-D has specific treatment options and dietary approaches distinct from other subtypes.",
    bullets:[
      "Characteristics: predominant BSS Types 6–7, urgency, loose stool, post-meal urgency (gastrocolic reflex hypersensitivity), often morning predominance. Most commonly associated with food triggers and stress.",
      "Dietary priorities: low-FODMAP diet (strongest evidence), regular small meals (avoid large meals triggering exaggerated gastrocolic reflex), reduce fat load per meal, limit caffeine and alcohol.",
      "Pharmacological options (discuss with gastroenterologist): loperamide (acute urgency management, not regular use), bile acid sequestrants if bile acid malabsorption suspected (10–30% of IBS-D), rifaximin (Rome IV-supported, reduces IBS severity including bloating), alosetron (5-HT3 antagonist, licensed in severe IBS-D), eluxadoline."
    ],
    action:"Track morning symptoms, urgency, and post-meal patterns using urgency and timing logs. IBS-D often worsens with stress, caffeine, and high-fat meals. Low-FODMAP is the starting point — if incomplete response, discuss bile acid testing with your gastroenterologist.",
    evidence:"Ford et al., Lancet Gastroenterol Hepatol 2014; Camilleri et al., Gastroenterology 2012; Pimentel et al., N Engl J Med 2011"
  });

  add({ cat:"IBS Subtypes", tag:"subtypes", title:"IBS-C — Constipation Predominant",
    why:"IBS-C is distinct from simple constipation and has specific therapies.",
    bullets:[
      "Characteristics: predominant BSS Types 1–2, infrequent stools, straining, incomplete evacuation sensation, bloating often prominent. Pain typically relieved by defecation.",
      "Dietary priorities: soluble fiber (oats, psyllium, linseeds — NOT insoluble fiber like wheat bran, which worsens bloating in IBS-C), adequate hydration (2–3L fluid daily), regular meal timing. Prunes contain sorbitol — effective stool softener in IBS-C.",
      "Pharmacological options: linaclotide (guanylate cyclase agonist — reduces abdominal pain and improves stool consistency, strong RCT evidence), lubiprostone (chloride channel activator), plecanatide, low-dose PEG for constipation rescue."
    ],
    action:"Track BSS Types 1–2 frequency. Adequate hydration and soluble fiber are the dietary foundation. If symptoms remain significant, linaclotide has the strongest evidence for IBS-C with pain — raise this specifically with your gastroenterologist.",
    evidence:"Chey et al., Am J Gastroenterol 2012 (linaclotide); Ford et al., Am J Gastroenterol 2014; NICE IBS Guidelines 2017"
  });

  add({ cat:"IBS Subtypes", tag:"subtypes", title:"Bloating and Distension in IBS",
    why:"Bloating is the most bothersome symptom for many IBS patients and has specific mechanisms and treatments.",
    bullets:[
      "Distinguish abdominal bloating (subjective sensation of fullness/pressure) from visible distension (objective increase in girth — abdomen visibly larger). Both occur in IBS but via different mechanisms. Distension visible in photographs/waistband tightening is more likely gas-related.",
      "Mechanisms: FODMAP fermentation producing gas, impaired gas propulsion (retrograde propulsion in IBS — gas moves backward instead of forward), abdominal accommodation reflex impairment, visceral hypersensitivity amplifying normal gas volume.",
      "Specific interventions: low-FODMAP (most consistent), rifaximin (reduces bacterial fermentation), simethicone (short-term gas relief), activated charcoal (gas adsorption), peppermint oil (smooth muscle antispasmodic — evidence-based for IBS pain and bloating), low-dose antidepressants (neuromodulation of visceral hypersensitivity)."
    ],
    action:"Rate bloating separately from pain in every entry. Identify whether bloating is consistently post-meal (FODMAP/fermentation) vs persistent throughout the day (motility) vs anxiety-associated (evening, stress-correlated). Each pattern suggests different interventions.",
    evidence:"Lasser et al., Ann Intern Med 1975; Caldarella et al., Dig Dis Sci 2002; Pimentel et al., Am J Gastroenterol 2006"
  });

  // PROBIOTICS
  add({ cat:"Probiotics & Microbiome", tag:"probiotics", title:"Probiotics in IBS — What the Evidence Shows",
    why:"Probiotics have the most variable evidence in IBS. Understanding what is supported helps avoid wasting money on ineffective products.",
    bullets:[
      "Most effective strains in RCTs: Bifidobacterium infantis 35624 (Align — the most consistently replicated single-strain result in IBS, Whorwell et al., Am J Gastroenterol 2006), Lactobacillus rhamnosus GG (moderate evidence for IBS-D), VSL#3 (multi-strain — consistent bloating reduction), Saccharomyces boulardii (IBS-D specific, moderate evidence).",
      "Meta-analytic conclusion (Ford et al., Am J Gastroenterol 2014; Hungin et al., Aliment Pharmacol Ther 2013): probiotics are modestly effective for global IBS symptoms, particularly bloating. Strain, dose, and individual microbiome composition all significantly affect response. Generic supermarket probiotics are unlikely to help.",
      "Prebiotics (non-digestible fibers that feed specific microbiome species) should be introduced cautiously in IBS — many are FODMAPs (FOS, inulin, GOS). Partially hydrolyzed guar gum (PHGG) and psyllium are better tolerated prebiotic options in IBS."
    ],
    action:"If trialing a probiotic: use a strain with RCT evidence for IBS (Bifidobacterium infantis 35624 / Align is the best starting point). Trial for 4–8 weeks. Log symptom scores before and after. If no improvement, discontinue — there is no benefit in continuing an ineffective probiotic.",
    evidence:"Whorwell et al., Am J Gastroenterol 2006; Ford et al., Am J Gastroenterol 2014; Moayyedi et al., Am J Gastroenterol 2010"
  });

  // RED FLAGS
  add({ cat:"Red Flags", tag:"safety", title:"IBS Red Flags — When Symptoms Need Investigation",
    why:"IBS is a diagnosis of exclusion. These features must trigger medical investigation before attributing symptoms to IBS.",
    bullets:[
      "Absolute red flags (urgent evaluation): rectal bleeding not explained by hemorrhoids or fissure (any age), blood mixed in stool, unintentional weight loss >5% in 3 months, nocturnal symptoms waking from sleep (IBS is classically absent at night), fever with abdominal symptoms, progressive dysphagia, new onset in patients over 50 years old without prior investigation.",
      "Family history flags: colorectal cancer in first-degree relative under 50, familial adenomatous polyposis, Lynch syndrome — requires accelerated surveillance regardless of IBS diagnosis.",
      "The IBS misdiagnosis risk: microscopic colitis (especially in older women on NSAIDs/PPIs), bile acid malabsorption (SeHCAT test), small bowel bacterial overgrowth (SIBO — hydrogen breath test), celiac disease (anti-TTG IgA — must be excluded in all IBS patients), ovarian pathology in women."
    ],
    action:"If any red flag feature is present in this log, contact your gastroenterologist before the next scheduled appointment. These features are not IBS until formally excluded by investigation. This app tracks symptoms — it does not assess or interpret symptoms clinically.",
    evidence:"NICE IBS Guidelines 2017; BSG IBS Guidance 2021; ACG IBS Guidelines 2021; Canavan et al., Aliment Pharmacol Ther 2014"
  });

  add({ cat:"Red Flags", tag:"safety", title:"Celiac Disease — Important to Exclude in IBS-Type Symptoms",
    why:"Celiac disease is frequently missed in people with IBS-type symptoms. It requires lifelong gluten exclusion and has serious complications if untreated.",
    bullets:[
      "Prevalence: 1% of the population; up to 5% in IBS-D patients. Symptoms overlap completely with IBS: bloating, diarrhoea, abdominal pain, fatigue.",
      "Test: anti-tissue transglutaminase IgA (anti-TTG IgA) and total IgA. Must be tested WHILE EATING GLUTEN — results are falsely negative after gluten exclusion. If IgA deficient, add IgG-based tests.",
      "Positive screen requires duodenal biopsy for confirmation. Dietary gluten challenge is not appropriate for self-diagnosis without serology."
    ],
    action:"Confirm celiac disease has been excluded with serology before accepting an IBS diagnosis. If you have already excluded gluten from your diet, discuss gluten challenge for testing with your gastroenterologist.",
    evidence:"NICE CG86 2009; Ludvigsson et al., Gut 2013; ACG Celiac Guidelines 2023"
  });

  return { cards };
})();

const LIB_CATS = ["all", ...new Set(LIBRARY.cards.map(c => c.cat))];

// ── STATE ────────────────────────────────────────────────────────
const State = {
  store: null, storageMode: "unknown",
  premium: false, subtype: null,
  draft: defaultDraft(), lastEntry: null,
  libCat: "all", libQuery: ""
};

// ── HTML ─────────────────────────────────────────────────────────
function renderHTML() {
  document.getElementById("module-root").innerHTML = `
<div class="p-app">
  <header class="p-header">
    <div class="p-brand">
      <div class="p-logo-dot" aria-hidden="true"></div>
      <div>
        <h1 class="p-brand-name">IBS OS</h1>
        <div class="p-brand-sub">Symptom tracker</div>
      </div>
    </div>
    <div class="p-header-right">
      <div class="p-pill">🔥 <b id="kpiStreak">0</b>&nbsp;·&nbsp;7d <b id="kpi7d">0</b>&nbsp;·&nbsp;<b id="kpiTotal">0</b> total</div>
    </div>
  </header>

  <nav class="p-nav">
    <div class="p-tabs" role="tablist">
      <button class="p-tab" role="tab" id="tab-log"      aria-selected="true"  data-tab="log"      type="button">Log</button>
      <button class="p-tab" role="tab" id="tab-history"  aria-selected="false" data-tab="history"  type="button">History</button>
      <button class="p-tab" role="tab" id="tab-library"  aria-selected="false" data-tab="library"  type="button">Library</button>
      <button class="p-tab" role="tab" id="tab-insights" aria-selected="false" data-tab="insights" type="button">Insights</button>
    </div>
  </nav>

  <!-- LOG -->
  <section id="view-log">
    <div class="p-grid two">
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>How are you today?</h2><p>Takes about a minute</p></div>
          <div class="p-kpis"><div class="p-kpi">Date <b id="todayLabel"></b></div></div>
        </div>
        <div class="p-card-b">

          <!-- Step 1: Subtype -->
          <div id="stepSubtype">
            <div class="p-labelrow"><div class="p-lbl">First — what type of IBS do you have?</div><div class="p-hint">we'll remember this</div></div>
            <div class="p-callout" style="font-size:13px;margin-bottom:10px;">Do you know your IBS subtype? If not, answer below and we'll guide you.</div>
            <div class="p-seg" id="subtypeSegs">
              <button class="p-segBtn" type="button" data-sub="ibsc"  aria-pressed="false">Constipation</button>
              <button class="p-segBtn" type="button" data-sub="ibsd"  aria-pressed="false">Diarrhea</button>
              <button class="p-segBtn" type="button" data-sub="ibsm"  aria-pressed="false">Mixed</button>
              <button class="p-segBtn" type="button" data-sub="ibsu"  aria-pressed="false">Not sure</button>
            </div>
            <div id="subtypeConfirm" class="hidden" style="margin-top:8px;">
              <div class="p-callout" style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
                <span>Subtype: <b id="subtypeLabel">—</b></span>
                <button class="p-btn ghost sm" type="button" id="btnChangeSub">Change</button>
              </div>
            </div>
          </div>

          <!-- Step 2: Overall day -->
          <div id="stepQuality" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">How was today overall?</div><div class="p-hint"></div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-quality="great" aria-pressed="false">Great</button>
              <button class="p-segBtn" type="button" data-quality="okay"  aria-pressed="false">Okay</button>
              <button class="p-segBtn" type="button" data-quality="rough" aria-pressed="false">Rough</button>
            </div>
          </div>

          <!-- Step 3: Bristol Stool Type -->
          <div id="stepBristol" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">What did your stool look like?</div><div class="p-hint">tap to select</div></div>
            <div class="p-bristolGrid">
              ${BRISTOL.map(b => `
              <button class="p-bOpt" type="button" data-bristol="${b.type}" aria-selected="false">
                <div class="bn">Type ${b.type}</div>
                <div class="bt">${b.label.replace("Type "+b.type,"")}</div>
                <div style="font-size:10px;color:var(--muted2);margin-top:2px;">${b.desc.split(",")[0]}</div>
              </button>`).join("")}
              <button class="p-bOpt" type="button" data-bristol="0" aria-selected="false">
                <div class="bn">—</div>
                <div class="bt">None</div>
                <div style="font-size:10px;color:var(--muted2);margin-top:2px;">No BM today</div>
              </button>
            </div>
          </div>

          <!-- Step 4: Frequency -->
          <div id="stepFreq" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">How many bowel movements today?</div><div class="p-hint">tap to select</div></div>
            <div class="p-freqGrid">
              ${[0,1,2,3,4,5,6,7].map(n => `
              <button class="p-freqBtn" type="button" data-freq="${n}" aria-pressed="false">
                <div class="fn">${n === 7 ? "7+" : n}</div>
                <div class="fl">${["none","once","twice","3×","4×","5×","6×","≥7×"][n]}</div>
              </button>`).join("")}
            </div>
          </div>

          <!-- Step 5: Color -->
          <div id="stepColor" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">What color was it?</div><div class="p-hint">optional</div></div>
            <div class="p-colorRow">
              ${COLORS.map(c => `
              <button class="p-swatch" type="button" data-color="${c.id}" aria-selected="false">
                <div class="sw-dot" style="background:${c.dot};"></div>
                <span>${c.label}</span>
              </button>`).join("")}
            </div>
            <div id="colorNote" class="p-callout" style="margin-top:8px;font-size:12px;display:none;"></div>
          </div>

          <!-- Step 6: Symptoms -->
          <div id="stepSymptoms" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Any symptoms today?</div><div class="p-hint">optional</div></div>

            <div class="p-labelrow" style="margin-top:4px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Abdominal pain</div><div class="p-hint" id="painLabel">none</div></div>
            <div class="p-chips" data-symptom="pain">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Bloating</div><div class="p-hint" id="bloatLabel">none</div></div>
            <div class="p-chips" data-symptom="bloating">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Urgency</div><div class="p-hint" id="urgLabel">none</div></div>
            <div class="p-chips" data-symptom="urgency">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Satisfied with your bowel today?</div><div class="p-hint" id="satLabel">complete</div></div>
            <div class="p-chips" data-symptom="satisfaction">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">Complete</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Slightly incomplete</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Incomplete</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Very incomplete</button>
            </div>

            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Flags</div><div class="p-hint">tick all that apply</div></div>
            <div class="p-chips">
              <button class="p-chip warn"   type="button" data-flag="stress"       aria-pressed="false">Stress↑</button>
              <button class="p-chip warn"   type="button" data-flag="poorslep"     aria-pressed="false">Poor sleep</button>
              <button class="p-chip"        type="button" data-flag="travel"       aria-pressed="false">Travel</button>
              <button class="p-chip"        type="button" data-flag="illness"      aria-pressed="false">Illness</button>
              <button class="p-chip"        type="button" data-flag="hormonal"     aria-pressed="false">Hormonal</button>
              <button class="p-chip warn"   type="button" data-flag="antibiotics"  aria-pressed="false">Antibiotics</button>
              <button class="p-chip warn"   type="button" data-flag="nsaids"       aria-pressed="false">NSAIDs</button>
              <button class="p-chip"        type="button" data-flag="latemeal"     aria-pressed="false">Late meal</button>
              <button class="p-chip"        type="button" data-flag="alcohol"      aria-pressed="false">Alcohol</button>
              <button class="p-chip"        type="button" data-flag="caffeine"     aria-pressed="false">Caffeine↑</button>
              <button class="p-chip"        type="button" data-flag="dietdeviation" aria-pressed="false">Diet deviation</button>
              <button class="p-chip"        type="button" data-flag="newmed"       aria-pressed="false">Med change</button>
            </div>

            <!-- Red flag chips (separate) -->
            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;color:var(--danger);">Red flags</div><div class="p-hint">urgent if present</div></div>
            <div class="p-chips">
              <button class="p-chip danger" type="button" data-redflag="bleeding"        aria-pressed="false">Rectal bleeding</button>
              <button class="p-chip danger" type="button" data-redflag="unintentionalwl" aria-pressed="false">Weight loss</button>
              <button class="p-chip danger" type="button" data-redflag="nightsymptoms"   aria-pressed="false">Nocturnal symptoms</button>
              <button class="p-chip danger" type="button" data-redflag="fever"           aria-pressed="false">Fever</button>
            </div>

            <div id="redFlagAlert" class="p-callout danger hidden" style="margin-top:10px;">
              <b>Red flag active.</b> These features require medical evaluation and must not be attributed to IBS without investigation. Contact your gastroenterologist.
            </div>

            <div class="p-section">
              <div class="p-labelrow"><div class="p-lbl">Notes</div><div class="p-hint"><span id="noteCount">0</span>/600</div></div>
              <textarea id="notes" class="p-note" maxlength="600" placeholder="Anything else worth noting?"></textarea>
            </div>
          </div>

          <!-- Actions -->
          <div id="stepActions" class="p-section hidden">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnSave" disabled>Done</button>
              <button class="p-btn" type="button" id="btnRepeat" disabled>Same as yesterday</button>
              <button class="p-btn ghost" type="button" id="btnReset">Reset</button>
            </div>
          </div>
        </div>
      </div>

      <!-- RIGHT -->
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>Today's Guidance</h2><p>Personalized to what you logged</p></div>
        </div>
        <div class="p-card-b">
          <div id="guidance" class="p-callout">Complete the log steps above — guidance will appear here.</div>
          <div id="inlineCard" class="p-section" style="display:none;"></div>

          <div id="scorePanel" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">IBS-SSS Score</div><div class="p-hint">0–500 scale</div></div>
            <div class="p-scoreWrap">
              <div class="p-scoreBig" id="scoreBig">—</div>
              <div class="p-scoreSubLabel">IBS Severity Scoring System</div>
            </div>
            <div id="scoreInterp" class="p-callout" style="margin-top:8px;"></div>
          </div>

          <div class="p-section">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnReport">Clinician report</button>
              <button class="p-btn" type="button" id="btnExportCsv">Export CSV</button>
              <button class="p-btn" type="button" id="btnExportJson">Export JSON</button>
              <button class="p-btn" type="button" id="btnImport">Import</button>
              <input id="importFile" type="file" accept="application/json" class="sr">
            </div>
          </div>

          <div class="p-section">
            <div class="p-premRow" id="premiumCta" style="cursor:pointer;">
              <div class="p-premLabel" id="premStatusLabel">Unlock Premium — trend analytics · trigger correlation · next steps</div>
              <div style="font-family:var(--font-mono);font-size:10px;letter-spacing:.08em;color:#f5c842;">UPGRADE ✦</div>
            </div>
          </div>

          <!-- Bristol reference mini-card -->
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Bristol reference</div></div>
            <div style="display:flex;flex-direction:column;gap:4px;">
              ${BRISTOL.map(b => `
              <div style="display:flex;gap:8px;align-items:baseline;font-size:12px;">
                <span style="font-family:var(--font-mono);font-size:11px;color:var(--accent);flex:0 0 48px;">Type ${b.type}</span>
                <span style="color:var(--muted);">${b.desc}</span>
              </div>`).join("")}
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- HISTORY -->
  <section id="view-history" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>History</h2><p>Most recent first</p></div>
        <div class="p-rowBtns" style="margin:0;">
          <button class="p-btn" type="button" id="btnExportCsv2">Export CSV</button>
          <button class="p-btn" type="button" id="btnExportJson2">Export JSON</button>
        </div>
      </div>
      <div class="p-card-b"><div class="p-list" id="histList"></div></div>
    </div>
  </section>

  <!-- LIBRARY -->
  <section id="view-library" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Clinical Library</h2><p>Low-FODMAP · Gut-Brain · Bristol · Subtypes · Red Flags</p></div>
        <div style="display:flex;gap:10px;align-items:center;">
          <div class="p-kpis"><div class="p-kpi">Cards <b id="kpiCards">0</b></div></div>
          <input id="libSearch" type="search" class="p-search" placeholder="Search FODMAP, Bristol, IBS-D…">
        </div>
      </div>
      <div class="p-card-b">
        <div class="p-libCats" id="libCats"></div>
        <div class="p-libGrid" id="libGrid"></div>
      </div>
    </div>
  </section>

  <!-- INSIGHTS -->
  <section id="view-insights" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Insights</h2><p>Free: Bristol distribution · Premium: trends + trigger correlation + next steps</p></div>
        <button class="p-btn" type="button" id="btnRefresh" style="margin:0;">Refresh</button>
      </div>
      <div class="p-card-b">
        <div id="insightsBody" class="p-callout">Log at least 5 entries to unlock insights.</div>
        <div class="p-section">
          <div class="p-chartWrap"><canvas id="chartBristol" height="200"></canvas><div class="p-chartMeta">Bristol type distribution (last 28 days)</div></div>
        </div>
        <div id="premiumPanel" class="p-section hidden">
          <div class="p-grid two">
            <div class="p-chartWrap"><canvas id="chartPain" height="200"></canvas><div class="p-chartMeta">Pain trend (last 30 entries)</div></div>
            <div class="p-chartWrap"><canvas id="chartBloat" height="200"></canvas><div class="p-chartMeta">Bloating trend (last 30 entries)</div></div>
          </div>
          <div class="p-section p-grid two">
            <div class="p-callout" id="triggerBox"></div>
            <div class="p-callout" id="bristolBox"></div>
          </div>
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Ranked next steps</div><div class="p-hint">data-driven</div></div>
            <div class="p-list" id="nextStepsList"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>`;
}

// ── LOGIC ────────────────────────────────────────────────────────
function setSubtypeUI(sub) {
  State.subtype = sub;
  State.draft.subtype = sub;
  $$("[data-sub]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.sub === sub)));
  const lbl = $("#subtypeLabel"); if (lbl) lbl.textContent = SUBTYPES[sub] || sub;
  $("#subtypeConfirm")?.classList.toggle("hidden", !sub);
}

function updateProgress() {
  const d = State.draft;
  const hasSub  = !!State.subtype;
  const hasQ    = !!d.quality;
  const hasB    = d.bristolType !== null && d.bristolType !== undefined;
  const hasF    = d.frequency !== null && d.frequency !== undefined;

  $("#stepQuality")?.classList.toggle("hidden", !hasSub);
  $("#stepBristol")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepFreq")?.classList.toggle("hidden", !(hasSub && hasQ && hasB));
  $("#stepColor")?.classList.toggle("hidden", !(hasSub && hasQ && hasB && hasF));
  $("#stepSymptoms")?.classList.toggle("hidden", !(hasSub && hasQ && hasB && hasF));
  $("#stepActions")?.classList.toggle("hidden", !(hasSub && hasQ && hasB && hasF));

  const canSave = hasSub && hasQ && hasB && hasF;
  const btnSave = $("#btnSave"); if (btnSave) btnSave.disabled = !canSave;
  const btnRepeat = $("#btnRepeat"); if (btnRepeat) btnRepeat.disabled = !State.lastEntry;

  // INVARIANT: red flags always visible — never gated on premium. MDR compliance.
  const hasRedFlag = RED_FLAGS.some(k => d.flags?.[k]);
  $("#redFlagAlert")?.classList.toggle("hidden", !hasRedFlag);

  updateGuidance(d);
}

// ── INLINE CARD RENDERER ─────────────────────────────────────────
// Surfaces a specific library card inline in the guidance panel
// based on what was logged today. The card title must match exactly.
function renderInlineCard(cardTitle) {
  const container = document.getElementById("inlineCard");
  if (!container) return;

  const card = LIBRARY.cards.find(c => c.title === cardTitle);
  if (!card) { container.style.display = "none"; return; }

  container.style.display = "block";
  const safeTitle = card.title.split("—")[0].trim().replace(/'/g, "\'");

  const bulletsHTML = (card.bullets || []).map(b =>
    `<li style="font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:6px;">${b}</li>`
  ).join("");

  const moreHTML = card.more
    ? `<div style="font-size:12px;color:var(--muted2);line-height:1.5;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);">${card.more}</div>`
    : "";

  const evidenceHTML = card.evidence
    ? `<div style="font-size:11px;color:var(--muted2);font-family:var(--font-mono);margin-top:8px;line-height:1.5;">${card.evidence}</div>`
    : "";

  container.innerHTML = `
    <div style="border-left:3px solid var(--accent);padding-left:14px;margin-top:8px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px;">Your doctor says</div>
      <div style="font-size:15px;font-weight:600;color:var(--fg);margin-bottom:8px;">${card.title}</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;margin-bottom:10px;">${card.why}</div>
      ${bulletsHTML ? `<ul style="margin:0 0 10px 0;padding-left:16px;">${bulletsHTML}</ul>` : ""}
      ${card.action ? `
        <div style="padding:12px 14px;background:var(--surface2);border-radius:10px;margin-bottom:10px;">
          <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">What to do</div>
          <div style="font-size:13px;color:var(--fg);line-height:1.6;">${card.action}</div>
        </div>` : ""}
      ${moreHTML}
      ${evidenceHTML}
      <button type="button"
        style="font-size:12px;color:var(--accent);background:none;border:none;padding:4px 0 0 0;cursor:pointer;text-decoration:underline;display:block;margin-top:6px;"
        onclick="(function(){document.getElementById('tab-library')?.click();var s=document.getElementById('libSearch');if(s){s.value='${safeTitle}';s.dispatchEvent(new Event('input'));}})()">
        Browse all library cards →
      </button>
    </div>
  `;
}


// Maps the current log state to the most clinically relevant library card
function pickInlineCard(d) {
  const b = d.bristolType;
  const sub = State.subtype;

  // Red flag — no card, just the alert
  if (d.flags && Object.keys(d.flags).some(k => RED_FLAGS.includes(k) && d.flags[k])) return null;

  // Loose stool — psyllium/fiber or IBS-D card
  if (b && b >= 6) {
    if (d.frequency >= 3) return "IBS-D — Diarrhoea Predominant";
    return "Fiber — Getting the Basics Right";
  }

  // Hard stool — fiber/psyllium card
  if (b && b <= 2) return "Fiber — Getting the Basics Right";

  // Significant bloating
  if (d.bloating >= 2) return "Bloating and Distension in IBS";

  // Stress flagged
  if (d.flags?.stress) return "Stress, Sleep, and the IBS Flare";

  // Significant pain
  if (d.pain >= 2) return "Gut-Directed Hypnotherapy";

  // Not sure of subtype
  if (sub === "ibsu") return "IBS-M — Mixed IBS";

  // Mixed subtype showing stable
  if (sub === "ibsm") return "IBS-M — Mixed IBS";

  // Default: gut-brain
  return "The Gut-Brain Axis in IBS";
}

function updateGuidance(d) {
  const g = $("#guidance"), sp = $("#scorePanel");
  if (!g) return;

  if (!State.subtype || !d.quality || d.bristolType === null || d.frequency === null) {
    g.innerHTML = "Complete the log steps above — guidance will appear here.";
    const ic = document.getElementById("inlineCard"); if (ic) ic.style.display = "none";
    sp?.classList.add("hidden"); return;
  }

  // Premium gate — guidance is gated after 14-day trial
  if (!PremiumGate.isPremium()) {
    PremiumGate.showGuidanceGate(g, MODULE_KEY, () => updateGuidance(d));
    sp?.classList.add("hidden");
    return;
  }


  const score = calcIBSSSS(d);
  const interp = interpIBSSSS(score);
  const b = d.bristolType;
  const freq = d.frequency || 0;

  // ── ASSESSMENT ───────────────────────────────────────────────
  // Describe what was logged in plain language, without diagnosing.
  // Uses data observation language — "your log shows", not "you have".
  let assessment = "";

  // Stool pattern is the primary signal
  if (b && b >= 6 && freq >= 3) {
    assessment = `Your log today shows a diarrhea pattern — ${freq === 7 ? "7 or more" : freq} bowel movement${freq !== 1 ? "s" : ""}, Type ${b} stool (loose/watery). This is consistent with an IBS-D flare.`;
  } else if (b && b >= 6) {
    assessment = `Your log shows loose stool today — Type ${b}. Frequency is lower than a typical flare, but the consistency pattern is worth tracking.`;
  } else if (b && b <= 2 && freq <= 1) {
    assessment = `Your log today shows a constipation pattern — Type ${b} stool (hard/pellet-like)${freq === 0 ? ", with no bowel movement today" : ", with only one bowel movement"}. This is consistent with an IBS-C pattern.`;
  } else if (b && b <= 2) {
    assessment = `Your log shows hard stool today — Type ${b}. The frequency is okay but the consistency suggests your transit is slow.`;
  } else if (d.quality === "rough" && d.pain >= 2) {
    assessment = `Your log shows a rough day with significant pain. Without a clear stool pattern signal today, pain and quality-of-life are the dominant findings.`;
  } else if (d.quality === "great") {
    assessment = `Your log shows a good day — stool pattern in normal range, no major symptoms flagged. Days like this are important data points. Note what you ate, your stress level, and your sleep.`;
  } else {
    assessment = `Your log shows a mixed day. No single dominant signal — stool pattern and symptoms are in the moderate range.`;
  }

  // Add secondary signals
  if (d.bloating >= 2 && b && b >= 4) assessment += ` Significant bloating alongside loose stool often points to FODMAP load or gas trapping — garlic and onion are the most common hidden triggers.`;
  if (d.flags?.stress && d.quality !== "great") assessment += ` Stress is flagged today. This is a direct physiologic trigger — cortisol accelerates gut transit and lowers the pain threshold.`;
  if (d.flags?.latemeal) assessment += ` Late meal flagged. Eating within 2–3 hours of lying down is one of the most consistent IBS aggravators.`;

  // ── PLAN ─────────────────────────────────────────────────────
  // Educational language — "many patients find", "worth discussing with your doctor".
  // Based on doctor's exact clinical voice from content session.
  let plan = "";

  if (b && b >= 6 && freq >= 3) {
    plan = `Many patients with this pattern find that psyllium husk helps significantly. It's partially soluble — it behaves like honey in the gut, binding acid, bile, and gas pockets, and creating consistent gentle pressure that gradually retrains the gut's nervous system to tolerate distension. A common starting approach is half a teaspoon mixed into a full glass of water once daily, taken at the same time each day — morning works well. Expect 2–4 weeks before seeing a consistent effect. If urgency is severe today, loperamide (Imodium) is appropriate for acute management — it's not a long-term solution but it works. Worth discussing both with your gastroenterologist.`;
  } else if (b && b >= 6) {
    plan = `Psyllium husk is worth considering for loose stool — half a teaspoon daily in a full glass of water. It regulates in both directions, so it helps with loose stool as well as constipation. Review what you ate yesterday — high-FODMAP foods (especially garlic, onion, wheat, and dairy) are the most common same-day triggers for loose stool in IBS.`;
  } else if (b && b <= 2) {
    plan = `For constipation-pattern days, psyllium husk is the first-line approach — half a teaspoon in a full glass of water daily. Soluble fiber (oats, psyllium) is more effective than insoluble fiber (bran, wheat) for IBS-C and causes less bloating. Sitting on the toilet 20 minutes after a meal takes advantage of the gastrocolic reflex — the gut's natural urge to move after eating. Adequate hydration (at least 6–8 glasses of water daily) is essential for fiber to work. Worth raising with your gastroenterologist if this pattern is consistent over 5 or more days.`;
  } else if (d.bloating >= 2) {
    plan = `For significant bloating, the starting point is FODMAP reduction — specifically garlic and onion, which are the highest-FODMAP foods and appear in almost every savory dish. Garlic-infused oil is a safe substitute — the FODMAP compounds don't transfer into oil. Peppermint oil capsules (enteric-coated) have good evidence for IBS-related bloating and pain. Worth discussing with your gastroenterologist if this is a recurring pattern.`;
  } else if (d.flags?.stress && d.quality !== "great") {
    plan = `For stress-driven IBS, gut-directed hypnotherapy has the strongest long-term evidence of any IBS treatment — 70–80% response rates in trials. The Nerva app is an accessible first step. Regular moderate exercise (30 minutes most days) also has consistent trial data for IBS symptom reduction, likely through improved vagal tone. These aren't soft suggestions — they're the most evidence-supported interventions available for the gut-brain axis component of IBS.`;
  } else if (d.quality === "great") {
    plan = `Keep doing what you're doing today. Log what worked — meal timing, stress management, sleep quality. Patterns across good days are as clinically useful as patterns across bad ones.`;
  } else {
    plan = `Continue logging consistently. Two weeks of daily data is usually enough to identify your primary trigger pattern — dietary, stress-related, or hormonal. That pattern determines the treatment approach. Bring your Clinician Report to your next gastroenterology appointment.`;
  }

  // Render Assessment + Plan
  g.innerHTML = `
    <div style="margin-bottom:12px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Assessment</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${assessment}</div>
    </div>
    <div>
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Plan</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${plan}</div>
    </div>
    <div style="font-size:11px;color:var(--muted2);margin-top:10px;border-top:1px solid var(--border);padding-top:8px;">This is patient education based on your logged data — not a medical diagnosis. Discuss any changes to your treatment with your gastroenterologist.</div>
  `;

  // Show inline library card relevant to today's log
  const cardTitle = pickInlineCard(d);
  if (cardTitle) renderInlineCard(cardTitle);
  else { const ic = document.getElementById("inlineCard"); if (ic) ic.style.display = "none"; }

  if (sp) {
    sp.classList.remove("hidden");
    const big = $("#scoreBig");
    if (big) { big.textContent = score; big.style.color = interp.color; }
    const si = $("#scoreInterp");
    if (si) {
      si.className = "p-callout " + (interp.cls || "");
      const tips = {
        ok:     "Minimal symptoms or remission. Maintain current management.",
        warn:   "Moderate symptoms. Review trigger logs and dietary compliance.",
        danger: "Significant symptom burden. Consider discussing with your gastroenterologist."
      };
      si.innerHTML = `<b>${interp.label}:</b> ${tips[interp.cls] || ""}`;
    }
  }
}

function resetDraft() {
  State.draft = defaultDraft();
  if (State.subtype) State.draft.subtype = State.subtype;
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$("[data-bristol]").forEach(b => b.setAttribute("aria-selected","false"));
  $$("[data-freq]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$("[data-color]").forEach(b => b.setAttribute("aria-selected","false"));
  $$("[data-symptom] .p-chip").forEach(c => c.setAttribute("aria-pressed", String(c.dataset.level === "0")));
  $$(".p-chip[data-flag], .p-chip[data-redflag]").forEach(c => c.setAttribute("aria-pressed","false"));
  const notes = $("#notes"); if (notes) notes.value = "";
  const nc = $("#noteCount"); if (nc) nc.textContent = "0";
  const cn = $("#colorNote"); if (cn) cn.style.display = "none";
  ["painLabel","bloatLabel","urgLabel","satLabel"].forEach((id,i) => {
    const el = $(`#${id}`); if (el) el.textContent = ["none","none","none","complete"][i];
  });
  updateProgress();
}

async function save() {
  try {
    if ($("#btnSave")) $("#btnSave").disabled = true;
    const d = State.draft;
    const entry = {
      ts: Util.nowISO(), dateKey: Util.dateKeyLocal(),
      subtype: State.subtype, quality: d.quality,
      bristolType: d.bristolType, frequency: d.frequency,
      color: d.color || null,
      pain: Util.clamp(d.pain,0,3), bloating: Util.clamp(d.bloating,0,3),
      urgency: Util.clamp(d.urgency,0,3), satisfaction: Util.clamp(d.satisfaction,0,3),
      ibssss: calcIBSSSS(d),
      flags: {...d.flags}, notes: (d.notes||"").slice(0,600), deleted: 0
    };
    const last = State.lastEntry;
    if (last) {
      const dt = Math.abs(+new Date(entry.ts) - +new Date(last.ts));
      if (dt < 90000 && entry.quality === last.quality && entry.bristolType === last.bristolType) {
        Util.toast("Duplicate entry blocked"); return;
      }
    }
    const saved = await Perf.time("entry-save", async () => { await State.store.addEntry(entry); });
    State.lastEntry = saved;
    Util.toast("Entry saved");
  // First-time upgrade nudge at 14 entries
  const allEntries = await State.store.getEntriesAll();
  if (allEntries.length === 14 && !PremiumGate.isPremium()) {
    setTimeout(() => PremiumGate.showPaywall(MODULE_KEY, () => {
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      Util.toast("Premium unlocked ✦");
    }), 1200);
  }
    resetDraft();
    await refreshKPIs();
  } catch(err) { console.error(err); Util.toast("Save failed"); }
  finally { updateProgress(); }
}

async function repeatLast() {
  const last = State.lastEntry || await State.store.getLastEntry();
  if (!last) return;
  State.lastEntry = last;
  if (last.subtype) setSubtypeUI(last.subtype);
  const d = State.draft;
  d.quality = last.quality; d.bristolType = last.bristolType; d.frequency = last.frequency;
  d.color = last.color; d.pain = last.pain||0; d.bloating = last.bloating||0;
  d.urgency = last.urgency||0; d.satisfaction = last.satisfaction||0;
  d.flags = {...defaultFlags(), ...(last.flags||{})};
  d.notes = last.notes||"";
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.quality === d.quality)));
  $$("[data-bristol]").forEach(b => b.setAttribute("aria-selected", String(Number(b.dataset.bristol) === d.bristolType)));
  $$("[data-freq]").forEach(b => b.setAttribute("aria-pressed", String(Number(b.dataset.freq) === d.frequency)));
  if (d.color) $$("[data-color]").forEach(b => b.setAttribute("aria-selected", String(b.dataset.color === d.color)));
  const syncSym = (sym, val) => {
    const w = $(`.p-chips[data-symptom="${sym}"]`);
    if (w) w.querySelectorAll(".p-chip").forEach(c => c.setAttribute("aria-pressed", String(Number(c.dataset.level) === val)));
  };
  syncSym("pain",d.pain); syncSym("bloating",d.bloating); syncSym("urgency",d.urgency); syncSym("satisfaction",d.satisfaction);
  $$(".p-chip[data-flag]").forEach(c => c.setAttribute("aria-pressed", String(!!d.flags[c.dataset.flag])));
  const notes = $("#notes"); if (notes) { notes.value = d.notes; const nc = $("#noteCount"); if (nc) nc.textContent = String(d.notes.length); }
  updateProgress();
  Util.toast("Repeated last entry");
}

async function refreshKPIs() {
  const kpis = await KPI.compute(State.store);
  const el = (id,v) => { const e = $(id); if (e) e.textContent = String(v); };
  el("#kpiTotal", kpis.total);
  el("#kpi7d", kpis.last7days);
  el("#kpiStreak", kpis.streak);
}

async function renderHistory() {
  const list = $("#histList"); if (!list) return;
  const all = (await State.store.getEntriesAll()).sort((a,b) => b.ts.localeCompare(a.ts));
  if (!all.length) { list.innerHTML = `<div class="p-callout">No entries yet.</div>`; return; }
  list.innerHTML = all.slice(0,80).map(e => {
    const interp = interpIBSSSS(e.ibssss || 0);
    const flags = FLAG_KEYS.filter(k => e.flags?.[k]).slice(0,5);
    return `<div class="p-item">
      <div class="p-itemTop">
        <div class="ts">${Util.esc(e.dateKey)}</div>
        <div class="q">${Util.esc(SUBTYPES[e.subtype]||e.subtype||"—")} · ${Util.esc(e.quality||"")} · Bristol ${Util.esc(String(e.bristolType||"-"))} · ${Util.esc(String(e.frequency||0))}×</div>
      </div>
      <div class="p-itemBody">Pain: <b>${Util.esc(Util.levelToText(e.pain))}</b> · Bloating: <b>${Util.esc(Util.levelToText(e.bloating))}</b> · Urgency: <b>${Util.esc(Util.levelToText(e.urgency))}</b> · SSS: <b style="color:${Util.cssVal(interp.color)}">${Util.esc(String(e.ibssss||0))} (${Util.esc(interp.label)})</b></div>
      ${flags.length ? `<div class="p-itemBody" style="margin-top:4px;font-family:var(--font-mono);font-size:11px;color:var(--muted2);">${Util.esc(flags.join(", "))}</div>` : ""}
      ${e.notes ? `<div class="p-itemBody" style="margin-top:4px;">${Util.esc(e.notes)}</div>` : ""}
    </div>`;
  }).join("");
}

async function renderInsights() {
  const all = (await State.store.getEntriesAll()).sort((a,b) => a.ts.localeCompare(b.ts));
  const body = $("#insightsBody");
  if (all.length < 5) { if (body) body.textContent = `Log at least 5 entries. (${all.length} so far)`; return; }
  if (body) body.innerHTML = `<b>${all.length}</b> total entries logged.`;

  // Bristol distribution last 28 days
  const cut28 = new Date(); cut28.setDate(cut28.getDate()-27); cut28.setHours(0,0,0,0);
  const last28 = all.filter(e => new Date(e.ts) >= cut28);
  const bristolDist = Array(8).fill(0);
  last28.forEach(e => { if (e.bristolType >= 0) bristolDist[e.bristolType]++; });
  const bc = $("#chartBristol");
  if (bc) Charts.drawBars(bc, ["None","1","2","3","4","5","6","7"], bristolDist,
    { c1:"rgba(120,194,164,.75)", c2:"rgba(135,182,255,.45)" });

  if (!PremiumGate.isPremium()) {
    const pp = $("#premiumPanel"); pp?.classList.add("hidden");
    // Show inline paywall nudge
    const body = $("#insightsBody");
    if (body && !body.querySelector(".pw-inline-nudge")) {
      const nudge = document.createElement("div");
      nudge.className = "pw-inline-nudge p-callout";
      nudge.style.cssText = "margin-top:12px;cursor:pointer;border-color:rgba(245,200,66,.25);background:rgba(245,200,66,.04);";
      nudge.innerHTML = `<b style="color:#f5c842;">✦ Unlock Premium to see your full Insights</b><br><span style="font-size:var(--font-size-sm);color:var(--muted);">Trend charts · trigger correlation · next steps · what's driving your symptoms</span><br><span style="display:inline-block;margin-top:8px;font-size:var(--font-size-sm);font-family:var(--font-mono);color:#f5c842;">Tap to upgrade →</span>`;
      nudge.addEventListener("click", () => PremiumGate.showPaywall(MODULE_KEY, () => { nudge.remove(); renderInsights(); }));
      body.appendChild(nudge);
    }
    return;
  }

  const pp = $("#premiumPanel"); pp?.classList.remove("hidden");
  const last30 = all.slice(-30);
  const painVals = last30.map(e => e.pain||0);
  const bloatVals = last30.map(e => e.bloating||0);

  const pc = $("#chartPain"); if (pc) Charts.drawLine(pc, painVals, { maxV:3, lc:"rgba(224,122,122,.8)", dc:"rgba(224,122,122,.9)" });
  const blc = $("#chartBloat"); if (blc) Charts.drawLine(blc, bloatVals, { maxV:3, lc:"rgba(224,155,79,.8)", dc:"rgba(224,155,79,.9)" });

  // Trigger analysis
  const tb = $("#triggerBox");
  if (tb) {
    const trigCount = {};
    FLAG_KEYS.forEach(k => trigCount[k] = 0);
    last30.forEach(e => FLAG_KEYS.forEach(k => { if (e.flags?.[k]) trigCount[k]++; }));
    const top = Object.entries(trigCount).sort((a,b)=>b[1]-a[1]).filter(([,v])=>v>0).slice(0,3);
    tb.className = "p-callout";
    tb.innerHTML = top.length
      ? `<b>Top triggers (last 30 entries):</b><br>${top.map(([k,v]) => `${Util.esc(k)}: ${v} days`).join("<br>")}`
      : "No consistent trigger flags found. Continue logging.";
  }

  // Bristol pattern box
  const bb = $("#bristolBox");
  if (bb) {
    const types = last30.map(e => e.bristolType).filter(t => t > 0);
    const mean = types.length ? Stats.mean(types) : null;
    let label = "insufficient data", cls = "";
    if (mean !== null) {
      if (mean <= 2.5) { label = "Constipation pattern (mean Type "+mean.toFixed(1)+")"; cls = "warn"; }
      else if (mean >= 5.5) { label = "Diarrhea pattern (mean Type "+mean.toFixed(1)+")"; cls = "warn"; }
      else { label = "Normal range (mean Type "+mean.toFixed(1)+")"; cls = "ok"; }
    }
    bb.className = "p-callout " + cls;
    bb.innerHTML = `<b>Bristol pattern:</b> ${Util.esc(label)}`;
  }

  // Next steps
  const ns = $("#nextStepsList");
  if (ns) {
    const steps = [];
    const last7 = all.slice(-7);
    const severeDay = last7.find(e => (e.ibssss||0) >= 300);
    if (severeDay) steps.push({ p:"danger", t:"Severe IBS-SSS score recorded in the past week. Consider earlier gastroenterology review." });
    const redFlagDay = all.slice(-14).find(e => RED_FLAGS.some(k => e.flags?.[k]));
    if (redFlagDay) steps.push({ p:"danger", t:"Red flag symptom logged in past 14 days. This requires medical evaluation if not already investigated." });
    const stressCount = last30.filter(e => e.flags?.stress).length;
    if (stressCount >= 10) steps.push({ p:"warn", t:`Stress flagged ${stressCount}/30 days. Consider gut-directed hypnotherapy or CBT for IBS — see Gut-Brain Axis library.` });
    const meanPain = Stats.mean(last30.map(e=>e.pain||0));
    if (meanPain >= 1.5) steps.push({ p:"warn", t:"Persistent pain pattern. Discuss neuromodulator therapy (low-dose amitriptyline or mirtazapine) with your gastroenterologist." });
    if (!steps.length) steps.push({ p:"ok", t:"No high-priority signals. Continue logging — insights improve with more data." });
    const colors = { danger:"var(--danger)", warn:"var(--warn)", ok:"var(--ok)" };
    ns.innerHTML = steps.map(s => `<div class="p-item"><div class="p-itemBody"><b style="color:${colors[s.p]}">${s.p.toUpperCase()}:</b> ${Util.esc(s.t)}</div></div>`).join("");
  }
}

function showTab(tab) {
  ["log","history","library","insights"].forEach(t => {
    $("#tab-"+t)?.setAttribute("aria-selected", String(t === tab));
    $("#view-"+t)?.classList.toggle("hidden", t !== tab);
  });
  if (tab === "history") renderHistory();
  if (tab === "library") {
    LibRenderer.renderCats($("#libCats"), LIB_CATS, State.libCat, cat => {
      State.libCat = cat; renderLibrary();
    });
    renderLibrary();
  }
  if (tab === "insights") renderInsights();
}

function renderLibrary() {
  const grid = $("#libGrid"); if (!grid) return;
  const kpi = $("#kpiCards"); if (kpi) kpi.textContent = String(LIBRARY.cards.length);
  LibRenderer.render(grid, LibRenderer.filterCards(LIBRARY.cards, State.libCat, State.libQuery));
}

// ── EVENTS ───────────────────────────────────────────────────────
function wireEvents() {
  $$(".p-tab").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));

  // Subtype
  $$("[data-sub]").forEach(b => b.addEventListener("click", () => {
    setSubtypeUI(b.dataset.sub);
    State.store.setSetting("subtype", b.dataset.sub);
    updateProgress();
    setTimeout(() => Util.scroll($("#stepQuality")), 80);
  }));
  $("#btnChangeSub")?.addEventListener("click", () => {
    State.subtype = null;
    $$("[data-sub]").forEach(b => b.setAttribute("aria-pressed","false"));
    $("#subtypeConfirm")?.classList.add("hidden");
    updateProgress();
  });

  // Quality
  $$("[data-quality]").forEach(b => b.addEventListener("click", () => {
    State.draft.quality = b.dataset.quality;
    $$("[data-quality]").forEach(x => x.setAttribute("aria-pressed", String(x === b)));
    updateProgress();
    setTimeout(() => Util.scroll($("#stepBristol")), 80);
  }));

  // Bristol
  $$("[data-bristol]").forEach(b => b.addEventListener("click", () => {
    State.draft.bristolType = Number(b.dataset.bristol);
    $$("[data-bristol]").forEach(x => x.setAttribute("aria-selected", String(x === b)));
    updateProgress();
    setTimeout(() => Util.scroll($("#stepFreq")), 80);
  }));

  // Frequency
  $$("[data-freq]").forEach(b => b.addEventListener("click", () => {
    State.draft.frequency = Number(b.dataset.freq);
    $$("[data-freq]").forEach(x => x.setAttribute("aria-pressed", String(x === b)));
    updateProgress();
    setTimeout(() => Util.scroll($("#stepColor")), 80);
  }));

  // Color swatches
  $$("[data-color]").forEach(b => b.addEventListener("click", () => {
    State.draft.color = b.dataset.color;
    $$("[data-color]").forEach(x => x.setAttribute("aria-selected", String(x === b)));
    const c = COLORS.find(x => x.id === b.dataset.color);
    const cn = $("#colorNote");
    if (c && cn) {
      cn.innerHTML = `<b>${Util.esc(c.label)}:</b> ${Util.esc(c.note)}`;
      cn.style.display = "block";
      cn.className = "p-callout" + (["black","red"].includes(c.id) ? " danger" : ["pale"].includes(c.id) ? " warn" : "");
    }
    updateProgress();
  }));

  // Symptom chips
  $$("[data-symptom]").forEach(wrap => wrap.addEventListener("click", e => {
    const btn = e.target.closest(".p-chip"); if (!btn) return;
    const sym = wrap.dataset.symptom, level = Number(btn.dataset.level);
    State.draft[sym] = Util.clamp(level, 0, 3);
    wrap.querySelectorAll(".p-chip").forEach(c => c.setAttribute("aria-pressed", String(c === btn)));
    const labels = { pain:"painLabel", bloating:"bloatLabel", urgency:"urgLabel", satisfaction:"satLabel" };
    const satTexts = ["complete","slightly incomplete","incomplete","very incomplete"];
    const lblEl = labels[sym] ? $(`#${labels[sym]}`) : null;
    if (lblEl) lblEl.textContent = sym === "satisfaction" ? satTexts[level] : Util.levelToText(level);
    updateProgress();
  }));

  // Flag chips
  $$(".p-chip[data-flag]").forEach(b => b.addEventListener("click", () => {
    const k = b.dataset.flag;
    State.draft.flags[k] = !State.draft.flags[k];
    b.setAttribute("aria-pressed", String(State.draft.flags[k]));
    updateProgress();
  }));

  // Red flag chips (stored in flags too)
  $$(".p-chip[data-redflag]").forEach(b => b.addEventListener("click", () => {
    const k = b.dataset.redflag;
    State.draft.flags[k] = !State.draft.flags[k];
    b.setAttribute("aria-pressed", String(State.draft.flags[k]));
    updateProgress();
  }));

  // Notes
  const notes = $("#notes");
  if (notes) notes.addEventListener("input", () => {
    State.draft.notes = notes.value;
    const nc = $("#noteCount"); if (nc) nc.textContent = String(notes.value.length);
  });

  // Actions
  $("#btnSave")?.addEventListener("click", save);
  $("#btnRepeat")?.addEventListener("click", repeatLast);
  $("#btnReset")?.addEventListener("click", resetDraft);

  // Export/Import
  const flagsForExport = [...FLAG_KEYS, ...RED_FLAGS];
  const doCSV = () => IO.exportCSV(State.store, MODULE_KEY, flagsForExport);
  const doJSON = () => IO.exportJSON(State.store, MODULE_KEY);
  // INVARIANT: clinician report is always free — do not gate on PremiumGate.isPremium()
  $("#btnReport")?.addEventListener("click", () => Report.generate(MODULE_KEY));
  ["#btnExportCsv","#btnExportCsv2"].forEach(s => $(s)?.addEventListener("click", doCSV));
  ["#btnExportJson","#btnExportJson2"].forEach(s => $(s)?.addEventListener("click", doJSON));
  const btnImport = $("#btnImport"), importFile = $("#importFile");
  if (btnImport && importFile) {
    btnImport.addEventListener("click", () => importFile.click());
    importFile.addEventListener("change", async e => {
      const f = e.target.files?.[0]; if (!f) return;
      await IO.importJSON(f, State.store, flagsForExport, async () => { await refreshKPIs(); await renderHistory(); });
      e.target.value = "";
    });
  }

  // Library search
  $("#libSearch")?.addEventListener("input", e => {
    State.libQuery = e.target.value || ""; renderLibrary();
  });

  // Premium CTA — wire paywall
  $("#premiumCta")?.addEventListener("click", () => {
    PremiumGate.showPaywall(MODULE_KEY, () => {
      const sl = $("#premStatusLabel");
      if (sl) sl.textContent = "✦ Premium active";
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      renderInsights?.();
      Util.toast("Premium unlocked ✦");
    });
  });

  // Insights
  $("#btnRefresh")?.addEventListener("click", renderInsights);

}

// ── BOOT ─────────────────────────────────────────────────────────
async function boot() {
  renderHTML();
  const todayEl = $("#todayLabel"); if (todayEl) todayEl.textContent = Util.dateKeyLocal();

  const { store, mode } = await initStorage(MODULE_KEY);
  State.store = store;
  updateStorageModeUI(mode);
  if (typeof GIOSNotifications !== "undefined") GIOSNotifications.init("ibs", "IBS OS");

  // Premium state managed by PremiumGate (localStorage)

  const savedSubtype = await store.getSetting("subtype", null);
  if (savedSubtype) setSubtypeUI(savedSubtype);
  State.lastEntry = await store.getLastEntry();
  
  // Apply progressive disclosure state
  const allForDisclosure = await store.getEntriesAll();
  const hasAlarm = allForDisclosure.slice(-7).some(e => 
    e.flags && Object.values(e.flags).some(v => v === true)
  );
  const disclosureState = Disclosure.getState(allForDisclosure.length, hasAlarm);
  Disclosure.applyToDOM(disclosureState, MODULE_KEY);
  // Show onboarding on first run
  setTimeout(() => Onboarding.show(MODULE_KEY, store), 400);

  // Update premium CTA label based on current gate state
  const { state, trialDaysLeft } = PremiumGate.getState();
  const sl = $("#premStatusLabel");
  if (sl) {
    if (state === "active") sl.textContent = "✦ Premium active";
    else if (state === "trial") sl.textContent = `✦ Trial active · ${trialDaysLeft}d remaining`;
    else sl.textContent = "Unlock Premium — trend analytics · trigger correlation · next steps";
  }
  PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();


  wireEvents();
  resetDraft();
  await refreshKPIs();

  LibRenderer.renderCats($("#libCats"), LIB_CATS, State.libCat, cat => {
    State.libCat = cat; renderLibrary();
  });
  renderLibrary();

  Util.toast("IBS OS ready");
}

boot();
})();
