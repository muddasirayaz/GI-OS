/* META
 * @title      Celiac OS — Clinical Tracker
 * @accent     #e8a44a
 * @accent2    #7ecba1
 * @accentGlow rgba(232,164,74,.12)
 */

/**
 * Celiac OS — Module
 * ═══════════════════════════════════════════════════════════
 * Gluten-free diet adherence tracking, symptom logging,
 * accidental exposure detection, serology trending (TTG-IgA),
 * dietary label literacy tools, cross-contamination tracking,
 * bone health and nutritional monitoring flags,
 * library covering GFD, label reading, nutritional deficiencies,
 * surveillance, associated conditions, red flags.
 * ═══════════════════════════════════════════════════════════
 */

(() => {
"use strict";

const { Util, Stats, Charts, LibRenderer, IO, KPI, Perf, Disclosure, initStorage, updateStorageModeUI } = Platform;
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

const MODULE_KEY = "celiac";

// Symptom flags — dietary and exposure
const FLAG_KEYS = [
  "restaurant","travel","social","bulk","processedfood","oats",
  "crosscontam","labelcheck","stress","illness","newmed"
];

// Exposure sources for accidental gluten
const EXPOSURE_SOURCES = [
  { id:"restaurant",    label:"Restaurant meal" },
  { id:"social",        label:"Social event / party" },
  { id:"travel",        label:"Travel / holiday" },
  { id:"bulk",          label:"Bulk bin / unlabelled" },
  { id:"processedgf",   label:"Processed 'GF' product" },
  { id:"crosscontam",   label:"Cross-contamination at home" },
  { id:"oats",          label:"Oats (even 'GF' oats)" },
  { id:"unknown",       label:"Unknown source" }
];

// Reaction severity after possible exposure
const REACTION_LEVELS = [
  { level:0, label:"None",     desc:"No reaction" },
  { level:1, label:"Mild",     desc:"Bloating/discomfort, resolved same day" },
  { level:2, label:"Moderate", desc:"GI symptoms, fatigue, lasted 1–3 days" },
  { level:3, label:"Severe",   desc:"Significant symptoms >3 days, systemically unwell" }
];

// Celiac Symptom Index proxy (Leffler et al., Am J Gastroenterol 2009)
// 5 domains: GI symptoms, fatigue, pain, emotional wellbeing, social impact
function calcCSI(d) {
  let s = 0;
  s += Util.clamp(d.gi, 0, 3);       // GI symptoms
  s += Util.clamp(d.fatigue, 0, 3);  // fatigue
  s += Util.clamp(d.pain, 0, 3);     // abdominal pain
  s += Util.clamp(d.fog, 0, 3);      // brain fog (celiac-specific)
  s += d.exposureReaction ? Util.clamp(d.exposureReaction, 0, 3) : 0;
  return Math.min(15, s);
}

function interpCSI(score) {
  if (score <= 2)  return { label:"Minimal / remission",    cls:"ok",     color:"var(--ok)" };
  if (score <= 6)  return { label:"Mild symptoms",          cls:"ok",     color:"var(--ok)" };
  if (score <= 10) return { label:"Moderate symptoms",      cls:"warn",   color:"var(--warn)" };
  return                  { label:"Significant symptoms",   cls:"danger", color:"var(--danger)" };
}

function defaultFlags() {
  const f = {};
  [...FLAG_KEYS, ...EXPOSURE_SOURCES.map(e=>e.id)].forEach(k => f[k] = false);
  return f;
}

function defaultDraft() {
  return {
    quality: null, gfdAdherence: null,
    gi: 0, fatigue: 0, pain: 0, fog: 0,
    exposureSuspected: false, exposureReaction: 0, exposureSources: [],
    flags: defaultFlags(), notes: ""
  };
}

// ── LIBRARY ──────────────────────────────────────────────────────
const LIBRARY = (() => {
  const cards = [];
  const add = o => cards.push({ id:(o.cat+"::"+o.title).toLowerCase().replace(/[^a-z0-9]+/g,"-"), ...o });

  // GFD FUNDAMENTALS
  add({ cat:"Gluten-Free Diet", tag:"gfd", title:"The Gluten-Free Diet — Why Strict Matters",
    why:"The gluten-free diet is the only treatment for celiac disease. Unlike dietary interventions in IBS or GERD, in celiac disease dietary adherence is disease-modifying — mucosal healing depends entirely on complete gluten elimination.",
    bullets:[
      "Mechanism: in celiac disease, gluten (specifically gliadin peptides) triggers an immune-mediated destruction of intestinal villi in genetically susceptible individuals (HLA-DQ2/DQ8). Even trace gluten (as little as 10–50mg/day — equivalent to 1/64 of a slice of bread) maintains mucosal inflammation and impairs mucosal healing.",
      "Threshold evidence: Catassi et al. (Am J Clin Nutr 2007) established that <10mg gluten daily does not cause mucosal damage in most celiacs. Most 'gluten-free' labelling standards (<20 ppm) reflect this threshold. However, individual sensitivity varies — some celiacs react to amounts below labelling thresholds.",
      "Mucosal healing timeline: villous atrophy begins resolving within weeks of strict GFD, but complete mucosal healing takes 1–2 years in adults (longer than children). Serology (TTG-IgA) typically normalizes within 6–12 months. Normal serology does not mean complete mucosal healing — repeat biopsy may be needed."
    ],
    action:"Strict means strict. There is no therapeutic benefit from 'mostly gluten-free.' Track GFD adherence daily in this app. Log suspected exposures immediately with source and reaction severity. Consistent logging reveals whether ongoing symptoms reflect exposure or non-responsive celiac disease.",
    more:"Non-responsive celiac disease (NRCD) — ongoing symptoms or abnormal serology despite strict GFD — affects 7–30% of celiacs at 1 year. The most common cause is inadvertent gluten ingestion (>90% of NRCD cases). True refractory celiac disease (RCD) affecting <5% requires specialist management.",
    evidence:"Catassi et al., Am J Clin Nutr 2007; Rubio-Tapia et al., Am J Gastroenterol 2010; Leffler et al., Clin Gastroenterol Hepatol 2007"
  });

  add({ cat:"Gluten-Free Diet", tag:"gfd", title:"Gluten Sources — Complete Reference",
    why:"Identifying every gluten source is the foundational skill of celiac management. Hidden sources are the most common cause of inadvertent exposure.",
    bullets:[
      "Obvious sources: wheat (all varieties — durum, spelt, kamut, einkorn, farro, semolina, bulgur), rye, barley (including malt, malt vinegar, malt extract, beer), triticale. Standard bread, pasta, pastry, cakes, biscuits, most crackers.",
      "Hidden sources requiring label vigilance: soy sauce (almost always contains wheat — use tamari), most commercial stocks and gravies (wheat flour thickener), salad dressings, marinades, condiments (some mustards, ketchups), flavoured crisps/chips, processed meats (sausages, deli meats — often wheat filler), communion wafers (significant source for practicing Catholics — seek rice wafers), medications and supplements (wheat starch excipient in some tablets — check with pharmacist).",
      "Cross-contamination sources: shared toasters, pasta water, shared cooking surfaces and utensils, deep fryers used for breaded items, bulk bins, shared butter/spreads (crumb contamination), restaurant kitchens without celiac protocols."
    ],
    action:"Photograph the ingredients of every new packaged food before purchasing. Share shopping with household members using this reference. A dedicated toaster, separate spreads, and separate colander for GF pasta are minimum home kitchen requirements.",
    evidence:"See table in Celiac Disease Foundation dietary guide; Catassi et al., Am J Clin Nutr 2007; ESPGHAN Celiac Guidelines 2020"
  });

  add({ cat:"Gluten-Free Diet", tag:"gfd", title:"Reading Labels — Celiac Standard",
    why:"Label reading for celiac disease is more stringent than general gluten avoidance. Understanding labelling law and its limitations is essential.",
    bullets:[
      "EU/UK law: products labelled 'gluten-free' must contain <20 ppm gluten. 'Very low gluten' = 20–100 ppm (not safe for celiac). Unlabelled products cannot be assumed safe.",
      "Safe label phrases: 'Gluten-free' (certified to <20 ppm), 'Free from gluten.' Check for Crossed Grain Symbol (certified GF symbol used by Celiac UK and international bodies).",
      "Unsafe assumptions: 'wheat-free' does not mean gluten-free (may contain rye or barley). 'Natural flavours' may contain barley malt. 'Modified starch' is usually corn/potato and safe, but verify. 'Dextrose' is safe. 'Maltodextrin' in UK/EU is usually corn-derived and safe — but verify country of origin for US products.",
      "Oats: even certified GF oats contain avenin (oat protein) which triggers immune response in approximately 5% of celiacs. Introduce oats cautiously after mucosal healing is confirmed. Many guidelines recommend excluding oats for the first year of GFD."
    ],
    action:"Download the Celiac UK Food and Drink Directory app — real-time database of certified GF products in the UK. Always re-read labels when products are reformulated. Call manufacturers directly for ambiguous ingredients — they are legally required to disclose allergens.",
    evidence:"EU Food Information Regulation 1169/2011; Catassi et al., Am J Clin Nutr 2007; Lundin et al., N Engl J Med 2012 (oats in celiac)"
  });

  add({ cat:"Gluten-Free Diet", tag:"gfd", title:"Eating Out Safely — Restaurant Protocol",
    why:"Restaurant eating is the most common source of inadvertent gluten exposure in adherent celiacs. A consistent communication protocol significantly reduces risk.",
    bullets:[
      "Before going: call ahead — not to the front desk but ask to speak to the chef. Ask specifically: 'Is there a separate preparation area, dedicated cookware, and separate fryer for gluten-free dishes?' A restaurant that cannot answer this question confidently is not safe.",
      "At the table: tell the server you have celiac disease, not 'gluten intolerance' or 'preference.' The word 'allergy' while technically incorrect often triggers better kitchen protocols. Ask them to confirm with the chef directly.",
      "Highest-risk foods in restaurants: fried items (shared fryer), pasta dishes (shared pasta water), risotto (cross-contaminated from flour dusting), salads with croutons (removing croutons does not make the salad safe), soups (often thickened with flour), sauces and gravies."
    ],
    action:"Log every restaurant visit using the Restaurant flag. If you develop symptoms 12–48 hours after a restaurant meal, log as a suspected exposure. Your exposure log is the most useful tool for identifying safe and unsafe restaurants for your personal use.",
    evidence:"Celiac Disease Foundation restaurant guide; Celiac UK eating out resources; Thompson et al., J Am Diet Assoc 2010"
  });

  // SEROLOGY & MONITORING
  add({ cat:"Serology & Monitoring", tag:"serology", title:"TTG-IgA — Your Key Monitoring Test",
    why:"Tissue transglutaminase IgA (TTG-IgA) is the primary serological marker for celiac disease and the main tool for monitoring GFD response.",
    bullets:[
      "What it measures: IgA antibodies against tissue transglutaminase 2 — the autoantigen in celiac disease. Elevated in active celiac disease; normalizes with strict GFD.",
      "Monitoring schedule: TTG-IgA at diagnosis, then at 6 months, then annually. Normalisation (to within lab reference range) expected by 6–12 months on strict GFD. Persistently elevated or rising TTG-IgA after 12 months of GFD indicates ongoing gluten exposure or non-responsive disease.",
      "Limitations: IgA deficiency (occurs in 2–3% of celiacs) causes false-negative TTG-IgA — total IgA must be checked at diagnosis. TTG-IgA normalisation does NOT confirm mucosal healing — histologic recovery lags behind serology."
    ],
    action:"Log every TTG-IgA result in the Serology section with the collection date. A rising or persistently elevated result after 12 months of GFD is the most important signal in celiac management — it requires dietary review with a specialist dietitian before attributing to non-responsive disease.",
    evidence:"Rubio-Tapia et al., Am J Gastroenterol 2013; Husby et al., J Pediatr Gastroenterol Nutr 2020 (ESPGHAN); Leffler et al., Am J Gastroenterol 2009"
  });

  add({ cat:"Serology & Monitoring", tag:"serology", title:"Follow-Up Biopsy — When and Why",
    why:"Duodenal biopsy at follow-up confirms mucosal healing — the ultimate treatment goal — which serology alone cannot verify.",
    bullets:[
      "When repeat biopsy is indicated: persistent or worsening symptoms despite strict GFD, persistently elevated TTG-IgA at 12 months, to confirm healing before significant life decisions (e.g., planning pregnancy in women with previously severe disease), suspected refractory celiac disease.",
      "Marsh Classification: the system for grading celiac histology. Marsh 3 at diagnosis (villous atrophy) should improve to Marsh 0 or 1 on GFD. Persistent Marsh 2–3 on GFD after 1–2 years = non-responsive or refractory celiac disease.",
      "Surveillance for intestinal lymphoma: refractory celiac disease type 2 (RCD2) carries significant risk of enteropathy-associated T-cell lymphoma (EATL). Any adult celiac with worsening symptoms and weight loss on GFD requires urgent evaluation."
    ],
    action:"Record your biopsy results and Marsh grade in Notes. If you have not had a follow-up biopsy at 12–24 months and have persistent symptoms, raise this with your gastroenterologist.",
    evidence:"Rubio-Tapia et al., Am J Gastroenterol 2013; Marsh, Gut 1992; Al-Toma et al., United European Gastroenterol J 2019 (RCDII and EATL)"
  });

  // NUTRITIONAL DEFICIENCIES
  add({ cat:"Nutritional Deficiencies", tag:"nutrition", title:"Key Deficiencies in Celiac Disease",
    why:"Villous atrophy impairs absorption across multiple micronutrients. Deficiency correction is a required component of celiac management alongside GFD.",
    bullets:[
      "Iron: most common deficiency. Absorbed in the duodenum and proximal jejunum — the primary site of celiac damage. Iron deficiency anemia is a frequent presenting feature and may be the only symptom. Monitor ferritin (not just hemoglobin) — ferritin reflects stores. Haemoglobin may be normal with depleted stores.",
      "Vitamin D and calcium: malabsorption of fat-soluble vitamins is universal in untreated celiac disease. Vitamin D deficiency drives secondary hyperparathyroidism and accelerated bone loss. Current guidance recommends a DEXA scan (bone density) at the time of celiac confirmation (bone density) at diagnosis or within 1 year.",
      "Folate and B12: folate absorbed in the proximal small bowel — frequently deficient. B12 absorbed in the terminal ileum — less commonly deficient in celiac unless extensive disease. Both essential for neural tube defect prevention in pregnancy.",
      "Zinc, magnesium, copper: less commonly measured but clinically relevant. Zinc deficiency causes dermatitis, impaired wound healing, immune dysfunction. Magnesium deficiency causes fatigue, muscle cramps, arrhythmia."
    ],
    action:"At diagnosis: check full blood count, ferritin, vitamin D, B12, folate, zinc, copper, calcium, PTH, and DEXA scan. Supplement deficiencies appropriately. Recheck at 6 and 12 months. Most deficiencies resolve with strict GFD over 1–2 years — supplementation bridges the gap.",
    evidence:"Saturni et al., Nutrients 2010; Rubio-Tapia et al., Am J Gastroenterol 2013; Bergamaschi et al., Eur J Clin Nutr 2008"
  });

  add({ cat:"Nutritional Deficiencies", tag:"nutrition", title:"Bone Health in Celiac Disease",
    why:"Celiac disease causes measurably reduced bone mineral density, and fracture risk is elevated. This is preventable with strict GFD and appropriate supplementation.",
    bullets:[
      "Mechanism: vitamin D malabsorption → reduced calcium absorption → secondary hyperparathyroidism → increased bone resorption. Active celiac disease accelerates bone loss significantly.",
      "GFD effect on bone: strict GFD improves bone mineral density, but recovery is incomplete in adults who have had prolonged untreated disease. BMD typically improves by 5% at 1 year on GFD.",
      "DEXA scan: recommended at diagnosis for all adults. Repeat at 2–5 years depending on initial findings. Z-score <-2.0 requires specialist osteoporosis review. Risk factors for worse bone outcomes: late diagnosis, male sex, HLA-DQ2 homozygosity, non-responsive disease."
    ],
    action:"Ensure DEXA scan is arranged within 12 months of diagnosis. Supplement vitamin D (800–2000 IU daily) and calcium (1000–1200mg/day from food + supplement). Weight-bearing exercise. Log supplement adherence in notes.",
    evidence:"Larussa et al., Nutrients 2019; AGA Celiac Disease Guidelines 2023; Scott et al., Gut 2000"
  });

  add({ cat:"Nutritional Deficiencies", tag:"nutrition", title:"Nutritional Pitfalls of the GFD",
    why:"The gluten-free diet, if poorly implemented, creates new nutritional risks. Most commercial GF products are nutritionally inferior to their wheat-based equivalents.",
    bullets:[
      "Fibre deficiency: GF bread and pasta are typically made from refined rice, corn, or potato starch — very low in fiber. Most celiacs on GFD do not meet recommended fiber intake. Compensate with naturally GF whole foods: quinoa, brown rice, buckwheat, legumes, vegetables.",
      "Excess refined starch and sugar: commercial GF products often use large amounts of refined starch and added sugar to replicate texture. The GFD increases glycaemic load if based on processed GF products — relevant for metabolic health.",
      "B vitamins: wheat flour is mandatorily fortified with thiamine, riboflavin, niacin, and folic acid in many countries. GF flours are often unfortified. Regularly check folate levels."
    ],
    action:"Build the GFD around whole naturally GF foods (rice, quinoa, buckwheat, potatoes, legumes, meat, fish, vegetables, fruit) as the foundation. Use commercial GF products as occasional convenience, not dietary staples. This approach avoids both the fiber deficit and excessive refined starch.",
    evidence:"Wild et al., J Hum Nutr Diet 2010; Vici et al., Nutrients 2016; Thompson, J Am Diet Assoc 2000"
  });

  // ASSOCIATED CONDITIONS
  add({ cat:"Associated Conditions", tag:"associated", title:"Conditions Associated with Celiac Disease",
    why:"Celiac disease has a cluster of associated autoimmune and other conditions that require active surveillance.",
    bullets:[
      "Type 1 diabetes: 5–10% of T1DM patients have celiac disease. Shared HLA-DQ2/DQ8 genetic susceptibility. Celiac diagnosis in T1DM requires adjustment of carbohydrate counting and insulin dosing with GFD initiation.",
      "Autoimmune thyroid disease (Hashimoto's thyroiditis, Graves'): 3–5× increased prevalence in celiac disease. Annual TSH monitoring is appropriate. Strict GFD may reduce thyroid antibody titres.",
      "Dermatitis herpetiformis (DH): the skin manifestation of celiac disease — intensely pruritic vesicular rash on elbows, knees, buttocks. Always associated with celiac enteropathy even when GI symptoms are absent. Treated with GFD + dapsone (short-term). DH is celiac disease of the skin.",
      "Selective IgA deficiency: 2–3× more prevalent in celiac disease. Causes false-negative TTG-IgA — always check total IgA at diagnosis.",
      "Primary biliary cholangitis, other autoimmune liver disease: increased prevalence — monitor LFTs."
    ],
    action:"If you have T1DM or thyroid disease: ensure celiac screening has been performed with TTG-IgA + total IgA. If you develop an itchy vesicular rash in classic distribution: request dermatology referral for skin biopsy (immunofluorescence shows IgA deposits).",
    evidence:"Ventura et al., Gastroenterology 1999; Sategna-Guidetti et al., J Endocrinol Invest 2001; Zone, Dermatol Clin 2011"
  });

  // RED FLAGS
  add({ cat:"Red Flags", tag:"safety", title:"Red Flags in Celiac Disease",
    why:"Most celiac disease is managed with GFD alone. These features indicate serious complications requiring urgent evaluation.",
    bullets:[
      "Refractory celiac disease (RCD): ongoing symptoms and abnormal histology despite strict GFD for >12 months. RCD type 2 has significant lymphoma risk. Any celiac with worsening symptoms on GFD rather than improvement requires urgent reassessment.",
      "Weight loss on GFD: celiac patients typically gain weight on strict GFD as absorption improves. Weight loss on an established GFD is a red flag for lymphoma (EATL), ulcerative jejunitis, or RCD type 2.",
      "Abdominal mass, lymphadenopathy: rare but may indicate lymphoma — urgent investigation required.",
      "Neurological symptoms: gluten ataxia, peripheral neuropathy. 'Gluten neuropathy' is an established diagnosis — progressive neurological symptoms in celiac disease warrant specialist neurology referral.",
      "Dermatitis herpetiformis with systemic symptoms: may indicate lymphoma or other complications."
    ],
    action:"Weight loss on an established GFD = contact your gastroenterologist urgently. This pattern should never be attributed to 'dietary change' without investigation.",
    evidence:"Al-Toma et al., United European Gastroenterol J 2019; Hadjivassiliou et al., Lancet Neurol 2010; Rubio-Tapia et al., Am J Gastroenterol 2013"
  });

  return { cards };
})();

const LIB_CATS = ["all", ...new Set(LIBRARY.cards.map(c => c.cat))];

// ── STATE ────────────────────────────────────────────────────────
const State = {
  store: null, premium: false,
  draft: defaultDraft(), lastEntry: null,
  libCat: "all", libQuery: ""
};

// ── HTML ─────────────────────────────────────────────────────────
function renderHTML() {
  document.getElementById("module-root").innerHTML = `
<div class="p-app">
  <header class="p-header">
    <div class="p-brand">
      <div class="p-logo-dot" aria-hidden="true"></div>
      <div>
        <h1 class="p-brand-name">Celiac OS</h1>
        <div class="p-brand-sub">Symptom tracker</div>
      </div>
    </div>
    <div class="p-header-right">
      <div class="p-pill">🔥 <b id="kpiStreak">0</b>&nbsp;·&nbsp;7d <b id="kpi7d">0</b>&nbsp;·&nbsp;<b id="kpiTotal">0</b> total</div>
    </div>
  </header>

  <nav class="p-nav">
    <div class="p-tabs" role="tablist">
      <button class="p-tab" role="tab" id="tab-log"       aria-selected="true"  data-tab="log"       type="button">Log</button>
      <button class="p-tab" role="tab" id="tab-serology"  aria-selected="false" data-tab="serology"  type="button">Serology</button>
      <button class="p-tab" role="tab" id="tab-history"   aria-selected="false" data-tab="history"   type="button">History</button>
      <button class="p-tab" role="tab" id="tab-library"   aria-selected="false" data-tab="library"   type="button">Library</button>
      <button class="p-tab" role="tab" id="tab-insights"  aria-selected="false" data-tab="insights"  type="button">Insights</button>
    </div>
  </nav>

  <!-- LOG -->
  <section id="view-log">
    <div class="p-grid two">
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>How are you today?</h2><p>Takes about a minute</p></div>
          <div class="p-kpis"><div class="p-kpi">Date <b id="todayLabel"></b></div></div>
        </div>
        <div class="p-card-b">

          <!-- Step 1: Overall day -->
          <div id="stepQuality">
            <div class="p-labelrow"><div class="p-lbl">How was today overall?</div><div class="p-hint">required</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-quality="great" aria-pressed="false">Great</button>
              <button class="p-segBtn" type="button" data-quality="okay"  aria-pressed="false">Okay</button>
              <button class="p-segBtn" type="button" data-quality="rough" aria-pressed="false">Rough</button>
            </div>
          </div>

          <!-- Step 2: GFD adherence -->
          <div id="stepGFD" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Did you stick to gluten-free today?</div><div class="p-hint">required</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-gfd="strict"   aria-pressed="false">Strict GF</button>
              <button class="p-segBtn" type="button" data-gfd="possible" aria-pressed="false">Possible exposure</button>
              <button class="p-segBtn" type="button" data-gfd="known"    aria-pressed="false">Known exposure</button>
            </div>
            <div id="gfdHint" class="p-callout hidden" style="margin-top:8px;font-size:12px;"></div>
          </div>

          <!-- Step 3: Exposure detail (conditional) -->
          <div id="stepExposure" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Where might gluten have come in?</div><div class="p-hint">mark all that apply</div></div>
            <div class="p-chips">
              ${EXPOSURE_SOURCES.map(s => `
              <button class="p-chip warn" type="button" data-source="${s.id}" aria-pressed="false">${Util.esc(s.label)}</button>`).join("")}
            </div>
            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Reaction severity</div><div class="p-hint" id="rxnLabel">none yet</div></div>
            <div class="p-chips" data-symptom="exposureReaction">
              ${REACTION_LEVELS.map(r => `
              <button class="p-chip${r.level>0?' warn':''}" type="button" data-level="${r.level}" aria-pressed="${r.level===0?'true':'false'}">${Util.esc(r.label)}</button>`).join("")}
            </div>
          </div>

          <!-- Step 4: Symptoms -->
          <div id="stepSymptoms" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Step ${State.draft.exposureSuspected ? "4" : "3"} — Symptoms</div><div class="p-hint">optional</div></div>

            <div class="p-labelrow" style="margin-top:4px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">GI symptoms (bloating / diarrhea / cramps)</div><div class="p-hint" id="giLabel">none</div></div>
            <div class="p-chips" data-symptom="gi">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Fatigue</div><div class="p-hint" id="fatLabel">none</div></div>
            <div class="p-chips" data-symptom="fatigue">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Abdominal pain</div><div class="p-hint" id="painLabel">none</div></div>
            <div class="p-chips" data-symptom="pain">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Brain fog / concentration</div><div class="p-hint" id="fogLabel">none</div></div>
            <div class="p-chips" data-symptom="fog">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Context flags</div></div>
            <div class="p-chips">
              <button class="p-chip" type="button" data-flag="restaurant"    aria-pressed="false">Restaurant</button>
              <button class="p-chip" type="button" data-flag="travel"        aria-pressed="false">Travel</button>
              <button class="p-chip" type="button" data-flag="social"        aria-pressed="false">Social event</button>
              <button class="p-chip" type="button" data-flag="oats"          aria-pressed="false">Ate oats</button>
              <button class="p-chip" type="button" data-flag="labelcheck"    aria-pressed="false">Label checked</button>
              <button class="p-chip" type="button" data-flag="stress"        aria-pressed="false">Stress↑</button>
              <button class="p-chip" type="button" data-flag="illness"       aria-pressed="false">Illness</button>
              <button class="p-chip" type="button" data-flag="newmed"        aria-pressed="false">New medication</button>
            </div>

            <div class="p-section">
              <div class="p-labelrow"><div class="p-lbl">Notes</div><div class="p-hint"><span id="noteCount">0</span>/600</div></div>
              <textarea id="notes" class="p-note" maxlength="600" placeholder="Specific foods eaten, restaurant name, label details, meal notes (optional)"></textarea>
            </div>
          </div>

          <!-- Actions -->
          <div id="stepActions" class="p-section hidden">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnSave" disabled>Done</button>
              <button class="p-btn" type="button" id="btnRepeat" disabled>Repeat last</button>
              <button class="p-btn ghost" type="button" id="btnReset">Reset</button>
            </div>
          </div>
        </div>
      </div>

      <!-- RIGHT -->
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>Today's Guidance</h2><p>Personalized to what you logged</p></div>
          
        </div>
        <div class="p-card-b">
          <div id="guidance" class="p-callout">Complete the log steps to see guidance and symptom score.</div>
          <div id="inlineCard" class="p-section" style="display:none;"></div>

          <div id="scorePanel" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Celiac Symptom Index</div><div class="p-hint">0–15 scale</div></div>
            <div class="p-scoreWrap">
              <div class="p-scoreBig" id="scoreBig">—</div>
              <div class="p-scoreSubLabel">CSI Proxy</div>
            </div>
            <div id="scoreInterp" class="p-callout" style="margin-top:8px;"></div>
          </div>

          <!-- GFD adherence summary -->
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">GFD adherence</div><div class="p-hint">last 14 days</div></div>
            <div id="gfdAdherence" class="p-kpis"></div>
          </div>

          <!-- Label literacy quick ref -->
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Safe label phrases</div></div>
            <div style="font-size:12px;color:var(--muted);line-height:1.7;">
              <div>✓ <b style="color:var(--ink);">Gluten-free</b> (certified, &lt;20 ppm)</div>
              <div>✓ <b style="color:var(--ink);">Crossed Grain Symbol</b> (Celiac UK certified)</div>
              <div style="margin-top:6px;">✗ <span style="color:var(--warn);">"Wheat-free"</span> — may contain rye/barley</div>
              <div>✗ <span style="color:var(--warn);">"Very low gluten"</span> — 20–100 ppm, not safe</div>
              <div>✗ <span style="color:var(--warn);">"May contain gluten"</span> — avoid in celiac</div>
              <div>✗ <span style="color:var(--danger);">"Natural flavours"</span> — verify; may contain barley malt</div>
            </div>
          </div>

          <div class="p-section">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnReport">Clinician report</button>
              <button class="p-btn" type="button" id="btnExportCsv">Export CSV</button>
              <button class="p-btn" type="button" id="btnExportJson">Export JSON</button>
              <button class="p-btn" type="button" id="btnImport">Import</button>
              <input id="importFile" type="file" accept="application/json" class="sr">
            </div>
          </div>
          <div class="p-section">
            <div class="p-premRow" id="premiumCta" style="cursor:pointer;">
              <div class="p-premLabel" id="premStatusLabel">Unlock Premium — trend analytics · trigger correlation · next steps</div>
              <div style="font-family:var(--font-mono);font-size:10px;letter-spacing:.08em;color:#f5c842;">UPGRADE ✦</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- SEROLOGY -->
  <section id="view-serology" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Serology Tracking</h2><p>TTG-IgA · trend monitoring · mucosal healing proxy</p></div>
        <div class="p-kpis"><div class="p-kpi">Results <b id="kpiSero">0</b></div></div>
      </div>
      <div class="p-card-b">
        <div class="p-callout" style="margin-bottom:14px;">
          <b>Clinical basis:</b> TTG-IgA normalizes within 6–12 months on strict GFD. Persistently elevated results at 12 months = ongoing exposure or non-responsive celiac. Normal serology does not confirm mucosal healing — biopsy may still be needed. Always tested while on a gluten-containing diet for diagnosis, but monitored on GFD for treatment response.
        </div>
        <div class="p-calpRow">
          <div class="p-calpField">
            <label>TTG-IgA result</label>
            <input type="number" id="seroVal" placeholder="e.g. 8 (U/mL)" min="0" max="1000" step="0.1">
          </div>
          <div class="p-calpField">
            <label>Lab upper limit of normal</label>
            <input type="number" id="seroULN" placeholder="e.g. 10" min="0" max="200" step="0.1">
          </div>
          <div class="p-calpField">
            <label>Collection date</label>
            <input type="date" id="seroDate">
          </div>
        </div>
        <div id="seroPreview" class="p-callout hidden" style="margin-top:8px;"></div>
        <div class="p-rowBtns"><button class="p-btn primary" type="button" id="btnSaveSero">Save result</button></div>

        <div class="p-section">
          <div class="p-labelrow"><div class="p-lbl">TTG-IgA trend</div><div class="p-hint">normalisation = good GFD response</div></div>
          <div class="p-chartWrap" style="margin-bottom:12px;">
            <canvas id="chartSero" height="200"></canvas>
            <div class="p-chartMeta">TTG-IgA over time (ratio to ULN — 1.0 = upper limit of normal)</div>
          </div>
          <div class="p-list" id="seroList"></div>
        </div>
      </div>
    </div>
  </section>

  <!-- HISTORY -->
  <section id="view-history" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>History</h2><p>Most recent first</p></div>
        <div class="p-rowBtns" style="margin:0;">
          <button class="p-btn" type="button" id="btnExportCsv2">Export CSV</button>
          <button class="p-btn" type="button" id="btnExportJson2">Export JSON</button>
        </div>
      </div>
      <div class="p-card-b"><div class="p-list" id="histList"></div></div>
    </div>
  </section>

  <!-- LIBRARY -->
  <section id="view-library" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Clinical Library</h2><p>GFD · label reading · serology · nutrition · associated conditions · red flags</p></div>
        <div style="display:flex;gap:10px;align-items:center;">
          <div class="p-kpis"><div class="p-kpi">Cards <b id="kpiCards">0</b></div></div>
          <input id="libSearch" type="search" class="p-search" placeholder="Search GFD, TTG, bone health…">
        </div>
      </div>
      <div class="p-card-b">
        <div class="p-libCats" id="libCats"></div>
        <div class="p-libGrid" id="libGrid"></div>
      </div>
    </div>
  </section>

  <!-- INSIGHTS -->
  <section id="view-insights" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Insights</h2><p>Free: adherence summary · Premium: trends + exposure patterns + symptom correlation</p></div>
        <button class="p-btn" type="button" id="btnRefresh" style="margin:0;">Refresh</button>
      </div>
      <div class="p-card-b">
        <div id="insightsBody" class="p-callout">Log at least 5 entries to unlock insights.</div>
        <div class="p-section">
          <div class="p-chartWrap"><canvas id="chartAdhere" height="200"></canvas><div class="p-chartMeta">GFD adherence (last 28 days — green=strict, amber=possible, red=known)</div></div>
        </div>
        <div id="premiumPanel" class="p-section hidden">
          <div class="p-grid two">
            <div class="p-chartWrap"><canvas id="chartCSI" height="200"></canvas><div class="p-chartMeta">Symptom index trend (last 30 entries)</div></div>
            <div class="p-chartWrap"><canvas id="chartFatigue" height="200"></canvas><div class="p-chartMeta">Fatigue trend (last 30 entries)</div></div>
          </div>
          <div class="p-section p-grid two">
            <div class="p-callout" id="exposureBox"></div>
            <div class="p-callout" id="adherenceBox"></div>
          </div>
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Ranked next steps</div></div>
            <div class="p-list" id="nextStepsList"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>`;
}

// ── LOGIC ────────────────────────────────────────────────────────
function updateProgress() {
  // INVARIANT: red flags always visible — never gated on premium. MDR compliance.
  // Note: Celiac OS has no acute alarm alert — safety coverage is via library red flag cards and clinician report.
  const d = State.draft;
  const hasQ   = !!d.quality;
  const hasGFD = d.gfdAdherence !== null;
  const hasExp = hasGFD && (d.gfdAdherence === "possible" || d.gfdAdherence === "known");

  $("#stepGFD")?.classList.toggle("hidden", !hasQ);
  $("#stepExposure")?.classList.toggle("hidden", !(hasGFD && hasExp));
  $("#stepSymptoms")?.classList.toggle("hidden", !hasGFD);
  $("#stepActions")?.classList.toggle("hidden", !hasGFD);

  const canSave = hasQ && hasGFD;
  const btnSave = $("#btnSave"); if (btnSave) btnSave.disabled = !canSave;
  const btnRepeat = $("#btnRepeat"); if (btnRepeat) btnRepeat.disabled = !State.lastEntry;

  updateGuidance(d);
}


function renderInlineCard(cardTitle) {
  const container = document.getElementById("inlineCard");
  if (!container) return;

  const card = LIBRARY.cards.find(c => c.title === cardTitle);
  if (!card) { container.style.display = "none"; return; }

  container.style.display = "block";
  const safeTitle = card.title.split("—")[0].trim().replace(/'/g, "\'");

  const bulletsHTML = (card.bullets || []).map(b =>
    `<li style="font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:6px;">${b}</li>`
  ).join("");

  const moreHTML = card.more
    ? `<div style="font-size:12px;color:var(--muted2);line-height:1.5;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);">${card.more}</div>`
    : "";

  const evidenceHTML = card.evidence
    ? `<div style="font-size:11px;color:var(--muted2);font-family:var(--font-mono);margin-top:8px;line-height:1.5;">${card.evidence}</div>`
    : "";

  container.innerHTML = `
    <div style="border-left:3px solid var(--accent);padding-left:14px;margin-top:8px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px;">Your doctor says</div>
      <div style="font-size:15px;font-weight:600;color:var(--fg);margin-bottom:8px;">${card.title}</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;margin-bottom:10px;">${card.why}</div>
      ${bulletsHTML ? `<ul style="margin:0 0 10px 0;padding-left:16px;">${bulletsHTML}</ul>` : ""}
      ${card.action ? `
        <div style="padding:12px 14px;background:var(--surface2);border-radius:10px;margin-bottom:10px;">
          <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">What to do</div>
          <div style="font-size:13px;color:var(--fg);line-height:1.6;">${card.action}</div>
        </div>` : ""}
      ${moreHTML}
      ${evidenceHTML}
      <button type="button"
        style="font-size:12px;color:var(--accent);background:none;border:none;padding:4px 0 0 0;cursor:pointer;text-decoration:underline;display:block;margin-top:6px;"
        onclick="(function(){document.getElementById('tab-library')?.click();var s=document.getElementById('libSearch');if(s){s.value='${safeTitle}';s.dispatchEvent(new Event('input'));}})()">
        Browse all library cards →
      </button>
    </div>
  `;
}


function pickInlineCard(d) {
  if (d.gfdAdherence !== "strict") return "Celiac Disease vs. Gluten Sensitivity — They Are Not the Same Thing";
  if (d.fatigue >= 2) return "Celiac Disease vs. Gluten Sensitivity — They Are Not the Same Thing";
  if (d.gi >= 2) return "Celiac Disease vs. Gluten Sensitivity — They Are Not the Same Thing";
  return "Celiac Disease vs. Gluten Sensitivity — They Are Not the Same Thing";
}
function updateGuidance(d) {
  const g = $("#guidance"), sp = $("#scorePanel");
  if (!g) return;

  if (!d.quality || d.gfdAdherence === null) {
    g.innerHTML = "Complete the log steps to see guidance and symptom score.";
    sp?.classList.add("hidden"); return;
  }

  // Premium gate — guidance is gated after 14-day trial
  if (!PremiumGate.isPremium()) {
    PremiumGate.showGuidanceGate(g, MODULE_KEY, () => updateGuidance(d));
    sp?.classList.add("hidden");
    return;
  }


  const score = calcCSI(d);
  const interp = interpCSI(score);

  let assessment = "";
  if (d.gfdAdherence === "known") assessment = `Your log records a known gluten exposure today. Symptoms from gluten ingestion in celiac disease typically appear 12–72 hours after exposure — not always immediately. The source logged today will help identify where future lapses occur.`;
  else if (d.gfdAdherence === "possible") assessment = `Your log records a possible gluten exposure today. Even trace amounts — cross-contamination levels below what you can taste — are sufficient to trigger intestinal immune activation in celiac disease. Trace exposure is clinically relevant, not just obvious gluten sources.`;
  else if (d.gi >= 2 && d.gfdAdherence === "strict") assessment = `Your log shows significant GI symptoms on a day of strict gluten-free diet. This pattern — symptoms without obvious gluten — may reflect inadvertent trace exposure, mucosal recovery still in progress (which can take 1–2 years), or a co-existing condition. IBS occurs in 3–4 times as many celiac patients as the general population.`;
  else if (d.fatigue >= 2) assessment = `Significant fatigue logged today. In celiac disease, fatigue most commonly reflects nutritional deficiency — iron, B12, vitamin D, and folate — rather than active inflammation. These require blood testing to identify and treat.`;
  else if (d.quality === "great") assessment = `Good day on strict GFD. Consistent symptom-free entries confirm your dietary adherence is working. This is what successful celiac management looks like.`;
  else assessment = `Your log shows a mixed day on strict GFD. Occasional symptoms during the first 1–2 years of GFD are common while mucosal healing progresses.`;

  let plan = "";
  if (d.gfdAdherence !== "strict") {
    plan = `Review the exposure source and identify how to prevent recurrence. The most common hidden gluten sources are: soy sauce, shared fryers, shared toasters, bulk bins, flavored chips, processed meats, and some medications. Restaurant meals require explicit communication — say "celiac disease" not "gluten-free preference." The threshold for intestinal immune activation in celiac disease is approximately 10mg of gluten per day — that is the size of a crumb. Trace amounts matter.`;
  } else if (d.fatigue >= 2) {
    plan = `Request a nutritional panel from your doctor — ferritin specifically (not just hemoglobin), B12, folate, vitamin D, and zinc. Deficiency correction is a required component of celiac management alongside GFD. If these haven't been checked in the past year, they should be. Supplement specific identified deficiencies — not generic multivitamins, which often don't correct the specific deficits celiac disease causes.`;
  } else if (d.gi >= 2 && d.gfdAdherence === "strict") {
    plan = `With persistent symptoms on strict GFD, the most useful next step is TTG-IgA retesting — this should normalize within 6–12 months of strict GFD and tracks mucosal recovery directly. If TTG-IgA remains elevated at 12 months, discuss repeat biopsy with your gastroenterologist. If TTG-IgA is normal but symptoms persist, ask about evaluation for coexisting IBS or small intestinal bacterial overgrowth.`;
  } else {
    plan = `Continue strict GFD and log any suspected exposures immediately. Annual TTG-IgA checks are standard follow-up. Bone density scanning at diagnosis and again at 2–3 years is recommended — malabsorption accelerates bone loss in celiac disease and this is frequently missed.`;
  }

  g.innerHTML = `
    <div style="margin-bottom:12px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Assessment</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${assessment}</div>
    </div>
    <div>
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Plan</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${plan}</div>
    </div>
    <div style="font-size:11px;color:var(--muted2);margin-top:10px;border-top:1px solid var(--border);padding-top:8px;">This is patient education based on your logged data — not a medical diagnosis. Discuss any changes to your treatment with your gastroenterologist.</div>
  `;

  if (sp) {
    sp.classList.remove("hidden");
    const big = $("#scoreBig");
    if (big) { big.textContent = score; big.style.color = interp.color; }
    const si = $("#scoreInterp");
    if (si) {
      si.className = "p-callout " + (interp.cls||"");
      const tips = {
        ok:     "Good symptom control. Continue strict GFD.",
        warn:   "Moderate symptoms. Review recent exposures and GFD adherence log.",
        danger: "Significant symptoms. If on strict GFD, discuss with gastroenterologist — may need serology recheck."
      };
      si.innerHTML = `<b>${interp.label}:</b> ${tips[interp.cls]||""}`;
    }
  }
}

function setGFDUI(val) {
  State.draft.gfdAdherence = val;
  State.draft.exposureSuspected = (val === "possible" || val === "known");
  $$("[data-gfd]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.gfd === val)));
  const hint = $("#gfdHint");
  if (hint) {
    const msgs = {
      strict:   null,
      possible: "Possible exposure: log the likely source below. Celiac reaction can be delayed 12–72 hours — note any symptoms over the next few days.",
      known:    "Known exposure: document source and reaction severity carefully. This entry becomes part of your exposure record for dietary review."
    };
    if (msgs[val]) { hint.textContent = msgs[val]; hint.className = "p-callout warn"; hint.classList.remove("hidden"); }
    else hint.classList.add("hidden");
  }
  updateProgress();
  setTimeout(() => {
    if (val !== "strict") Util.scroll($("#stepExposure"));
    else Util.scroll($("#stepSymptoms"));
  }, 80);
}

function resetDraft() {
  State.draft = defaultDraft();
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$("[data-gfd]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$("[data-source]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$("[data-symptom] .p-chip").forEach(c => c.setAttribute("aria-pressed", String(c.dataset.level === "0")));
  $$(".p-chip[data-flag]").forEach(c => c.setAttribute("aria-pressed","false"));
  const notes = $("#notes"); if (notes) notes.value = "";
  const nc = $("#noteCount"); if (nc) nc.textContent = "0";
  const hi = $("#gfdHint"); if (hi) hi.classList.add("hidden");
  ["giLabel","fatLabel","painLabel","fogLabel","rxnLabel"].forEach((id,i) => {
    const el = $(`#${id}`); if (el) el.textContent = ["none","none","none","none","none yet"][i];
  });
  updateProgress();
}

async function save() {
  try {
    if ($("#btnSave")) $("#btnSave").disabled = true;
    const d = State.draft;
    const entry = {
      ts: Util.nowISO(), dateKey: Util.dateKeyLocal(),
      quality: d.quality, gfdAdherence: d.gfdAdherence,
      exposureSuspected: d.exposureSuspected,
      exposureReaction: d.exposureReaction||0,
      exposureSources: [...(d.exposureSources||[])],
      gi: Util.clamp(d.gi,0,3), fatigue: Util.clamp(d.fatigue,0,3),
      pain: Util.clamp(d.pain,0,3), fog: Util.clamp(d.fog,0,3),
      csi: calcCSI(d),
      flags: {...d.flags}, notes: (d.notes||"").slice(0,600), deleted: 0
    };
    const last = State.lastEntry;
    if (last) {
      const dt = Math.abs(+new Date(entry.ts) - +new Date(last.ts));
      if (dt < 90000 && entry.quality === last.quality && entry.gfdAdherence === last.gfdAdherence) {
        Util.toast("Duplicate entry blocked"); return;
      }
    }
    const saved = await Perf.time("entry-save", async () => { await State.store.addEntry(entry); });
    State.lastEntry = saved;
    Util.toast("Entry saved");
  // First-time upgrade nudge at 14 entries
  const allEntries = await State.store.getEntriesAll();
  if (allEntries.length === 14 && !PremiumGate.isPremium()) {
    setTimeout(() => PremiumGate.showPaywall(MODULE_KEY, () => {
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      Util.toast("Premium unlocked ✦");
    }), 1200);
  }
    resetDraft();
    await refreshKPIs();
    await renderGFDAdherence();
  } catch(err) { console.error(err); Util.toast("Save failed"); }
  finally { updateProgress(); }
}

async function repeatLast() {
  const last = State.lastEntry || await State.store.getLastEntry();
  if (!last) return;
  State.lastEntry = last;
  const d = State.draft;
  d.quality = last.quality; setGFDUI(last.gfdAdherence||"strict");
  d.gi = last.gi||0; d.fatigue = last.fatigue||0; d.pain = last.pain||0; d.fog = last.fog||0;
  d.flags = {...defaultFlags(),...(last.flags||{})};
  d.notes = last.notes||"";
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.quality === d.quality)));
  const syncSym = (sym, val) => {
    const w = $(`.p-chips[data-symptom="${sym}"]`);
    if (w) w.querySelectorAll(".p-chip").forEach(c => c.setAttribute("aria-pressed", String(Number(c.dataset.level)===val)));
  };
  ["gi","fatigue","pain","fog"].forEach(s => syncSym(s, d[s]));
  $$(".p-chip[data-flag]").forEach(c => c.setAttribute("aria-pressed", String(!!d.flags[c.dataset.flag])));
  const notes = $("#notes"); if (notes) { notes.value = d.notes; const nc=$("#noteCount"); if(nc) nc.textContent=String(d.notes.length); }
  updateProgress();
  Util.toast("Repeated last entry");
}

async function refreshKPIs() {
  const kpis = await KPI.compute(State.store);
  const el = (id,v) => { const e=$(id); if(e) e.textContent=String(v); };
  el("#kpiTotal",kpis.total); el("#kpi7d",kpis.last7days); el("#kpiStreak",kpis.streak);
}

async function renderGFDAdherence() {
  const el = $("#gfdAdherence"); if (!el) return;
  const all = (await State.store.getEntriesAll()).sort((a,b)=>b.ts.localeCompare(a.ts)).slice(0,14);
  if (!all.length) { el.innerHTML = `<div class="p-kpi">No data yet</div>`; return; }
  const strict = all.filter(e => e.gfdAdherence === "strict").length;
  const exposures = all.filter(e => e.gfdAdherence !== "strict").length;
  const pct = Math.round((strict/all.length)*100);
  const cls = pct >= 93 ? "ok" : pct >= 80 ? "warn" : "danger";
  el.innerHTML = `<div class="p-kpi">Strict GFD <b style="color:var(--${cls})">${pct}%</b></div>
    <div class="p-kpi">Exposures <b style="color:${exposures>0?'var(--warn)':'var(--ok)'}">${exposures}</b> days</div>`;
}

async function renderSerology() {
  const seros = await State.store.getSetting("seros", []);
  const kpi = $("#kpiSero"); if(kpi) kpi.textContent = String(seros.length);
  const list = $("#seroList"); if (!list) return;
  if (!seros.length) { list.innerHTML = `<div class="p-callout">No serology results logged yet.</div>`; return; }

  // Chart using calprotectin-style
  const chart = $("#chartSero");
  if (chart && seros.length >= 2) {
    const ratios = seros.map(s => s.uln > 0 ? +(s.value/s.uln).toFixed(2) : 0);
    Charts.drawLine(chart, ratios, { maxV: Math.max(3, ...ratios) * 1.1,
      thresholds:[{y:1.0, label:"ULN"}] });
  }

  list.innerHTML = [...seros].reverse().map(s => {
    const ratio = s.uln > 0 ? (s.value/s.uln).toFixed(2) : "—";
    const cls = parseFloat(ratio) <= 1 ? "ok" : parseFloat(ratio) <= 3 ? "warn" : "danger";
    return `<div class="p-item">
      <div class="p-itemTop"><div class="ts">${Util.esc(s.date)}</div></div>
      <div class="p-itemBody">TTG-IgA: <b>${Util.esc(String(s.value))} U/mL</b> · ULN: ${Util.esc(String(s.uln))} · Ratio: <b style="color:var(--${cls})">${Util.esc(String(ratio))}</b> ${parseFloat(ratio)<=1?'✓ Normal':parseFloat(ratio)<=3?'↑ Elevated':'↑↑ High'}</div>
    </div>`;
  }).join("");
}

async function renderHistory() {
  const list = $("#histList"); if (!list) return;
  const all = (await State.store.getEntriesAll()).sort((a,b)=>b.ts.localeCompare(a.ts));
  if (!all.length) { list.innerHTML = `<div class="p-callout">No entries yet.</div>`; return; }
  list.innerHTML = all.slice(0,80).map(e => {
    const interp = interpCSI(e.csi||0);
    const adh = {strict:"Strict GF", possible:"Possible exposure", known:"Known exposure"}[e.gfdAdherence]||"—";
    return `<div class="p-item">
      <div class="p-itemTop">
        <div class="ts">${Util.esc(e.dateKey)}</div>
        <div class="q">${Util.esc(e.quality||"")} · ${Util.esc(adh)}</div>
      </div>
      <div class="p-itemBody">GI: <b>${Util.esc(Util.levelToText(e.gi))}</b> · Fatigue: <b>${Util.esc(Util.levelToText(e.fatigue))}</b> · Brain fog: <b>${Util.esc(Util.levelToText(e.fog))}</b> · CSI: <b style="color:${Util.cssVal(interp.color)}">${Util.esc(String(e.csi||0))}</b></div>
      ${e.exposureSuspected ? `<div class="p-itemBody" style="color:var(--warn);margin-top:4px;font-size:12px;">⚠ Exposure: ${Util.esc((e.exposureSources||[]).join(", ")||"source unspecified")}</div>` : ""}
      ${e.notes ? `<div class="p-itemBody" style="margin-top:4px;">${Util.esc(e.notes)}</div>` : ""}
    </div>`;
  }).join("");
}

async function renderInsights() {
  const all = (await State.store.getEntriesAll()).sort((a,b)=>a.ts.localeCompare(b.ts));
  const body = $("#insightsBody");
  if (all.length < 5) { if(body) body.textContent = `Log at least 5 entries. (${all.length} so far)`; return; }
  if (body) body.innerHTML = `<b>${all.length}</b> total entries logged.`;

  // Adherence chart last 28 days
  const last28 = all.slice(-28);
  const adhVals = last28.map(e => e.gfdAdherence==="strict"?2:e.gfdAdherence==="possible"?1:0);
  const ac = $("#chartAdhere");
  if (ac) Charts.drawBars(ac, last28.map((_,i)=>String(i+1)), adhVals,
    { c1:"rgba(120,194,164,.8)", c2:"rgba(232,164,74,.6)" });

  if (!PremiumGate.isPremium()) {
    const pp = $("#premiumPanel"); pp?.classList.add("hidden");
    // Show inline paywall nudge
    const body = $("#insightsBody");
    if (body && !body.querySelector(".pw-inline-nudge")) {
      const nudge = document.createElement("div");
      nudge.className = "pw-inline-nudge p-callout";
      nudge.style.cssText = "margin-top:12px;cursor:pointer;border-color:rgba(245,200,66,.25);background:rgba(245,200,66,.04);";
      nudge.innerHTML = `<b style="color:#f5c842;">✦ Unlock Premium to see your full Insights</b><br><span style="font-size:var(--font-size-sm);color:var(--muted);">Trend charts · trigger correlation · next steps · what's driving your symptoms</span><br><span style="display:inline-block;margin-top:8px;font-size:var(--font-size-sm);font-family:var(--font-mono);color:#f5c842;">Tap to upgrade →</span>`;
      nudge.addEventListener("click", () => PremiumGate.showPaywall(MODULE_KEY, () => { nudge.remove(); renderInsights(); }));
      body.appendChild(nudge);
    }
    return;
  }
  const pp = $("#premiumPanel"); pp?.classList.remove("hidden");
  const last30 = all.slice(-30);

  const csiVals = last30.map(e => e.csi||0);
  const fatVals = last30.map(e => e.fatigue||0);
  const cc = $("#chartCSI"); if(cc) Charts.drawLine(cc, csiVals, { maxV:15 });
  const fc = $("#chartFatigue"); if(fc) Charts.drawLine(fc, fatVals, { maxV:3 });

  // Exposure analysis
  const eb = $("#exposureBox");
  if (eb) {
    const exposures = last30.filter(e => e.gfdAdherence !== "strict");
    const sources = {};
    exposures.forEach(e => (e.exposureSources||[]).forEach(s => sources[s] = (sources[s]||0)+1));
    const top = Object.entries(sources).sort((a,b)=>b[1]-a[1]).slice(0,3);
    eb.className = "p-callout " + (exposures.length > 3 ? "warn" : "");
    eb.innerHTML = exposures.length === 0
      ? "<b>No exposures</b> in last 30 entries. Excellent adherence."
      : `<b>${exposures.length} exposure events</b> in 30 days.<br>${top.length ? "Top sources: " + top.map(([k,v])=>`${Util.esc(k)} (${v}×)`).join(", ") : ""}`;
  }

  // Adherence stats
  const ab = $("#adherenceBox");
  if (ab) {
    const strict = last30.filter(e=>e.gfdAdherence==="strict").length;
    const pct = Math.round((strict/last30.length)*100);
    const cls = pct>=93?"ok":pct>=80?"warn":"danger";
    ab.className = "p-callout "+cls;
    ab.innerHTML = `<b>GFD adherence:</b> ${pct}% strict (${strict}/${last30.length} days). ${pct<80?"Inadvertent gluten exposure is the most common cause of ongoing symptoms in celiac disease.":pct>=93?"Excellent — consistent strict GFD is the only treatment.":"Good — aim for >95% for complete mucosal healing."}`;
  }

  // Next steps
  const ns = $("#nextStepsList");
  if (ns) {
    const steps = [];
    const pct = Math.round((last30.filter(e=>e.gfdAdherence==="strict").length/last30.length)*100);
    if (pct < 80) steps.push({ p:"danger", t:"GFD adherence below 80%. Mucosal healing requires near-complete gluten elimination. Consider review with a specialist GFD dietitian." });
    const meanCSI = Stats.mean(last30.map(e=>e.csi||0));
    if (meanCSI >= 8 && pct >= 90) steps.push({ p:"warn", t:"Significant symptoms despite good adherence. Request TTG-IgA recheck and discuss non-responsive celiac disease with your gastroenterologist." });
    const restExp = last30.filter(e=>(e.exposureSources||[]).includes("restaurant")).length;
    if (restExp >= 3) steps.push({ p:"warn", t:`Restaurant-linked exposures: ${restExp} times in 30 days. Use the restaurant protocol — call ahead, speak to the chef, ask about dedicated fryers and prep surfaces.` });
    const fatMean = Stats.mean(last30.map(e=>e.fatigue||0));
    if (fatMean >= 1.5) steps.push({ p:"warn", t:"Persistent fatigue. Check ferritin, vitamin D, B12, folate if not done in past 6 months — deficiencies are common even on GFD." });
    if (!steps.length) steps.push({ p:"ok", t:"Good symptom control and adherence. Continue strict GFD and annual serology." });
    const colors={danger:"var(--danger)",warn:"var(--warn)",ok:"var(--ok)"};
    ns.innerHTML = steps.map(s=>`<div class="p-item"><div class="p-itemBody"><b style="color:${colors[s.p]}">${s.p.toUpperCase()}:</b> ${Util.esc(s.t)}</div></div>`).join("");
  }
}

function showTab(tab) {
  ["log","serology","history","library","insights"].forEach(t => {
    $("#tab-"+t)?.setAttribute("aria-selected", String(t===tab));
    $("#view-"+t)?.classList.toggle("hidden", t!==tab);
  });
  if (tab==="history") renderHistory();
  if (tab==="serology") renderSerology();
  if (tab==="library") {
    LibRenderer.renderCats($("#libCats"), LIB_CATS, State.libCat, cat => { State.libCat=cat; renderLibrary(); });
    renderLibrary();
  }
  if (tab==="insights") renderInsights();
}

function renderLibrary() {
  const grid = $("#libGrid"); if (!grid) return;
  const kpi = $("#kpiCards"); if(kpi) kpi.textContent = String(LIBRARY.cards.length);
  LibRenderer.render(grid, LibRenderer.filterCards(LIBRARY.cards, State.libCat, State.libQuery));
}

// ── EVENTS ───────────────────────────────────────────────────────
function wireEvents() {
  $$(".p-tab").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));

  $$("[data-quality]").forEach(b => b.addEventListener("click", () => {
    State.draft.quality = b.dataset.quality;
    $$("[data-quality]").forEach(x => x.setAttribute("aria-pressed", String(x===b)));
    updateProgress();
    setTimeout(() => Util.scroll($("#stepGFD")), 80);
  }));

  $$("[data-gfd]").forEach(b => b.addEventListener("click", () => setGFDUI(b.dataset.gfd)));

  $$("[data-source]").forEach(b => b.addEventListener("click", () => {
    const s = b.dataset.source;
    const pressed = b.getAttribute("aria-pressed") === "true";
    b.setAttribute("aria-pressed", String(!pressed));
    if (!pressed) State.draft.exposureSources.push(s);
    else State.draft.exposureSources = State.draft.exposureSources.filter(x=>x!==s);
  }));

  $$("[data-symptom]").forEach(wrap => wrap.addEventListener("click", e => {
    const btn = e.target.closest(".p-chip"); if (!btn) return;
    const sym = wrap.dataset.symptom, level = Number(btn.dataset.level);
    State.draft[sym] = Util.clamp(level,0,3);
    wrap.querySelectorAll(".p-chip").forEach(c => c.setAttribute("aria-pressed", String(c===btn)));
    const labelMap = {gi:"giLabel",fatigue:"fatLabel",pain:"painLabel",fog:"fogLabel",exposureReaction:"rxnLabel"};
    const lel = labelMap[sym] ? $(`#${labelMap[sym]}`) : null;
    if (lel) lel.textContent = sym==="exposureReaction" ? REACTION_LEVELS[level]?.label||"" : Util.levelToText(level);
    updateProgress();
  }));

  $$(".p-chip[data-flag]").forEach(b => b.addEventListener("click", () => {
    const k = b.dataset.flag;
    State.draft.flags[k] = !State.draft.flags[k];
    b.setAttribute("aria-pressed", String(State.draft.flags[k]));
  }));

  const notes = $("#notes");
  if (notes) notes.addEventListener("input", () => {
    State.draft.notes = notes.value;
    const nc=$("#noteCount"); if(nc) nc.textContent=String(notes.value.length);
  });

  $("#btnSave")?.addEventListener("click", save);
  $("#btnRepeat")?.addEventListener("click", repeatLast);
  $("#btnReset")?.addEventListener("click", resetDraft);

  const doCSV = () => IO.exportCSV(State.store, MODULE_KEY, FLAG_KEYS);
  const doJSON = () => IO.exportJSON(State.store, MODULE_KEY);
  // INVARIANT: clinician report is always free — do not gate on PremiumGate.isPremium()
  $("#btnReport")?.addEventListener("click", () => Report.generate(MODULE_KEY));
  ["#btnExportCsv","#btnExportCsv2"].forEach(s => $(s)?.addEventListener("click", doCSV));
  ["#btnExportJson","#btnExportJson2"].forEach(s => $(s)?.addEventListener("click", doJSON));
  const btnImport=$("#btnImport"), importFile=$("#importFile");
  if (btnImport && importFile) {
    btnImport.addEventListener("click", () => importFile.click());
    importFile.addEventListener("change", async e => {
      const f=e.target.files?.[0]; if(!f) return;
      await IO.importJSON(f,State.store,FLAG_KEYS,async()=>{await refreshKPIs();await renderHistory();});
      e.target.value="";
    });
  }

  // Serology
  const seroVal=$("#seroVal"),seroULN=$("#seroULN"),seroDate=$("#seroDate"),seroPreview=$("#seroPreview");
  const updateSeroPreview = () => {
    const v=parseFloat(seroVal?.value), u=parseFloat(seroULN?.value);
    if (!isNaN(v) && !isNaN(u) && u>0 && seroPreview) {
      const ratio=(v/u).toFixed(2);
      const cls=parseFloat(ratio)<=1?"ok":parseFloat(ratio)<=3?"warn":"danger";
      seroPreview.className="p-callout "+cls;
      seroPreview.innerHTML=`TTG-IgA ratio: <b>${ratio}× ULN</b> — ${parseFloat(ratio)<=1?"Normal (within reference range)":parseFloat(ratio)<=3?"Elevated — ongoing gluten exposure likely if on GFD for >6 months":"Significantly elevated"}`;
      seroPreview.classList.remove("hidden");
    } else seroPreview?.classList.add("hidden");
  };
  seroVal?.addEventListener("input", updateSeroPreview);
  seroULN?.addEventListener("input", updateSeroPreview);

  $("#btnSaveSero")?.addEventListener("click", async () => {
    const v=parseFloat(seroVal?.value), u=parseFloat(seroULN?.value), d=seroDate?.value;
    if (isNaN(v)||v<0){Util.toast("Enter a valid value");return;}
    if (!d){Util.toast("Enter collection date");return;}
    const seros=await State.store.getSetting("seros",[]);
    seros.push({value:v,uln:isNaN(u)?10:u,date:d});
    await State.store.setSetting("seros",seros);
    Util.toast("Serology result saved");
    if(seroVal) seroVal.value="";
    if(seroULN) seroULN.value="";
    if(seroDate) seroDate.value="";
    seroPreview?.classList.add("hidden");
    await renderSerology();
  });

  $("#libSearch")?.addEventListener("input", e => { State.libQuery=e.target.value||""; renderLibrary(); });
  $("#btnRefresh")?.addEventListener("click", renderInsights);

  // Premium CTA
  $("#premiumCta")?.addEventListener("click", () => {
    PremiumGate.showPaywall(MODULE_KEY, () => {
      const sl = $("#premStatusLabel");
      if (sl) sl.textContent = "✦ Premium active";
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      renderInsights?.();
      Util.toast("Premium unlocked ✦");
    });
  });
}

// ── BOOT ─────────────────────────────────────────────────────────
async function boot() {
  renderHTML();
  const todayEl=$("#todayLabel"); if(todayEl) todayEl.textContent=Util.dateKeyLocal();

  const {store,mode}=await initStorage(MODULE_KEY);
  State.store=store;
  if (typeof GIOSNotifications !== "undefined") GIOSNotifications.init("celiac", "Celiac OS");
  updateStorageModeUI(mode);

  const savedPremium=await store.getSetting("premium",false);
  State.premium=!!savedPremium;
  const m=$("#modeLabel"); if(m) m.textContent=State.premium?"Premium":"Free";

  State.lastEntry=await store.getLastEntry();
  wireEvents();
  resetDraft();
  await refreshKPIs();
  await renderGFDAdherence();

  LibRenderer.renderCats($("#libCats"),LIB_CATS,State.libCat,cat=>{State.libCat=cat;renderLibrary();});
  renderLibrary();

  Util.toast("Celiac OS ready");
}

boot();
})();
