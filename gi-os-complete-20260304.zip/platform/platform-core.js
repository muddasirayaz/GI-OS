/**
 * GI Platform — Core JavaScript
 * ═══════════════════════════════════════════════════════════
 * All shared logic. Every module uses this.
 * Modules only define: schema, steps, library cards, scoring.
 *
 * Version: 1.0.0
 * ═══════════════════════════════════════════════════════════
 */

const Platform = (() => {
"use strict";

// ── UTILS ────────────────────────────────────────────────────────
const Util = {
  nowISO: () => new Date().toISOString(),

  dateKeyLocal(iso) {
    const d = iso ? new Date(iso) : new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  },

  // Intl-aware date/time formatting (7.2) — respects user locale + timezone
  _dtFmt: null,
  _timeFmt: null,
  fmtDate(iso) {
    // Full date+time for history entries
    if (!Util._dtFmt) Util._dtFmt = new Intl.DateTimeFormat(undefined, {month:"short",day:"numeric",hour:"numeric",minute:"2-digit"});
    try { return Util._dtFmt.format(new Date(iso)); } catch { return String(iso).slice(0,16).replace("T"," "); }
  },
  fmtDateOnly(iso) {
    return new Intl.DateTimeFormat(undefined, {month:"short",day:"numeric",year:"numeric"}).format(new Date(iso));
  },
  fmtRelative(iso) {
    // "today", "yesterday", "3 days ago" — falls back to fmtDateOnly
    try {
      const days = Math.floor((Date.now() - new Date(iso).getTime()) / 86400000);
      if (days === 0) return "today";
      if (days === 1) return "yesterday";
      if (days < 7)  return `${days} days ago`;
      return Util.fmtDateOnly(iso);
    } catch { return Util.fmtDateOnly(iso); }
  },

  clamp: (n, lo, hi) => Math.max(lo, Math.min(hi, Number(n) || 0)),

  esc(s) {
    return String(s ?? "").replace(/[&<>"']/g, c => ({
      "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
    }[c]));
  },


  // CSS value sanitiser — prevents injection via color/style interpolation
  cssVal(s) {
    // Allow safe CSS color values: hex, rgb/rgba(), named colors, CSS custom props
    const safe = /^(#[0-9a-fA-F]{3,8}|rgba?\([^)]{1,60}\)|[a-zA-Z]{2,30}|var\(--[a-zA-Z0-9-]{1,40}\))$/;
    return safe.test(String(s ?? "").trim()) ? s : "#888888";
  },

  _toastTimer: null,
  // ARIA live region — ensure screen readers announce toasts
  _ensureToastLive() {
    if (document.getElementById("gi-toast-live")) return;
    const live = document.createElement("div");
    live.id = "gi-toast-live";
    live.setAttribute("aria-live", "polite");
    live.setAttribute("aria-atomic", "true");
    live.style.cssText = "position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;";
    document.body.appendChild(live);
  },
  toast(msg, ms = 1800) {
    // Announce to screen readers via ARIA live region
    this._ensureToastLive();
    const live = document.getElementById("gi-toast-live");
    if (live) { live.textContent = ""; setTimeout(() => { live.textContent = msg; }, 50); }
    const t = document.querySelector(".p-toast");
    if (!t) return;
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(Util._toastTimer);
    Util._toastTimer = setTimeout(() => t.classList.remove("show"), ms);
  },

  scroll(el) {
    if (el) el.scrollIntoView({ behavior: "smooth", block: "nearest" });
  },

  // Run callback when browser is idle — use for non-critical renders
  // Falls back to setTimeout(0) if requestIdleCallback unavailable (iOS <16)
  onIdle(fn, timeout = 2000) {
    if (typeof requestIdleCallback === "function") {
      requestIdleCallback(fn, { timeout });
    } else {
      setTimeout(fn, 0);
    }
  },

  // Legacy browser detection (6.5) — check for required APIs
  checkBrowserCompat() {
    const missing = [];
    if (!window.localStorage)  missing.push("localStorage");
    if (!window.crypto?.subtle) missing.push("WebCrypto");
    if (!window.CSS?.supports)  missing.push("CSS.supports");
    if (missing.length) {
      setTimeout(() => {
        Util.toast(
          `Your browser may not support all features (missing: ${missing.join(", ")}). ` +
          "For the best experience, use Chrome, Safari, or Firefox.",
          10000
        );
      }, 3000);
    }
    return missing.length === 0;
  },

  levelToText: (l) => (["none","mild","moderate","severe"][Util.clamp(l,0,3)] || "none"),

  csvEsc(v) {
    let s = String(v ?? "");
    // Formula injection defence: prefix dangerous leading chars with single quote
    // Prevents Excel/Sheets executing =, +, -, @, tab, carriage return as formulas
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
    // Quote wrap if contains comma, double-quote, or newline
    return /[,"\n]/.test(s) ? `"${s.replace(/"/g,'""')}"` : s;
  }
};



// ── PROGRESSIVE DISCLOSURE ENGINE ────────────────────────────────
const Disclosure = {
  // States: novice → habitual → power → clinical_review | anomaly_mode
  
  getState(entryCount, hasAlarm) {
    if (hasAlarm) return 'anomaly_mode';
    if (entryCount < 7)  return 'novice';
    if (entryCount < 30) return 'habitual';
    return 'power';
  },

  // Returns which UI elements should be visible for a given state
  getVisibility(state) {
    const base = {
      logTab:      true,
      historyTab:  true,
      libraryTab:  true,
      insightsTab: true,
      exportBtn:   true,
      reportBtn:   true,   // INVARIANT: always visible
      alarmBanner: true,   // INVARIANT: always visible
      streakWidget: true,
    };

    switch(state) {
      case 'novice':
        return { ...base, 
          insightsTab: false,  // Hidden until habitual — less overwhelm
          exportBtn: false,
        };
      case 'habitual':
        return { ...base,
          insightsTab: false,  // Visible at power stage or premium
        };
      case 'power':
      case 'clinical_review':
      case 'anomaly_mode':
        return { ...base };
      default:
        return base;
    }
  },

  // Apply visibility rules to DOM
  applyToDOM(state, moduleKey) {
    const vis = this.getVisibility(state);
    
    // Insights tab — show with lock icon for free users below power threshold
    const insightsTab = document.getElementById('tab-insights');
    if (insightsTab) {
      if (state === 'novice' || state === 'habitual') {
        insightsTab.style.opacity = '0.45';
        insightsTab.title = state === 'novice' 
          ? 'Log 7 days to unlock Insights' 
          : 'Log 30 days to unlock full Insights';
      } else {
        insightsTab.style.opacity = '';
        insightsTab.title = '';
      }
    }

    // Anomaly mode — ensure alarm banner is prominent
    if (state === 'anomaly_mode') {
      const banner = document.getElementById('redFlagAlert');
      if (banner) {
        banner.classList.remove('hidden');
        banner.style.animation = 'none'; // Force visible
      }
    }
  },
};

// ── PERFORMANCE INSTRUMENTATION ──────────────────────────────────
const Perf = {
  _marks: {},
  _dev: typeof location !== 'undefined' && location.hostname === 'localhost',

  mark(name) {
    this._marks[name] = performance.now();
  },

  measure(name, startMark) {
    const start = this._marks[startMark || name] ?? 0;
    const dur = performance.now() - start;
    if (this._dev && dur > 50) {
      console.warn(`[Perf] ${name}: ${dur.toFixed(1)}ms ${dur > 100 ? '⚠ SLOW' : ''}`);
    }
    return dur;
  },

  // Wrap an async operation with timing
  async time(name, fn) {
    const t0 = performance.now();
    const result = await fn();
    const dur = performance.now() - t0;
    if (this._dev && dur > 20) {
      console.log(`[Perf] ${name}: ${dur.toFixed(1)}ms`);
    }
    // Budget warnings
    const budgets = { 'entry-save': 100, 'report-generate': 2000,
                      'db-query': 20, 'chart-render': 200 };
    if (budgets[name] && dur > budgets[name]) {
      console.warn(`[Perf] ${name} exceeded budget: ${dur.toFixed(1)}ms > ${budgets[name]}ms`);
    }
    return result;
  }
};

// ── STORAGE ──────────────────────────────────────────────────────
const LS = { e: "giplatform_e", s: "giplatform_s", c: "giplatform_c" };

function lsRead(k, fb) {
  try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : fb; }
  catch { return fb; }
}
function lsWrite(k, v) {
  try {
    localStorage.setItem(k, JSON.stringify(v));
    // Notify other tabs of the storage change (10.3 — cross-tab sync)
    _bcBroadcast(k);
  }
  catch(e) {
    console.warn("lsWrite:", e);
    if (e.name === "QuotaExceededError" || e.code === 22) {
      _storageQuotaWarning();
    }
  }
}

// BroadcastChannel for cross-tab state sync (10.3)
let _bc = null;
let _bcOnUpdate = null; // callback registered by the active module

function _bcBroadcast(key) {
  if (typeof BroadcastChannel === "undefined") return;
  try {
    if (!_bc) _bc = new BroadcastChannel("gi-os-sync");
    _bc.postMessage({ type: "storage-updated", key, ts: Date.now() });
  } catch {}
}

function initBroadcastSync(onUpdate) {
  if (typeof BroadcastChannel === "undefined") return;
  try {
    if (!_bc) _bc = new BroadcastChannel("gi-os-sync");
    _bcOnUpdate = onUpdate;
    _bc.onmessage = (e) => {
      if (e.data?.type === "storage-updated" && _bcOnUpdate) {
        // Debounce — don't fire more than once per 500ms
        clearTimeout(_bc._debounce);
        _bc._debounce = setTimeout(() => _bcOnUpdate(e.data.key), 500);
      }
    };
  } catch {}
}

let _quotaWarnedAt = 0;
function _storageQuotaWarning() {
  const now = Date.now();
  if (now - _quotaWarnedAt < 60000) return; // debounce — max once per minute
  _quotaWarnedAt = now;
  // Use Util.toast if available, else fallback to alert
  const msg = "Storage almost full — export your data to avoid losing entries. Settings → Export.";
  if (typeof Util !== "undefined" && Util.toast) {
    Util.toast(msg, 8000);
  } else {
    console.error("[GI OS] " + msg);
  }
}
function canLS() {
  try { const k="__gip__"; localStorage.setItem(k,"1"); localStorage.removeItem(k); return true; }
  catch { return false; }
}

function makeMemStore() {
  const m = { e: [], s: {}, c: [] };
  let ei = 0, ci = 0;
  return {
    async open() {},
    async getSetting(k, fb=null) { return k in m.s ? m.s[k] : fb; },
    async setSetting(k, v) { m.s[k] = v; },
    async addEntry(e) { const r = {...e, id: ++ei}; m.e.push(r); return r; },
    async getEntriesAll() { return m.e.filter(e => e && !e.deleted); },
    async getLastEntry() {
      const a = m.e.filter(e => e && !e.deleted && e.ts).sort((a,b) => b.ts.localeCompare(a.ts));
      return a[0] || null;
    },
    async addCalp(c) { const r = {...c, id: ++ci}; m.c.push(r); return r; },
    async getCalpAll() { return m.c.slice().sort((a,b) => a.date.localeCompare(b.date)); }
  };
}

function makeLSStore(moduleKey) {
  const ek = `${LS.e}_${moduleKey}`;
  const sk = `${LS.s}_${moduleKey}`;
  const ck = `${LS.c}_${moduleKey}`;
  return {
    async open() {},
    async getSetting(k, fb=null) {
      const s = lsRead(sk, {}); return k in s ? s[k] : fb;
    },
    async setSetting(k, v) {
      const s = lsRead(sk, {}); s[k] = v; lsWrite(sk, s);
    },
    async addEntry(e) {
      const a = lsRead(ek, []);
      const id = a.reduce((x,r) => Math.max(x, r.id||0), 0) + 1;
      const r = {...e, id}; a.push(r); lsWrite(ek, a); return r;
    },
    async getEntriesAll() {
      return lsRead(ek, []).filter(e => e && !e.deleted);
    },
    async getLastEntry() {
      const a = lsRead(ek, []).filter(e => e && !e.deleted && e.ts).sort((a,b) => b.ts.localeCompare(a.ts));
      return a[0] || null;
    },
    async addCalp(c) {
      const a = lsRead(ck, []);
      const id = a.reduce((x,r) => Math.max(x, r.id||0), 0) + 1;
      const r = {...c, id}; a.push(r); lsWrite(ck, a); return r;
    },
    async getCalpAll() {
      return lsRead(ck, []).slice().sort((a,b) => a.date.localeCompare(b.date));
    }
  };
}

function makeDexieStore(moduleKey) {
  if (typeof Dexie === "undefined") return null;
  const db = new Dexie(`gi_platform_${moduleKey}`);
  db.version(1).stores({
    entries: "++id,ts,dateKey,deleted",
    settings: "key",
    calp: "++id,date"
  });
  return {
    async open() { await db.open(); },
    async _ping() {
      await db.settings.put({key:"__p__",value:1});
      await db.settings.delete("__p__");
    },
    async getSetting(k, fb=null) {
      const r = await db.settings.get(k); return r?.value ?? fb;
    },
    async setSetting(k, v) { await db.settings.put({key:k, value:v}); },
    async addEntry(e) { const id = await db.entries.add(e); return {...e, id}; },
    async getEntriesAll() { return db.entries.where("deleted").equals(0).toArray(); },
    async getLastEntry() {
      const a = await db.entries.where("deleted").equals(0).toArray();
      a.sort((a,b) => b.ts.localeCompare(a.ts));
      return a[0] || null;
    },
    async addCalp(c) { const id = await db.calp.add(c); return {...c, id}; },
    async getCalpAll() {
      const a = await db.calp.toArray();
      a.sort((a,b) => a.date.localeCompare(b.date));
      return a;
    }
  };
}

async function initStorage(moduleKey) {
  const dex = makeDexieStore(moduleKey);
  if (dex) {
    try {
      await dex.open();
      await dex._ping();
      return { store: dex, mode: "indexeddb" };
    } catch(e) { console.warn("IDB unavailable:", e); }
  }
  if (canLS()) {
    const s = makeLSStore(moduleKey);
    await s.open();
    return { store: s, mode: "localstorage" };
  }
  const s = makeMemStore();
  await s.open();
  _warnPrivateMode(); // Surfaces incognito/private mode warning
  return { store: s, mode: "memory" };
}

// ── STATISTICS ───────────────────────────────────────────────────
const Stats = {
  mean(arr) {
    const a = arr.filter(x => typeof x === "number" && !isNaN(x));
    if (!a.length) return 0;
    return a.reduce((s,v) => s+v, 0) / a.length;
  },

  std(arr) {
    const a = arr.filter(x => typeof x === "number" && !isNaN(x));
    if (a.length < 2) return 0;
    const m = Stats.mean(a);
    return Math.sqrt(a.reduce((s,x) => s+(x-m)*(x-m), 0) / a.length);
  },

  pearson(x, y) {
    const n = Math.min(x.length, y.length);
    if (n < 6) return null;
    const X = x.slice(-n).map(Number);
    const Y = y.slice(-n).map(Number);
    const mx = Stats.mean(X), my = Stats.mean(Y);
    let num=0, dx=0, dy=0;
    for (let i=0; i<n; i++) {
      const a=X[i]-mx, b=Y[i]-my;
      num += a*b; dx += a*a; dy += b*b;
    }
    const den = Math.sqrt(dx*dy);
    return den ? num/den : null;
  }
};

// ── CHARTS ───────────────────────────────────────────────────────
const Charts = {
  _dpr: () => window.devicePixelRatio || 1,

  _prep(canvas, h) {
    const dpr = Charts._dpr();
    const w = canvas.width = Math.max(1, canvas.clientWidth) * dpr;
    const ch = canvas.height = (h || Number(canvas.getAttribute("height")) || 200) * dpr;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, w, ch);
    return { ctx, w, h: ch, dpr };
  },

  drawBars(canvas, labels, values, opts = {}) {
    const { ctx, w, h, dpr } = Charts._prep(canvas);
    const pad = 16*dpr, innerW = w-pad*2, innerH = h-pad*2;
    const max = Math.max(1, ...values);

    ctx.strokeStyle = "rgba(231,237,245,.08)";
    ctx.lineWidth = 1*dpr;
    ctx.beginPath();
    ctx.moveTo(pad, pad+innerH);
    ctx.lineTo(pad+innerW, pad+innerH);
    ctx.stroke();

    const n = values.length;
    const gap = (innerW/n)*0.3;
    const bw = (innerW/n) - gap;
    ctx.font = `${10*dpr}px monospace`;

    for (let i=0; i<n; i++) {
      const v = values[i];
      const x = pad + i*(bw+gap) + gap/2;
      const bh = (v/max) * (innerH*0.84);
      const y = pad + innerH - bh;

      if (bh > 0) {
        const grad = ctx.createLinearGradient(x,y,x,y+bh);
        grad.addColorStop(0, opts.c1 || "rgba(79,168,213,.75)");
        grad.addColorStop(1, opts.c2 || "rgba(126,203,161,.45)");
        ctx.fillStyle = grad;
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(x,y,bw,bh,6*dpr);
        else ctx.rect(x,y,bw,bh);
        ctx.fill();
      }

      ctx.fillStyle = "rgba(231,237,245,.45)";
      const lb = String(labels[i]);
      ctx.fillText(lb, x+bw/2-(ctx.measureText(lb).width/2), pad+innerH+12*dpr);

      if (v > 0) {
        ctx.fillStyle = "rgba(231,237,245,.65)";
        const vl = String(v);
        ctx.fillText(vl, x+bw/2-(ctx.measureText(vl).width/2), y-4*dpr);
      }
    }
  },

  drawLine(canvas, values, opts = {}) {
    const { ctx, w, h, dpr } = Charts._prep(canvas);
    if (values.length < 2) return;
    const n = values.length, pad = 16*dpr;
    const minV = opts.minV ?? 0;
    const maxV = opts.maxV ?? Math.max(...values, 1);
    const xAt = i => pad + (w-pad*2)*(i/(n-1));
    const yAt = v => pad + (h-pad*2)*(1-((v-minV)/(maxV-minV||1)));

    if (opts.threshold !== undefined) {
      ctx.strokeStyle = "rgba(224,122,122,.4)";
      ctx.lineWidth = 1.5*dpr;
      ctx.setLineDash([6*dpr,4*dpr]);
      ctx.beginPath();
      ctx.moveTo(pad, yAt(opts.threshold));
      ctx.lineTo(w-pad, yAt(opts.threshold));
      ctx.stroke();
      ctx.setLineDash([]);
    }

    if (opts.guides) {
      opts.guides.forEach(v => {
        ctx.strokeStyle = "rgba(231,237,245,.06)";
        ctx.lineWidth = 1*dpr;
        ctx.beginPath(); ctx.moveTo(pad,yAt(v)); ctx.lineTo(w-pad,yAt(v)); ctx.stroke();
      });
    }

    ctx.strokeStyle = opts.lc || "rgba(79,168,213,.8)";
    ctx.lineWidth = 2*dpr;
    ctx.beginPath(); ctx.moveTo(xAt(0), yAt(values[0]));
    for (let i=1; i<n; i++) ctx.lineTo(xAt(i), yAt(values[i]));
    ctx.stroke();

    ctx.fillStyle = opts.dc || "rgba(126,203,161,.9)";
    for (let i=0; i<n; i++) {
      ctx.beginPath();
      ctx.arc(xAt(i), yAt(values[i]), 2.5*dpr, 0, Math.PI*2);
      ctx.fill();
    }
  },

  drawCalprotectin(canvas, readings) {
    const { ctx, w, h, dpr } = Charts._prep(canvas);
    if (!readings.length) return;
    const vals = readings.map(r => r.value);
    const maxV = Math.max(600, ...vals);
    const pad = 20*dpr;
    const xAt = i => pad + (w-pad*2)*(i/Math.max(1, readings.length-1));
    const yAt = v => pad + (h-pad*2)*(1-(v/maxV));

    ctx.strokeStyle = "rgba(224,122,122,.45)";
    ctx.lineWidth = 1.5*dpr;
    ctx.setLineDash([6*dpr,4*dpr]);
    ctx.beginPath();
    ctx.moveTo(pad, yAt(150)); ctx.lineTo(w-pad, yAt(150));
    ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = "rgba(224,122,122,.45)";
    ctx.font = `${10*dpr}px monospace`;
    ctx.fillText("150 µg/g", pad+2*dpr, yAt(150)-3*dpr);

    if (readings.length < 2) return;

    ctx.strokeStyle = "rgba(79,168,213,.8)";
    ctx.lineWidth = 2*dpr;
    ctx.beginPath(); ctx.moveTo(xAt(0), yAt(vals[0]));
    for (let i=1; i<readings.length; i++) ctx.lineTo(xAt(i), yAt(vals[i]));
    ctx.stroke();

    for (let i=0; i<readings.length; i++) {
      const v = vals[i];
      ctx.fillStyle = v<50 ? "rgba(126,203,161,.9)" : v<150 ? "rgba(224,155,79,.9)" : "rgba(224,122,122,.9)";
      ctx.beginPath(); ctx.arc(xAt(i), yAt(v), 4*dpr, 0, Math.PI*2); ctx.fill();
    }
  }
};

// ── CALPROTECTIN ─────────────────────────────────────────────────
const Calprotectin = {
  // Threshold: 150 µg/g — strongest sensitivity/specificity for mucosal healing
  // Sources: Tibble et al. Am J Gastroenterol 2017; CALM trial, Lancet 2017
  THRESHOLD: 150,

  interpret(v) {
    if (v < 50)  return { cls:"rem",  label:"Deep remission",       color:"var(--ok)" };
    if (v < 150) return { cls:"mild", label:"Grey zone",            color:"var(--warn)" };
    return               { cls:"act",  label:"Active inflammation",  color:"var(--danger)" };
  },

  renderList(containerEl, readings) {
    if (!readings.length) {
      containerEl.innerHTML = `<div class="p-callout">No readings logged yet.</div>`;
      return;
    }
    containerEl.innerHTML = [...readings].reverse().map(r => {
      const interp = Calprotectin.interpret(r.value);
      const pct = Math.min(100, (r.value / 600) * 100);
      return `<div class="p-calpListRow">
        <div class="cd">${Util.esc(r.date)}</div>
        <div class="cv" style="color:${interp.color}">${Util.esc(String(r.value))}</div>
        <div class="cbar"><div class="cbf" style="width:${pct}%;background:${interp.color};"></div></div>
        <div class="cs" style="color:${interp.color}">${Util.esc(interp.label)}</div>
      </div>`;
    }).join("");
  }
};

// ── LIBRARY RENDERER ─────────────────────────────────────────────
const LibRenderer = {
  render(containerEl, cards) {
    if (!cards.length) {
      containerEl.innerHTML = `<div class="p-callout">No matches found.</div>`;
      return;
    }
    containerEl.innerHTML = cards.slice(0, 160).map(c => `
      <div class="p-cardlet" data-cardid="${Util.esc(c.id)}" data-open="false">
        <div class="p-cardlet-top">
          <div class="p-ctag">${Util.esc(c.tag)}</div>
          <div class="p-ctag">${Util.esc(c.cat)}</div>
        </div>
        <h3>${Util.esc(c.title)}</h3>
        <div class="p-cwhy">${Util.esc(c.why)}</div>
        ${c.bullets ? `<ul class="p-cbullets">${c.bullets.map(b=>`<li>${Util.esc(b)}</li>`).join("")}</ul>` : ""}
        ${c.action ? `<div class="p-caction"><b>What to do:</b> ${Util.esc(c.action)}</div>` : ""}
        ${c.evidence ? `<div class="p-cevidence">Sources: ${Util.esc(c.evidence)}</div>` : ""}
        ${c.more ? `<button class="p-moreBtn" type="button">More detail ▾</button><div class="p-moreBody">${Util.esc(c.more)}</div>` : ""}
      </div>
    `).join("");

    containerEl.querySelectorAll(".p-moreBtn").forEach(btn => {
      btn.addEventListener("click", () => {
        const card = btn.closest(".p-cardlet");
        card.dataset.open = card.dataset.open === "true" ? "false" : "true";
        btn.textContent = card.dataset.open === "true" ? "Less ▴" : "More detail ▾";
      });
    });
  },

  renderCats(containerEl, cats, activeCat, onSelect) {
    containerEl.innerHTML = cats.map(c =>
      `<button class="p-catBtn${c === activeCat ? " active" : ""}" type="button" data-libcat="${Util.esc(c)}">${Util.esc(c === "all" ? "All" : c)}</button>`
    ).join("");
    containerEl.querySelectorAll(".p-catBtn").forEach(b => {
      b.addEventListener("click", () => {
        containerEl.querySelectorAll(".p-catBtn").forEach(x => x.classList.toggle("active", x === b));
        onSelect(b.dataset.libcat);
      });
    });
  },

  filterCards(cards, cat, query) {
    const q = (query || "").trim().toLowerCase();
    return cards.filter(c => {
      const catOk = cat === "all" || c.cat === cat;
      if (!catOk) return false;
      if (!q) return true;
      const blob = [c.title, c.cat, c.tag, c.why, ...(c.bullets||[]), c.action||"", c.more||""]
        .join(" ").toLowerCase();
      return blob.includes(q);
    });
  }
};

// ── EXPORT / IMPORT ──────────────────────────────────────────────
const IO = {
  async exportCSV(store, moduleKey, flagKeys) {
    const all = (await store.getEntriesAll()).sort((a,b) => a.ts.localeCompare(b.ts));
    const header = ["ts","dateKey","quality","frequency","blood","pain","wellbeing","urgency",...flagKeys,"notes"];
    const lines = ["\ufeff"+header.join(","), ...all.map(e => {
      const f = e.flags || {};
      return [e.ts,e.dateKey,e.quality,e.frequency,e.blood,e.pain,e.wellbeing,e.urgency,
        ...flagKeys.map(k => !!f[k]), e.notes||""].map(Util.csvEsc).join(",");
    })];
    IO._download(lines.join("\n"), `${moduleKey}-${Util.dateKeyLocal()}.csv`, "text/csv;charset=utf-8");
    Util.toast("Exported CSV");
  },

  async exportJSON(store, moduleKey) {
    const all = (await store.getEntriesAll()).sort((a,b) => a.ts.localeCompare(b.ts));
    const payload = {
      // Provenance metadata (5.4 — data portability with traceability)
      schema: "gi-os-v1",
      appVersion: "1.0.0",
      module: moduleKey,
      exportedAt: Util.nowISO(),
      entryCount: all.length,
      dataSource: "client-side-only",  // no server, no third-party data
      entries: all
    };
    const json = JSON.stringify(payload, null, 2);
    // Append a SHA-256 digest so the recipient can verify the file was not tampered
    let digest = "";
    try {
      const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(json));
      digest = Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,"0")).join("");
    } catch {}
    const final = digest ? JSON.stringify({...payload, _sha256: digest}, null, 2) : json;
    IO._download(final, `${moduleKey}-${Util.dateKeyLocal()}.json`, "application/json");
    Util.toast("Exported JSON");
  },

  async importJSON(file, store, flagKeys, onDone) {
    try {
      const text = await file.text();
      const payload = JSON.parse(text);
      const entries = Array.isArray(payload.entries) ? payload.entries : [];
      let n = 0;
      for (const e of entries) {
        if (!e?.ts) continue;
        await store.addEntry({
          ts: String(e.ts),
          dateKey: e.dateKey || Util.dateKeyLocal(e.ts),
          quality: e.quality || "okay",
          frequency: Number(e.frequency) || 0,
          blood: Number(e.blood) || 0,
          pain: Util.clamp(e.pain, 0, 3),
          wellbeing: Util.clamp(e.wellbeing, 0, 3),
          urgency: Util.clamp(e.urgency, 0, 3),
          flags: (() => {
            const f = {};
            flagKeys.forEach(k => f[k] = !!(e.flags||{})[k]);
            return f;
          })(),
          notes: String(e.notes || "").slice(0, 800),
          deleted: 0
        });
        n++;
      }
      Util.toast(`Imported ${n} entries`);
      if (onDone) onDone();
    } catch(err) {
      console.error(err);
      Util.toast("Import failed");
    }
  },

  // GDPR: one-click data deletion (5.1)
  async deleteAllData(moduleKey, onDone) {
    // Remove all storage keys for this module
    const ek = `${LS.e}_${moduleKey}`;
    const sk = `${LS.s}_${moduleKey}`;
    const ck = `${LS.c}_${moduleKey}`;
    try {
      localStorage.removeItem(ek);
      localStorage.removeItem(sk);
      localStorage.removeItem(ck);
    } catch {}
    // Also wipe Dexie IndexedDB if available
    if (typeof Dexie !== "undefined") {
      try { await Dexie.delete(`gi_platform_${moduleKey}`); } catch {}
    }
    Util.toast("All data deleted");
    if (onDone) setTimeout(onDone, 800);
  },

  _download(content, filename, type) {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 8000);
  }
};

// ── KPI CALCULATOR ───────────────────────────────────────────────
const KPI = {
  async compute(store) {
    const all = await store.getEntriesAll();
    const cutoff7 = new Date(); cutoff7.setDate(cutoff7.getDate()-6); cutoff7.setHours(0,0,0,0);
    const last7 = all.filter(e => new Date(e.ts) >= cutoff7);
    const dateSet7 = new Set(last7.map(e => e.dateKey));

    const keys = new Set(all.map(e => e.dateKey));
    let streak = 0;
    while (streak < 3650) {
      const d = new Date(); d.setDate(d.getDate()-streak);
      if (keys.has(Util.dateKeyLocal(d.toISOString()))) streak++;
      else break;
    }

    return { total: all.length, last7days: dateSet7.size, streak };
  }
};

// ── STORAGE MODE UI ──────────────────────────────────────────────
function updateStorageModeUI(mode) {
  const el = document.querySelector("#storageMode");
  if (el) el.textContent = mode;
  const dot = document.querySelector(".p-pill .p-dot");
  if (dot) {
    const colors = {
      indexeddb: "var(--storage-idb)",
      localstorage: "var(--storage-ls)",
      memory: "var(--storage-mem)"
    };
    dot.style.background = colors[mode] || colors.memory;
  }
}


// ── STORAGE HEALTH ───────────────────────────────────────────────
async function checkStorageQuota() {
  if (!navigator.storage?.estimate) return null;
  try {
    const { usage, quota } = await navigator.storage.estimate();
    const pct = quota > 0 ? (usage / quota) * 100 : 0;
    if (pct > 80) {
      const usedMB  = (usage  / 1048576).toFixed(1);
      const totalMB = (quota  / 1048576).toFixed(0);
      Util.toast(
        `Storage ${pct.toFixed(0)}% full (${usedMB}MB / ${totalMB}MB). Export your data in Settings to free space.`,
        10000
      );
    }
    return { usage, quota, pct };
  } catch(e) {
    console.warn("Storage estimate error:", e);
    return null;
  }
}

// ── PRIVATE / INCOGNITO DETECTION ───────────────────────────────
// Detects memory-only storage mode and surfaces a warning once.
// Called automatically by initStorage when falling back to memory.
let _privateWarnShown = false;
function _warnPrivateMode() {
  if (_privateWarnShown) return;
  _privateWarnShown = true;
  // Delay until DOM is ready
  setTimeout(() => {
    Util.toast(
      "Private/Incognito mode detected — your data will not be saved when you close this tab. Switch to a regular browser tab to keep your logs.",
      12000
    );
    // Style the storage mode indicator to signal private mode (keep text as "memory")
    const el = document.querySelector("#storageMode");
    if (el) {
      el.style.color = "var(--warn)";
      el.title = "Private/Incognito mode — data will not persist";
    }
  }, 2000);
}


// ── LAZY TAB HYDRATION (8.5) ─────────────────────────────────────
// Modules call: Platform.hydrateTab("insights", renderInsights)
// The render fn runs once when that tab is first activated.
// Subsequent tab switches are instant (DOM already populated).
const _hydratedTabs = new Set();
function hydrateTab(tabName, renderFn) {
  if (_hydratedTabs.has(tabName)) return;
  _hydratedTabs.add(tabName);
  Util.onIdle(() => {
    try { renderFn(); }
    catch(e) { console.warn(`[hydrateTab] ${tabName}:`, e); }
  });
}
function resetHydration(tabName) {
  // Call after data changes to force re-render on next tab visit
  _hydratedTabs.delete(tabName);
}

// ── PUBLIC API ───────────────────────────────────────────────────
return {
  Util,
  Stats,
  Charts,
  Calprotectin,
  LibRenderer,
  IO,
  KPI,
  Perf,
  Disclosure,
  initStorage,
  updateStorageModeUI,
  checkStorageQuota,
  initBroadcastSync,
  hydrateTab,
  resetHydration,
};

})();

// Make globally available
window.Platform = Platform;
