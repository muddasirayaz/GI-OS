#!/usr/bin/env node
/**
 * GI Platform — Build Script
 * ═══════════════════════════════════════════════════════════
 * Reads platform files + a module definition,
 * outputs a single standalone HTML file per condition.
 *
 * Usage:
 *   node build.js ibd     → builds dist/ibd-os.html
 *   node build.js ibs     → builds dist/ibs-os.html
 *   node build.js all     → builds all modules
 *
 * Version: 1.0.0
 * ═══════════════════════════════════════════════════════════
 */

const fs   = require("fs");
const path = require("path");

const PLATFORM_DIR = path.join(__dirname, "platform");
const MODULES_DIR  = path.join(__dirname, "modules");
const DIST_DIR     = path.join(__dirname, "dist");

// Read platform files once
function readPlatform() {
  const reportPath     = path.join(__dirname, "report.js");
  const onboardingPath = path.join(__dirname, "onboarding.js");
  const premiumPath    = path.join(__dirname, "premium.js");
  return {
    theme:      fs.readFileSync(path.join(PLATFORM_DIR, "platform-theme.css"),      "utf8"),
    components: fs.readFileSync(path.join(PLATFORM_DIR, "platform-components.css"), "utf8"),
    core:       fs.readFileSync(path.join(PLATFORM_DIR, "platform-core.js"),        "utf8"),
    report:     fs.existsSync(reportPath)     ? fs.readFileSync(reportPath,     "utf8") : "",
    onboarding: fs.existsSync(onboardingPath) ? fs.readFileSync(onboardingPath, "utf8") : "",
    premium:    fs.existsSync(premiumPath)    ? fs.readFileSync(premiumPath,    "utf8") : "",
  };
}

// Build one module
function buildModule(moduleKey) {
  const modulePath = path.join(MODULES_DIR, `module-${moduleKey}.js`);
  if (!fs.existsSync(modulePath)) {
    console.error(`Module not found: ${modulePath}`);
    process.exit(1);
  }

  const platform = readPlatform();
  const moduleCode = fs.readFileSync(modulePath, "utf8");

  // Extract module metadata from the module file
  // Modules export a META object at the top
  const metaMatch = moduleCode.match(/\/\*\s*META\s*([\s\S]*?)\*\//);
  const meta = {};
  if (metaMatch) {
    metaMatch[1].split("\n").forEach(line => {
      const m = line.match(/\s*@(\w+)\s+(.+)/);
      if (m) meta[m[1]] = m[2].trim();
    });
  }

  const title     = meta.title     || `GI OS — ${moduleKey.toUpperCase()}`;
  const accent    = meta.accent    || "#4fa8d5";
  const accent2   = meta.accent2   || "#7ecba1";
  const accentGlow= meta.accentGlow|| "rgba(79,168,213,.12)";
  const dexieUrl  = "https://cdn.jsdelivr.net/npm/dexie@3.2.4/dist/dexie.min.js";

  const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <title>${escHtml(title)}</title>
  <script src="${dexieUrl}"></script>
  <style>
/* ── PLATFORM THEME ─────────────────────────────────────── */
${platform.theme}

/* ── MODULE COLOR OVERRIDES ─────────────────────────────── */
:root {
  --accent:      ${accent};
  --accent2:     ${accent2};
  --accent-glow: ${accentGlow};
}

/* ── PLATFORM COMPONENTS ────────────────────────────────── */
${platform.components}
  </style>
</head>
<body>
<!-- Built by GI Platform build.js — do not edit directly -->
<!-- Module: ${moduleKey} | Built: ${new Date().toISOString()} -->

<!-- MODULE HTML — injected by module file -->
<div id="module-root"></div>
<div class="p-toast" id="toast" role="status" aria-live="polite"></div>

<script>
/* ── PLATFORM CORE ──────────────────────────────────────── */
${platform.core}

/* ── PREMIUM GATE ────────────────────────────────────────── */
${platform.premium}

/* ── CLINICIAN REPORT GENERATOR ─────────────────────────── */
${platform.report}

/* ── ONBOARDING ─────────────────────────────────────────── */
${platform.onboarding}

/* ── MODULE ─────────────────────────────────────────────── */
${moduleCode}
</script>
</body>
</html>`;

  if (!fs.existsSync(DIST_DIR)) fs.mkdirSync(DIST_DIR, { recursive: true });

  const outFile = path.join(DIST_DIR, `${moduleKey}-os.html`);
  fs.writeFileSync(outFile, html, "utf8");

  const kb = (fs.statSync(outFile).size / 1024).toFixed(1);
  console.log(`✓ Built: ${outFile} (${kb} KB)`);
  return outFile;
}

function escHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

function buildAll() {
  if (!fs.existsSync(MODULES_DIR)) { console.error("No modules/ directory found"); process.exit(1); }
  const modules = fs.readdirSync(MODULES_DIR)
    .filter(f => f.startsWith("module-") && f.endsWith(".js"))
    .map(f => f.replace("module-","").replace(".js",""));

  if (!modules.length) { console.log("No modules found in modules/"); return; }
  modules.forEach(buildModule);
  console.log(`\nBuilt ${modules.length} module(s).`);
}

// CLI
const arg = process.argv[2];
if (!arg) {
  console.log("Usage: node build.js <module-key|all>");
  console.log("  node build.js ibd");
  console.log("  node build.js ibs");
  console.log("  node build.js all");
  process.exit(0);
}

if (arg === "all") buildAll();
else buildModule(arg);
