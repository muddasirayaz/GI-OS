/* META
 * @title      Functional Dyspepsia OS — Clinical Tracker
 * @accent     #5b9bd5
 * @accent2    #c97dd4
 * @accentGlow rgba(91,155,213,.12)
 */

/**
 * Functional Dyspepsia OS — Module
 * ═══════════════════════════════════════════════════════════
 * Rome IV subtyping (EPS/PDS), Leuven Postprandial Distress
 * Score proxy, meal-symptom timing correlation, H. pylori
 * treatment tracking, accommodation reflex logging,
 * neuromodulator response tracking, library covering
 * Rome IV criteria, H. pylori, dietary approaches,
 * gut-brain axis in FD, pharmacotherapy, red flags.
 * ═══════════════════════════════════════════════════════════
 */

(() => {
"use strict";

const { Util, Stats, Charts, LibRenderer, IO, KPI, Perf, Disclosure, initStorage, updateStorageModeUI } = Platform;
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

const MODULE_KEY = "fd";

// Rome IV FD subtypes
const SUBTYPES = {
  eps: "EPS — Epigastric Pain Syndrome",
  pds: "PDS — Postprandial Distress Syndrome",
  overlap: "EPS + PDS Overlap"
};

// Meal-symptom timing (key feature of FD)
const MEAL_TIMING = [
  { id:"preprandial",  label:"Before meals",     desc:"Fasting / preprandial" },
  { id:"immediate",   label:"During / right after", desc:"Immediate postprandial (<30 min)" },
  { id:"delayed",     label:"1–3h after meal",   desc:"Delayed postprandial" },
  { id:"unrelated",   label:"Unrelated to meals",desc:"No meal correlation" },
  { id:"nocturnal",   label:"Nocturnal",         desc:"Waking from sleep" }
];

const FLAG_KEYS = [
  "largemeal","fattyfoods","spicyfoods","coffee","stress","anxiety",
  "poorsleep","skippedmed","nsaids","aspirin","alcohol","smoking","newmed"
];

const ALARM_FLAGS = [
  "dysphagia","unintentionalwl","hematemesis","melena","progressivevomit","newanemia","familyhx"
];

// Leuven Postprandial Distress Score (LPDS) proxy
// Validated instrument for FD symptom severity (Tack et al.)
// 5 core FD symptoms: postprandial fullness, early satiation, epigastric pain, epigastric burning, nausea
function calcLPDS(d) {
  let s = 0;
  s += Util.clamp(d.fullness,   0, 3);
  s += Util.clamp(d.satiety,    0, 3);
  s += Util.clamp(d.epipain,    0, 3);
  s += Util.clamp(d.epiburn,    0, 3);
  s += Util.clamp(d.nausea,     0, 3);
  s += Util.clamp(d.belching,   0, 3);
  return Math.min(18, s);
}

function interpLPDS(score) {
  if (score <= 2)  return { label:"Minimal symptoms",     cls:"ok",     color:"var(--ok)" };
  if (score <= 6)  return { label:"Mild FD",              cls:"ok",     color:"var(--ok)" };
  if (score <= 11) return { label:"Moderate FD",          cls:"warn",   color:"var(--warn)" };
  return                  { label:"Severe FD",            cls:"danger", color:"var(--danger)" };
}

function defaultFlags() {
  const f = {};
  [...FLAG_KEYS, ...ALARM_FLAGS].forEach(k => f[k] = false);
  return f;
}

function defaultDraft() {
  return {
    subtype: null, quality: null,
    fullness: 0, satiety: 0, epipain: 0, epiburn: 0, nausea: 0, belching: 0,
    mealTiming: null, mealSize: null,
    flags: defaultFlags(), notes: ""
  };
}

// ── LIBRARY ──────────────────────────────────────────────────────
const LIBRARY = (() => {
  const cards = [];
  const add = o => cards.push({ id:(o.cat+"::"+o.title).toLowerCase().replace(/[^a-z0-9]+/g,"-"), ...o });

  // ROME IV & DIAGNOSIS
  add({ cat:"Rome IV & Diagnosis", tag:"rome", title:"What Is Functional Dyspepsia — Rome IV Definition",
    why:"Functional dyspepsia (FD) is defined by Rome IV criteria as one or more of four cardinal symptoms originating in the gastroduodenal region, with no structural explanation on endoscopy. It is the most prevalent functional GI disorder after IBS, affecting 10–20% of the population.",
    bullets:[
      "Rome IV cardinal symptoms (one or more, present for >3 months, onset >6 months ago): bothersome postprandial fullness; bothersome early satiation; bothersome epigastric pain; bothersome epigastric burning. Symptoms must cause meaningful distress or lifestyle impact.",
      "Two subtypes with distinct pathophysiology: Postprandial Distress Syndrome (PDS) — postprandial fullness and/or early satiation, triggered by meals, impaired gastric accommodation is the dominant mechanism. Epigastric Pain Syndrome (EPS) — epigastric pain and/or burning, not exclusively postprandial, visceral hypersensitivity is dominant. Overlap (EPS+PDS) occurs in ~40% of patients.",
      "'Functional' is a mechanistic term, not dismissive: FD has demonstrable pathophysiology — impaired gastric accommodation (fundic relaxation failure after meals), antral hypomotility, duodenal hypersensitivity (to acid, fat, lipopolysaccharide), H. pylori-associated mucosal inflammation, and gut-brain axis sensitisation. These are measurable biological abnormalities, not 'psychosomatic' symptoms."
    ],
    action:"Know your FD subtype — EPS and PDS respond differently to treatment. PDS responds better to prokinetics (itopride, domperidone) and dietary modification (small frequent meals). EPS responds better to acid suppression (PPI, H2 blocker) and neuromodulators (TCAs). Subtype determines the pharmacological approach.",
    more:"FD and IBS overlap in 30–40% of patients — shared mechanisms include visceral hypersensitivity and gut-brain axis dysregulation. Presence of IBS does not exclude FD. Treat both symptom complexes specifically. The clinical assessment should identify which symptom domain is most distressing and target that first.",
    evidence:"Drossman, Gastroenterology 2016 (Rome IV); Tack et al., Gut 2006; Stanghellini et al., Gastroenterology 2016; Moayyedi et al., Aliment Pharmacol Ther 2004"
  });

  add({ cat:"Rome IV & Diagnosis", tag:"rome", title:"EPS vs PDS — Subtyping and What It Means",
    why:"Subtype identification changes treatment selection. Treating EPS with prokinetics or PDS with acid suppression alone gives inferior outcomes.",
    bullets:[
      "EPS (Epigastric Pain Syndrome): epigastric pain or burning, not exclusively postprandial, may be nocturnal, relieved by eating (sometimes) or antacids. Dominant mechanism: duodenal acid hypersensitivity, visceral hypersensitivity at the gastroduodenal junction. Best responds to: PPI (acid suppression), H2 blockers, low-dose tricyclic antidepressants (TCAs — mirtazapine, amitriptyline), psychological approaches.",
      "PDS (Postprandial Distress Syndrome): postprandial fullness lasting beyond meal, early satiation preventing completion of normal meal. Triggered by eating — especially large or fatty meals. Dominant mechanism: impaired gastric accommodation (fundic relaxation failure — the fundus fails to relax normally to accommodate food), antral hypomotility, slow gastric emptying. Best responds to: prokinetics (itopride, domperidone, erythromycin low-dose), dietary modification (small frequent low-fat meals), buspirone (fundus relaxant), acotiamide.",
      "Overlap (40% of patients): requires dual approach — address both accommodation failure and hypersensitivity. Mirtazapine is particularly useful in overlap as it addresses both visceral hypersensitivity AND improves gastric accommodation and stimulates appetite."
    ],
    action:"Log your predominant symptom pattern daily. The meal timing field (before / during-immediately-after / 1–3h after / unrelated) helps differentiate EPS from PDS over time. Discuss subtype with your gastroenterologist — it directly determines the medication strategy.",
    evidence:"Tack et al., Gut 2006; Talley & Ford, N Engl J Med 2015; Vanheel & Tack, Gut 2014"
  });

  // H. PYLORI
  add({ cat:"H. Pylori", tag:"hp", title:"H. Pylori in Functional Dyspepsia",
    why:"H. pylori eradication is the only treatment for FD with a clear disease-modifying mechanism — approximately 10% of FD patients achieve long-term symptom resolution after eradication. This is modest but the effect is durable and the treatment is finite.",
    bullets:[
      "Test-and-treat strategy: all patients with uninvestigated dyspepsia under 60 (or 55 in higher-prevalence regions) should receive H. pylori testing before empirical PPI therapy or endoscopy. Positive result → eradication therapy → reassess symptoms at 4–6 weeks.",
      "Testing methods: urea breath test (UBT) — most sensitive and specific for active infection; stool antigen test — comparable accuracy, non-invasive; serology — confirms past exposure, not active infection (remains positive post-eradication — do NOT use for confirmation of eradication). Endoscopic biopsy (CLO test / culture) — if endoscopy already performed.",
      "Eradication regimens (UK first line): Clarithromycin triple therapy — PPI + clarithromycin + amoxicillin × 7 days (where local clarithromycin resistance <15%). Bismuth quadruple — PPI + bismuth + metronidazole + tetracycline × 14 days (where resistance higher or triple failed). Confirm eradication with UBT or stool antigen ≥4 weeks after completing antibiotics and ≥2 weeks after stopping PPI."
    ],
    action:"Log H. pylori status and eradication treatment in the Notes or Serology tab. If you received eradication therapy, confirm a post-treatment test (UBT or stool antigen) was performed — many patients are not tested after treatment. Log antibiotic course, completion, and post-treatment result.",
    more:"The mechanism of FD symptom improvement after H. pylori eradication is debated but likely involves reduction of duodenal mucosal inflammation, improved acid secretion regulation, and microbiome restoration. The 10% response rate represents long-term remission — not just short-term improvement — which makes it clinically significant despite the modest number.",
    evidence:"Moayyedi et al., Cochrane Review 2006; Sugano et al., J Gastroenterol 2015 (Kyoto consensus); Talley & Ford, N Engl J Med 2015; NICE Dyspepsia Guidelines 2014"
  });

  // DIETARY MANAGEMENT
  add({ cat:"Dietary Management", tag:"diet", title:"Dietary Approach to Functional Dyspepsia",
    why:"Dietary modification is a cornerstone of FD management, particularly for PDS where meal composition and size directly trigger the accommodation reflex failure that causes symptoms.",
    bullets:[
      "Meal size and frequency: the most consistently effective dietary intervention in FD. Small, frequent meals (5–6 small meals vs 3 large) reduce the accommodation demand per meal. Large meals produce excessive gastric distension that exceeds the accommodation capacity of a dysfunctional fundus — producing fullness, early satiation, and nausea.",
      "Fat content: dietary fat delays gastric emptying (via CCK release) and increases duodenal hypersensitivity in FD patients. Low-fat meals improve gastric emptying and reduce postprandial symptoms significantly. Fat is the single most important macronutrient to reduce in FD-PDS.",
      "Eating rate: rapid eating reduces oropharyngeal and cephalic-vagal stimulation of gastric accommodation — slowing meal pace allows the accommodation reflex time to operate. Allow ≥20 minutes per meal. This also reduces aerophagia (air swallowing) which contributes to belching and upper bloating."
    ],
    action:"Trial small, low-fat, frequent meals for 4 weeks before concluding diet has no effect. Log meal size and timing using the Meal size field and flags. The Insights tab will show whether large-meal days consistently produce higher symptom scores.",
    more:"Capsaicin (chilli/hot sauce) may actually reduce FD symptoms with regular consumption via desensitisation of TRPV1 receptors in the gastric mucosa — the opposite of its acute triggering effect. This paradoxical desensitisation has been demonstrated in small RCTs. Spicy food avoidance should not be recommended categorically in FD without personal symptom tracking.",
    evidence:"Bisschops et al., Aliment Pharmacol Ther 2008; Pilichiewicz et al., Am J Gastroenterol 2009; Hammer & Talley, J Clin Gastroenterol 2018"
  });

  add({ cat:"Dietary Management", tag:"diet", title:"Low-FODMAP in FD — Evidence and Role",
    why:"Low-FODMAP reduces FD symptoms in some patients, but the mechanism and evidence are distinct from IBS.",
    bullets:[
      "Evidence: Staudacher et al. and subsequent work suggest low-FODMAP improves symptoms in FD, likely by reducing the osmotic load and fermentation products that sensitise the duodenum. Effect size is smaller than in IBS but clinically meaningful in overlap patients.",
      "The mechanism in FD: fructose and fructans trigger duodenal hypersensitivity through multiple mechanisms — osmotic distension, microbiome-derived metabolites, and direct activation of duodenal sensory neurons. This is distinct from the colonic fermentation mechanism in IBS.",
      "Practical approach: if FD symptoms persist despite small low-fat meals, a 4-week modified low-FODMAP trial targeting fructans (wheat, onion, garlic) and fructose is reasonable. Full low-FODMAP protocol as in IBS is usually unnecessary — selective fructan reduction is often sufficient."
    ],
    action:"If trialling low-FODMAP in FD: focus specifically on reducing wheat, onion, and garlic (highest fructan sources) and monitor symptom response over 4 weeks. Log dietary changes in Notes. Full FODMAP restriction adds complexity without proportional benefit in most FD patients.",
    evidence:"Halmos et al., Gastroenterology 2014 (FD subgroup); Vanheel & Tack, Gut 2014; Tack & Talley, Nat Rev Gastroenterol Hepatol 2013"
  });

  // PHARMACOTHERAPY
  add({ cat:"Pharmacotherapy", tag:"meds", title:"Acid Suppression in FD — PPIs and H2 Blockers",
    why:"PPIs are the most widely prescribed treatment for FD despite modest evidence — understanding their role and limitations helps avoid inappropriate long-term use.",
    bullets:[
      "Evidence: PPIs are superior to placebo in FD but the effect size is modest — NNT approximately 9 (Moayyedi et al. 2004 Cochrane review). Effect is more consistent in EPS than PDS. Mechanism: reduce duodenal acid load, which reduces duodenal hypersensitivity and visceral pain sensitisation.",
      "H2 blockers (ranitidine, famotidine): comparable to PPIs in FD efficacy and may be preferable for on-demand use given faster onset. Famotidine is the preferred agent post-ranitidine withdrawal (NDMA contamination 2020).",
      "Important: acid suppression treats EPS symptoms (epigastric pain/burning). It does not address impaired gastric accommodation — the dominant mechanism in PDS. PDS patients often do not respond meaningfully to PPIs alone."
    ],
    action:"If on long-term PPI for FD: annual review with your gastroenterologist is appropriate. If PDS-predominant without epigastric pain/burning, discuss whether acid suppression is your primary treatment or whether prokinetic therapy should be added or substituted.",
    evidence:"Moayyedi et al., Cochrane Review 2004; Talley & Ford, N Engl J Med 2015; Fischbach et al., Am J Gastroenterol 2012"
  });

  add({ cat:"Pharmacotherapy", tag:"meds", title:"Neuromodulators in FD — TCAs and Mirtazapine",
    why:"Low-dose antidepressants are disease-modifying in FD — they act on the gut-brain axis, not as antidepressants at these doses. They are underused and frequently not offered until late in the treatment course.",
    bullets:[
      "Mechanism: TCAs (amitriptyline, nortriptyline) at low doses (10–50mg) modulate visceral hypersensitivity via central and peripheral serotonin/noradrenaline pathways. They are NOT being used as antidepressants — the dose is sub-antidepressant. Do not confuse the two uses.",
      "Mirtazapine: particularly valuable in FD. Acts as 5-HT3 antagonist (reduces nausea) + H1 antihistamine (improves sleep + appetite) + α2 antagonist (increases noradrenaline and serotonin). Specifically shown to improve gastric accommodation in FD patients (Tack et al. 2009). Dose: 7.5–15mg at night. Also addresses weight loss and early satiation — particularly useful in patients who have lost weight from FD.",
      "Buspirone: 5-HT1A agonist. Acts specifically on the gastric fundus to improve accommodation. Small RCT (Tack et al.) showed significant improvement in postprandial fullness, early satiation, and overall FD severity vs placebo. Dose: 10mg three times daily before meals."
    ],
    action:"Log neuromodulator medication and dose in Notes. If starting a TCA or mirtazapine: give it 4–6 weeks before assessing response — central sensitisation modulation takes time. Track symptom scores weekly using this app during the trial period.",
    more:"Patient education is critical: many patients refuse neuromodulators when told they are 'antidepressants.' The framing should be: 'These medications work on the gut-brain axis at doses much lower than used for depression. Your gut has a nervous system, and this medication resets how your gut's nervous system perceives normal sensations.'",
    evidence:"Tack et al., Clin Gastroenterol Hepatol 2009 (mirtazapine); Tack et al., Gastroenterology 2012 (buspirone); van Kerkhoven et al., Am J Gastroenterol 2008 (TCAs); Ford et al., Gut 2017 (meta-analysis)"
  });

  add({ cat:"Pharmacotherapy", tag:"meds", title:"Prokinetics in FD — Itopride, Domperidone, Acotiamide",
    why:"Prokinetics target gastric dysmotility — the dominant mechanism in PDS. They are the most physiologically rational pharmacotherapy for PDS-predominant FD.",
    bullets:[
      "Acotiamide: acetylcholinesterase inhibitor + muscarinic M1/M2 antagonist. Approved in Japan for FD (Phase III trial: Matsueda et al., Gut 2012). Improves postprandial fullness, early satiation, and upper bloating. Dose: 100mg three times daily before meals. Not widely available outside Japan but may be obtainable.",
      "Itopride (Ganaton): dopamine D2 antagonist + acetylcholinesterase inhibitor. Improves antral motility and gastric emptying. RCT evidence in FD (Holtmann et al., N Engl J Med 2006 — positive phase II; phase III results mixed). Dose: 50mg three times daily before meals. Available in parts of Europe, Asia.",
      "Domperidone: peripheral D2 antagonist. Improves gastric emptying. Cardiac QTc prolongation risk — baseline ECG required, avoid in patients with prolonged QTc or on QT-prolonging drugs. Maximum 10mg three times daily, short-term use."
    ],
    action:"If PDS-predominant: discuss prokinetic therapy with your gastroenterologist, specifying the subtype. Log medication name and dose in Notes. Track postprandial fullness and early satiation scores (the two PDS core symptoms) as the primary outcome measure.",
    evidence:"Matsueda et al., Gut 2012; Holtmann et al., N Engl J Med 2006; Talley & Ford, N Engl J Med 2015; Tack et al., Gut 2006"
  });

  // GUT-BRAIN AXIS
  add({ cat:"Gut-Brain Axis", tag:"gutbrain", title:"Gut-Brain Axis in Functional Dyspepsia",
    why:"FD is a disorder of gut-brain interaction. Understanding the mechanism helps patients engage with psychological and neuromodulator treatments rather than seeing them as dismissive.",
    bullets:[
      "Gastric accommodation reflex: when food enters the stomach, the vagus nerve signals the fundus to relax — expanding to receive the meal without pressure rise. In FD-PDS, this accommodation reflex is blunted or absent — the fundus fails to relax, meal-induced distension activates mechanoreceptors at normal meal volumes, producing premature fullness and nausea.",
      "Duodenal sensitisation: recent evidence (Vanheel & Tack, Gut 2014; Walker et al.) shows that duodenal mucosal eosinophilia and mast cell activation are present in FD. These cause low-grade inflammation and sensitise afferent neurons — amplifying normal stimuli (acid, fat, distension) into pain signals. This is a genuine mucosal abnormality, not psychological.",
      "Stress and FD: psychological stress acutely impairs gastric accommodation via HPA axis activation and alters duodenal permeability. Anxiety is both a driver of FD and a consequence — vicious cycle. Gut-directed CBT and hypnotherapy have RCT evidence in FD."
    ],
    action:"Log stress and anxiety flags consistently. After 30+ entries, the correlation between stress flag days and symptom scores reveals the gut-brain contribution to your FD. This data supports the case for psychological co-treatment as physiologically rational, not as a psychological crutch.",
    evidence:"Vanheel & Tack, Gut 2014; Van Oudenhove et al., Gastroenterology 2011; Tack & Talley, Nat Rev Gastroenterol Hepatol 2013; Koloski et al., Gut 2012"
  });

  // RED FLAGS
  add({ cat:"Red Flags", tag:"safety", title:"Red Flags in Dyspepsia — When to Investigate Urgently",
    why:"Functional dyspepsia is a diagnosis of exclusion. These features mandate upper GI endoscopy regardless of age or prior investigation.",
    bullets:[
      "Absolute indications for urgent endoscopy: dysphagia (progressive difficulty swallowing — any), unintentional weight loss >5% in 3 months, hematemesis (vomiting blood), melena (black tarry stool), progressive vomiting (inability to retain food), iron deficiency anemia without alternative explanation.",
      "Age threshold: NICE 2015 recommends urgent endoscopy for all patients ≥55 with new unexplained dyspepsia. The risk of upper GI malignancy increases substantially in this age group. Do not manage on empirical PPI alone without investigation.",
      "Family history: first-degree relative with gastric cancer warrants lower threshold for endoscopy regardless of age. H. pylori eradication in this group is particularly important."
    ],
    action:"Any alarm feature = contact your gastroenterologist the same day or urgently. Do not adjust PPI dose or try dietary changes first when alarm features are present. These features cannot be attributed to functional dyspepsia without endoscopic exclusion.",
    evidence:"NICE Dyspepsia and GORD Guidelines 2014; Vakil et al., Am J Gastroenterol 2006; Ford et al., BMJ 2013"
  });

  return { cards };
})();

const LIB_CATS = ["all", ...new Set(LIBRARY.cards.map(c => c.cat))];

// ── STATE ────────────────────────────────────────────────────────
const State = {
  store: null, premium: false,
  draft: defaultDraft(), lastEntry: null,
  libCat: "all", libQuery: ""
};

// ── HTML ─────────────────────────────────────────────────────────
function renderHTML() {
  document.getElementById("module-root").innerHTML = `
<div class="p-app">
  <header class="p-header">
    <div class="p-brand">
      <div class="p-logo-dot" aria-hidden="true"></div>
      <div>
        <h1 class="p-brand-name">Functional Dyspepsia OS</h1>
        <div class="p-brand-sub">Symptom tracker</div>
      </div>
    </div>
    <div class="p-header-right">
      <div class="p-pill">🔥 <b id="kpiStreak">0</b>&nbsp;·&nbsp;7d <b id="kpi7d">0</b>&nbsp;·&nbsp;<b id="kpiTotal">0</b> total</div>
    </div>
  </header>

  <nav class="p-nav">
    <div class="p-tabs" role="tablist">
      <button class="p-tab" role="tab" id="tab-log"      aria-selected="true"  data-tab="log"      type="button">Log</button>
      <button class="p-tab" role="tab" id="tab-history"  aria-selected="false" data-tab="history"  type="button">History</button>
      <button class="p-tab" role="tab" id="tab-library"  aria-selected="false" data-tab="library"  type="button">Library</button>
      <button class="p-tab" role="tab" id="tab-insights" aria-selected="false" data-tab="insights" type="button">Insights</button>
    </div>
  </nav>

  <!-- LOG -->
  <section id="view-log">
    <div class="p-grid two">
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>How are you today?</h2><p>Takes about a minute</p></div>
          <div class="p-kpis"><div class="p-kpi">Date <b id="todayLabel"></b></div></div>
        </div>
        <div class="p-card-b">

          <!-- Step 1: Subtype -->
          <div id="stepSubtype">
            <div class="p-labelrow"><div class="p-lbl">First — what's your FD pattern?</div><div class="p-hint">saved permanently</div></div>
            <div class="p-seg" id="subtypeSegs">
              ${Object.entries(SUBTYPES).map(([k,v]) =>
                `<button class="p-segBtn" type="button" data-sub="${k}" aria-pressed="false" style="font-size:11px;">${v.split(" — ")[0]}</button>`
              ).join("")}
            </div>
            <div id="subtypeConfirm" class="hidden" style="margin-top:8px;">
              <div class="p-callout" style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
                <span>Subtype: <b id="subtypeLabel">—</b></span>
                <button class="p-btn ghost sm" type="button" id="btnChangeSub">Change</button>
              </div>
            </div>
          </div>

          <!-- Step 2: Overall day -->
          <div id="stepQuality" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">How was today overall?</div><div class="p-hint">required</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-quality="great" aria-pressed="false">Great</button>
              <button class="p-segBtn" type="button" data-quality="okay"  aria-pressed="false">Okay</button>
              <button class="p-segBtn" type="button" data-quality="rough" aria-pressed="false">Rough</button>
            </div>
          </div>

          <!-- Step 3: Core FD symptoms -->
          <div id="stepSymptoms" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Any symptoms today?</div><div class="p-hint">tap all that apply</div></div>

            <!-- PDS symptoms -->
            <div class="p-labelrow" style="margin-top:8px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;color:var(--accent2);">PDS symptoms</div></div>

            <div class="p-labelrow" style="margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Postprandial fullness</div><div class="p-hint" id="fullnessLabel">none</div></div>
            <div class="p-chips" data-symptom="fullness">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:10px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Early satiation</div><div class="p-hint" id="satietyLabel">none</div></div>
            <div class="p-chips" data-symptom="satiety">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate — unable to finish</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe — minimal intake</button>
            </div>

            <div class="p-labelrow" style="margin-top:10px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Nausea</div><div class="p-hint" id="nauseaLabel">none</div></div>
            <div class="p-chips" data-symptom="nausea">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <!-- EPS symptoms -->
            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;color:var(--accent);">EPS symptoms</div></div>

            <div class="p-labelrow" style="margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Epigastric pain</div><div class="p-hint" id="epipainLabel">none</div></div>
            <div class="p-chips" data-symptom="epipain">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:10px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Epigastric burning</div><div class="p-hint" id="epiburnLabel">none</div></div>
            <div class="p-chips" data-symptom="epiburn">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:10px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Belching / bloating</div><div class="p-hint" id="belchingLabel">none</div></div>
            <div class="p-chips" data-symptom="belching">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>
          </div>

          <!-- Step 4: Meal timing -->
          <div id="stepMealTiming" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">When do symptoms tend to peak?</div><div class="p-hint">tap to select</div></div>
            <div style="display:flex;flex-direction:column;gap:6px;">
              ${MEAL_TIMING.map(mt => `
              <button class="p-mealBtn" type="button" data-timing="${mt.id}" aria-selected="false">
                <div style="font-weight:700;font-size:13px;">${Util.esc(mt.label)}</div>
                <div style="font-size:11px;color:var(--muted2);font-family:var(--font-mono);">${Util.esc(mt.desc)}</div>
              </button>`).join("")}
            </div>

            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Meal size today</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-meal="small"  aria-pressed="false" style="font-size:11px;">Small meals</button>
              <button class="p-segBtn" type="button" data-meal="normal" aria-pressed="false" style="font-size:11px;">Normal meals</button>
              <button class="p-segBtn" type="button" data-meal="large"  aria-pressed="false" style="font-size:11px;">Large meals</button>
            </div>
          </div>

          <!-- Step 5: Triggers & flags -->
          <div id="stepTriggers" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Any triggers today?</div><div class="p-hint">mark all that apply</div></div>
            <div class="p-chips">
              <button class="p-chip warn" type="button" data-flag="largemeal"   aria-pressed="false">Large meal</button>
              <button class="p-chip warn" type="button" data-flag="fattyfoods"  aria-pressed="false">High-fat foods</button>
              <button class="p-chip"      type="button" data-flag="spicyfoods"  aria-pressed="false">Spicy foods</button>
              <button class="p-chip warn" type="button" data-flag="coffee"      aria-pressed="false">Coffee</button>
              <button class="p-chip warn" type="button" data-flag="stress"      aria-pressed="false">Stress / anxiety</button>
              <button class="p-chip warn" type="button" data-flag="poorsleep"   aria-pressed="false">Poor sleep</button>
              <button class="p-chip warn" type="button" data-flag="nsaids"      aria-pressed="false">NSAIDs</button>
              <button class="p-chip warn" type="button" data-flag="aspirin"     aria-pressed="false">Aspirin</button>
              <button class="p-chip"      type="button" data-flag="alcohol"     aria-pressed="false">Alcohol</button>
              <button class="p-chip"      type="button" data-flag="smoking"     aria-pressed="false">Smoking</button>
              <button class="p-chip"      type="button" data-flag="skippedmed"  aria-pressed="false">Skipped medication</button>
              <button class="p-chip"      type="button" data-flag="newmed"      aria-pressed="false">New medication</button>
            </div>

            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;">
              <div class="p-lbl" style="font-size:11px;color:var(--danger);">Alarm features</div>
              <div class="p-hint">urgent if new</div>
            </div>
            <div class="p-chips">
              <button class="p-chip danger" type="button" data-flag="dysphagia"         aria-pressed="false">Dysphagia</button>
              <button class="p-chip danger" type="button" data-flag="unintentionalwl"   aria-pressed="false">Weight loss</button>
              <button class="p-chip danger" type="button" data-flag="hematemesis"       aria-pressed="false">Hematemesis</button>
              <button class="p-chip danger" type="button" data-flag="melena"            aria-pressed="false">Melena</button>
              <button class="p-chip danger" type="button" data-flag="progressivevomit"  aria-pressed="false">Progressive vomiting</button>
              <button class="p-chip danger" type="button" data-flag="newanemia"         aria-pressed="false">New anemia</button>
            </div>

            <div id="alarmAlert" class="p-callout danger hidden" style="margin-top:10px;">
              <b>Alarm feature flagged.</b> These features cannot be attributed to functional dyspepsia without upper GI endoscopy. Contact your gastroenterologist today.
            </div>

            <div class="p-section">
              <div class="p-labelrow"><div class="p-lbl">Notes</div><div class="p-hint"><span id="noteCount">0</span>/600</div></div>
              <textarea id="notes" class="p-note" maxlength="600" placeholder="Specific meals, timing, medication doses, observations (optional)"></textarea>
            </div>
          </div>

          <!-- Actions -->
          <div id="stepActions" class="p-section hidden">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnSave" disabled>Done</button>
              <button class="p-btn" type="button" id="btnRepeat" disabled>Repeat last</button>
              <button class="p-btn ghost" type="button" id="btnReset">Reset</button>
            </div>
          </div>
        </div>
      </div>

      <!-- RIGHT -->
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>Today's Guidance</h2><p>Personalized to what you logged</p></div>
          
        </div>
        <div class="p-card-b">
          <div id="guidance" class="p-callout">Select your FD subtype and complete the log. Guidance and LPDS score will appear here.</div>
          <div id="inlineCard" class="p-section" style="display:none;"></div>

          <div id="scorePanel" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">FD Symptom Score (LPDS)</div><div class="p-hint">0–18 scale</div></div>
            <div class="p-scoreWrap">
              <div class="p-scoreBig" id="scoreBig">—</div>
              <div class="p-scoreSubLabel">Leuven Postprandial Distress Score</div>
            </div>
            <div id="scoreInterp" class="p-callout" style="margin-top:8px;"></div>
          </div>

          <!-- Rome IV quick reference -->
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Rome IV FD criteria</div></div>
            <div style="font-size:12px;color:var(--muted);line-height:1.8;">
              <div><b style="color:var(--accent2);">PDS:</b> Postprandial fullness · Early satiation</div>
              <div><b style="color:var(--accent);">EPS:</b> Epigastric pain · Epigastric burning</div>
              <div style="margin-top:6px;font-family:var(--font-mono);font-size:10px;color:var(--muted2);">≥3 months · onset ≥6 months ago · no structural cause</div>
            </div>
          </div>

          <!-- Meal timing quick ref -->
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Meal-timing clues</div></div>
            <div style="font-size:12px;color:var(--muted);line-height:1.8;">
              <div>Immediate postprandial → PDS (accommodation failure)</div>
              <div>Fasting / nocturnal → EPS (acid hypersensitivity)</div>
              <div>Delayed 1–3h → gastroparesis overlap to consider</div>
              <div>Unrelated to meals → EPS, or consider alternative diagnosis</div>
            </div>
          </div>

          <div class="p-section">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnReport">Clinician report</button>
              <button class="p-btn" type="button" id="btnExportCsv">Export CSV</button>
              <button class="p-btn" type="button" id="btnExportJson">Export JSON</button>
              <button class="p-btn" type="button" id="btnImport">Import</button>
              <input id="importFile" type="file" accept="application/json" class="sr">
            </div>
          </div>
          <div class="p-section">
            <div class="p-premRow" id="premiumCta" style="cursor:pointer;">
              <div class="p-premLabel" id="premStatusLabel">Unlock Premium — trend analytics · trigger correlation · next steps</div>
              <div style="font-family:var(--font-mono);font-size:10px;letter-spacing:.08em;color:#f5c842;">UPGRADE ✦</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- HISTORY -->
  <section id="view-history" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>History</h2><p>Most recent first</p></div>
        <div class="p-rowBtns" style="margin:0;">
          <button class="p-btn" type="button" id="btnExportCsv2">Export CSV</button>
          <button class="p-btn" type="button" id="btnExportJson2">Export JSON</button>
        </div>
      </div>
      <div class="p-card-b"><div class="p-list" id="histList"></div></div>
    </div>
  </section>

  <!-- LIBRARY -->
  <section id="view-library" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Clinical Library</h2><p>Rome IV · H. pylori · dietary management · pharmacotherapy · gut-brain · red flags</p></div>
        <div style="display:flex;gap:10px;align-items:center;">
          <div class="p-kpis"><div class="p-kpi">Cards <b id="kpiCards">0</b></div></div>
          <input id="libSearch" type="search" class="p-search" placeholder="Search EPS, PDS, mirtazapine, H. pylori…">
        </div>
      </div>
      <div class="p-card-b">
        <div class="p-libCats" id="libCats"></div>
        <div class="p-libGrid" id="libGrid"></div>
      </div>
    </div>
  </section>

  <!-- INSIGHTS -->
  <section id="view-insights" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Insights</h2><p>Free: symptom distribution · Premium: trends + meal-size correlation + next steps</p></div>
        <button class="p-btn" type="button" id="btnRefresh" style="margin:0;">Refresh</button>
      </div>
      <div class="p-card-b">
        <div id="insightsBody" class="p-callout">Log at least 5 entries to unlock insights.</div>
        <div class="p-section">
          <div class="p-chartWrap"><canvas id="chartLPDS" height="200"></canvas><div class="p-chartMeta">LPDS score trend (last 28 entries)</div></div>
        </div>
        <div id="premiumPanel" class="p-section hidden">
          <div class="p-grid two">
            <div class="p-chartWrap"><canvas id="chartFullness" height="200"></canvas><div class="p-chartMeta">Postprandial fullness (last 30 entries)</div></div>
            <div class="p-chartWrap"><canvas id="chartPain" height="200"></canvas><div class="p-chartMeta">Epigastric pain (last 30 entries)</div></div>
          </div>
          <div class="p-section p-grid two">
            <div class="p-callout" id="mealBox"></div>
            <div class="p-callout" id="triggerBox"></div>
          </div>
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Ranked next steps</div></div>
            <div class="p-list" id="nextStepsList"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>`;
}

// ── CSS additions for meal timing buttons ─────────────────────────
function injectStyles() {
  const s = document.createElement("style");
  s.textContent = `
    .p-mealBtn {
      padding: 10px 14px; border-radius: 12px;
      border: 1px solid var(--line); background: rgba(255,255,255,.02);
      color: var(--muted); cursor: pointer; text-align: left;
      transition: border-color .12s, background .12s;
    }
    .p-mealBtn[aria-selected="true"] {
      border-color: rgba(91,155,213,.5);
      background: rgba(91,155,213,.10);
      color: var(--ink);
    }
  `;
  document.head.appendChild(s);
}

// ── LOGIC ────────────────────────────────────────────────────────
function setSubtypeUI(sub) {
  State.draft.subtype = sub;
  $$("[data-sub]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.sub === sub)));
  const lbl = $("#subtypeLabel"); if (lbl) lbl.textContent = SUBTYPES[sub] || sub;
  $("#subtypeConfirm")?.classList.toggle("hidden", !sub);
}

function updateProgress() {
  const d = State.draft;
  const hasSub = !!State.draft.subtype;
  const hasQ   = !!d.quality;

  $("#stepQuality")?.classList.toggle("hidden", !hasSub);
  $("#stepSymptoms")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepMealTiming")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepTriggers")?.classList.toggle("hidden", !(hasSub && hasQ));
  $("#stepActions")?.classList.toggle("hidden", !(hasSub && hasQ));

  // INVARIANT: red flags always visible — never gated on premium. MDR compliance.
  const hasAlarm = ALARM_FLAGS.some(k => d.flags?.[k]);
  $("#alarmAlert")?.classList.toggle("hidden", !hasAlarm);

  const canSave = hasSub && hasQ;
  const btnSave = $("#btnSave"); if (btnSave) btnSave.disabled = !canSave;
  const btnRepeat = $("#btnRepeat"); if (btnRepeat) btnRepeat.disabled = !State.lastEntry;

  updateGuidance(d);
}


function renderInlineCard(cardTitle) {
  const container = document.getElementById("inlineCard");
  if (!container) return;

  const card = LIBRARY.cards.find(c => c.title === cardTitle);
  if (!card) { container.style.display = "none"; return; }

  container.style.display = "block";
  const safeTitle = card.title.split("—")[0].trim().replace(/'/g, "\'");

  const bulletsHTML = (card.bullets || []).map(b =>
    `<li style="font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:6px;">${b}</li>`
  ).join("");

  const moreHTML = card.more
    ? `<div style="font-size:12px;color:var(--muted2);line-height:1.5;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);">${card.more}</div>`
    : "";

  const evidenceHTML = card.evidence
    ? `<div style="font-size:11px;color:var(--muted2);font-family:var(--font-mono);margin-top:8px;line-height:1.5;">${card.evidence}</div>`
    : "";

  container.innerHTML = `
    <div style="border-left:3px solid var(--accent);padding-left:14px;margin-top:8px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px;">Your doctor says</div>
      <div style="font-size:15px;font-weight:600;color:var(--fg);margin-bottom:8px;">${card.title}</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;margin-bottom:10px;">${card.why}</div>
      ${bulletsHTML ? `<ul style="margin:0 0 10px 0;padding-left:16px;">${bulletsHTML}</ul>` : ""}
      ${card.action ? `
        <div style="padding:12px 14px;background:var(--surface2);border-radius:10px;margin-bottom:10px;">
          <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">What to do</div>
          <div style="font-size:13px;color:var(--fg);line-height:1.6;">${card.action}</div>
        </div>` : ""}
      ${moreHTML}
      ${evidenceHTML}
      <button type="button"
        style="font-size:12px;color:var(--accent);background:none;border:none;padding:4px 0 0 0;cursor:pointer;text-decoration:underline;display:block;margin-top:6px;"
        onclick="(function(){document.getElementById('tab-library')?.click();var s=document.getElementById('libSearch');if(s){s.value='${safeTitle}';s.dispatchEvent(new Event('input'));}})()">
        Browse all library cards →
      </button>
    </div>
  `;
}


function pickInlineCard(d) {
  if (d.flags?.largemeal) return "Acid Suppression in Functional Dyspepsia — PPIs, P-CABs, and When to Use Them";
  if (d.mealTiming === "immediate" || d.mealTiming === "delayed") return "Acid Suppression in Functional Dyspepsia — PPIs, P-CABs, and When to Use Them";
  if (d.flags?.stress) return "Acid Suppression in Functional Dyspepsia — PPIs, P-CABs, and When to Use Them";
  return "Acid Suppression in Functional Dyspepsia — PPIs, P-CABs, and When to Use Them";
}
function updateGuidance(d) {
  const g = $("#guidance"), sp = $("#scorePanel");
  if (!g) return;

  if (!State.draft.subtype || !d.quality) {
    g.innerHTML = "Select your FD subtype and complete the log. Guidance and LPDS score will appear here.";
    sp?.classList.add("hidden"); return;
  }

  // Premium gate — guidance is gated after 14-day trial
  if (!PremiumGate.isPremium()) {
    PremiumGate.showGuidanceGate(g, MODULE_KEY, () => updateGuidance(d));
    sp?.classList.add("hidden");
    return;
  }


  const score = calcLPDS(d);
  const interp = interpLPDS(score);

  const sub = State.subtype;
  let assessment = "";
  if (d.mealTiming === "immediate") {
    assessment = `Your log shows immediate postprandial symptoms — onset during or right after eating. This strongly suggests impaired gastric accommodation, the PDS mechanism. Your stomach isn't relaxing adequately to receive the meal, producing early fullness, nausea, and bloating at or just after the first few bites.`;
  } else if (d.mealTiming === "delayed") {
    assessment = `Your log shows delayed postprandial symptoms — onset 1–3 hours after eating. This may suggest delayed gastric emptying or a duodenal hypersensitivity mechanism. If this is your consistent pattern, a gastric emptying study is worth discussing with your gastroenterologist.`;
  } else if (d.mealTiming === "preprandial" || d.mealTiming === "nocturnal") {
    assessment = `Your log shows fasting or nocturnal symptoms — occurring before meals or overnight. This pattern points toward the EPS mechanism, epigastric pain syndrome — acid hypersensitivity and visceral pain that isn't meal-triggered. EPS responds differently to treatment than postprandial FD.`;
  } else if (d.flags?.largemeal) {
    assessment = `A large meal is flagged today. Large meal volume is the single most consistent trigger for PDS-pattern FD — the stomach's accommodation reflex has a limited capacity, and exceeding it produces the fullness, early satiation, and nausea characteristic of PDS.`;
  } else if (d.quality === "great") {
    assessment = `Good day logged. Note what was different — meal size, meal timing, stress level, fat content. Patterns across good days are as clinically useful as patterns across bad ones.`;
  } else {
    assessment = `Your log shows a moderate FD day. Consistent tracking of meal-symptom timing is the most clinically useful thing you can do right now — it determines which subtype and which treatment approach applies to you.`;
  }

  let plan = "";
  if (d.mealTiming === "immediate" || sub === "pds" || d.flags?.largemeal) {
    plan = `For postprandial fullness and early satiation — the PDS pattern — small, frequent meals are the most consistently effective dietary change. Five or six small meals rather than three large ones reduces the accommodation demand each time you eat. Eat slowly — the accommodation reflex takes time to operate. Low-fat meals clear the stomach faster. Prokinetic therapy (acotiamide, or domperidone if available) directly targets the accommodation reflex and is worth discussing with your gastroenterologist if dietary changes are insufficient.`;
  } else if (d.mealTiming === "preprandial" || d.mealTiming === "nocturnal" || sub === "eps") {
    plan = `For fasting or nocturnal epigastric pain — the EPS pattern — acid suppression is the primary pharmacological approach. A PPI taken 30–60 minutes before your largest meal is the starting point. For nighttime pain specifically, an H2 blocker at bedtime such as famotidine is often more effective than a PPI for nocturnal symptoms. Low-dose tricyclic antidepressants at night — prescribed at a tenth of the antidepressant dose — reduce visceral hypersensitivity and have good evidence for EPS. Discuss this with your gastroenterologist.`;
  } else if (d.flags?.stress) {
    plan = `Stress acutely impairs gastric accommodation — this is a direct physiologic effect through HPA axis activation, not coincidence. Mind-body approaches have evidence specifically for FD. Neuromodulator therapy — low-dose antidepressant prescribed for its gut effects, not for depression — is appropriate in stress-driven FD and can be discussed with your gastroenterologist.`;
  } else {
    plan = `Log meal-symptom timing consistently for the next 2 weeks. The pattern will clarify whether you are EPS, PDS, or mixed — and that distinction determines which medications are likely to help. Bring your Clinician Report to your next gastroenterology appointment.`;
  }

  g.innerHTML = `
    <div style="margin-bottom:12px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Assessment</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${assessment}</div>
    </div>
    <div>
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Plan</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${plan}</div>
    </div>
    <div style="font-size:11px;color:var(--muted2);margin-top:10px;border-top:1px solid var(--border);padding-top:8px;">This is patient education based on your logged data — not a medical diagnosis. Discuss any changes to your treatment with your gastroenterologist.</div>
  `;

  if (sp) {
    sp.classList.remove("hidden");
    const big = $("#scoreBig");
    if (big) { big.textContent = score; big.style.color = interp.color; }
    const si = $("#scoreInterp");
    if (si) {
      si.className = "p-callout " + (interp.cls||"");
      const tips = {
        ok:     "Good symptom control. Continue current management strategy.",
        warn:   "Moderate symptoms. Review triggers and meal composition.",
        danger: "Significant FD burden. Discuss pharmacotherapy escalation with your gastroenterologist."
      };
      si.innerHTML = `<b>${interp.label}:</b> ${tips[interp.cls]||""}`;
    }
  }
}

function resetDraft() {
  State.draft = defaultDraft();
  if (State.draft.subtype) State.draft.subtype = State.draft.subtype;
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$("[data-symptom] .p-chip").forEach(c => c.setAttribute("aria-pressed", String(c.dataset.level==="0")));
  $$(".p-mealBtn").forEach(b => b.setAttribute("aria-selected","false"));
  $$("[data-meal]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$(".p-chip[data-flag]").forEach(c => c.setAttribute("aria-pressed","false"));
  const notes = $("#notes"); if (notes) notes.value = "";
  const nc = $("#noteCount"); if (nc) nc.textContent = "0";
  ["fullnessLabel","satietyLabel","nauseaLabel","epipainLabel","epiburnLabel","belchingLabel"].forEach(id => {
    const el = $(`#${id}`); if (el) el.textContent = "none";
  });
  updateProgress();
}

async function save() {
  try {
    if ($("#btnSave")) $("#btnSave").disabled = true;
    const d = State.draft;
    const entry = {
      ts: Util.nowISO(), dateKey: Util.dateKeyLocal(),
      subtype: State.draft.subtype, quality: d.quality,
      fullness: Util.clamp(d.fullness,0,3), satiety: Util.clamp(d.satiety,0,3),
      epipain: Util.clamp(d.epipain,0,3), epiburn: Util.clamp(d.epiburn,0,3),
      nausea: Util.clamp(d.nausea,0,3), belching: Util.clamp(d.belching,0,3),
      lpds: calcLPDS(d),
      mealTiming: d.mealTiming||null, mealSize: d.mealSize||null,
      flags: {...d.flags}, notes: (d.notes||"").slice(0,600), deleted: 0
    };
    const last = State.lastEntry;
    if (last) {
      const dt = Math.abs(+new Date(entry.ts) - +new Date(last.ts));
      if (dt < 90000 && entry.quality === last.quality && entry.lpds === last.lpds) {
        Util.toast("Duplicate entry blocked"); return;
      }
    }
    const saved = await Perf.time("entry-save", async () => { await State.store.addEntry(entry); });
    State.lastEntry = saved;
    Util.toast("Entry saved");
  // First-time upgrade nudge at 14 entries
  const allEntries = await State.store.getEntriesAll();
  if (allEntries.length === 14 && !PremiumGate.isPremium()) {
    setTimeout(() => PremiumGate.showPaywall(MODULE_KEY, () => {
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      Util.toast("Premium unlocked ✦");
    }), 1200);
  }
    resetDraft();
    if (State.draft.subtype) setSubtypeUI(State.draft.subtype); // restore subtype after reset
    await refreshKPIs();
  } catch(err) { console.error(err); Util.toast("Save failed"); }
  finally { updateProgress(); }
}

async function repeatLast() {
  const last = State.lastEntry || await State.store.getLastEntry();
  if (!last) return;
  State.lastEntry = last;
  const d = State.draft;
  if (last.subtype) setSubtypeUI(last.subtype);
  d.quality = last.quality;
  d.fullness = last.fullness||0; d.satiety = last.satiety||0;
  d.epipain = last.epipain||0; d.epiburn = last.epiburn||0;
  d.nausea = last.nausea||0; d.belching = last.belching||0;
  d.mealTiming = last.mealTiming||null; d.mealSize = last.mealSize||null;
  d.flags = {...defaultFlags(),...(last.flags||{})};
  d.notes = last.notes||"";
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.quality===d.quality)));
  const syncSym = (sym,val) => {
    const w=$(`.p-chips[data-symptom="${sym}"]`);
    if(w) w.querySelectorAll(".p-chip").forEach(c=>c.setAttribute("aria-pressed",String(Number(c.dataset.level)===val)));
  };
  ["fullness","satiety","epipain","epiburn","nausea","belching"].forEach(s=>syncSym(s,d[s]));
  if (d.mealTiming) $$(".p-mealBtn").forEach(b=>b.setAttribute("aria-selected",String(b.dataset.timing===d.mealTiming)));
  if (d.mealSize) $$("[data-meal]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.meal===d.mealSize)));
  $$(".p-chip[data-flag]").forEach(c=>c.setAttribute("aria-pressed",String(!!d.flags[c.dataset.flag])));
  const notes=$("#notes"); if(notes){notes.value=d.notes;const nc=$("#noteCount");if(nc)nc.textContent=String(d.notes.length);}
  updateProgress();
  Util.toast("Repeated last entry");
}

async function refreshKPIs() {
  const kpis = await KPI.compute(State.store);
  const el=(id,v)=>{const e=$(id);if(e)e.textContent=String(v);};
  el("#kpiTotal",kpis.total); el("#kpi7d",kpis.last7days); el("#kpiStreak",kpis.streak);
}

async function renderHistory() {
  const list=$("#histList"); if(!list) return;
  const all=(await State.store.getEntriesAll()).sort((a,b)=>b.ts.localeCompare(a.ts));
  if(!all.length){list.innerHTML=`<div class="p-callout">No entries yet.</div>`;return;}
  list.innerHTML=all.slice(0,80).map(e=>{
    const interp=interpLPDS(e.lpds||0);
    const sub=SUBTYPES[e.subtype]||e.subtype||"—";
    const timing=MEAL_TIMING.find(m=>m.id===e.mealTiming)?.label||"—";
    const flags=FLAG_KEYS.filter(k=>e.flags?.[k]).slice(0,4);
    const alarms=ALARM_FLAGS.filter(k=>e.flags?.[k]);
    return `<div class="p-item">
      <div class="p-itemTop">
        <div class="ts">${Util.esc(e.dateKey)}</div>
        <div class="q">${Util.esc(sub.split(" — ")[0])} · ${Util.esc(e.quality||"")} · LPDS: <span style="color:${Util.cssVal(interp.color)}">${Util.esc(String(e.lpds||0))}</span></div>
      </div>
      <div class="p-itemBody">Fullness: <b>${Util.esc(Util.levelToText(e.fullness))}</b> · Satiation: <b>${Util.esc(Util.levelToText(e.satiety))}</b> · Pain: <b>${Util.esc(Util.levelToText(e.epipain))}</b> · Timing: <b>${Util.esc(timing)}</b></div>
      ${alarms.length?`<div class="p-itemBody" style="color:var(--danger);margin-top:4px;font-family:var(--font-mono);font-size:11px;">⚠ ${Util.esc(alarms.join(", "))}</div>`:""}
      ${flags.length?`<div class="p-itemBody" style="margin-top:4px;font-family:var(--font-mono);font-size:11px;color:var(--muted2);">${Util.esc(flags.join(", "))}</div>`:""}
      ${e.notes?`<div class="p-itemBody" style="margin-top:4px;">${Util.esc(e.notes)}</div>`:""}
    </div>`;
  }).join("");
}

async function renderInsights() {
  const all=(await State.store.getEntriesAll()).sort((a,b)=>a.ts.localeCompare(b.ts));
  const body=$("#insightsBody");
  if(all.length<5){if(body)body.textContent=`Log at least 5 entries. (${all.length} so far)`;return;}
  if(body)body.innerHTML=`<b>${all.length}</b> total entries logged.`;

  const last28=all.slice(-28);
  const lpdsVals=last28.map(e=>e.lpds||0);
  const lc=$("#chartLPDS"); if(lc) Charts.drawLine(lc,lpdsVals,{maxV:18,lc:"rgba(91,155,213,.8)",dc:"rgba(91,155,213,.9)"});

  if(!State.premium){$("#premiumPanel")?.classList.add("hidden");return;}
  const pp=$("#premiumPanel"); pp?.classList.remove("hidden");
  const last30=all.slice(-30);

  const fullVals=last30.map(e=>e.fullness||0);
  const painVals=last30.map(e=>e.epipain||0);
  const fc=$("#chartFullness"); if(fc) Charts.drawLine(fc,fullVals,{maxV:3,lc:"rgba(201,125,212,.8)",dc:"rgba(201,125,212,.9)"});
  const pc=$("#chartPain"); if(pc) Charts.drawLine(pc,painVals,{maxV:3,lc:"rgba(232,164,74,.8)",dc:"rgba(232,164,74,.9)"});

  // Meal size correlation
  const mb=$("#mealBox");
  if(mb){
    const large=last30.filter(e=>e.mealSize==="large");
    const small=last30.filter(e=>e.mealSize==="small");
    const largeMean=large.length?Stats.mean(large.map(e=>e.lpds||0)):null;
    const smallMean=small.length?Stats.mean(small.map(e=>e.lpds||0)):null;
    mb.className="p-callout"+(largeMean&&smallMean&&largeMean>smallMean+2?" warn":"");
    mb.innerHTML=`<b>Meal size correlation:</b><br>Large meals: avg LPDS ${largeMean!==null?largeMean.toFixed(1):"insufficient data"}<br>Small meals: avg LPDS ${smallMean!==null?smallMean.toFixed(1):"insufficient data"}${largeMean&&smallMean&&largeMean>smallMean+1?" — large meals produce meaningfully higher symptom scores":""}`;
  }

  // Trigger analysis
  const tb=$("#triggerBox");
  if(tb){
    const cnt={}; FLAG_KEYS.forEach(k=>cnt[k]=0);
    last30.forEach(e=>FLAG_KEYS.forEach(k=>{if(e.flags?.[k])cnt[k]++;}));
    const top=Object.entries(cnt).sort((a,b)=>b[1]-a[1]).filter(([,v])=>v>0).slice(0,3);
    tb.className="p-callout";
    tb.innerHTML=top.length
      ?`<b>Top triggers (30 days):</b><br>${top.map(([k,v])=>`${Util.esc(k)}: ${v} days`).join("<br>")}`
      :"No consistent triggers flagged.";
  }

  // Next steps
  const ns=$("#nextStepsList");
  if(ns){
    const steps=[];
    const alarmDay=all.slice(-14).find(e=>ALARM_FLAGS.some(k=>e.flags?.[k]));
    if(alarmDay) steps.push({p:"danger",t:"Alarm feature logged in past 14 days. Requires endoscopy if not already performed. Contact gastroenterologist."});
    const meanLPDS=Stats.mean(last30.map(e=>e.lpds||0));
    if(meanLPDS>=10) steps.push({p:"warn",t:`Mean LPDS ${meanLPDS.toFixed(1)} — significant FD burden. If not on neuromodulator therapy, discuss low-dose amitriptyline or mirtazapine with your gastroenterologist.`});
    const largeDays=last30.filter(e=>e.mealSize==="large").length;
    if(largeDays>=10) steps.push({p:"warn",t:`Large meals on ${largeDays}/30 days. Small frequent meals are the most consistently effective lifestyle intervention for FD-PDS. Trial 5 small meals/day for 4 weeks.`});
    const stressDays=last30.filter(e=>e.flags?.stress).length;
    if(stressDays>=12) steps.push({p:"warn",t:`Stress flagged ${stressDays}/30 days. Gut-directed CBT or hypnotherapy have RCT evidence in FD. Discuss with your gastroenterologist.`});
    const nsaidDays=last30.filter(e=>e.flags?.nsaids||e.flags?.aspirin).length;
    if(nsaidDays>=5) steps.push({p:"warn",t:`NSAIDs/aspirin flagged ${nsaidDays}/30 days. These directly damage the gastric mucosa and worsen dyspeptic symptoms. Discuss alternatives with your prescriber.`});
    if(!steps.length) steps.push({p:"ok",t:"No high-priority signals. Continue logging — patterns become clearer over time."});
    const colors={danger:"var(--danger)",warn:"var(--warn)",ok:"var(--ok)"};
    ns.innerHTML=steps.map(s=>`<div class="p-item"><div class="p-itemBody"><b style="color:${colors[s.p]}">${s.p.toUpperCase()}:</b> ${Util.esc(s.t)}</div></div>`).join("");
  }
}

function showTab(tab) {
  ["log","history","library","insights"].forEach(t=>{
    $("#tab-"+t)?.setAttribute("aria-selected",String(t===tab));
    $("#view-"+t)?.classList.toggle("hidden",t!==tab);
  });
  if(tab==="history") renderHistory();
  if(tab==="library"){
    LibRenderer.renderCats($("#libCats"),LIB_CATS,State.libCat,cat=>{State.libCat=cat;renderLibrary();});
    renderLibrary();
  }
  if(tab==="insights") renderInsights();
}

function renderLibrary() {
  const grid=$("#libGrid"); if(!grid) return;
  const kpi=$("#kpiCards"); if(kpi) kpi.textContent=String(LIBRARY.cards.length);
  LibRenderer.render(grid,LibRenderer.filterCards(LIBRARY.cards,State.libCat,State.libQuery));
}

// ── EVENTS ───────────────────────────────────────────────────────
function wireEvents() {
  $$(".p-tab").forEach(b=>b.addEventListener("click",()=>showTab(b.dataset.tab)));

  $$("[data-sub]").forEach(b=>b.addEventListener("click",()=>{
    setSubtypeUI(b.dataset.sub);
    State.store.setSetting("subtype",b.dataset.sub);
    updateProgress();
    setTimeout(()=>Util.scroll($("#stepQuality")),80);
  }));
  $("#btnChangeSub")?.addEventListener("click",()=>{
    State.draft.subtype=null;
    $$("[data-sub]").forEach(b=>b.setAttribute("aria-pressed","false"));
    $("#subtypeConfirm")?.classList.add("hidden");
    updateProgress();
  });

  $$("[data-quality]").forEach(b=>b.addEventListener("click",()=>{
    State.draft.quality=b.dataset.quality;
    $$("[data-quality]").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
    updateProgress();
    setTimeout(()=>Util.scroll($("#stepSymptoms")),80);
  }));

  $$("[data-symptom]").forEach(wrap=>wrap.addEventListener("click",e=>{
    const btn=e.target.closest(".p-chip"); if(!btn) return;
    const sym=wrap.dataset.symptom, level=Number(btn.dataset.level);
    State.draft[sym]=Util.clamp(level,0,3);
    wrap.querySelectorAll(".p-chip").forEach(c=>c.setAttribute("aria-pressed",String(c===btn)));
    const lmap={fullness:"fullnessLabel",satiety:"satietyLabel",nausea:"nauseaLabel",epipain:"epipainLabel",epiburn:"epiburnLabel",belching:"belchingLabel"};
    const lel=lmap[sym]?$(`#${lmap[sym]}`):null;
    if(lel) lel.textContent=Util.levelToText(level);
    updateProgress();
  }));

  $$(".p-mealBtn").forEach(b=>b.addEventListener("click",()=>{
    State.draft.mealTiming=b.dataset.timing;
    $$(".p-mealBtn").forEach(x=>x.setAttribute("aria-selected",String(x===b)));
    updateProgress();
  }));

  $$("[data-meal]").forEach(b=>b.addEventListener("click",()=>{
    State.draft.mealSize=b.dataset.meal;
    $$("[data-meal]").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
    updateProgress();
  }));

  $$(".p-chip[data-flag]").forEach(b=>b.addEventListener("click",()=>{
    const k=b.dataset.flag;
    State.draft.flags[k]=!State.draft.flags[k];
    b.setAttribute("aria-pressed",String(State.draft.flags[k]));
    updateProgress();
  }));

  const notes=$("#notes");
  if(notes) notes.addEventListener("input",()=>{
    State.draft.notes=notes.value;
    const nc=$("#noteCount"); if(nc) nc.textContent=String(notes.value.length);
  });

  $("#btnSave")?.addEventListener("click",save);
  $("#btnRepeat")?.addEventListener("click",repeatLast);
  $("#btnReset")?.addEventListener("click",resetDraft);

  // INVARIANT: clinician report is always free — do not gate on PremiumGate.isPremium()
  $("#btnReport")?.addEventListener("click", () => Report.generate(MODULE_KEY));

  const doCSV=()=>IO.exportCSV(State.store,MODULE_KEY,[...FLAG_KEYS,...ALARM_FLAGS]);
  const doJSON=()=>IO.exportJSON(State.store,MODULE_KEY);
  ["#btnExportCsv","#btnExportCsv2"].forEach(s=>$(s)?.addEventListener("click",doCSV));
  ["#btnExportJson","#btnExportJson2"].forEach(s=>$(s)?.addEventListener("click",doJSON));
  const btnImport=$("#btnImport"),importFile=$("#importFile");
  if(btnImport&&importFile){
    btnImport.addEventListener("click",()=>importFile.click());
    importFile.addEventListener("change",async e=>{
      const f=e.target.files?.[0]; if(!f) return;
      await IO.importJSON(f,State.store,[...FLAG_KEYS,...ALARM_FLAGS],async()=>{await refreshKPIs();await renderHistory();});
      e.target.value="";
    });
  }

  $("#libSearch")?.addEventListener("input",e=>{State.libQuery=e.target.value||"";renderLibrary();});
  $("#btnRefresh")?.addEventListener("click",renderInsights);

  // Premium CTA — wire paywall
  $("#premiumCta")?.addEventListener("click", () => {
    PremiumGate.showPaywall(MODULE_KEY, () => {
      const sl = $("#premStatusLabel");
      if (sl) sl.textContent = "✦ Premium active";
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      renderInsights?.();
      Util.toast("Premium unlocked ✦");
    });
  });

}

// ── BOOT ─────────────────────────────────────────────────────────
async function boot() {
  injectStyles();
  renderHTML();
  const todayEl=$("#todayLabel"); if(todayEl) todayEl.textContent=Util.dateKeyLocal();

  const {store,mode}=await initStorage(MODULE_KEY);
  State.store=store;
  if (typeof GIOSNotifications !== "undefined") GIOSNotifications.init("fd", "FD OS");
  updateStorageModeUI(mode);

  const savedPremium=await store.getSetting("premium",false);
  State.premium=!!savedPremium;
  const m=$("#modeLabel"); if(m) m.textContent=State.premium?"Premium":"Free";

  const savedSubtype=await store.getSetting("subtype",null);
  if(savedSubtype) setSubtypeUI(savedSubtype);

  State.lastEntry=await store.getLastEntry();
  wireEvents();
  resetDraft();
  await refreshKPIs();

  LibRenderer.renderCats($("#libCats"),LIB_CATS,State.libCat,cat=>{State.libCat=cat;renderLibrary();});
  renderLibrary();

  Util.toast("Functional Dyspepsia OS ready");
}

boot();
})();
