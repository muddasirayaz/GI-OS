/* META
 * @title      GERD & Barrett's OS — Clinical Tracker
 * @accent     #c97dd4
 * @accent2    #e09b4f
 * @accentGlow rgba(201,125,212,.12)
 */

/**
 * GERD & Barrett's OS — Module
 * ═══════════════════════════════════════════════════════════
 * GERD symptom scoring, PPI adherence, Barrett's surveillance
 * interval tracking, alarm feature detection, dietary triggers,
 * positional/timing patterns.
 * ═══════════════════════════════════════════════════════════
 */

(() => {
"use strict";

const { Util, Stats, Charts, LibRenderer, IO, KPI, Perf, Disclosure, initStorage, updateStorageModeUI } = Platform;
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

const MODULE_KEY = "gerd";

const FLAG_KEYS = [
  "latemeal","fatty","spicy","citrus","coffee","alcohol","chocolate","mint",
  "carbonated","stress","lyingdown","tightclothing","nsaids","skippedppi"
];

const ALARM_FLAGS = [
  "dysphagia","odynophagia","hematemesis","melena","unintentionalwl","progressivevomiting","anemia"
];

// Barrett's surveillance intervals (BSG/ACG 2023)
const SURVEILLANCE = {
  none:       { label:"No Barrett's",           interval:"No Barrett's surveillance required" },
  shortseg:   { label:"Short segment (<3cm)",   interval:"Endoscopy every 3–5 years" },
  longseg:    { label:"Long segment (≥3cm)",    interval:"Endoscopy every 2–3 years" },
  lgg:        { label:"Low-grade dysplasia",    interval:"Endoscopy every 6–12 months or ablation" },
  hgg:        { label:"High-grade dysplasia",   interval:"Endoscopic therapy (RFA/EMR) — urgent" },
  post_rfa:   { label:"Post-ablation",          interval:"Endoscopy at 3 months, then annually × 2, then every 3 years" }
};

// GERD-Q proxy (Jones et al., Aliment Pharmacol Ther 2009)
// 4 domains: heartburn, regurgitation, sleep disruption, nocturnal/timing
function calcGERDQ(d) {
  let s = 0;
  s += Util.clamp(d.heartburn, 0, 3);
  s += Util.clamp(d.regurg, 0, 3);
  s += Math.round((Util.clamp(d.sleep, 0, 3) / 3) * 2);
  if (d.flags?.lyingdown)  s += 1;
  if (d.flags?.skippedppi) s += 1;
  return Math.min(12, s);
}

function interpGERDQ(score) {
  if (score <= 2) return { label:"Well controlled",       cls:"ok",     color:"var(--ok)" };
  if (score <= 5) return { label:"Partially controlled",  cls:"warn",   color:"var(--warn)" };
  if (score <= 8) return { label:"Poorly controlled",     cls:"warn",   color:"var(--warn)" };
  return                 { label:"Severely uncontrolled", cls:"danger", color:"var(--danger)" };
}

function defaultFlags() {
  const f = {};
  [...FLAG_KEYS, ...ALARM_FLAGS].forEach(k => f[k] = false);
  return f;
}
function defaultDraft() {
  return {
    quality: null, heartburn: 0, regurg: 0,
    sleep: 0, throat: 0, cough: 0, nausea: 0,
    ppiTaken: null, flags: defaultFlags(), notes: ""
  };
}

// ── LIBRARY ──────────────────────────────────────────────────────
const LIBRARY = (() => {
  const cards = [];
  const add = o => cards.push({ id:(o.cat+"::"+o.title).toLowerCase().replace(/[^a-z0-9]+/g,"-"), ...o });

  // PPI THERAPY
  add({ cat:"PPI Therapy", tag:"ppi", title:"PPIs — Mechanism and Correct Use",
    why:"PPIs are the most effective GERD treatment and the only medication shown to heal erosive esophagitis. They are also among the most incorrectly used medications in clinical practice — timing errors account for most treatment failures.",
    bullets:[
      "Mechanism: irreversibly inhibit the H+/K+ ATPase (proton pump) in parietal cells. Require activation in the acidic secretory canaliculus of actively secreting cells. Half-life 1–2 hours but functional duration 24–48h. Only active pumps are inhibited — new pumps are synthesized continuously over 24h.",
      "Critical timing: take 30–60 minutes BEFORE a meal. Food stimulates parietal cell proton pump expression. PPIs must be circulating when pumps activate post-meal. PPIs taken on an empty stomach without an imminent meal, or at bedtime, have dramatically reduced efficacy — this is the most common cause of 'PPI failure' in practice.",
      "Twice-daily for breakthrough: add a second dose 30–60 min before the evening meal — NOT at bedtime. Evening meal pre-treatment suppresses the post-meal pump surge driving nocturnal acid breakthrough."
    ],
    action:"Take PPI immediately on waking, then eat breakfast 30–60 minutes later. Set a phone alarm. If you've missed the pre-meal window, take it anyway. Log adherence using the Skipped PPI flag — the Insights tab will show correlation between missed doses and symptom scores.",
    more:"Comparative efficacy: esomeprazole and pantoprazole show marginally superior acid suppression in meta-analyses. Omeprazole (generic) is clinically equivalent for most GERD. The choice between agents matters less than consistent pre-meal timing. Long-term safety: well-established modest risks — fracture (dose-dependent), hypomagnesemia (check Mg if on high-dose long-term), C. diff (modest), B12 malabsorption. Annual review of PPI necessity is appropriate best practice.",
    evidence:"Jones et al., Aliment Pharmacol Ther 2009; Katz et al., Am J Gastroenterol 2022; Hatlebakk et al., Scand J Gastroenterol 1999"
  });

  add({ cat:"PPI Therapy", tag:"ppi", title:"PPI Non-Response — What to Do",
    why:"True PPI-refractory GERD is less common than believed. Most 'failures' are timing, adherence, or diagnosis failures.",
    bullets:[
      "Before escalating: confirm correct timing (30–60 min pre-meal), confirm twice-daily trial (before breakfast AND before evening meal), confirm minimum 8-week adequate trial at standard dose.",
      "PPI-refractory differentials: non-erosive reflux disease (NERD) with mucosal sensitivity without acid excess; functional heartburn — visceral hypersensitivity mimicking GERD, does not respond to acid suppression; bile reflux — alkaline, not acid-driven; eosinophilic esophagitis — may present identically to GERD.",
      "Investigation: 24h pH-impedance study on PPI (confirms whether ongoing acid or non-acid reflux events cause symptoms), high-resolution manometry (excludes achalasia), repeat endoscopy if Barrett's history."
    ],
    action:"If symptoms persist on twice-daily correctly-timed PPI for 8 weeks, do not simply increase dose — discuss pH-impedance testing with your gastroenterologist. This test, done on PPI, identifies the true mechanism of residual symptoms.",
    evidence:"ACG GERD Guidelines 2022; Tutuian & Castell, Am J Gastroenterol 2006; Zerbib et al., Gut 2012"
  });

  add({ cat:"PPI Therapy", tag:"ppi", title:"PPI De-Escalation — When and How",
    why:"Long-term PPI use should be periodically reviewed. Many patients on chronic PPIs can step down or stop with lifestyle measures.",
    bullets:[
      "Appropriate de-escalation candidates: patients on PPI for uncomplicated GERD, no erosive esophagitis on endoscopy, no Barrett's esophagus, asymptomatic on PPI for >3 months.",
      "Barrett's esophagus: PPI continuation is recommended indefinitely regardless of symptoms. PPIs reduce cancer risk in Barrett's (meta-analysis: 71% risk reduction for esophageal adenocarcinoma, Singh et al., Gut 2014). Do NOT de-escalate PPI in Barrett's patients.",
      "Step-down approach: attempt dose reduction (full dose → half dose) before stopping. If stopping, taper over 4 weeks rather than abrupt cessation — abrupt stop causes acid rebound hypersecretion that mimics worsening GERD and leads to re-starting unnecessarily."
    ],
    action:"If Barrett's is confirmed: PPI is indefinite — do not stop without gastroenterologist advice. For uncomplicated GERD: discuss annual 'PPI holiday' attempt with your physician. Taper over 4 weeks if stopping.",
    evidence:"Singh et al., Gut 2014; Hvid-Jensen et al., N Engl J Med 2011; Inadomi et al., Am J Gastroenterol 2009"
  });

  // BARRETT'S
  add({ cat:"Barrett's Esophagus", tag:"barretts", title:"Barrett's — What It Is and Why It Matters",
    why:"Barrett's esophagus is the most significant complication of chronic GERD. Understanding it accurately reduces anxiety and guides informed decision-making.",
    bullets:[
      "Definition: replacement of normal squamous esophageal epithelium with specialized intestinal metaplasia (columnar epithelium with goblet cells) at the gastroesophageal junction. Caused by chronic acid and bile exposure driving epithelial transformation.",
      "Cancer risk: Barrett's itself has an annual progression to esophageal adenocarcinoma (EAC) of approximately 0.1–0.3% per year (non-dysplastic Barrett's). This is low in absolute terms — the population risk of EAC is not dramatically elevated by non-dysplastic Barrett's. The key risk escalation occurs with dysplasia.",
      "Risk stratification: non-dysplastic Barrett's → low risk, surveillance endoscopy. Low-grade dysplasia (LGD) → moderate risk, ablation or intensified surveillance. High-grade dysplasia (HGD) → high risk, endoscopic therapy (RFA/EMR) urgently indicated. EAC → oncologic management."
    ],
    action:"Know your Barrett's status, segment length, and dysplasia grade. Log your last endoscopy date and next due date in the Surveillance tab. PPI is lifelong in Barrett's. The anxiety around Barrett's is often disproportionate to actual cancer risk — most patients with non-dysplastic Barrett's never develop cancer.",
    more:"Esophageal adenocarcinoma incidence has risen substantially since the 1970s, tracking the obesity epidemic. Barrett's is found in approximately 1.6% of the population, but EAC develops in only a minority. The majority of EAC cases occur without a known Barrett's diagnosis — reinforcing the importance of endoscopic surveillance in known Barrett's patients.",
    evidence:"Hvid-Jensen et al., N Engl J Med 2011; Wani et al., Gastroenterology 2015; Fitzgerald et al., Gut 2014 (BSG guidelines); Shaheen et al., Gastroenterology 2011"
  });

  add({ cat:"Barrett's Esophagus", tag:"barretts", title:"Barrett's Surveillance Intervals",
    why:"Surveillance endoscopy intervals are precisely defined by evidence-based guidelines. Missing intervals increases cancer detection failure risk; attending unnecessarily creates procedure risk and cost.",
    bullets:[
      "Non-dysplastic, short segment (<3cm): endoscopy every 3–5 years (BSG 2023). Some guidelines allow 5-year interval for very short segment (<1cm) with two prior negative biopsies.",
      "Non-dysplastic, long segment (≥3cm): endoscopy every 2–3 years.",
      "Low-grade dysplasia (LGD) confirmed by two expert pathologists: endoscopic ablation (RFA preferred) or endoscopy every 6–12 months. Current BSG guidance favors ablation for confirmed LGD given significant progression risk.",
      "High-grade dysplasia (HGD): endoscopic therapy (RFA ± EMR for visible lesions) — not surveillance. Same-treatment-year management required.",
      "Post-ablation (complete eradication of intestinal metaplasia, CEIM): endoscopy at 3 months, then 6 months, then annually × 2 years, then every 3 years."
    ],
    action:"Log your Barrett's grade and last/next endoscopy in the Surveillance section. Set a reminder using this app when next endoscopy is due. Missing surveillance intervals is the most preventable cause of late-stage diagnosis.",
    evidence:"Fitzgerald et al., Gut 2014; ASGE Standards of Practice 2019; Shaheen et al., Gastroenterology 2011; BSG Barrett's Guidelines 2023"
  });

  add({ cat:"Barrett's Esophagus", tag:"barretts", title:"Ablation — RFA and Endoscopic Therapy",
    why:"Radiofrequency ablation (RFA) is the most evidence-supported endoscopic treatment for Barrett's with dysplasia and can eliminate Barrett's metaplasia entirely.",
    bullets:[
      "RFA mechanism: controlled thermal energy delivered via endoscopic balloon (circumferential) or focal catheter destroys the metaplastic epithelium to a depth of 500–1000µm — sufficient to ablate Barrett's while preserving submucosa. Regenerating epithelium is squamous if acid suppression is adequate.",
      "AIM Dysplasia trial (Shaheen et al., N Engl J Med 2009): RFA achieved complete eradication of dysplasia in 91% (HGD) and 81% (LGD) at 12 months vs 23% and 19% for sham. Landmark result establishing RFA as standard of care.",
      "EMR (endoscopic mucosal resection): used for visible nodular lesions — provides histologic specimen (unlike RFA which destroys tissue). Often precedes RFA for visible lesions. Combined EMR + RFA for nodular Barrett's with HGD/EAC is current standard."
    ],
    action:"If RFA is recommended: PPI twice daily is mandatory starting 2 weeks before ablation and for 2 months after each session. Adequate acid suppression is required for normal squamous re-epithelialisation. Log PPI adherence meticulously in the weeks around ablation.",
    more:"Recurrence after CEIM occurs in approximately 10–20% at 5 years — predominantly intestinal metaplasia recurrence rather than dysplasia. This is why post-ablation surveillance continues long-term. Recurrence is most common at the gastroesophageal junction and is usually manageable with focal re-treatment.",
    evidence:"Shaheen et al., N Engl J Med 2009; Haidry et al., Gastroenterology 2015; HALO RFA trial; BSG Barrett's Guidelines 2023"
  });

  // LIFESTYLE
  add({ cat:"Lifestyle Measures", tag:"lifestyle", title:"Dietary Triggers — Evidence and Reality",
    why:"Dietary modification is a cornerstone of GERD management, but the evidence is more nuanced than generic 'avoid spicy food' advice.",
    bullets:[
      "Well-evidenced triggers (consistent across studies): late evening meals within 2–3 hours of lying down, large meal volumes (distension increases transient lower esophageal sphincter relaxation — TLESR — frequency), alcohol (reduces LES pressure and increases acid secretion), coffee (increases acid secretion and esophageal sensitivity), high-fat meals (delay gastric emptying, increase TLESR).",
      "Commonly blamed, evidence weaker: citrus, tomatoes, chocolate, mint. These are individually variable — some patients have clear triggering, others none. Log them using flags and let your own data show whether they consistently precede symptoms.",
      "Not consistently evidenced: 'spicy food' as a class. Capsaicin may actually reduce esophageal sensitivity with regular exposure. Carbonated beverages: mild acid burden, inconsistent symptom effect."
    ],
    action:"Use the trigger flags consistently for 4 weeks. The Insights tab will identify which flags most consistently precede high symptom days for you specifically. Generic elimination diets are less useful than your own longitudinal data.",
    evidence:"Katz et al., Am J Gastroenterol 2022; Kaltenbach et al., Arch Intern Med 2006; Ness-Jensen et al., Gut 2016"
  });

  add({ cat:"Lifestyle Measures", tag:"lifestyle", title:"Positional Measures — The Evidence",
    why:"Positioning changes have some of the strongest lifestyle evidence in GERD, yet are underused.",
    bullets:[
      "Head of bed elevation (15–20cm / 6–8 inches): reduces nocturnal acid exposure significantly in RCTs. Not pillow elevation (which flexes the torso and can worsen reflux) — elevation of the bed head itself using bed risers or a wedge mattress topper.",
      "Left lateral decubitus sleeping position: strong evidence for reduced nocturnal acid exposure vs right lateral or supine. When on the right side, the gastroesophageal junction is submerged in gastric contents. Left side keeps GEJ above the gastric pool.",
      "Timing of meals: nothing to eat within 2–3 hours of lying down. This is the most consistently evidenced dietary intervention in GERD. Late evening meals are a major driver of nocturnal symptoms and Barrett's progression risk."
    ],
    action:"If nocturnal symptoms are present: bed head elevation + left lateral position is the first-line non-pharmacological intervention. Log lying-down correlation using the Lying flat flag. If late meals are flagged consistently, a 7pm meal cutoff on weeknights is a practical target.",
    evidence:"Katz et al., Am J Gastroenterol 2022; Stanciu & Bennett, Scand J Gastroenterol 1977; Hamilton et al., Am J Gastroenterol 1988"
  });

  add({ cat:"Lifestyle Measures", tag:"lifestyle", title:"Weight Loss and GERD",
    why:"Obesity is one of the strongest independent risk factors for GERD, Barrett's, and esophageal adenocarcinoma. Weight loss is disease-modifying.",
    bullets:[
      "Mechanism: increased intraabdominal pressure with obesity directly increases TLESRs, impairs the antireflux barrier, and increases gastric pressure gradient. Central obesity (visceral fat) has stronger association with GERD than total BMI.",
      "Evidence: even modest weight loss (5–10% body weight) significantly reduces GERD symptoms and esophageal acid exposure. Ness-Jensen et al. (Gut 2016): in a large population cohort, women who lost weight had significantly reduced reflux symptoms independent of initial BMI.",
      "Barrett's and cancer risk: obesity is an independent risk factor for Barrett's and EAC beyond its effect on GERD symptoms. Metabolic syndrome and central adiposity are associated with Barrett's even without severe GERD symptoms."
    ],
    action:"For overweight or obese patients: weight reduction is the most clinically meaningful lifestyle intervention for GERD and Barrett's progression risk — more impactful than any dietary restriction. Log weight trend in Notes if tracking.",
    evidence:"Ness-Jensen et al., Gut 2016; Hampel et al., Ann Intern Med 2005; Lagergren et al., Gut 2016"
  });

  // ALARM FEATURES
  add({ cat:"Alarm Features", tag:"alarm", title:"GERD Alarm Features — When to Investigate Urgently",
    why:"GERD has a set of alarm features that mandate urgent investigation to exclude malignancy, serious complication, or alternative diagnosis.",
    bullets:[
      "Dysphagia (difficulty swallowing): progressive dysphagia — initially to solids, then liquids — is the most important alarm feature. In a GERD patient, it may indicate peptic stricture (benign) or esophageal adenocarcinoma (urgent). Any new dysphagia requires endoscopy within 2 weeks.",
      "Odynophagia (pain on swallowing): suggests ulceration, severe esophagitis, or infectious esophagitis (candida, CMV, HSV — particularly in immunosuppressed patients).",
      "Hematemesis / melena: upper GI bleeding — requires urgent or emergency evaluation depending on severity. In GERD patients, may indicate esophageal ulceration, Mallory-Weiss tear, or malignancy.",
      "Unintentional weight loss: red flag for malignancy in any GI patient. Any GERD patient with weight loss >5% requires urgent upper GI investigation.",
      "Progressive vomiting: concerning for gastric outlet obstruction or malignancy."
    ],
    action:"If any alarm feature is flagged in this app: contact your gastroenterologist the same day or present to urgent care. Do not wait for a scheduled appointment. These features are not explained by GERD alone until investigated.",
    evidence:"NICE Dyspepsia and GORD Guidelines 2014; Vakil et al., Am J Gastroenterol 2006; BSG GERD Guidance 2019"
  });

  add({ cat:"Alarm Features", tag:"alarm", title:"Extra-Esophageal GERD — Beyond Heartburn",
    why:"GERD commonly presents with symptoms outside the esophagus. These are frequently misattributed to other conditions, leading to years of inappropriate treatment.",
    bullets:[
      "Laryngopharyngeal reflux (LPR): hoarseness, throat clearing, globus sensation (lump in throat), chronic cough, post-nasal drip sensation. LPR occurs with minimal heartburn in up to 50% of cases — often dismissed by ENT as 'vocal cord dysfunction' without considering reflux.",
      "Chronic cough: GERD is among the top 3 causes of chronic cough alongside post-nasal drip and asthma. Reflux cough may occur without heartburn. Mechanism: micro-aspiration triggering cough reflex, and/or vagal sensitization by esophageal acid.",
      "Dental erosion: chronic acid regurgitation causes characteristic erosion of dental enamel on the palatal surfaces of upper teeth. Dentists often identify this before gastroenterologists."
    ],
    action:"Log throat symptoms (throat clearing, globus) and cough using the Throat symptoms and Chronic cough fields. If these dominate over heartburn, raise laryngopharyngeal reflux specifically with your gastroenterologist — it often requires twice-daily PPI plus dietary modification.",
    evidence:"Vakil et al., Am J Gastroenterol 2006; Irwin et al., Chest 2006; Koufman, Laryngoscope 1991"
  });

  // INVESTIGATION
  add({ cat:"Investigation", tag:"invest", title:"Endoscopy in GERD — Indications and What It Shows",
    why:"Endoscopy is not required for uncomplicated GERD but becomes essential in specific circumstances that every GERD patient should understand.",
    bullets:[
      "Indications for endoscopy: alarm features (dysphagia, weight loss, hematemesis), age >60 with new onset GERD, symptoms refractory to PPI, screening for Barrett's in patients with chronic GERD (≥5 years) with additional risk factors (male sex, obesity, white ethnicity, smoking, family history of Barrett's or EAC).",
      "Los Angeles (LA) Classification of erosive esophagitis: Grade A (mucosal breaks <5mm), Grade B (breaks ≥5mm, not between folds), Grade C (extending between folds, <75% of circumference), Grade D (≥75% circumference). Grade C/D requires PPI until healed, repeat endoscopy at 8–12 weeks to confirm healing and exclude malignancy.",
      "Normal endoscopy does not exclude GERD: up to 70% of patients with typical GERD symptoms have non-erosive reflux disease (NERD) with normal endoscopy. Diagnosis requires 24h pH monitoring or pH-impedance testing."
    ],
    action:"Log your endoscopy findings and date in Notes or the Surveillance section. If LA Grade C or D esophagitis was found: confirm a repeat endoscopy at 8–12 weeks on PPI is scheduled — do not miss this follow-up.",
    evidence:"Armstrong et al., Can J Gastroenterol 2005; Vakil et al., Am J Gastroenterol 2006; ACG GERD Guidelines 2022"
  });

  add({ cat:"Investigation", tag:"invest", title:"24h pH-Impedance Testing — What It Tells You",
    why:"pH-impedance testing is the gold standard investigation for PPI-refractory symptoms, LPR, and confirming or refuting a GERD diagnosis.",
    bullets:[
      "What it measures: 24-hour ambulatory catheter measures both acid events (pH <4) AND non-acid reflux events (impedance detects liquid/gas movement regardless of pH). Correlates every reflux event with patient-reported symptoms via a symptom diary button.",
      "Done on PPI (for refractory symptoms): determines whether symptoms persist because of ongoing acid reflux despite PPI, non-acid reflux, or neither (functional heartburn — no correlation with any reflux events).",
      "Done off PPI (for diagnosis): establishes whether pathologic acid exposure exists. If negative off PPI in a patient with classic symptoms, consider functional heartburn or alternative diagnosis."
    ],
    action:"If you have undergone pH-impedance testing: log the result (DeMeester score, symptom-association probability) in Notes. This result determines whether PPI intensification, alginate, baclofen, or neuromodulator therapy is the appropriate next step.",
    evidence:"Pandolfino & Kahrilas, N Engl J Med 2006; Zerbib et al., Gut 2012; Gyawali et al., Neurogastroenterol Motil 2018"
  });

  // RED FLAGS
  add({ cat:"Red Flags", tag:"safety", title:"When GERD Needs Same-Day or Emergency Attention",
    why:"GERD is chronic and often managed long-term, but specific acute features require immediate escalation.",
    bullets:[
      "Emergency: hematemesis (vomiting blood — any amount), melena (black tarry stool indicating upper GI bleed), complete inability to swallow liquids, signs of perforation (severe chest pain with fever, mediastinal emphysema).",
      "Urgent (same day or next day): new progressive dysphagia, odynophagia with fever (infectious esophagitis), >5% weight loss in 3 months, new anemia on bloods.",
      "This month: any new alarm feature listed in the Alarm Features library. Worsening symptoms despite correct twice-daily PPI for 8+ weeks."
    ],
    action:"Hematemesis or complete dysphagia = emergency department immediately. New progressive dysphagia = same-day gastroenterology call. Discuss all alarm features with your gastroenterologist — endoscopy is typically needed before any treatment changes.",
    evidence:"NICE Guidelines 2014; BSG Guidance 2019; ACG GERD Guidelines 2022"
  });

  return { cards };
})();

const LIB_CATS = ["all", ...new Set(LIBRARY.cards.map(c => c.cat))];

// ── STATE ────────────────────────────────────────────────────────
const State = {
  store: null, premium: false,
  barrettsStatus: null, lastEndoscopy: null, nextEndoscopy: null,
  draft: defaultDraft(), lastEntry: null,
  libCat: "all", libQuery: ""
};

// ── HTML ─────────────────────────────────────────────────────────
function renderHTML() {
  document.getElementById("module-root").innerHTML = `
<div class="p-app">
  <header class="p-header">
    <div class="p-brand">
      <div class="p-logo-dot" aria-hidden="true"></div>
      <div>
        <h1 class="p-brand-name">GERD & Barrett's OS</h1>
        <div class="p-brand-sub">Symptom tracker</div>
      </div>
    </div>
    <div class="p-header-right">
      <div class="p-pill">🔥 <b id="kpiStreak">0</b>&nbsp;·&nbsp;7d <b id="kpi7d">0</b>&nbsp;·&nbsp;<b id="kpiTotal">0</b> total</div>
    </div>
  </header>

  <nav class="p-nav">
    <div class="p-tabs" role="tablist">
      <button class="p-tab" role="tab" id="tab-log"          aria-selected="true"  data-tab="log"          type="button">Log</button>
      <button class="p-tab" role="tab" id="tab-surveillance" aria-selected="false" data-tab="surveillance" type="button">Surveillance</button>
      <button class="p-tab" role="tab" id="tab-history"      aria-selected="false" data-tab="history"      type="button">History</button>
      <button class="p-tab" role="tab" id="tab-library"      aria-selected="false" data-tab="library"      type="button">Library</button>
      <button class="p-tab" role="tab" id="tab-insights"     aria-selected="false" data-tab="insights"     type="button">Insights</button>
    </div>
  </nav>

  <!-- LOG -->
  <section id="view-log">
    <div class="p-grid two">
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>How are you today?</h2><p>Takes about a minute</p></div>
          <div class="p-kpis"><div class="p-kpi">Date <b id="todayLabel"></b></div></div>
        </div>
        <div class="p-card-b">

          <!-- Step 1: Overall day -->
          <div id="stepQuality">
            <div class="p-labelrow"><div class="p-lbl">How was today overall?</div><div class="p-hint">required</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-quality="great" aria-pressed="false">Great</button>
              <button class="p-segBtn" type="button" data-quality="okay"  aria-pressed="false">Okay</button>
              <button class="p-segBtn" type="button" data-quality="rough" aria-pressed="false">Rough</button>
            </div>
          </div>

          <!-- Step 2: PPI taken -->
          <div id="stepPPI" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Did you take your PPI today?</div><div class="p-hint">timing matters</div></div>
            <div class="p-seg">
              <button class="p-segBtn" type="button" data-ppi="yes"     aria-pressed="false">✓ Taken</button>
              <button class="p-segBtn" type="button" data-ppi="late"    aria-pressed="false">Taken late</button>
              <button class="p-segBtn" type="button" data-ppi="skipped" aria-pressed="false">Skipped</button>
              <button class="p-segBtn" type="button" data-ppi="noppi"   aria-pressed="false">Not on PPI</button>
            </div>
            <div id="ppiHint" class="p-callout hidden" style="margin-top:8px;font-size:12px;"></div>
          </div>

          <!-- Step 3: Core symptoms -->
          <div id="stepSymptoms" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Any symptoms today?</div><div class="p-hint">tap to select</div></div>

            <div class="p-labelrow" style="margin-top:4px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Heartburn / chest burning</div><div class="p-hint" id="hbLabel">none</div></div>
            <div class="p-chips" data-symptom="heartburn">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Regurgitation / acid taste</div><div class="p-hint" id="regLabel">none</div></div>
            <div class="p-chips" data-symptom="regurg">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Sleep disruption from symptoms</div><div class="p-hint" id="slpLabel">none</div></div>
            <div class="p-chips" data-symptom="sleep">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe / woken</button>
            </div>

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Throat / LPR symptoms</div><div class="p-hint" id="thrLabel">none</div></div>
            <div class="p-chips" data-symptom="throat">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>

            <div class="p-labelrow" style="margin-top:12px;margin-bottom:6px;"><div class="p-lbl" style="font-size:11px;">Nausea</div><div class="p-hint" id="nauLabel">none</div></div>
            <div class="p-chips" data-symptom="nausea">
              <button class="p-chip" type="button" data-level="0" aria-pressed="true">None</button>
              <button class="p-chip" type="button" data-level="1" aria-pressed="false">Mild</button>
              <button class="p-chip" type="button" data-level="2" aria-pressed="false">Moderate</button>
              <button class="p-chip" type="button" data-level="3" aria-pressed="false">Severe</button>
            </div>
          </div>

          <!-- Step 4: Triggers -->
          <div id="stepTriggers" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">Any triggers today?</div><div class="p-hint">mark all that apply</div></div>
            <div class="p-chips">
              <button class="p-chip warn" type="button" data-flag="latemeal"     aria-pressed="false">Late meal</button>
              <button class="p-chip warn" type="button" data-flag="lyingdown"    aria-pressed="false">Lying flat after meal</button>
              <button class="p-chip warn" type="button" data-flag="fatty"        aria-pressed="false">High-fat meal</button>
              <button class="p-chip"      type="button" data-flag="spicy"        aria-pressed="false">Spicy food</button>
              <button class="p-chip"      type="button" data-flag="citrus"       aria-pressed="false">Citrus</button>
              <button class="p-chip warn" type="button" data-flag="coffee"       aria-pressed="false">Coffee</button>
              <button class="p-chip warn" type="button" data-flag="alcohol"      aria-pressed="false">Alcohol</button>
              <button class="p-chip"      type="button" data-flag="chocolate"    aria-pressed="false">Chocolate</button>
              <button class="p-chip"      type="button" data-flag="mint"         aria-pressed="false">Mint</button>
              <button class="p-chip"      type="button" data-flag="carbonated"   aria-pressed="false">Carbonated drinks</button>
              <button class="p-chip warn" type="button" data-flag="stress"       aria-pressed="false">Stress↑</button>
              <button class="p-chip"      type="button" data-flag="tightclothing" aria-pressed="false">Tight clothing</button>
              <button class="p-chip warn" type="button" data-flag="nsaids"       aria-pressed="false">NSAIDs</button>
            </div>

            <!-- Alarm features -->
            <div class="p-labelrow" style="margin-top:14px;margin-bottom:6px;">
              <div class="p-lbl" style="font-size:11px;color:var(--danger);">Alarm features</div>
              <div class="p-hint">urgent if new</div>
            </div>
            <div class="p-chips">
              <button class="p-chip danger" type="button" data-flag="dysphagia"          aria-pressed="false">Dysphagia</button>
              <button class="p-chip danger" type="button" data-flag="odynophagia"        aria-pressed="false">Painful swallowing</button>
              <button class="p-chip danger" type="button" data-flag="hematemesis"        aria-pressed="false">Hematemesis</button>
              <button class="p-chip danger" type="button" data-flag="melena"             aria-pressed="false">Melena</button>
              <button class="p-chip danger" type="button" data-flag="unintentionalwl"    aria-pressed="false">Weight loss</button>
              <button class="p-chip danger" type="button" data-flag="progressivevomiting" aria-pressed="false">Progressive vomiting</button>
            </div>

            <div id="alarmAlert" class="p-callout danger hidden" style="margin-top:10px;">
              <b>Alarm feature flagged.</b> Dysphagia, hematemesis, melena, or weight loss require urgent investigation — do not attribute to GERD without endoscopy. Contact your gastroenterologist today.
            </div>

            <div class="p-section">
              <div class="p-labelrow"><div class="p-lbl">Notes</div><div class="p-hint"><span id="noteCount">0</span>/600</div></div>
              <textarea id="notes" class="p-note" maxlength="600" placeholder="Meals, timing, specific foods, observations (optional)"></textarea>
            </div>
          </div>

          <!-- Actions -->
          <div id="stepActions" class="p-section hidden">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnSave" disabled>Done</button>
              <button class="p-btn" type="button" id="btnRepeat" disabled>Repeat last</button>
              <button class="p-btn ghost" type="button" id="btnReset">Reset</button>
            </div>
          </div>
        </div>
      </div>

      <!-- RIGHT -->
      <div class="p-card">
        <div class="p-card-h">
          <div><h2>Today's Guidance</h2><p>Personalized to what you logged</p></div>
          
        </div>
        <div class="p-card-b">
          <div id="guidance" class="p-callout">Complete the log steps. GERD-Q score and guidance will appear here.</div>
          <div id="inlineCard" class="p-section" style="display:none;"></div>

          <div id="scorePanel" class="p-section hidden">
            <div class="p-labelrow"><div class="p-lbl">GERD-Q Score</div><div class="p-hint">0–12 scale</div></div>
            <div class="p-scoreWrap">
              <div class="p-scoreBig" id="scoreBig">—</div>
              <div class="p-scoreSubLabel">GERD-Q Proxy</div>
            </div>
            <div id="scoreInterp" class="p-callout" style="margin-top:8px;"></div>
          </div>

          <!-- PPI adherence streak -->
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">PPI adherence</div><div class="p-hint">last 7 days</div></div>
            <div id="ppiAdherence" class="p-kpis"></div>
          </div>

          <div class="p-section">
            <div class="p-rowBtns">
              <button class="p-btn primary" type="button" id="btnReport">Clinician report</button>
              <button class="p-btn" type="button" id="btnExportCsv">Export CSV</button>
              <button class="p-btn" type="button" id="btnExportJson">Export JSON</button>
              <button class="p-btn" type="button" id="btnImport">Import</button>
              <input id="importFile" type="file" accept="application/json" class="sr">
            </div>
          </div>
          <div class="p-section">
            <div class="p-premRow" id="premiumCta" style="cursor:pointer;">
              <div class="p-premLabel" id="premStatusLabel">Unlock Premium — trend analytics · trigger correlation · next steps</div>
              <div style="font-family:var(--font-mono);font-size:10px;letter-spacing:.08em;color:#f5c842;">UPGRADE ✦</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- SURVEILLANCE -->
  <section id="view-surveillance" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Barrett's Surveillance</h2><p>Endoscopy intervals · BSG/ACG 2023 guidelines</p></div>
      </div>
      <div class="p-card-b">
        <div class="p-callout" style="margin-bottom:14px;">
          <b>Clinical basis:</b> Barrett's esophagus surveillance intervals are defined by segment length and dysplasia grade. Log your status below to calculate when your next endoscopy is due. PPI is lifelong in Barrett's regardless of symptoms.
        </div>

        <div class="p-labelrow"><div class="p-lbl">Barrett's status</div><div class="p-hint">from last endoscopy report</div></div>
        <div class="p-seg" id="barrettsSegs" style="flex-wrap:wrap;">
          ${Object.entries(SURVEILLANCE).map(([k,v]) =>
            `<button class="p-segBtn" type="button" data-barrett="${k}" aria-pressed="false" style="flex:1 1 140px;font-size:11px;">${v.label}</button>`
          ).join("")}
        </div>

        <div id="surveillanceResult" class="p-callout hidden" style="margin-top:14px;"></div>

        <div class="p-section">
          <div class="p-labelrow"><div class="p-lbl">Last endoscopy</div></div>
          <div class="p-calpRow">
            <div class="p-calpField"><label>Date</label><input type="date" id="lastScopeDate"></div>
            <div class="p-calpField"><label>Finding / grade</label><input type="text" id="lastScopeFinding" placeholder="e.g. C2M4, LGD, post-RFA" style="width:100%;height:44px;border-radius:10px;border:1px solid var(--line);background:rgba(231,237,245,.03);color:var(--ink);padding:0 12px;outline:none;font-size:13px;"></div>
          </div>
          <div class="p-rowBtns"><button class="p-btn primary" type="button" id="btnSaveScope">Save scope record</button></div>
        </div>

        <div class="p-section" id="scopeHistory">
          <div class="p-labelrow"><div class="p-lbl">Scope history</div></div>
          <div class="p-list" id="scopeList"></div>
        </div>
      </div>
    </div>
  </section>

  <!-- HISTORY -->
  <section id="view-history" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>History</h2><p>Most recent first</p></div>
        <div class="p-rowBtns" style="margin:0;">
          <button class="p-btn" type="button" id="btnExportCsv2">Export CSV</button>
          <button class="p-btn" type="button" id="btnExportJson2">Export JSON</button>
        </div>
      </div>
      <div class="p-card-b"><div class="p-list" id="histList"></div></div>
    </div>
  </section>

  <!-- LIBRARY -->
  <section id="view-library" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Clinical Library</h2><p>PPI therapy · Barrett's · lifestyle · alarm features · investigation</p></div>
        <div style="display:flex;gap:10px;align-items:center;">
          <div class="p-kpis"><div class="p-kpi">Cards <b id="kpiCards">0</b></div></div>
          <input id="libSearch" type="search" class="p-search" placeholder="Search PPI, Barrett's, alarm…">
        </div>
      </div>
      <div class="p-card-b">
        <div class="p-libCats" id="libCats"></div>
        <div class="p-libGrid" id="libGrid"></div>
      </div>
    </div>
  </section>

  <!-- INSIGHTS -->
  <section id="view-insights" class="hidden">
    <div class="p-card">
      <div class="p-card-h">
        <div><h2>Insights</h2><p>Free: symptom summary · Premium: trends + trigger correlation + adherence analysis</p></div>
        <button class="p-btn" type="button" id="btnRefresh" style="margin:0;">Refresh</button>
      </div>
      <div class="p-card-b">
        <div id="insightsBody" class="p-callout">Log at least 5 entries to unlock insights.</div>
        <div class="p-section">
          <div class="p-chartWrap"><canvas id="chartSymptoms" height="200"></canvas><div class="p-chartMeta">Daily heartburn severity (last 28 days)</div></div>
        </div>
        <div id="premiumPanel" class="p-section hidden">
          <div class="p-grid two">
            <div class="p-chartWrap"><canvas id="chartGERDQ" height="200"></canvas><div class="p-chartMeta">GERD-Q score trend (last 30 entries)</div></div>
            <div class="p-chartWrap"><canvas id="chartAdherence" height="200"></canvas><div class="p-chartMeta">PPI adherence (last 30 entries)</div></div>
          </div>
          <div class="p-section p-grid two">
            <div class="p-callout" id="triggerBox"></div>
            <div class="p-callout" id="adherenceBox"></div>
          </div>
          <div class="p-section">
            <div class="p-labelrow"><div class="p-lbl">Ranked next steps</div></div>
            <div class="p-list" id="nextStepsList"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>`;
}

// ── LOGIC ────────────────────────────────────────────────────────
function updateProgress() {
  const d = State.draft;
  const hasQ   = !!d.quality;
  const hasPPI = d.ppiTaken !== null;

  $("#stepPPI")?.classList.toggle("hidden", !hasQ);
  $("#stepSymptoms")?.classList.toggle("hidden", !(hasQ && hasPPI));
  $("#stepTriggers")?.classList.toggle("hidden", !(hasQ && hasPPI));
  $("#stepActions")?.classList.toggle("hidden", !(hasQ && hasPPI));

  // INVARIANT: red flags always visible — never gated on premium. MDR compliance.
  const hasAlarm = ALARM_FLAGS.some(k => d.flags?.[k]);
  $("#alarmAlert")?.classList.toggle("hidden", !hasAlarm);

  const canSave = hasQ && hasPPI;
  const btnSave = $("#btnSave"); if (btnSave) btnSave.disabled = !canSave;
  const btnRepeat = $("#btnRepeat"); if (btnRepeat) btnRepeat.disabled = !State.lastEntry;

  updateGuidance(d);
}


function renderInlineCard(cardTitle) {
  const container = document.getElementById("inlineCard");
  if (!container) return;

  const card = LIBRARY.cards.find(c => c.title === cardTitle);
  if (!card) { container.style.display = "none"; return; }

  container.style.display = "block";
  const safeTitle = card.title.split("—")[0].trim().replace(/'/g, "\'");

  const bulletsHTML = (card.bullets || []).map(b =>
    `<li style="font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:6px;">${b}</li>`
  ).join("");

  const moreHTML = card.more
    ? `<div style="font-size:12px;color:var(--muted2);line-height:1.5;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);">${card.more}</div>`
    : "";

  const evidenceHTML = card.evidence
    ? `<div style="font-size:11px;color:var(--muted2);font-family:var(--font-mono);margin-top:8px;line-height:1.5;">${card.evidence}</div>`
    : "";

  container.innerHTML = `
    <div style="border-left:3px solid var(--accent);padding-left:14px;margin-top:8px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px;">Your doctor says</div>
      <div style="font-size:15px;font-weight:600;color:var(--fg);margin-bottom:8px;">${card.title}</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;margin-bottom:10px;">${card.why}</div>
      ${bulletsHTML ? `<ul style="margin:0 0 10px 0;padding-left:16px;">${bulletsHTML}</ul>` : ""}
      ${card.action ? `
        <div style="padding:12px 14px;background:var(--surface2);border-radius:10px;margin-bottom:10px;">
          <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">What to do</div>
          <div style="font-size:13px;color:var(--fg);line-height:1.6;">${card.action}</div>
        </div>` : ""}
      ${moreHTML}
      ${evidenceHTML}
      <button type="button"
        style="font-size:12px;color:var(--accent);background:none;border:none;padding:4px 0 0 0;cursor:pointer;text-decoration:underline;display:block;margin-top:6px;"
        onclick="(function(){document.getElementById('tab-library')?.click();var s=document.getElementById('libSearch');if(s){s.value='${safeTitle}';s.dispatchEvent(new Event('input'));}})()">
        Browse all library cards →
      </button>
    </div>
  `;
}


function pickInlineCard(d) {
  if (d.ppiTaken === "skipped" || d.ppiTaken === "late") return "Dietary Triggers and Mucosal Protection in GERD";
  if (d.heartburn >= 2) return "When Your PPI Isn't Working — What's Actually Going On";
  if (d.flags?.lyingdown) return "Dietary Triggers and Mucosal Protection in GERD";
  if (d.sleep >= 2) return "Dietary Triggers and Mucosal Protection in GERD";
  return "Barrett's Esophagus — What It Is and What It Actually Means for You";
}
function updateGuidance(d) {
  const g = $("#guidance"), sp = $("#scorePanel");
  if (!g) return;

  if (!d.quality || d.ppiTaken === null) {
    g.innerHTML = "Complete the log steps. Your GERD-Q score and personalized guidance will appear here.";
    sp?.classList.add("hidden"); return;
  }

  // Premium gate — guidance is gated after 14-day trial
  if (!PremiumGate.isPremium()) {
    PremiumGate.showGuidanceGate(g, MODULE_KEY, () => updateGuidance(d));
    sp?.classList.add("hidden");
    return;
  }


  const score = calcGERDQ(d);
  const interp = interpGERDQ(score);

  let assessment = "";
  if (d.ppiTaken === "skipped") assessment = `Your log records a missed PPI dose today. PPI effectiveness depends on consistent daily dosing — a single missed dose significantly reduces acid suppression for that 24-hour period.`;
  else if (d.ppiTaken === "late") assessment = `Your log shows a late PPI dose today. Timing matters as much as taking it — PPIs must be taken 30–60 minutes before your first meal to reach peak effectiveness. Taking it at the same time as breakfast can halve its efficacy.`;
  else if (d.heartburn >= 2) assessment = `Your log shows significant heartburn despite PPI. Persistent symptoms on a correctly-timed PPI may indicate non-acid reflux — bile or gas rather than stomach acid — or a functional component. This pattern over multiple entries is worth raising with your gastroenterologist.`;
  else if (d.sleep >= 2) assessment = `Your log shows significant nocturnal symptoms today. Nighttime reflux is a distinct clinical pattern — it occurs when lying flat allows acid to pool in the esophagus regardless of PPI timing, and it has specific management options.`;
  else if (d.quality === "great") assessment = `Your log shows a well-controlled day — symptoms minimal, PPI taken correctly. Note what contributed: meal timing, portion size, stress level, sleep position. Good days are as useful as bad ones.`;
  else assessment = `Your log shows a moderate GERD day. Tracking which triggers correlate with worse days is the most useful thing you can do right now.`;

  let plan = "";
  if (d.ppiTaken === "skipped" || d.ppiTaken === "late") {
    plan = `Set a daily alarm for your PPI — 30 minutes before breakfast, every day. This single habit change is the most common driver of GERD-Q improvement. If you're on once-daily PPI with persistent symptoms, discuss twice-daily dosing with your gastroenterologist — morning and evening before meals — rather than simply increasing dose.`;
  } else if (d.heartburn >= 2) {
    plan = `If heartburn persists despite correctly-timed PPI, consider that nearly half of PPI non-responders have non-acid reflux. A pH-impedance study can distinguish acid from non-acid reflux and is the appropriate next investigation. In the meantime: avoid lying down within 3 hours of eating, elevate the head of your bed 6–8 inches (a wedge pillow is more effective than extra pillows), and trial eliminating coffee, alcohol, and large evening meals for 2 weeks. Discuss this with your gastroenterologist.`;
  } else if (d.sleep >= 2) {
    plan = `For nocturnal symptoms specifically: left lateral sleeping position significantly reduces reflux compared to right-side or lying on your back. Head-of-bed elevation has randomised trial evidence. Last meal should be at least 3 hours before lying down. Alginate preparations like Gaviscon Advance taken at bedtime form a raft on top of stomach contents and are effective for nocturnal breakthrough — they work differently from PPIs and the two can be combined.`;
  } else if (d.flags?.lyingdown) {
    plan = `Lying down after eating is one of the strongest acute GERD triggers — gravity is a major component of the lower esophageal sphincter's barrier function. Wait at least 2–3 hours after any meal before lying down. If this is a consistent pattern, an evening PPI dose before dinner may be worth discussing with your gastroenterologist.`;
  } else {
    plan = `Continue logging triggers consistently. The most actionable data comes from identifying which specific factors correlate with worse days. Bring your Clinician Report to your next appointment — GERD-Q trend over time is more informative than a single clinic visit assessment.`;
  }

  g.innerHTML = `
    <div style="margin-bottom:12px;">
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Assessment</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${assessment}</div>
    </div>
    <div>
      <div style="font-size:11px;color:var(--accent);font-family:var(--font-mono);letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px;">Plan</div>
      <div style="font-size:13px;color:var(--fg);line-height:1.6;">${plan}</div>
    </div>
    <div style="font-size:11px;color:var(--muted2);margin-top:10px;border-top:1px solid var(--border);padding-top:8px;">This is patient education based on your logged data — not a medical diagnosis. Discuss any changes to your treatment with your gastroenterologist.</div>
  `;

  if (sp) {
    sp.classList.remove("hidden");
    const big = $("#scoreBig");
    if (big) { big.textContent = score; big.style.color = interp.color; }
    const si = $("#scoreInterp");
    if (si) {
      si.className = "p-callout " + (interp.cls || "");
      const tips = {
        ok:     "Symptoms well controlled. Maintain PPI timing and lifestyle measures.",
        warn:   "Partial control. Review PPI timing, consider twice-daily, and log triggers.",
        danger: "Poor control. Discuss with gastroenterologist — pH-impedance testing may be indicated."
      };
      si.innerHTML = `<b>${interp.label}:</b> ${tips[interp.cls] || ""}`;
    }
  }
}

function setPPIUI(val) {
  State.draft.ppiTaken = val;
  State.draft.flags.skippedppi = val === "skipped";
  $$("[data-ppi]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.ppi === val)));
  const hint = $("#ppiHint");
  if (hint) {
    const msgs = {
      yes:     null,
      late:    "PPI taken after eating has significantly reduced efficacy — pumps activate with the meal stimulus before PPI arrives.",
      skipped: "Skipped PPI: gastric acid production will be significantly elevated today. Avoid trigger foods especially.",
      noppi:   "Not on PPI: if you have confirmed GERD or Barrett's, discuss PPI initiation with your gastroenterologist."
    };
    if (msgs[val]) { hint.textContent = msgs[val]; hint.className = "p-callout " + (val === "skipped" ? "warn" : ""); hint.classList.remove("hidden"); }
    else hint.classList.add("hidden");
  }
  updateProgress();
  setTimeout(() => Util.scroll($("#stepSymptoms")), 80);
}

function resetDraft() {
  State.draft = defaultDraft();
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$("[data-ppi]").forEach(b => b.setAttribute("aria-pressed","false"));
  $$("[data-symptom] .p-chip").forEach(c => c.setAttribute("aria-pressed", String(c.dataset.level === "0")));
  $$(".p-chip[data-flag]").forEach(c => c.setAttribute("aria-pressed","false"));
  const notes = $("#notes"); if (notes) notes.value = "";
  const nc = $("#noteCount"); if (nc) nc.textContent = "0";
  const hi = $("#ppiHint"); if (hi) hi.classList.add("hidden");
  ["hbLabel","regLabel","slpLabel","thrLabel","nauLabel"].forEach(id => {
    const el = $(`#${id}`); if (el) el.textContent = "none";
  });
  updateProgress();
}

async function save() {
  try {
    if ($("#btnSave")) $("#btnSave").disabled = true;
    const d = State.draft;
    const gerdq = calcGERDQ(d);
    const entry = {
      ts: Util.nowISO(), dateKey: Util.dateKeyLocal(),
      quality: d.quality, ppiTaken: d.ppiTaken,
      heartburn: Util.clamp(d.heartburn,0,3), regurg: Util.clamp(d.regurg,0,3),
      sleep: Util.clamp(d.sleep,0,3), throat: Util.clamp(d.throat,0,3),
      nausea: Util.clamp(d.nausea,0,3),
      gerdq, flags: {...d.flags},
      notes: (d.notes||"").slice(0,600), deleted: 0
    };
    const last = State.lastEntry;
    if (last) {
      const dt = Math.abs(+new Date(entry.ts) - +new Date(last.ts));
      if (dt < 90000 && entry.quality === last.quality && entry.heartburn === last.heartburn) {
        Util.toast("Duplicate entry blocked"); return;
      }
    }
    const saved = await Perf.time("entry-save", async () => { await State.store.addEntry(entry); });
    State.lastEntry = saved;
    Util.toast("Entry saved");
  // First-time upgrade nudge at 14 entries
  const allEntries = await State.store.getEntriesAll();
  if (allEntries.length === 14 && !PremiumGate.isPremium()) {
    setTimeout(() => PremiumGate.showPaywall(MODULE_KEY, () => {
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      Util.toast("Premium unlocked ✦");
    }), 1200);
  }
    resetDraft();
    await refreshKPIs();
    await renderPPIAdherence();
  } catch(err) { console.error(err); Util.toast("Save failed"); }
  finally { updateProgress(); }
}

async function repeatLast() {
  const last = State.lastEntry || await State.store.getLastEntry();
  if (!last) return;
  State.lastEntry = last;
  const d = State.draft;
  d.quality = last.quality; d.ppiTaken = last.ppiTaken;
  d.heartburn = last.heartburn||0; d.regurg = last.regurg||0;
  d.sleep = last.sleep||0; d.throat = last.throat||0; d.nausea = last.nausea||0;
  d.flags = {...defaultFlags(), ...(last.flags||{})};
  d.notes = last.notes||"";
  $$("[data-quality]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.quality === d.quality)));
  if (d.ppiTaken) setPPIUI(d.ppiTaken);
  const syncSym = (sym, val) => {
    const w = $(`.p-chips[data-symptom="${sym}"]`);
    if (w) w.querySelectorAll(".p-chip").forEach(c => c.setAttribute("aria-pressed", String(Number(c.dataset.level) === val)));
  };
  ["heartburn","regurg","sleep","throat","nausea"].forEach(s => syncSym(s, d[s]));
  $$(".p-chip[data-flag]").forEach(c => c.setAttribute("aria-pressed", String(!!d.flags[c.dataset.flag])));
  const notes = $("#notes"); if (notes) { notes.value = d.notes; const nc = $("#noteCount"); if (nc) nc.textContent = String(d.notes.length); }
  updateProgress();
  Util.toast("Repeated last entry");
}

async function refreshKPIs() {
  const kpis = await KPI.compute(State.store);
  const el = (id,v) => { const e = $(id); if (e) e.textContent = String(v); };
  el("#kpiTotal", kpis.total); el("#kpi7d", kpis.last7days); el("#kpiStreak", kpis.streak);
}

async function renderPPIAdherence() {
  const el = $("#ppiAdherence"); if (!el) return;
  const all = (await State.store.getEntriesAll()).sort((a,b) => b.ts.localeCompare(a.ts)).slice(0,7);
  if (!all.length) { el.innerHTML = `<div class="p-kpi">No data yet</div>`; return; }
  const taken = all.filter(e => e.ppiTaken === "yes").length;
  const pct = Math.round((taken / all.length) * 100);
  const cls = pct >= 90 ? "ok" : pct >= 70 ? "warn" : "danger";
  el.innerHTML = `<div class="p-kpi">Adherence <b style="color:var(--${cls})">${pct}%</b></div>
    <div class="p-kpi">On time <b>${taken}/${all.length}</b> days</div>`;
}

async function renderHistory() {
  const list = $("#histList"); if (!list) return;
  const all = (await State.store.getEntriesAll()).sort((a,b) => b.ts.localeCompare(a.ts));
  if (!all.length) { list.innerHTML = `<div class="p-callout">No entries yet.</div>`; return; }
  list.innerHTML = all.slice(0,80).map(e => {
    const interp = interpGERDQ(e.gerdq||0);
    const triggers = FLAG_KEYS.filter(k => e.flags?.[k]).slice(0,4);
    const alarms = ALARM_FLAGS.filter(k => e.flags?.[k]);
    return `<div class="p-item">
      <div class="p-itemTop">
        <div class="ts">${Util.esc(e.dateKey)}</div>
        <div class="q">${Util.esc(e.quality||"")} · PPI: ${Util.esc(e.ppiTaken||"—")} · HB: ${Util.esc(Util.levelToText(e.heartburn))} · Regurg: ${Util.esc(Util.levelToText(e.regurg))}</div>
      </div>
      <div class="p-itemBody">Sleep: <b>${Util.esc(Util.levelToText(e.sleep))}</b> · Throat: <b>${Util.esc(Util.levelToText(e.throat))}</b> · GERD-Q: <b style="color:${Util.cssVal(interp.color)}">${Util.esc(String(e.gerdq||0))} (${Util.esc(interp.label)})</b></div>
      ${alarms.length ? `<div class="p-itemBody" style="color:var(--danger);margin-top:4px;font-family:var(--font-mono);font-size:11px;">⚠ ${Util.esc(alarms.join(", "))}</div>` : ""}
      ${triggers.length ? `<div class="p-itemBody" style="margin-top:4px;font-family:var(--font-mono);font-size:11px;color:var(--muted2);">${Util.esc(triggers.join(", "))}</div>` : ""}
      ${e.notes ? `<div class="p-itemBody" style="margin-top:4px;">${Util.esc(e.notes)}</div>` : ""}
    </div>`;
  }).join("");
}

async function renderSurveillance() {
  const scopes = await State.store.getSetting("scopes", []);
  const list = $("#scopeList"); if (!list) return;
  if (!scopes.length) { list.innerHTML = `<div class="p-callout">No endoscopy records yet.</div>`; return; }
  list.innerHTML = [...scopes].reverse().map(s =>
    `<div class="p-item">
      <div class="p-itemTop"><div class="ts">${Util.esc(s.date)}</div></div>
      <div class="p-itemBody"><b>${Util.esc(s.finding||"—")}</b></div>
    </div>`
  ).join("");
}

async function renderInsights() {
  const all = (await State.store.getEntriesAll()).sort((a,b) => a.ts.localeCompare(b.ts));
  const body = $("#insightsBody");
  if (all.length < 5) { if (body) body.textContent = `Log at least 5 entries. (${all.length} so far)`; return; }
  if (body) body.innerHTML = `<b>${all.length}</b> total entries logged.`;

  // Free chart: heartburn last 28 days
  const cut28 = new Date(); cut28.setDate(cut28.getDate()-27); cut28.setHours(0,0,0,0);
  const last28 = all.filter(e => new Date(e.ts) >= cut28);
  const days = Array.from({length:28},(_,i) => { const d=new Date(); d.setDate(d.getDate()-27+i); return Util.dateKeyLocal(d.toISOString()); });
  const hbByDay = days.map(dk => { const e = last28.find(x=>x.dateKey===dk); return e ? (e.heartburn||0) : 0; });
  const sc = $("#chartSymptoms");
  if (sc) Charts.drawLine(sc, hbByDay, { maxV:3, lc:"rgba(201,125,212,.8)", dc:"rgba(201,125,212,.9)" });

  if (!PremiumGate.isPremium()) {
    const pp = $("#premiumPanel"); pp?.classList.add("hidden");
    // Show inline paywall nudge
    const body = $("#insightsBody");
    if (body && !body.querySelector(".pw-inline-nudge")) {
      const nudge = document.createElement("div");
      nudge.className = "pw-inline-nudge p-callout";
      nudge.style.cssText = "margin-top:12px;cursor:pointer;border-color:rgba(245,200,66,.25);background:rgba(245,200,66,.04);";
      nudge.innerHTML = `<b style="color:#f5c842;">✦ Unlock Premium to see your full Insights</b><br><span style="font-size:var(--font-size-sm);color:var(--muted);">Trend charts · trigger correlation · next steps · what's driving your symptoms</span><br><span style="display:inline-block;margin-top:8px;font-size:var(--font-size-sm);font-family:var(--font-mono);color:#f5c842;">Tap to upgrade →</span>`;
      nudge.addEventListener("click", () => PremiumGate.showPaywall(MODULE_KEY, () => { nudge.remove(); renderInsights(); }));
      body.appendChild(nudge);
    }
    return;
  }
  const pp = $("#premiumPanel"); pp?.classList.remove("hidden");
  const last30 = all.slice(-30);

  const gerdqVals = last30.map(e => e.gerdq||0);
  const gc = $("#chartGERDQ"); if (gc) Charts.drawLine(gc, gerdqVals, { maxV:12 });

  const ppiVals = last30.map(e => e.ppiTaken === "yes" ? 1 : 0);
  const ac = $("#chartAdherence");
  if (ac) Charts.drawBars(ac, last30.map((_,i)=>String(i+1)), ppiVals, { c1:"rgba(126,203,161,.75)", c2:"rgba(126,203,161,.45)" });

  // Trigger analysis
  const tb = $("#triggerBox");
  if (tb) {
    const cnt = {}; FLAG_KEYS.forEach(k=>cnt[k]=0);
    last30.forEach(e => FLAG_KEYS.forEach(k => { if (e.flags?.[k]) cnt[k]++; }));
    const top = Object.entries(cnt).sort((a,b)=>b[1]-a[1]).filter(([,v])=>v>0).slice(0,3);
    tb.className = "p-callout";
    tb.innerHTML = top.length
      ? `<b>Top triggers (30 days):</b><br>${top.map(([k,v]) => `${Util.esc(k)}: ${v} days`).join("<br>")}`
      : "No consistent triggers flagged. Continue logging.";
  }

  // Adherence analysis
  const ab = $("#adherenceBox");
  if (ab) {
    const taken = last30.filter(e => e.ppiTaken === "yes").length;
    const pct = Math.round((taken/last30.length)*100);
    const skipped = last30.filter(e => e.ppiTaken === "skipped").length;
    const cls = pct >= 90 ? "ok" : pct >= 70 ? "warn" : "danger";
    ab.className = "p-callout " + cls;
    ab.innerHTML = `<b>PPI adherence:</b> ${pct}% (${taken}/${last30.length} days). Skipped: ${skipped} days. ${pct < 80 ? "Poor adherence is the most common cause of persistent GERD symptoms." : pct >= 90 ? "Excellent adherence." : "Moderate adherence — aim for >90%."}`;
  }

  // Next steps
  const ns = $("#nextStepsList");
  if (ns) {
    const steps = [];
    const alarmDay = all.slice(-14).find(e => ALARM_FLAGS.some(k => e.flags?.[k]));
    if (alarmDay) steps.push({ p:"danger", t:"Alarm feature logged in past 14 days. This requires urgent gastroenterology evaluation if not already arranged." });
    const pct = Math.round((last30.filter(e=>e.ppiTaken==="yes").length/last30.length)*100);
    if (pct < 80) steps.push({ p:"warn", t:`PPI adherence ${pct}% in 30 days. Poor adherence is the most modifiable cause of persistent symptoms and mucosal damage. Set a daily alarm.` });
    const nightScore = Stats.mean(last30.map(e=>e.sleep||0));
    if (nightScore >= 1.5) steps.push({ p:"warn", t:"Consistent nocturnal symptoms. Discuss head of bed elevation and left lateral sleeping position — both have RCT evidence. Ensure no food intake within 3 hours of lying down." });
    const latemeal = last30.filter(e=>e.flags?.latemeal).length;
    if (latemeal >= 10) steps.push({ p:"warn", t:`Late meals flagged ${latemeal}/30 days. This is among the strongest modifiable GERD triggers. Target a 7pm meal cutoff.` });
    if (!steps.length) steps.push({ p:"ok", t:"No high-priority signals. Continue consistent logging and PPI adherence." });
    const colors = { danger:"var(--danger)", warn:"var(--warn)", ok:"var(--ok)" };
    ns.innerHTML = steps.map(s => `<div class="p-item"><div class="p-itemBody"><b style="color:${colors[s.p]}">${s.p.toUpperCase()}:</b> ${Util.esc(s.t)}</div></div>`).join("");
  }
}

function showTab(tab) {
  ["log","surveillance","history","library","insights"].forEach(t => {
    $("#tab-"+t)?.setAttribute("aria-selected", String(t === tab));
    $("#view-"+t)?.classList.toggle("hidden", t !== tab);
  });
  if (tab === "history") renderHistory();
  if (tab === "surveillance") renderSurveillance();
  if (tab === "library") {
    LibRenderer.renderCats($("#libCats"), LIB_CATS, State.libCat, cat => { State.libCat = cat; renderLibrary(); });
    renderLibrary();
  }
  if (tab === "insights") renderInsights();
}

function renderLibrary() {
  const grid = $("#libGrid"); if (!grid) return;
  const kpi = $("#kpiCards"); if (kpi) kpi.textContent = String(LIBRARY.cards.length);
  LibRenderer.render(grid, LibRenderer.filterCards(LIBRARY.cards, State.libCat, State.libQuery));
}

// ── EVENTS ───────────────────────────────────────────────────────
function wireEvents() {
  $$(".p-tab").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));

  $$("[data-quality]").forEach(b => b.addEventListener("click", () => {
    State.draft.quality = b.dataset.quality;
    $$("[data-quality]").forEach(x => x.setAttribute("aria-pressed", String(x === b)));
    updateProgress();
    setTimeout(() => Util.scroll($("#stepPPI")), 80);
  }));

  $$("[data-ppi]").forEach(b => b.addEventListener("click", () => setPPIUI(b.dataset.ppi)));

  $$("[data-symptom]").forEach(wrap => wrap.addEventListener("click", e => {
    const btn = e.target.closest(".p-chip"); if (!btn) return;
    const sym = wrap.dataset.symptom, level = Number(btn.dataset.level);
    State.draft[sym] = Util.clamp(level, 0, 3);
    wrap.querySelectorAll(".p-chip").forEach(c => c.setAttribute("aria-pressed", String(c === btn)));
    const labelMap = { heartburn:"hbLabel", regurg:"regLabel", sleep:"slpLabel", throat:"thrLabel", nausea:"nauLabel" };
    const lel = labelMap[sym] ? $(`#${labelMap[sym]}`) : null;
    if (lel) lel.textContent = Util.levelToText(level);
    updateProgress();
  }));

  $$(".p-chip[data-flag]").forEach(b => b.addEventListener("click", () => {
    const k = b.dataset.flag;
    State.draft.flags[k] = !State.draft.flags[k];
    b.setAttribute("aria-pressed", String(State.draft.flags[k]));
    updateProgress();
  }));

  const notes = $("#notes");
  if (notes) notes.addEventListener("input", () => {
    State.draft.notes = notes.value;
    const nc = $("#noteCount"); if (nc) nc.textContent = String(notes.value.length);
  });

  $("#btnSave")?.addEventListener("click", save);
  $("#btnRepeat")?.addEventListener("click", repeatLast);
  $("#btnReset")?.addEventListener("click", resetDraft);

  const doCSV = () => IO.exportCSV(State.store, MODULE_KEY, [...FLAG_KEYS,...ALARM_FLAGS]);
  const doJSON = () => IO.exportJSON(State.store, MODULE_KEY);
  // INVARIANT: clinician report is always free — do not gate on PremiumGate.isPremium()
  $("#btnReport")?.addEventListener("click", () => Report.generate(MODULE_KEY));
  ["#btnExportCsv","#btnExportCsv2"].forEach(s => $(s)?.addEventListener("click", doCSV));
  ["#btnExportJson","#btnExportJson2"].forEach(s => $(s)?.addEventListener("click", doJSON));
  const btnImport = $("#btnImport"), importFile = $("#importFile");
  if (btnImport && importFile) {
    btnImport.addEventListener("click", () => importFile.click());
    importFile.addEventListener("change", async e => {
      const f = e.target.files?.[0]; if (!f) return;
      await IO.importJSON(f, State.store, [...FLAG_KEYS,...ALARM_FLAGS], async () => { await refreshKPIs(); await renderHistory(); });
      e.target.value = "";
    });
  }

  // Barrett's surveillance
  $$("[data-barrett]").forEach(b => b.addEventListener("click", () => {
    const k = b.dataset.barrett;
    State.barrettsStatus = k;
    $$("[data-barrett]").forEach(x => x.setAttribute("aria-pressed", String(x === b)));
    const res = $("#surveillanceResult");
    if (res) {
      const sv = SURVEILLANCE[k];
      res.className = "p-callout" + (k === "hgg" ? " danger" : k === "lgg" ? " warn" : "");
      res.innerHTML = `<b>${Util.esc(sv.label)}:</b> ${Util.esc(sv.interval)}`;
      res.classList.remove("hidden");
    }
    State.store.setSetting("barrettsStatus", k);
  }));

  $("#btnSaveScope")?.addEventListener("click", async () => {
    const date = $("#lastScopeDate")?.value;
    const finding = $("#lastScopeFinding")?.value;
    if (!date) { Util.toast("Enter scope date"); return; }
    const scopes = await State.store.getSetting("scopes", []);
    scopes.push({ date, finding: finding||"" });
    await State.store.setSetting("scopes", scopes);
    Util.toast("Scope record saved");
    if ($("#lastScopeDate")) $("#lastScopeDate").value = "";
    if ($("#lastScopeFinding")) $("#lastScopeFinding").value = "";
    await renderSurveillance();
  });

  $("#libSearch")?.addEventListener("input", e => { State.libQuery = e.target.value||""; renderLibrary(); });
  $("#btnRefresh")?.addEventListener("click", renderInsights);

  // Premium CTA
  $("#premiumCta")?.addEventListener("click", () => {
    PremiumGate.showPaywall(MODULE_KEY, () => {
      const sl = $("#premStatusLabel");
      if (sl) sl.textContent = "✦ Premium active";
      PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

      renderInsights?.();
      Util.toast("Premium unlocked ✦");
    });
  });
}

// ── BOOT ─────────────────────────────────────────────────────────
async function boot() {
  renderHTML();
  const todayEl = $("#todayLabel"); if (todayEl) todayEl.textContent = Util.dateKeyLocal();

  const { store, mode } = await initStorage(MODULE_KEY);
  State.store = store;
  updateStorageModeUI(mode);
  if (typeof GIOSNotifications !== "undefined") GIOSNotifications.init("gerd", "GERD OS");

  // Premium state managed by PremiumGate (localStorage)

  const savedBarretts = await store.getSetting("barrettsStatus", null);
  if (savedBarretts) {
    State.barrettsStatus = savedBarretts;
    $$("[data-barrett]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.barrett === savedBarretts)));
    const res = $("#surveillanceResult");
    if (res && SURVEILLANCE[savedBarretts]) {
      const sv = SURVEILLANCE[savedBarretts];
      res.className = "p-callout" + (savedBarretts === "hgg" ? " danger" : savedBarretts === "lgg" ? " warn" : "");
      res.innerHTML = `<b>${Util.esc(sv.label)}:</b> ${Util.esc(sv.interval)}`;
      res.classList.remove("hidden");
    }
  }

  State.lastEntry = await store.getLastEntry();
  
  // Apply progressive disclosure state
  const allForDisclosure = await store.getEntriesAll();
  const hasAlarm = allForDisclosure.slice(-7).some(e => 
    e.flags && Object.values(e.flags).some(v => v === true)
  );
  const disclosureState = Disclosure.getState(allForDisclosure.length, hasAlarm);
  Disclosure.applyToDOM(disclosureState, MODULE_KEY);
  // Show onboarding on first run
  setTimeout(() => Onboarding.show(MODULE_KEY, store), 400);

  // Update premium CTA label based on current gate state
  const { state, trialDaysLeft } = PremiumGate.getState();
  const sl = $("#premStatusLabel");
  if (sl) {
    if (state === "active") sl.textContent = "✦ Premium active";
    else if (state === "trial") sl.textContent = `✦ Trial active · ${trialDaysLeft}d remaining`;
    else sl.textContent = "Unlock Premium — trend analytics · trigger correlation · next steps";
  }
  PremiumGate.renderBadge(document.querySelector(".p-header-right"));
  // Verify subscription status with RevenueCat (non-blocking)
  PremiumGate.checkOnBoot();
  // Check storage quota — warns user if approaching limit
  Platform.checkStorageQuota();

  wireEvents();
  resetDraft();
  await refreshKPIs();
  await renderPPIAdherence();

  LibRenderer.renderCats($("#libCats"), LIB_CATS, State.libCat, cat => { State.libCat = cat; renderLibrary(); });
  renderLibrary();

  Util.toast("GERD & Barrett's OS ready");
}

boot();
})();
